"""All-period exclusion of both lower fat (1,2,3) bands with omega_3=0, (j,k,l)=(1,0,2).

Drift (1,-3), lower-cap coordinates t=3x+y. The first five stable rows are

    0: WR
    1: NR,SL
    2: WR,WL,WR
    3: SR,SL,NR,SL,NR,SL
    4: WR,WL,ER,EL,WR,WL,WR,WL,[WR]^b          b = omega_4 in {0,1}.

For each b, every later row is enumerated exhaustively from the flow and excess
equations and right/left alternation. A word is discarded only for one of:

  * a zero-displacement return through already built rows that forces the next
    stable event and is violated (applied while the word is being built);
  * a witnessed finite same-cell first return to an event other than the next
    stable visit (the walk is followed only through built rows and is not
    extrapolated around a quotient cycle);
  * infeasibility of the exact lifted clock
        tau(target) = tau(source) + 1 - N*lambda,   N >= 6,
        tau(t,i+1) - tau(t,i) >= 4,
    solved over the integers by Z3.

No P22 wake restriction, period upper bound, width bound, row-length bound, or
black-lifetime bound is used; both wake values are tried at every level. Every
row at level nine or below exists in any candidate or is enumerated as the empty
word, so an empty level-nine frontier excludes the band at every period.

Run from the repository root:
    python code/python/verify_lower_fat123_a0_102_exclusion.py
It writes results/lower_fat123_a0_102_checks_2026-09-22.json.
"""
from collections import Counter
from multiprocessing import Pool
from pathlib import Path
import json
import sys

import z3

RIGHT = frozenset(('ER', 'WR', 'NR', 'SR'))
OUT = {'ER': 'S', 'EL': 'N', 'WR': 'N', 'WL': 'S',
       'NR': 'E', 'NL': 'W', 'SR': 'W', 'SL': 'E'}
SHIFT = {'E': 3, 'W': -3, 'N': 1, 'S': -1}
VOLT = {'E': 1, 'W': -1, 'N': 0, 'S': 0}
PORTS = ('ER', 'EL', 'WR', 'WL', 'NR', 'NL', 'SR', 'SL')

EXPECTED = {
    0: [4, 42, 60, 452, 0],
    1: [4, 57, 294, 3112, 0],
}


def seed(b):
    return {
        0: ('WR',),
        1: ('NR', 'SL'),
        2: ('WR', 'WL', 'WR'),
        3: ('SR', 'SL', 'NR', 'SL', 'NR', 'SL'),
        4: ('WR', 'WL', 'ER', 'EL', 'WR', 'WL', 'WR', 'WL') + ('WR',) * b,
    }


def row_counts(rows, t, wake):
    old3 = rows.get(t - 3, ())
    old1 = rows.get(t - 1, ())
    a = sum(OUT[p] == 'E' for p in old3)
    b = sum(OUT[p] == 'N' for p in old1)
    c = sum(p[0] == 'W' for p in old3)
    d = sum(p[0] == 'S' for p in old1)
    if t % 2 == 0:
        assert b == 0 and c == 0
        for er in range(min(a, d) + 1):
            wr = wake + a + d - 3 * er
            if wr >= 0:
                yield {'ER': er, 'EL': a - er, 'WR': wr, 'WL': d - er}
    else:
        assert a == 0 and d == 0
        for nl in range(min(b, c) + 1):
            sl = b + c - 3 * nl - wake
            if sl >= 0:
                yield {'NR': b - nl, 'NL': nl, 'SR': c - nl, 'SL': sl}


def successors(rows):
    succ = {}
    for t, row in rows.items():
        dep = Counter()
        for i, p in enumerate(row):
            h = OUT[p]
            k = dep[h]
            dep[h] += 1
            u = t + SHIFT[h]
            if u not in rows:
                continue
            arr = [j for j, q in enumerate(rows[u]) if q[0] == h]
            if k >= len(arr):
                return None
            succ[(t, i)] = (u, arr[k], VOLT[h])
    return succ


def witnessed_bad_return(rows, succ):
    for t, row in rows.items():
        for i in range(len(row)):
            node, copy, seen = (t, i), 0, set()
            while node in succ and node not in seen:
                seen.add(node)
                u, j, v = succ[node]
                copy += v
                if u == t and copy == 0:
                    if j != i + 1:
                        return (t, i), (u, j)
                    break
                node = (u, j)
    return None


def clock_feasible(rows, succ):
    n = z3.Int('N')
    tau = {(t, i): z3.Int(f'tau_{t}_{i}') for t, r in rows.items() for i in range(len(r))}
    s = z3.SolverFor('QF_LIA')
    s.add(n >= 6)
    for (t, i), (u, j, v) in succ.items():
        s.add(tau[u, j] - tau[t, i] == 1 - v * n)
    for t, r in rows.items():
        for i in range(len(r) - 1):
            s.add(tau[t, i + 1] - tau[t, i] >= 4)
    res = s.check()
    if res == z3.unknown:
        raise RuntimeError(s.reason_unknown())
    return res == z3.sat


def boundary_return(old, new_t, port, out_ord):
    h = OUT[port]
    u = new_t + SHIFT[h]
    if u not in old:
        return None
    arr = [j for j, q in enumerate(old[u]) if q[0] == h]
    if out_ord >= len(arr):
        return 'BAD'
    q, copy, seen = (u, arr[out_ord]), VOLT[h], set()
    while q not in seen:
        seen.add(q)
        t, i = q
        h = OUT[old[t][i]]
        nt = t + SHIFT[h]
        k = sum(OUT[x] == h for x in old[t][:i + 1]) - 1
        copy += VOLT[h]
        if nt == new_t:
            return (h, k, copy)
        if nt not in old:
            return None
        arr = [j for j, x in enumerate(old[nt]) if x[0] == h]
        if k >= len(arr):
            return 'BAD'
        q = (nt, arr[k])
    return None


def words(old, t, counts):
    choices = tuple(p for p in PORTS if counts.get(p))
    arcs = {}
    for p in choices:
        n = sum(counts[x] for x in choices if OUT[x] == OUT[p])
        for i in range(n):
            arcs[p, i] = boundary_return(old, t, p, i)
    remaining = {p: counts[p] for p in choices}
    seq, used_in, used_out = [], Counter(), Counter()
    length = sum(remaining.values())

    def dfs(required):
        i = len(seq)
        if i == length:
            if required is None:
                yield tuple(seq)
            return
        for p in choices:
            if remaining[p] == 0 or (p in RIGHT) != (i % 2 == 0):
                continue
            head, h = p[0], OUT[p]
            if required is not None and (head, used_in[head]) != required:
                continue
            arc = arcs[p, used_out[h]]
            if arc == 'BAD':
                continue
            remaining[p] -= 1
            used_in[head] += 1
            used_out[h] += 1
            seq.append(p)
            nxt, ok = None, True
            if arc is not None and arc[2] == 0:
                nxt = arc[:2]
                ok = nxt[1] >= used_in[nxt[0]]
            if ok:
                yield from dfs(nxt)
            seq.pop()
            used_out[h] -= 1
            used_in[head] -= 1
            remaining[p] += 1

    yield from dfs(None)


def expand(args):
    rows, t = args
    out, st = [], Counter()
    for wake in (0, 1):
        for cnt in row_counts(rows, t, wake):
            st['count_rows'] += 1
            for w in words(rows, t, cnt):
                st['words'] += 1
                child = {**rows, t: w}
                succ = successors(child)
                assert succ is not None
                if witnessed_bad_return(child, succ) is not None:
                    st['return_rejected'] += 1
                    continue
                if not clock_feasible(child, succ):
                    st['clock_rejected'] += 1
                    continue
                st['survivors'] += 1
                out.append(child)
    return out, st


def run_band(b, pool):
    rows = seed(b)
    succ = successors(rows)
    assert witnessed_bad_return(rows, succ) is None and clock_feasible(rows, succ)
    states, history = [rows], []
    for t in range(5, 10):
        nxt, tot = [], Counter()
        for out, st in pool.imap_unordered(expand, [(s, t) for s in states], chunksize=8):
            nxt.extend(out)
            tot.update(st)
        states = nxt
        history.append({'level': t, **{k: tot[k] for k in ('count_rows', 'words', 'return_rejected', 'clock_rejected')},
                        'survivors': len(states)})
        print('omega4', b, history[-1], flush=True)
    assert [h['survivors'] for h in history] == EXPECTED[b], history
    return history


def main():
    procs = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    with Pool(procs) as pool:
        cases = [{'omega4': b, 'history': run_band(b, pool)} for b in (0, 1)]
    report = {
        'claim': 'Both lower fat (1,2,3) bands with omega3=0 and (j,k,l)=(1,0,2) are impossible at every period',
        'assumptions': ['flow and excess count equations', 'right/left alternation',
                        'ordinal edge matching', 'witnessed same-cell first returns land on the next stable visit',
                        'exact lifted clock with N>=6 and same-cell gaps>=4'],
        'not_used': ['P22 or any wake restriction', 'quotient-cycle extrapolation', 'period, width, row-length or lifetime bounds'],
        'cases': cases,
        'all_checks_passed': True,
    }
    out = Path(__file__).resolve().parents[2] / 'results' / 'lower_fat123_a0_102_checks_2026-09-22.json'
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
