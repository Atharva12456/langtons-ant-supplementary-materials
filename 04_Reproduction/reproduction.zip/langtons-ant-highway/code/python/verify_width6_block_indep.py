"""Independent set-valued verifier for the width-six six-column obstruction.

This file imports no project dynamics or width-six search module.  Compass-letter
headings, frozensets of black cells, frozensets of touched extreme cells, and an
independently written recursive graph traversal reproduce the multi-column block
experiment.  In the preferred ``--relaxed`` mode all outer history is forgotten and
every geometrically allowed return is permitted.  A terminal is any legal
right-boundary exit, since the unknown exterior may choose not to return after it.

The mathematical reduction from a periodic highway to this finite block remains a
paper argument; this script independently checks the finite local premise only.
"""
from __future__ import annotations

import argparse
from collections import Counter


RIGHT = {"N": "E", "E": "S", "S": "W", "W": "N"}
LEFT = {value: key for key, value in RIGHT.items()}
LOCAL_LOOP = object()


def run_until_outside(columns, black_cells, touched_extremes,
                      column, row, heading):
    black = set(black_cells)
    touched = set(touched_extremes)
    local_visits = 0
    local_states = set()
    while 0 <= column < columns:
        local_state = (
            frozenset(black), frozenset(touched), column, row, heading
        )
        if local_state in local_states:
            return LOCAL_LOOP
        local_states.add(local_state)
        cell = (column, row)
        if not 0 <= row <= 6:
            raise AssertionError((cell, heading))
        if row in (0, 6):
            if cell in touched:
                return None
            touched.add(cell)

        was_black = cell in black
        if was_black:
            black.remove(cell)
            heading = LEFT[heading]
        else:
            black.add(cell)
            heading = RIGHT[heading]
        local_visits += 1

        if heading == "E":
            column += 1
            row += 1
        elif heading == "W":
            column -= 1
            row -= 1
        elif heading == "N":
            row += 1
        else:
            row -= 1

    side = "left" if column < 0 else "right"
    return frozenset(black), frozenset(touched), side, row, local_visits


def verify(columns, keep_witness=False):
    # (black, touched extreme cells, boundary column, row, heading,
    #  left-top-entry, left-bottom-exit, right-top-exit, right-bottom-entry)
    pending = []
    for row in (2, 4, 6):
        pending.append((frozenset(), frozenset(), 0, row, "E",
                        row == 6, False, False, False))

    visited = set(pending)
    parent = {state: None for state in pending}
    parent_action = {
        state: ("initial_left_entry", state[3]) for state in pending
    }
    terminals = set()
    witness = None
    exits = Counter()
    transitions = 0
    rejected = 0
    max_local_visits = 0

    while pending:
        state = pending.pop()
        black, touched, column, row, heading, lp, lm, rp, rm = state
        result = run_until_outside(
            columns, black, touched, column, row, heading
        )
        if result is LOCAL_LOOP:
            raise AssertionError(("unexpected confined local loop", state))
        if result is None:
            rejected += 1
            continue
        black2, touched2, side, landing, local_visits = result
        max_local_visits = max(max_local_visits, local_visits)
        exits[(side, landing)] += 1

        if side == "right":
            if landing == 6 and rp:
                rejected += 1
                continue
            rp2 = rp or landing == 6
            terminals.add((black2, touched2, landing, lp, lm, rp2, rm))
            if keep_witness and witness is None:
                actions = [("final_right_exit", landing)]
                cursor = state
                while cursor is not None:
                    actions.append(parent_action[cursor])
                    cursor = parent[cursor]
                witness = list(reversed(actions))
            for entry in (0, 2, 4):
                if entry == 0 and rm:
                    continue
                next_state = (
                    black2, touched2, columns - 1, entry, "W",
                    lp, lm, rp2, rm or entry == 0,
                )
                transitions += 1
                if next_state not in visited:
                    visited.add(next_state)
                    parent[next_state] = state
                    parent_action[next_state] = (
                        "right_exit_return", landing, entry
                    )
                    pending.append(next_state)
        else:
            if landing == 0 and lm:
                rejected += 1
                continue
            lm2 = lm or landing == 0
            for entry in (2, 4, 6):
                if entry == 6 and lp:
                    continue
                next_state = (
                    black2, touched2, 0, entry, "E",
                    lp or entry == 6, lm2, rp, rm,
                )
                transitions += 1
                if next_state not in visited:
                    visited.add(next_state)
                    parent[next_state] = state
                    parent_action[next_state] = (
                        "left_exit_return", landing, entry
                    )
                    pending.append(next_state)

    return {
        "columns": columns,
        "states": len(visited),
        "transitions": transitions,
        "terminals": len(terminals),
        "rejected": rejected,
        "max_local_visits": max_local_visits,
        "exits": exits,
        "witness": witness,
    }


def verify_relaxed(columns):
    """Forget every outer-cut flag and permit every return after every exit."""
    pending = [
        (frozenset(), frozenset(), 0, row, "E") for row in (2, 4, 6)
    ]
    visited = set(pending)
    terminals = set()
    exits = Counter()
    transitions = rejected = local_loops = 0
    max_local_visits = 0

    while pending:
        state = pending.pop()
        black, touched, column, row, heading = state
        result = run_until_outside(
            columns, black, touched, column, row, heading
        )
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            rejected += 1
            continue
        black2, touched2, side, landing, local_visits = result
        max_local_visits = max(max_local_visits, local_visits)
        exits[(side, landing)] += 1
        if side == "right":
            terminals.add((black2, touched2, landing))
            choices = ((columns - 1, 0, "W"),
                       (columns - 1, 2, "W"),
                       (columns - 1, 4, "W"))
        else:
            choices = ((0, 2, "E"), (0, 4, "E"), (0, 6, "E"))
        for next_column, entry, next_heading in choices:
            next_state = (
                black2, touched2, next_column, entry, next_heading
            )
            transitions += 1
            if next_state not in visited:
                visited.add(next_state)
                pending.append(next_state)

    return {
        "columns": columns,
        "states": len(visited),
        "transitions": transitions,
        "terminals": len(terminals),
        "rejected": rejected,
        "local_loops": local_loops,
        "max_local_visits": max_local_visits,
        "exits": exits,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-columns", type=int, default=6)
    parser.add_argument("--show-witness", type=int, default=0,
                        help="print one terminal outer-event transcript for this width")
    parser.add_argument("--relaxed", action="store_true",
                        help="forget all outer-cut history and allow every return")
    args = parser.parse_args()
    expected_terminals = {1: 162, 2: 824, 3: 259, 4: 36, 5: 0, 6: 0}
    expected_relaxed = {
        1: (192, 480, 72),
        2: (3453, 6951, 1131),
        3: (5208, 7977, 1867),
        4: (633, 900, 102),
        5: (555, 819, 46),
        6: (357, 555, 0),
    }
    for columns in range(1, args.max_columns + 1):
        result = (verify_relaxed(columns) if args.relaxed else
                  verify(columns, keep_witness=columns == args.show_witness))
        if not args.relaxed and columns in expected_terminals:
            assert result["terminals"] == expected_terminals[columns], result
        if args.relaxed and columns in expected_relaxed:
            actual = (result["states"], result["transitions"], result["terminals"])
            assert actual == expected_relaxed[columns], (actual, expected_relaxed[columns])
        print(
            "independent{mode} columns={columns} states={states:,} transitions={transitions:,} "
            "terminals={terminals:,} rejected={rejected:,} max_local_visits={max_local_visits}"
            .format(mode=" relaxed" if args.relaxed else "", **result)
        )
        print(f"  exits={dict(sorted(result['exits'].items()))}")
        if not args.relaxed and result["witness"] is not None:
            print(f"  witness={result['witness']}")


if __name__ == "__main__":
    main()
