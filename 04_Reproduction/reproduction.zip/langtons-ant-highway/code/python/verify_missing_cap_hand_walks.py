"""Check every displayed walk and time identity of the hand proof
odd_skew_missing_cap_offsets_five_six_2026-09-23.md.

Independent of the explorer code.  Rows may be known only as prefixes; a walk
step is followed only when ordinal matching determines it from the known
prefixes (otherwise the check fails loudly).

A walk is started either at a concrete event (t,i) or at an abstract
departure "the k-th departure with heading h from row t" (k counted from 1),
and stops at the first arrival on the target level with copy counter 0.
It returns the direction word, the net voltage, the visited events and the
end point (an arrival heading, its ordinal among the arrivals with that
heading on the target row, and its position if that position is known).
"""
import sys

OUT = {'ER': 'S', 'EL': 'N', 'WR': 'N', 'WL': 'S',
       'NR': 'E', 'NL': 'W', 'SR': 'W', 'SL': 'E'}
SHIFT = {'E': 3, 'W': -3, 'N': 1, 'S': -1}
VOLT = {'E': 1, 'W': -1, 'N': 0, 'S': 0}

CAP = {0: ['WR'], 1: ['NR'], 2: [], 3: ['SR', 'SL'], 4: ['WR', 'WL', 'ER']}


def dep_rank(rows, t, i):
    h = OUT[rows[t][i]]
    return h, sum(1 for p in rows[t][:i] if OUT[p] == h) + 1


def arrival(rows, u, h, k):
    """position of the k-th arrival with heading h on row u, or None if unknown."""
    if u not in rows:
        return None
    pos = [j for j, p in enumerate(rows[u]) if p[0] == h]
    return pos[k - 1] if k <= len(pos) else None


def walk(rows, target, start=None, dep=None, maxsteps=60, anycopy=False):
    if start is not None:
        t, i = start
        h, k = dep_rank(rows, t, i)
        visited = [f'{t}:{rows[t][i]}{i}']
    else:
        t, h, k = dep
        visited = [f'{t}:{h}-dep#{k}']
    word, volt = '', 0
    for _ in range(maxsteps):
        u = t + SHIFT[h]
        word += h
        volt += VOLT[h]
        j = arrival(rows, u, h, k)
        if u == target and (volt == 0 or anycopy):
            end = f'{u}:{h}-arr#{k}' + (f'={rows[u][j]}{j}' if j is not None else '')
            visited.append(end)
            return dict(word=word, volt=volt, steps=len(word), visited=visited, end=(h, k, j))
        if j is None:
            raise RuntimeError(f'walk undetermined at row {u}, {h}-arrival #{k}; so far {visited}')
        visited.append(f'{u}:{rows[u][j]}{j}')
        t = u
        h, k = dep_rank(rows, t, j)
    raise RuntimeError('too long')


def disp(word):
    x = word.count('E') - word.count('W')
    y = word.count('N') - word.count('S')
    return x, y


def check(name, rows, target, expect_end, expect_word=None, **kw):
    src = (kw.get('start') or kw.get('dep'))[0]
    r = walk(rows, target, anycopy=(target != src), **kw)
    h, k, j = r['end']
    ok = (h, k) == expect_end[:2] and (len(expect_end) < 3 or j == expect_end[2])
    src = (kw.get('start') or kw.get('dep'))[0]
    if target == src:
        ok = ok and disp(r['word']) == (0, 0)
    if expect_word is not None:
        ok = ok and r['word'] == expect_word
    # no intermediate visit to the target level at copy 0 is guaranteed by the stopping rule
    print(('OK  ' if ok else 'FAIL'), name, '|', r['word'], f'({r["steps"]} steps, displacement {disp(r["word"])})')
    print('      ', ' -> '.join(r['visited']))
    if not ok:
        print('      expected end', expect_end, 'got', r['end'])
        sys.exit(1)
    return r


def rows_with(**extra):
    r = {t: list(v) for t, v in CAP.items()}
    for key, v in extra.items():
        r[int(key[1:])] = v.split(',') if v else []
    return r


def tau_offset(rows, path_start, target, sign, **kw):
    r = walk(rows, target, **kw)
    return r['steps'], r['volt']


if __name__ == '__main__':
    print('== Theorem 1: omega_5 = 1 ==')
    for r6 in ('WR,EL', 'WR,EL,WR'):
        R = rows_with(r5='NR', r6=r6)
        check(f'eight-step return, row 6 = {r6}', R, 7, ('N', 2), 'WSWNESEN', dep=(7, 'W', 2))
        check(f'square start W1 -> first E-arrival of row 8, row 6 = {r6}', R, 8, ('E', 1), 'WNE', dep=(7, 'W', 1))

    print('== Theorem 2, row 6 orders ==')
    R = rows_with(r5='NR,SL', r6='WR,EL,WR,WL')
    check('order A: eight-step return lands on N2', R, 7, ('N', 2), 'WSWNESEN', dep=(7, 'W', 2))
    check('order A: square start', R, 8, ('E', 1), 'WNE', dep=(7, 'W', 1))
    R = rows_with(r5='NR,SL', r6='WR,WL,WR,EL')
    check('order B: eight-step return lands on N3', R, 7, ('N', 3), 'WSWNESEN', dep=(7, 'W', 2))
    check('order B: square start', R, 8, ('E', 1), 'WNE', dep=(7, 'W', 1))

    for r7 in ('SR,SL,NR,NL,NR,SL', 'SR,SL,NR,NL,NR'):
        print(f'== family P, row 7 = {r7} ==')
        R = rows_with(r5='NR,SL', r6='WR,WL,WR,EL', r7=r7, r8='WR,WL,ER,EL')
        check('eight-step return from 7:NL3 to 7:NR4', R, 7, ('N', 3, 4), 'WSWNESEN', start=(7, 3))
        check('P1: W2(9) -> 6:WL1 -> 5:SL -> 8:EL3 -> N2(9)', R, 9, ('N', 2), 'WSEN', dep=(9, 'W', 2))
        check('P1b: same walk ends on row 8 at EL3', R, 8, ('E', 2, 3), 'WSE', dep=(9, 'W', 2))
        check('P3: W3(9) -> ... -> E3(10)', R, 10, ('E', 3), 'WNWSWNESENE', dep=(9, 'W', 3))
        check('P5: W1(9) -> 6:WR0 -> 7:NR2 -> E2(10)', R, 10, ('E', 2), 'WNE', dep=(9, 'W', 1))
        check('P2/P6: 8:WR0 -> first N-arrival of row 9', R, 9, ('N', 1), 'N', start=(8, 0))
        for name, w in (('P4 J-walk', 'S' + 'WSEN' + 'WNWSWNESENE'), ('P6 walk', 'N' + 'WNE' + 'S' + 'WSE')):
            print('     ', name, w, 'displacement', disp(w), 'length', len(w))
            assert disp(w) == (0, 0)

    for extra in ('', ',WR'):
        print(f'== family Q, row 8 = WR,WL,ER,WL,WR,EL{extra} ==')
        R = rows_with(r5='NR,SL', r6='WR,WL,WR,EL', r7='SR,SL,NR,NL,NR,SL', r8='WR,WL,ER,WL,WR,EL' + extra)
        check('Q: W2(9) -> 6:WL1 -> 5:SL -> 8:EL5 -> N3(9)', R, 9, ('N', 3), 'WSEN', dep=(9, 'W', 2))
        check('Q: W3(9) -> ... -> E3(10)', R, 10, ('E', 3), 'WNWSWNESENE', dep=(9, 'W', 3))
        check('Q: W1(9) -> 6:WR0 -> 7:NR2 -> E2(10)', R, 10, ('E', 2), 'WNE', dep=(9, 'W', 1))
        check('Q: 8:WR0 -> N1(9)', R, 9, ('N', 1), 'N', start=(8, 0))
        # case II
        R2 = dict(R); R2[9] = 'NR,NL,SR,NL'.split(','); R2[10] = 'WR,EL,ER,EL'.split(',')
        check('Q-II: W2(9) walk ends at N3(9) = NL3 = W3', R2, 9, ('N', 3, 3), 'WSEN', dep=(9, 'W', 2))
        check('Q-II: W1(9)=NL1 -> ... -> E2(10) = ER2', R2, 10, ('E', 2, 2), 'WNE', start=(9, 1))
        check('Q-II: 10:ER2 feeds the first S-arrival of row 9 = SR2', R2, 9, ('S', 1, 2), 'S', start=(10, 2))
        check('Q-II H2: W2(11) -> ... -> 10:EL1 -> N2(11)', R2, 11, ('N', 2), 'WSWNESEN', dep=(11, 'W', 2))
        check('Q-II H3: 7:SL1 -> 10:EL1 -> N2(11)', R2, 11, ('N', 2), 'EN', start=(7, 1))
        check('Q-II H3: W3(11) -> 8:WL3 -> third S-arrival of row 7 = SL5', R2, 7, ('S', 3, 5), 'WS', dep=(11, 'W', 3))
        check('Q-II square at 11: W1(11) -> 8:WR0 -> 9:NR0 -> E1(12)', R2, 12, ('E', 1), 'WNE', dep=(11, 'W', 1))
        # case I
        R1 = dict(R); R1[9] = 'NR,SL,SR,NL,NR'.split(','); R1[10] = 'WR,WL,ER,EL'.split(',')
        check('Q-I: W2(9)=NL3 walk ends at N3(9) = NR4', R1, 9, ('N', 3, 4), 'WSEN', start=(9, 3))
        check('Q-I: W1(9)=SR2 -> ... -> E2(10) = EL3', R1, 10, ('E', 2, 3), 'WNE', start=(9, 2))
        check('Q-I: 10:ER2 feeds the second S-arrival of row 9 = SR2', R1, 9, ('S', 2, 2), 'S', start=(10, 2))
        check('Q-I: 10:WL1 feeds the first S-arrival of row 9 = SL1', R1, 9, ('S', 1, 1), 'S', start=(10, 1))
        check('Q-I H2: W2(11) -> ... -> 10:ER2 -> 9:SR2 -> ... -> 10:EL3 -> N2(11)', R1, 11, ('N', 2),
              'WSWNESESWNEN', dep=(11, 'W', 2))
        check('Q-I H3: 7:NR2 -> 10:EL3 -> N2(11)', R1, 11, ('N', 2), 'EN', start=(7, 2))
        check('Q-I H3: W3(11) -> 8:WL3 -> SL5', R1, 7, ('S', 3, 5), 'WS', dep=(11, 'W', 3))
        check('Q-I square at 11', R1, 12, ('E', 1), 'WNE', dep=(11, 'W', 1))
        for name, w in (('Q-II J-walk', 'S' + 'WSEN' + 'WNWSWNESENE'),):
            print('     ', name, w, 'displacement', disp(w), 'length', len(w))
            assert disp(w) == (0, 0)

    print('== time identities (steps, net voltage) ==')
    R = rows_with(r5='NR,SL', r6='WR,WL,WR,EL', r7='SR,SL,NR,NL,NR,SL', r8='WR,WL,ER,WL,WR,EL')
    for name, kw, target in (
            ('6:WL1 -> 5:SL -> 8:EL5', dict(start=(6, 1)), 8),
            ('6:WR2 -> 7:NL3', dict(start=(6, 2)), 7),
            ('8:WL3 -> 7:SL5', dict(start=(8, 3)), 7),
            ('4:WR -> 5:NR -> 8:ER2 (continue to 7:SL1)', dict(start=(4, 0)), 8),
            ('8:ER2 -> 7:SL1', dict(start=(8, 2)), 7),
            ('6:WR0 -> 7:NR2', dict(start=(6, 0)), 7),
            ('W1(9) -> 6:WR0', dict(dep=(9, 'W', 1)), 6),
            ('8:WL1 -> 7:SR0 -> 4:WR', dict(start=(8, 1)), 4)):
        r = walk(R, target, anycopy=True, **kw)
        print(f'   {name}: steps {r["steps"]}, net voltage {r["volt"]}, end {r["visited"][-1]}')
    print('all checks passed')
