"""Explore complete transcripts through a blank width-six multi-column block.

The preferred ``--relaxed`` certificate retains all 7*k in-block colours, the
inward boundary pose, and the once-visit status of the physical extremal cells.  It
forgets every outer-cut history and permits every geometrically allowed return after
every exit.  The older default mode additionally tracks four outer extreme-event
flags and is retained as a diagnostic.

A legal final exit through the right boundary gives a compatible directed path of
``k`` all-white column edges.  Thus proving that no such terminal is reachable for
some fixed k would be an all-signature local obstruction, not a bounded-length
search.  Reachable-state cycles are explored as graph states rather than truncated.

At six columns the relaxed model has no right-exit terminal.  A separately written
set-valued verifier reproduces the complete reachability counts.  The resulting
width-six exclusion is computer-assisted: the global bridge is proved on paper, but
enumerator completeness is not formalized in Lean.
"""
from __future__ import annotations

import argparse
from collections import Counter, deque


NORTH, EAST, SOUTH, WEST = range(4)
RIGHT = (EAST, SOUTH, WEST, NORTH)
LEFT = (WEST, NORTH, EAST, SOUTH)
LOCAL_LOOP = object()


def cell_index(x: int, line: int) -> int:
    return 7 * x + line


def advance_inside(columns: int, black: int, extreme_seen: int,
                   x: int, line: int, heading: int):
    """Run literal cell updates until the ant crosses an outer boundary.

    Return ``None`` if a physical extremal cell would be revisited.  Otherwise
    return ``(black, extreme_seen, side, landing_line, visits)``.
    """
    visits = 0
    local_states = set()
    while True:
        if not (0 <= x < columns and 0 <= line <= 6):
            raise AssertionError((columns, x, line, heading))
        local_state = (black, extreme_seen, x, line, heading)
        if local_state in local_states:
            return LOCAL_LOOP
        local_states.add(local_state)
        bit = 1 << cell_index(x, line)
        if line in (0, 6):
            if extreme_seen & bit:
                return None
            extreme_seen |= bit
        was_black = bool(black & bit)
        black ^= bit
        heading = LEFT[heading] if was_black else RIGHT[heading]
        visits += 1

        old_x = x
        if heading == EAST:
            x += 1
            line += 1
        elif heading == WEST:
            x -= 1
            line -= 1
        elif heading == NORTH:
            line += 1
        else:
            line -= 1

        if x < 0:
            return black, extreme_seen, "left", line, visits
        if x >= columns:
            return black, extreme_seen, "right", line, visits
        # Horizontal moves change columns; vertical moves retain them.  ``old_x``
        # is kept only to make that convention explicit during audit.
        if heading in (NORTH, SOUTH) and x != old_x:
            raise AssertionError((old_x, x, heading))


def explore(columns: int):
    # Flags: left top/rightward entry, left bottom/leftward exit,
    # right top/rightward exit, right bottom/leftward entry.
    initial = [
        (0, 0, entry, EAST, (entry == 6, False, False, False))
        for entry in (2, 4, 6)
    ]
    queue = deque(initial)
    seen = set(initial)
    terminals = []
    transition_count = 0
    invalid_extreme = 0
    exit_counts = Counter()
    max_cell_visits = 0
    local_loops = 0

    while queue:
        black, extreme_seen, line, heading, flags = queue.popleft()
        x = 0 if heading == EAST else columns - 1
        result = advance_inside(
            columns, black, extreme_seen, x, line, heading
        )
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            invalid_extreme += 1
            continue
        black2, extreme2, side, landing, visits = result
        max_cell_visits = max(max_cell_visits, visits)
        exit_counts[(side, landing)] += 1
        lp, lm, rp, rm = flags
        if side == "right":
            if landing == 6 and rp:
                invalid_extreme += 1
                continue
            flags2 = (lp, lm, rp or landing == 6, rm)
            terminals.append((black2, extreme2, landing, flags2))
            for entry in (0, 2, 4):
                if entry == 0 and rm:
                    continue
                state = (
                    black2,
                    extreme2,
                    entry,
                    WEST,
                    (flags2[0], flags2[1], flags2[2], rm or entry == 0),
                )
                transition_count += 1
                if state not in seen:
                    seen.add(state)
                    queue.append(state)
        else:
            if landing == 0 and lm:
                invalid_extreme += 1
                continue
            flags2 = (lp, lm or landing == 0, rp, rm)
            for entry in (2, 4, 6):
                if entry == 6 and lp:
                    continue
                state = (
                    black2,
                    extreme2,
                    entry,
                    EAST,
                    (lp or entry == 6, flags2[1], rp, rm),
                )
                transition_count += 1
                if state not in seen:
                    seen.add(state)
                    queue.append(state)

    return {
        "columns": columns,
        "states": len(seen),
        "transitions": transition_count,
        "terminals": len(terminals),
        "terminal_masks": len({black for black, *_rest in terminals}),
        "invalid_extreme": invalid_extreme,
        "exit_counts": exit_counts,
        "max_cell_visits_between_outer_crossings": max_cell_visits,
        "local_loops": local_loops,
    }


def explore_relaxed(columns: int):
    """Strict over-approximation with no constraints on outer-cut history.

    Only colours, in-block extremal visits, and the inward boundary pose are kept.
    Every geometrically allowed outer re-entry is available after every exit.  This
    avoids relying on any state belonging to cells just outside the block.
    """
    initial = [(0, 0, entry, EAST) for entry in (2, 4, 6)]
    queue = deque(initial)
    seen = set(initial)
    terminal_states = set()
    terminal_events = 0
    transition_count = 0
    invalid_extreme = 0
    exit_counts = Counter()
    max_cell_visits = 0
    local_loops = 0

    while queue:
        black, extreme_seen, line, heading = queue.popleft()
        x = 0 if heading == EAST else columns - 1
        result = advance_inside(
            columns, black, extreme_seen, x, line, heading
        )
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            invalid_extreme += 1
            continue
        black2, extreme2, side, landing, visits = result
        max_cell_visits = max(max_cell_visits, visits)
        exit_counts[(side, landing)] += 1
        if side == "right":
            terminal_events += 1
            terminal_states.add((black2, extreme2, landing))
            entries = ((0, WEST), (2, WEST), (4, WEST))
        else:
            entries = ((2, EAST), (4, EAST), (6, EAST))
        for entry, next_heading in entries:
            state = (black2, extreme2, entry, next_heading)
            transition_count += 1
            if state not in seen:
                seen.add(state)
                queue.append(state)

    return {
        "columns": columns,
        "states": len(seen),
        "transitions": transition_count,
        "terminal_events": terminal_events,
        "terminal_states": len(terminal_states),
        "invalid_extreme": invalid_extreme,
        "exit_counts": exit_counts,
        "max_cell_visits_between_outer_crossings": max_cell_visits,
        "local_loops": local_loops,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-columns", type=int, default=1)
    parser.add_argument("--max-columns", type=int, default=6)
    parser.add_argument("--relaxed", action="store_true",
                        help="forget all outer-cut history and allow every return")
    args = parser.parse_args()
    for columns in range(args.min_columns, args.max_columns + 1):
        result = explore_relaxed(columns) if args.relaxed else explore(columns)
        if args.relaxed:
            print(
                "relaxed columns={columns} states={states:,} transitions={transitions:,} "
                "terminal_events={terminal_events:,} terminal_states={terminal_states:,} "
                "invalid_extreme={invalid_extreme:,} local_loops={local_loops:,} "
                "max_inner_visits={max_cell_visits_between_outer_crossings}"
                .format(**result)
            )
        else:
            print(
                "columns={columns} states={states:,} transitions={transitions:,} "
                "terminals={terminals:,} terminal_masks={terminal_masks:,} "
                "invalid_extreme={invalid_extreme:,} local_loops={local_loops:,} "
                "max_inner_visits={max_cell_visits_between_outer_crossings}"
                .format(**result)
            )
        print(f"  exits={dict(sorted(result['exit_counts'].items()))}")


if __name__ == "__main__":
    main()
