#!/usr/bin/env python3
"""Audit the forced growth-eight boundary at drift (3,-3).

The calculation checks every normalized two-rail placement through a chosen
transverse width.  It compares the full drift-periodic mod-four additive family
with one explicit moment, then solves the finite parity-flow system and computes
its rank sign.  This is a bounded regression for the displayed algebra in the
research note; it is not a search over ant periods or an all-width proof.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path


LANES = 3
DRIFT = (3, -3)
Block = tuple[str, int, int]
Vertex = tuple[int, int]


def forced_boundary(width: int, horizontal: int, vertical: int) -> set[Vertex]:
    """Return the two rails and the remaining horizontal/vertical classes."""
    top = width - 1
    return (
        {(-1, lane) for lane in range(LANES)}
        | {(top, lane) for lane in range(LANES)}
        | {(horizontal, 0), (vertical, 0)}
    )


def explicit_weight(x: int, y: int) -> int:
    checker = 1 if (x + y) % 2 == 0 else -1
    return checker * (x // LANES + y // LANES) % 4


def explicit_moment(boundary: set[Vertex]) -> int:
    return sum(
        explicit_weight(lane, level - lane) for level, lane in boundary
    ) % 4


def period_residue_mod_8(boundary: set[Vertex]) -> tuple[int, int]:
    """Return the even-checker odd-class count and the forced period residue."""
    even_checker = sum(level % 2 == 0 for level, _lane in boundary)
    residue = 2 * (-(sum(DRIFT) + even_checker) % 4) % 8
    return even_checker, residue


def extend_weight(
    first: int, last: int, initial: tuple[int, ...]
) -> dict[Vertex, int]:
    """Extend two quotient rows by the zero-four-corner recurrence."""
    values = {
        (first + offset, lane): initial[offset * LANES + lane]
        for offset in range(2)
        for lane in range(LANES)
    }
    for level in range(first, last - 1):
        for target_lane in range(LANES):
            prior_lane = (target_lane - 1) % LANES
            values[level + 2, target_lane] = (
                -values[level, prior_lane]
                - values[level + 1, target_lane]
                - values[level + 1, prior_lane]
            ) % 4
    return values


def additive_residuals(
    boundary: set[Vertex], first: int, last: int
) -> tuple[int, ...]:
    """Evaluate the endpoint equation on generators of all 4^6 weights."""
    residuals = []
    for position in range(2 * LANES):
        initial = tuple(int(index == position) for index in range(2 * LANES))
        weight = extend_weight(first, last, initial)
        strand_sum = sum(weight[vertex] for vertex in boundary)
        monodromy = sum(weight[0, lane] for lane in range(LANES))
        monodromy -= sum(weight[1, lane] for lane in range(LANES))
        residuals.append((strand_sum + monodromy) % 4)
    return tuple(residuals)


def target(block: Block) -> Vertex:
    kind, level, lane = block
    if kind == "W":
        return level - 1, (lane - 1) % LANES
    if kind == "E":
        return level + 1, (lane + 1) % LANES
    if kind == "S":
        return level - 1, lane
    if kind == "N":
        return level + 1, lane
    raise AssertionError(kind)


def source_key(block: Block) -> tuple[int, int, int]:
    kind, level, lane = block
    return level, lane, int(kind in "EN")


def target_key(block: Block) -> tuple[int, int, int]:
    kind, _level, _lane = block
    level, lane = target(block)
    return level, lane, int(kind in "EN")


def strip_blocks(low: int, high: int) -> list[Block]:
    blocks = []
    for level in range(low, high + 1):
        kinds = "WE" if level % 2 == 0 else "SN"
        for lane in range(LANES):
            for kind in kinds:
                block = kind, level, lane
                target_level, _target_lane = target(block)
                if low <= target_level <= high:
                    blocks.append(block)
    return blocks


def solve_parity_flow(boundary: set[Vertex], margin: int) -> set[Block]:
    low = min(level for level, _lane in boundary) - margin
    high = max(level for level, _lane in boundary) + margin
    blocks = strip_blocks(low, high)
    index = {block: position for position, block in enumerate(blocks)}
    rows = []
    for level in range(low, high + 1):
        for lane in range(LANES):
            vertex = level, lane
            right = int(vertex in boundary)
            outgoing = [block for block in blocks if block[1:] == vertex]
            incoming = [block for block in blocks if target(block) == vertex]
            for incident in (outgoing, incoming):
                coefficients = sum(1 << index[block] for block in incident)
                rows.append(coefficients | (right << len(blocks)))

    rank = 0
    pivots = []
    for column in range(len(blocks)):
        pivot = next(
            (row for row in range(rank, len(rows)) if (rows[row] >> column) & 1),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for row in range(len(rows)):
            if row != rank and ((rows[row] >> column) & 1):
                rows[row] ^= rows[rank]
        pivots.append(column)
        rank += 1

    coefficient_mask = (1 << len(blocks)) - 1
    assert not any(
        (row & coefficient_mask) == 0 and ((row >> len(blocks)) & 1)
        for row in rows
    )
    assert rank == len(blocks)
    solution = 0
    for row, pivot in zip(rows[:rank], pivots):
        if (row >> len(blocks)) & 1:
            solution |= 1 << pivot
    return {
        block for position, block in enumerate(blocks) if (solution >> position) & 1
    }


def parity_flow_sign(boundary: set[Vertex], margin: int) -> int:
    blocks = solve_parity_flow(boundary, margin)
    ordered = sorted(blocks, key=source_key)
    edge_sign = sum(
        target_key(first) > target_key(second)
        for index, first in enumerate(ordered)
        for second in ordered[index + 1 :]
    ) & 1

    outgoing: dict[Vertex, list[Block]] = defaultdict(list)
    incoming: dict[Vertex, list[Block]] = defaultdict(list)
    for block in blocks:
        outgoing[block[1:]].append(block)
        incoming[target(block)].append(block)

    local_sign = 0
    for vertex in set(outgoing) | set(incoming) | boundary:
        level, _lane = vertex
        excess = int(vertex in boundary)
        positive = (
            sum(block[0] in "EN" for block in outgoing[vertex])
            + sum(block[0] in "EN" for block in incoming[vertex])
        ) & 1
        if level % 2 == 0:
            local_sign ^= positive & (excess ^ 1)
        else:
            local_sign ^= excess & (positive ^ 1)
    return edge_sign ^ local_sign


def audit_explicit_weight() -> int:
    checks = 0
    for x in range(-8, 9):
        for y in range(-8, 9):
            assert (
                explicit_weight(x, y)
                + explicit_weight(x + 1, y)
                + explicit_weight(x, y + 1)
                + explicit_weight(x + 1, y + 1)
            ) % 4 == 0
            assert explicit_weight(x + 3, y - 3) == explicit_weight(x, y)
            checks += 2
            if (x + y) % 2 == 0:
                monodromy = 0
                here_x, here_y = x, y
                for _step in range(3):
                    monodromy += explicit_weight(here_x, here_y - 1)
                    monodromy -= explicit_weight(here_x + 1, here_y - 1)
                    here_x, here_y = here_x + 1, here_y - 1
                assert monodromy % 4 == 1
                checks += 1
    return checks


def audit(max_width: int, margin: int) -> dict[str, object]:
    if max_width < 4 or max_width % 2:
        raise ValueError("max_width must be even and at least four")
    if margin < 2:
        raise ValueError("margin must be at least two")

    tested = 0
    additive_survivors = 0
    sign_counts = [0, 0]
    examples = []
    generator_checks = 0
    boundary_even_checker_counts: set[int] = set()
    boundary_period_residues: set[int] = set()
    survivor_period_residue_counts: dict[int, int] = defaultdict(int)
    # The representative has period start t=0 and rails t=-1,W-1.  For a
    # general start p and lower rail b, horizontal-versus-vertical arrival parity
    # makes b-p odd, so the endpoint coefficient changes by a multiple of four.
    for width in range(4, max_width + 1, 2):
        top = width - 1
        for horizontal in range(1, top, 2):
            for vertical in range(0, top, 2):
                if (horizontal - vertical) % LANES:
                    continue
                boundary = forced_boundary(width, horizontal, vertical)
                tested += 1
                even_checker, period_residue = period_residue_mod_8(boundary)
                boundary_even_checker_counts.add(even_checker)
                boundary_period_residues.add(period_residue)
                residuals = additive_residuals(boundary, -2, top + 2)
                generator_checks += len(residuals)
                additive_ok = not any(residuals)
                moment = explicit_moment(boundary)
                assert moment == (2 - width + (vertical - horizontal) // 3) % 4
                assert additive_ok == (moment == 3)
                if not additive_ok:
                    continue
                additive_survivors += 1
                survivor_period_residue_counts[period_residue] += 1
                sign = parity_flow_sign(boundary, margin)
                sign_counts[sign] += 1
                if len(examples) < 12:
                    examples.append(
                        {
                            "width": width,
                            "horizontal_level": horizontal,
                            "vertical_level": vertical,
                            "parity_flow_sign": sign,
                        }
                    )

    expected_survivor_residues = (
        {6: additive_survivors} if additive_survivors else {}
    )
    period_residue_check = (
        (
            tested == 0
            or (
                boundary_even_checker_counts == {1}
                and boundary_period_residues == {6}
            )
        )
        and survivor_period_residue_counts == expected_survivor_residues
    )
    return {
        "schema": "langton-growth8-m3-boundary-audit-v2",
        "status": "bounded_evidence_not_proof",
        "maximum_width": max_width,
        "exterior_margin": margin,
        "representative_start_level": 0,
        "representative_rail_levels": ["-1", "W-1"],
        "boundaries_tested": tested,
        "additive_generator_checks": generator_checks,
        "additive_survivors": additive_survivors,
        "additive_survivor_period_residue_counts_mod_8": dict(
            sorted(survivor_period_residue_counts.items())
        ),
        "even_checker_odd_classes": 1,
        "period_residue_mod_8": 6,
        "parity_flow_sign_counts": sign_counts,
        "joint_survivors": sign_counts[0],
        "survivor_examples": examples,
        "explicit_weight_checks": audit_explicit_weight(),
        "moment_condition": "(v-h)/3 = W+1 (mod 4)",
        "required_parity_flow_sign": 0,
        "all_checks_passed": sign_counts[1] == 0 and period_residue_check,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-width", type=int, default=30)
    parser.add_argument("--margin", type=int, default=3)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = audit(args.max_width, args.margin)
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
