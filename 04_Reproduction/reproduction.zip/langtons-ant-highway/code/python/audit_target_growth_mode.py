#!/usr/bin/env python3
"""Cross-check fixed-growth search against the original all-growth traversal.

For each small even period, the accepted leaves of the original residue-pruned
search must split exactly by their final growth.  This audit compares the leaf,
residue, P3, and hit records from that search with the sum of separate
``--target-growth`` runs.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path


PARTITIONED_COUNTERS = (
    "leaves",
    "residue_checks",
    "residue_prunes",
    "p3_checks",
)


def run(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def search_record(
    repo: Path, class_dir: Path, period: int, growth: int | None
) -> dict[str, object]:
    command = [
        "java",
        "-cp",
        str(class_dir),
        "PositiveGrowthResidueSearch",
        "--period",
        str(period),
        "--prefix-length",
        "1",
        "--rank-start",
        "0",
        "--rank-stop",
        "1",
        "--deficit-depths",
        "0",
    ]
    if growth is not None:
        command.extend(("--target-growth", str(growth)))
    return json.loads(run(command, repo).stdout)


def hit_key(hit: dict[str, object]) -> tuple[object, ...]:
    drift = hit.get("drift")
    return hit.get("trace"), hit.get("growth"), tuple(drift) if drift else None


def audit(max_period: int) -> dict[str, object]:
    repo = Path(__file__).resolve().parents[2]
    source = repo / "code" / "java" / "PositiveGrowthResidueSearch.java"
    periods: list[dict[str, object]] = []
    problems: list[str] = []

    with tempfile.TemporaryDirectory(prefix="target-growth-audit-") as raw:
        class_dir = Path(raw)
        run(["javac", "-d", str(class_dir), str(source)], repo)

        for period in range(4, max_period + 1, 2):
            original = search_record(repo, class_dir, period, None)
            targets = [
                search_record(repo, class_dir, period, growth)
                for growth in range(4, period + 1, 4)
            ]
            period_problems: list[str] = []

            if original.get("target_growth") is not None:
                period_problems.append("original run has non-null target_growth")
            if not original.get("search_complete"):
                period_problems.append("original run is incomplete")

            for growth, record in zip(range(4, period + 1, 4), targets):
                if record.get("target_growth") != growth:
                    period_problems.append(f"growth {growth}: wrong metadata")
                if not record.get("search_complete"):
                    period_problems.append(f"growth {growth}: incomplete run")
                for hit in record.get("hits", []):
                    if hit.get("growth") != growth:
                        period_problems.append(
                            f"growth {growth}: hit has growth {hit.get('growth')}"
                        )

            counter_comparison: dict[str, dict[str, int]] = {}
            for counter in PARTITIONED_COUNTERS:
                original_value = int(original[counter])
                target_sum = sum(int(record[counter]) for record in targets)
                counter_comparison[counter] = {
                    "original": original_value,
                    "target_sum": target_sum,
                }
                if original_value != target_sum:
                    period_problems.append(
                        f"{counter}: original {original_value}, targets {target_sum}"
                    )

            original_hits = sorted(hit_key(hit) for hit in original.get("hits", []))
            target_hits = sorted(
                hit_key(hit) for record in targets for hit in record.get("hits", [])
            )
            if original_hits != target_hits:
                period_problems.append("target hit lists do not partition original hits")

            periods.append(
                {
                    "period": period,
                    "target_growths": list(range(4, period + 1, 4)),
                    "counters": counter_comparison,
                    "hits": len(original_hits),
                    "problems": period_problems,
                }
            )
            problems.extend(f"period {period}: {item}" for item in period_problems)

    return {
        "schema": "langton-target-growth-mode-cross-check-v1",
        "max_period": max_period,
        "periods": periods,
        "problems": problems,
        "all_checks_passed": not problems,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-period", type=int, default=18)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.max_period < 4 or args.max_period % 2:
        parser.error("--max-period must be an even integer at least 4")

    result = audit(args.max_period)
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    if not result["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
