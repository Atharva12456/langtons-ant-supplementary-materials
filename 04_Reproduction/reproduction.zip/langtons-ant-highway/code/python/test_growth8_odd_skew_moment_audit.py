#!/usr/bin/env python3
"""Regression test for the `(1,3)` and `(1,-3)` additive moments."""

from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("growth8_odd_skew_moment_audit.py")


class GrowthEightOddSkewMomentAuditTest(unittest.TestCase):
    def test_small_window_keeps_half_of_the_p22_boundaries(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--maximum-index", "3"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        report = json.loads(completed.stdout)
        self.assertEqual(
            [row["drift"] for row in report["orientations"]],
            [[1, 3], [1, -3]],
        )
        for row in report["orientations"]:
            self.assertEqual(row["p22_boundaries"], 3888)
            self.assertEqual(row["moment_survivors"], 1944)
        self.assertTrue(report["all_checks_passed"])


if __name__ == "__main__":
    unittest.main()
