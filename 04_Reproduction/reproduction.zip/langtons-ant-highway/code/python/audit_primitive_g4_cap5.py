#!/usr/bin/env python3
"""Cross-audit the exact bottom- and top-boundary cap-five enumerators."""

from __future__ import annotations

import ast
import contextlib
import hashlib
import importlib.util
import io
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
CERTIFICATE = ROOT / "results" / "primitive_g4_cap5_certificate.json"
PROGRAMS = (
    ROOT / "code" / "python" / "primitive_g4_cap5_symbolic.py",
    ROOT / "code" / "python" / "verify_primitive_g4_cap5_indep.py",
)
TOP_PROGRAM = ROOT / "code" / "python" / "verify_primitive_g4_cap5_top.py"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(path: Path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    stream = io.StringIO()
    with contextlib.redirect_stdout(stream):
        module.main()
    lines = stream.getvalue().splitlines()
    headline = ast.literal_eval(lines[0])
    regimes = [ast.literal_eval(line.removeprefix("SOURCE "))
               for line in lines[1:] if line.startswith("SOURCE ")]
    return headline, regimes


def tuples(value):
    if isinstance(value, list):
        return tuple(tuples(item) for item in value)
    return value


def main() -> None:
    certificate = json.loads(CERTIFICATE.read_text(encoding="utf-8"))
    expected_regimes = sorted(tuples(row) for row in certificate["source_regimes"])
    expected_top_regimes = sorted(
        tuples(row) for row in certificate["top_source_regimes"]
    )
    results = [run(path) for path in PROGRAMS]
    top = run(TOP_PROGRAM)

    primary, independent = results
    assert primary[0]["skeleton_leaf_choices"] == 1320
    assert independent[0]["skeleton_leaf_choices"] == 1320
    assert primary[0]["distinct_exact_source_regimes"] == 9
    assert independent[0]["distinct_exact_source_regimes"] == 9
    assert primary[0]["survivors"] == independent[0]["survivors"] == 0
    assert sorted(primary[1]) == expected_regimes
    assert sorted(independent[1]) == expected_regimes
    assert certificate["counts"] == {
        "skeleton_leaf_choices": 1320,
        "distinct_exact_source_regimes": 9,
        "survivors": 0,
    }
    assert top[0] == {
        "schema": "primitive-g4-cap5-top-v1",
        "skeleton_leaf_choices": 1320,
        "source_regimes": 2,
        "survivors": 0,
        "status": "verified_zero",
    }
    assert sorted(top[1]) == expected_top_regimes
    assert certificate["top_counts"] == {
        "skeleton_leaf_choices": 1320,
        "distinct_exact_source_regimes": 2,
        "survivors": 0,
    }

    for relative, expected in certificate["files"].items():
        assert digest(ROOT / relative) == expected

    print(json.dumps({
        "schema": certificate["schema"],
        "primary_independent_regimes_equal": True,
        "certified_regimes": len(expected_regimes),
        "certified_top_regimes": len(expected_top_regimes),
        "top_sign_reversed_check_passed": True,
        "survivors": 0,
        "hashes_match": True,
        "all_checks_passed": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
