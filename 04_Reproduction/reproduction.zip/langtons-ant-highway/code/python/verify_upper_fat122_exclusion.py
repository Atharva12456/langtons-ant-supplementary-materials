"""Exact checks for the finite walks and clock sum in the accompanying hand proof.

This script does not establish the prior two-sided normal form or certify an
exhaustive search. It uses only Python's standard library.
"""
import json
from pathlib import Path

HEADINGS = ('E', 'N', 'W', 'S')
VECTORS = ((1, 0), (0, 1), (-1, 0), (0, -1))

CERTIFICATES = [
    ('B_second_east_right', 5, 'SR WR NR ER SL', 4),
    ('B_south_predecessor_square', 6, 'ER SR WR NR EL', 4),
    ('B_second_west_left', 6, 'EL NL WL SR WR NR ER SL ER', 8),
    ('B_second_west_right', 7, 'SR WL SR WR NR ER SL ER SR WR NR EL NL', 12),
    ('B_second_to_third_east', 6, 'EL NL WL SL ER', 4),
    ('B_skipped_successor', 5, 'SR WR NR EL NL WL SL ER SL', 8),
]

def check_walk(name, offset, text, expected_steps, rotated=False):
    ports = text.split()
    turn = {'R': -1, 'L': 1}
    positions = [(0, offset)]
    directions = []
    for source, target in zip(ports, ports[1:]):
        heading = HEADINGS.index(source[0])
        departure = (heading + turn[source[1]]) % 4
        assert HEADINGS[departure] == target[0], (name, source, target)
        dx, dy = VECTORS[departure]
        if rotated:
            dx, dy = -dx, -dy
        x, y = positions[-1]
        positions.append((x + dx, y + dy))
        directions.append(HEADINGS[departure])
    assert len(directions) == expected_steps
    assert positions[-1] == positions[0], (name, positions)
    assert positions[0] not in positions[1:-1], (name, positions)
    assert ports[0][1] != ports[-1][1]
    return {
        'name': name,
        'steps': expected_steps,
        'directions': ''.join(directions),
        'displacement': [0, 0],
        'first_return': True,
        'offsets': [3*x+y for x,y in positions] if not rotated else None,
    }

def main():
    records = []
    for name, offset, ports, steps in CERTIFICATES:
        records.append(check_walk(name, offset, ports, steps))
        check_walk(name, offset, ports, steps, rotated=True)
    # Every edge is a lower bound on target time minus source time.
    # Coefficients are (constant, coefficient of N), in upper coordinates.
    inequalities = [
        ('4:WR1', '4:WL1', 4, 0),
        ('4:WL1', '4:ER', 4, 0),
        ('4:ER', '3:SL1', 1, 0),
        ('3:SL1', '3:NR', 4, 0),
        ('3:NR', '6:E2', 1, 1),
        ('6:E2', '6:D2', 0, 0),
        ('6:D2', '5:SL1', 1, 0),
        ('5:SL1', '5:NR1', 4, 0),
        ('5:NR1', '4:WR1', -1, 0),
    ]
    for i, edge in enumerate(inequalities):
        assert edge[1] == inequalities[(i+1) % len(inequalities)][0]
    constant = sum(edge[2] for edge in inequalities)
    period_coefficient = sum(edge[3] for edge in inequalities)
    assert (constant, period_coefficient) == (18, 1)
    assert constant > 0 and period_coefficient >= 0
    # The key B return arrives from the south; its prescribed immediate
    # successor in the normal form arrives from the north.
    assert CERTIFICATES[-1][2].split()[-1][0] == 'S'
    assert 'NL'[0] == 'N'
    result = {
        'all_checks_passed': True,
        'walk_certificates': records,
        'half_turn_checks_passed': True,
        'upper_clock_cycle': {'constant': constant, 'N_coefficient': period_coefficient},
        'lower_orientation_control': {'necessary_bound': 'N >= 18', 'not_excluded': True},
        'scope': 'Finite certificate checks for a hand proof; prior normal form not formalized.',
    }
    output = Path(__file__).with_name('upper_fat122_exclusion_checks_2026-09-21.json')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
