"""Explore an exact-W=10 diagonal blank block and classify final wake masks.

This is a research diagnostic, not a theorem certificate.  It uses the same strict
exterior relaxation as the accepted width-six and width-eight block classifiers:
after each outer exit all outside history is forgotten and every geometrically
possible same-boundary return is allowed.  The strip is ``t=x+y in 0,...,10`` and
only the proved once-entry condition on in-block extremal cells is enforced.

At each right exit the current block colouring is treated as a possible final wake.
For diagonal drift ``(m,-m)``, an actual final wake must be periodic under
``x -> x+m`` and contain exactly ``g`` black cells in each ``m``-column domain.
The script counts relaxed terminals satisfying that necessary condition for
``g in {4,8,12}`` and small ``m``.  A zero is meaningful only for diagonal
highways confined to this full eleven-line strip, hence only for transverse width
exactly ``W=10`` once the proved ``W>=10`` bound is used.  Wider diagonal highways
and non-diagonal drift remain outside the model.
"""
from __future__ import annotations

import argparse
from collections import Counter, deque


NORTH, EAST, SOUTH, WEST = range(4)
RIGHT = (EAST, SOUTH, WEST, NORTH)
LEFT = (WEST, NORTH, EAST, SOUTH)
TOP = 10
HEIGHT = TOP + 1
LEFT_ENTRIES = tuple(range(2, TOP + 1, 2))
RIGHT_ENTRIES = tuple(range(0, TOP, 2))
LOCAL_LOOP = object()


def cell_index(column: int, line: int) -> int:
    return HEIGHT * column + line


def advance_inside(columns: int, black: int, extreme_seen: int,
                   column: int, line: int, heading: int):
    local_states = set()
    visits = 0
    while True:
        state = (black, extreme_seen, column, line, heading)
        if state in local_states:
            return LOCAL_LOOP
        local_states.add(state)

        bit = 1 << cell_index(column, line)
        if line in (0, TOP):
            if extreme_seen & bit:
                return None
            extreme_seen |= bit

        was_black = bool(black & bit)
        black ^= bit
        heading = LEFT[heading] if was_black else RIGHT[heading]
        visits += 1

        if heading == EAST:
            column += 1
            line += 1
        elif heading == WEST:
            column -= 1
            line -= 1
        elif heading == NORTH:
            line += 1
        else:
            line -= 1

        if column < 0:
            return black, extreme_seen, "left", line, visits
        if column >= columns:
            return black, extreme_seen, "right", line, visits
        if not 0 <= line <= TOP:
            raise AssertionError((column, line, heading))


def periodic_weight(black: int, columns: int, period: int) -> int | None:
    """Return weight per period if the finite mask repeats, else ``None``."""
    if columns < 2 * period:
        return None
    for column in range(period, columns):
        for line in range(HEIGHT):
            here = bool(black & (1 << cell_index(column, line)))
            prior = bool(black & (1 << cell_index(column - period, line)))
            if here != prior:
                return None
    return sum(
        bool(black & (1 << cell_index(column, line)))
        for column in range(period)
        for line in range(HEIGHT)
    )


def explore(columns: int, max_states: int | None = None):
    initial = [(0, 0, entry, EAST) for entry in LEFT_ENTRIES]
    queue = deque(initial)
    seen = set(initial)
    terminal_events = 0
    terminal_masks = set()
    compatible_events = Counter()
    compatible_masks: dict[tuple[int, int], set[int]] = {
        (m, g): set() for g in (4, 8, 12) for m in range(1, min(6, g // 2) + 1)
    }
    transitions = rejected = local_loops = 0
    max_visits = 0

    while queue:
        if max_states is not None and len(seen) > max_states:
            return {
                "complete": False, "states": len(seen), "queued": len(queue),
                "columns": columns, "transitions": transitions,
                "terminal_events": terminal_events,
                "terminal_masks": len(terminal_masks),
                "rejected": rejected, "local_loops": local_loops,
                "max_visits": max_visits,
                "compatible_events": dict(sorted(compatible_events.items())),
                "compatible_masks": {
                    key: len(value)
                    for key, value in sorted(compatible_masks.items()) if value
                },
            }
        black, extreme_seen, line, heading = queue.popleft()
        column = 0 if heading == EAST else columns - 1
        result = advance_inside(
            columns, black, extreme_seen, column, line, heading
        )
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            rejected += 1
            continue

        black2, extreme2, side, _landing, visits = result
        max_visits = max(max_visits, visits)
        if side == "right":
            terminal_events += 1
            terminal_masks.add(black2)
            for key in compatible_masks:
                period, growth = key
                if periodic_weight(black2, columns, period) == growth:
                    compatible_events[key] += 1
                    compatible_masks[key].add(black2)
            entries = ((entry, WEST) for entry in RIGHT_ENTRIES)
        else:
            entries = ((entry, EAST) for entry in LEFT_ENTRIES)

        for entry, next_heading in entries:
            next_state = (black2, extreme2, entry, next_heading)
            transitions += 1
            if next_state not in seen:
                seen.add(next_state)
                queue.append(next_state)

    return {
        "complete": True,
        "columns": columns,
        "states": len(seen),
        "transitions": transitions,
        "terminal_events": terminal_events,
        "terminal_masks": len(terminal_masks),
        "rejected": rejected,
        "local_loops": local_loops,
        "max_visits": max_visits,
        "compatible_events": dict(sorted(compatible_events.items())),
        "compatible_masks": {
            key: len(value) for key, value in sorted(compatible_masks.items())
            if value
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--columns", type=int, default=8)
    parser.add_argument("--max-states", type=int, default=2_000_000)
    args = parser.parse_args()
    result = explore(args.columns, args.max_states or None)
    for key, value in result.items():
        print(f"{key}={value}")


if __name__ == "__main__":
    main()
