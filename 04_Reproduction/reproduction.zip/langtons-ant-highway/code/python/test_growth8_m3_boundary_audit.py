#!/usr/bin/env python3
"""Regression test for the three-lane growth-eight endpoint audit."""

from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("growth8_m3_boundary_audit.py")


class GrowthEightM3BoundaryAuditTest(unittest.TestCase):
    def test_width_four_empty_window_is_not_a_failed_check(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--max-width", "4"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        report = json.loads(completed.stdout)
        self.assertEqual(report["boundaries_tested"], 0)
        self.assertEqual(report["additive_survivors"], 0)
        self.assertEqual(report["period_residue_mod_8"], 6)
        self.assertTrue(report["all_checks_passed"])

    def test_known_window_keeps_exactly_the_compatible_boundaries(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--max-width", "16"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        report = json.loads(completed.stdout)
        self.assertEqual(report["boundaries_tested"], 54)
        self.assertEqual(report["additive_survivors"], 27)
        self.assertEqual(
            report.get("additive_survivor_period_residue_counts_mod_8"),
            {"6": 27},
        )
        self.assertEqual(report.get("even_checker_odd_classes"), 1)
        self.assertEqual(report.get("period_residue_mod_8"), 6)
        self.assertEqual(report["parity_flow_sign_counts"], [27, 0])
        self.assertEqual(report["joint_survivors"], 27)
        self.assertEqual(
            report["survivor_examples"][0],
            {
                "width": 6,
                "horizontal_level": 3,
                "vertical_level": 0,
                "parity_flow_sign": 0,
            },
        )
        self.assertTrue(report["all_checks_passed"])


if __name__ == "__main__":
    unittest.main()
