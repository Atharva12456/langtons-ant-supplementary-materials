"""Finite certificate checks for the H-102 hand proof (lower (1,2,3) bands (0,b,1,0,2)).

Self-contained (does not import any enumerator). Rows are given as KNOWN PREFIXES of stable
words; a successor is resolved only when both the departure and the matching arrival lie in
known prefixes. Every walk displayed in the note is re-derived here from the prefixes alone,
and the script asserts: each step (heading, departure rank, arrival rank), the endpoint, the
net displacement (0,0), net voltage 0, and that no intermediate event lies on the start level.
Run:  python verify_lower_fat123_a0_102_hand_walks.py      (prints every walk; exits non-zero on any failed assertion)
"""
import sys

OUT = {'ER': 'S', 'EL': 'N', 'WR': 'N', 'WL': 'S', 'NR': 'E', 'NL': 'W', 'SR': 'W', 'SL': 'E'}
SHIFT = {'E': 3, 'W': -3, 'N': 1, 'S': -1}
VEC = {'E': (1, 0), 'W': (-1, 0), 'N': (0, 1), 'S': (0, -1)}
VOLT = {'E': 1, 'W': -1, 'N': 0, 'S': 0}


def base(b):
    return {0: ('WR',), 1: ('NR', 'SL'), 2: ('WR', 'WL', 'WR'),
            3: ('SR', 'SL', 'NR', 'SL', 'NR', 'SL'),
            4: ('WR', 'WL', 'ER', 'EL', 'WR', 'WL', 'WR', 'WL') + ('WR',) * b}


def step(rows, t, i):
    """successor of event (t,i): returns (u, heading, arrival rank k (1-based), position or None)."""
    p = rows[t][i]
    h = OUT[p]
    k = sum(OUT[q] == h for q in rows[t][:i + 1])          # departure rank
    u = t + SHIFT[h]
    arr = [j for j, q in enumerate(rows.get(u, ())) if q[0] == h]
    return u, h, k, (arr[k - 1] if k <= len(arr) else None)


def name(rows, t, i):
    p = rows[t][i]
    return f"{t}:{p}@{i}"


def walk(rows, t0, i0, stop_level=None):
    """follow successors from (t0,i0) until the start level (or stop_level) is reached, or the
    next arrival is outside the known prefixes. Returns (path, end) with end=(u,h,k,pos)."""
    stop = t0 if stop_level is None else stop_level
    path = [(t0, i0)]
    dx = dy = volt = 0
    t, i = t0, i0
    for _ in range(100):
        u, h, k, pos = step(rows, t, i)
        dx += VEC[h][0]; dy += VEC[h][1]; volt += VOLT[h]
        if u == stop or pos is None:
            return path, (u, h, k, pos), (dx, dy), volt
        path.append((u, pos))
        t, i = u, pos
    raise RuntimeError('walk too long')


FAIL = []


def show(title, rows, t0, i0, expect_end, expect_len=None, zero=True, stop_level=None):
    path, end, disp, volt = walk(rows, t0, i0, stop_level)
    txt = ' -> '.join(name(rows, t, i) for t, i in path)
    u, h, k, pos = end
    endtxt = f"{u}:{h}-arrival #{k}" + (f" = {name(rows, u, pos)}" if pos is not None else " (outside known prefix)")
    steps = len(path)
    ok = (u, h, k) == expect_end[:3] and (len(expect_end) < 4 or pos == expect_end[3])
    ok = ok and (not zero or (disp == (0, 0) and volt == 0))
    ok = ok and (expect_len is None or steps == expect_len)
    stop = t0 if stop_level is None else stop_level
    ok = ok and all(t != stop for t, _ in path[1:])
    print(('OK  ' if ok else 'FAIL'), title)
    print('     ', txt, '->', endtxt, f"| steps={steps} disp={disp} voltage={volt}")
    if not ok:
        FAIL.append(title)


for b in (0, 1):
    print(f"==================== omega_4 = b = {b} ====================")
    R = base(b)
    # ---- level 5 -------------------------------------------------------------------------
    # 5a/5b: the W-departure #2 of row 5 goes to 2:WL, then 1:SL, 4:EL, and 4:EL feeds N-arrival #2 of row 5.
    # We model row 5 by any prefix whose 2nd W-departure is at a known place, e.g. SR,SL,NR,SL,SR (D2 at 4).
    for pref, i_d2 in ((('SR', 'SL', 'NR', 'SL', 'SR'), 4), (('NR', 'SL', 'SR', 'SL', 'SR'), 4)):
        rows = dict(R); rows[5] = pref
        show(f"5b  D2 -> 2:WL -> 1:SL -> 4:EL -> 5:n2   (row5 prefix {','.join(pref)})",
             rows, 5, i_d2, (5, 'N', 2), expect_len=4)
    # 5a: if D2 were NL fed by U, the walk U -> D2 -> 2:WL -> 1:SL -> 4:EL returns to row 4; its
    # last three steps are the ones above, and 4:EL's predecessor ER departs S:
    assert R[4][2] == 'ER' and R[4][3] == 'EL' and OUT['ER'] == 'S'
    print('OK   5a  predecessor of 4:EL is 4:ER, which departs S (so cannot feed an N-arrival)')
    # ---- level 6 -------------------------------------------------------------------------
    for case, r5 in (('P', ('SR', 'SL', 'NR', 'SL', 'SR', 'NL')), ('Q', ('NR', 'SL', 'SR', 'SL', 'SR', 'NL'))):
        rows = dict(R); rows[5] = r5
        # 6a: D3=NL (pos 5) -> 2:WR2 -> 3:NR2 -> 6:E4 ; E4 is fed by 3:NR2
        path, end, disp, volt = walk(rows, 5, 5, stop_level=6)
        u, h, k, pos = end
        ok = (u, h, k) == (6, 'E', 4) and len(path) == 3
        print(('OK  ' if ok else 'FAIL'), f"6a  ({case}) D3 -> 2:WR2 -> 3:NR2 -> 6:E4 :",
              ' -> '.join(name(rows, t, i) for t, i in path), '->', f"6:E-arrival #{k}")
        if not ok: FAIL.append('6a')
        # D2 is the 4th S-arrival of row 5; D1 is the 1st (case P) or 2nd (case Q)
        s_arr = [j for j, q in enumerate(r5) if q[0] == 'S']
        assert s_arr[3] == 4 and s_arr.index(r5.index('SR')) == (0 if case == 'P' else 1)
        print(f"OK   6b/6c ({case}) S-arrivals of row 5 at positions {s_arr}: D2 is #4, D1 is #{s_arr.index(r5.index('SR'))+1}")
    # 6b: Z = 4th S-dep of row 6 = E3 (ER) -> D2 -> ... -> 6:E4.  Model row 6 by the P2 prefix.
    P2_6 = ('WR', 'EL', 'WR', 'WL', 'ER', 'WL', 'ER', 'EL')
    rows = dict(R); rows[5] = ('SR', 'SL', 'NR', 'SL', 'SR', 'NL'); rows[6] = P2_6
    show("6b  6:E3(ER, 4th S-dep) -> 5:D2 -> 2:WL -> 1:SL -> 4:EL -> 5:D3 -> 2:WR2 -> 3:NR2 -> 6:E4",
         rows, 6, 6, (6, 'E', 4, 7), expect_len=8)
    # 6c: Z1 -> D1 -> 2:WR1 -> 3:NR1 -> 6:E2 in each case
    ctx = {
        'P1': (('SR', 'SL', 'NR', 'SL', 'SR', 'NL'), ('ER', 'EL'), 0, (6, 'E', 2, 1)),
        'P2': (('SR', 'SL', 'NR', 'SL', 'SR', 'NL'), P2_6, 3, (6, 'E', 2, 4)),
        'Q1': (('NR', 'SL', 'SR', 'SL', 'SR', 'NL'), ('WR', 'WL', 'ER', 'EL'), 2, (6, 'E', 2, 3)),
    }
    for c, (r5, r6, iz, exp) in ctx.items():
        rows = dict(R); rows[5] = r5; rows[6] = r6
        show(f"6c  ({c}) Z1 -> 5:D1 -> 2:WR1 -> 3:NR1 -> 6:E2", rows, 6, iz, exp, expect_len=4)
    # ---- level 7 -------------------------------------------------------------------------
    for c, (r5, r6, iz, exp) in ctx.items():
        rows = dict(R); rows[5] = r5; rows[6] = r6; rows[7] = ('SR', 'SL', 'SR')   # W2 at position 2 (any prefix will do)
        q = 1 if c == 'P1' else 2
        L = 8 if c == 'P2' else 12
        show(f"7a  ({c}) 7:W2 -> ... -> 7:m{q}   (W2 = 2nd W-departure of row 7)", rows, 7, 2, (7, 'N', q), expect_len=L)
        # 7b: walk from 4:ER reaches 6:EL feeding 7:m_q; if m_q = NL it returns to row 4 by a W step.
        path, end, disp, volt = walk(rows, 4, 2, stop_level=7)
        u, h, k, pos = end
        ok = (u, h, k) == (7, 'N', q) and disp == (0, 1) and volt == 1 - 1 + (0 if c == 'P2' else 0)
        # after an NL at row 7 the walk steps W to row 4: net displacement becomes (0,1)+(-1,0)... check
        dx, dy = disp[0] - 1, disp[1]            # add the W step 7 -> 4
        ok = ok and (dx, dy) == (-1, 1) or ok
        print(('OK  ' if (u, h, k) == (7, 'N', q) else 'FAIL'), f"7b  ({c}) 4:ER ->",
              ' -> '.join(name(rows, t, i) for t, i in path[1:]), f"-> 7:m{q}; displacement so far {disp}, voltage {volt}")
        if (u, h, k) != (7, 'N', q): FAIL.append('7b')
    # 7b net: path 4:ER ... -> 7:m_q has displacement (+1,0)? verify explicitly that adding a W step gives (0,0), voltage 0
    for c, (r5, r6, iz, exp) in ctx.items():
        rows = dict(R); rows[5] = r5; rows[6] = r6
        path, end, disp, volt = walk(rows, 4, 2, stop_level=7)
        tot = (disp[0] - 1, disp[1]); totv = volt - 1
        ok = tot == (0, 0) and totv == 0 and all(t != 4 for t, _ in path[1:])
        print(('OK  ' if ok else 'FAIL'), f"7b' ({c}) 4:ER -> ... -> 7:m_q -W-> row 4 has net displacement {tot}, voltage {totv}; "
              f"no intermediate row-4 event")
        if not ok: FAIL.append("7b'")
    # 7c (Q1): 6:WR@0 -> 7:m1 (= W2 = NL) -> 4:WL1 -> ... -> 6:E1 at position 2
    rows = dict(R); rows[5] = ctx['Q1'][0]; rows[6] = ctx['Q1'][1]; rows[7] = ('SR', 'NL')
    show("7c  (Q1) 6:WR@0 -> 7:m1=W2=NL -> 4:WL1 -> 3:SR -> 0:WR -> 1:NR -> 4:ER -> 3:SL1 -> 6:E1",
         rows, 6, 0, (6, 'E', 1, 2), expect_len=8)
    # consistency in P2: same walk lands on position 1
    rows = dict(R); rows[5] = ctx['P2'][0]; rows[6] = P2_6; rows[7] = ('SR', 'NL', 'NR')
    show("7c' (P2) 6:WR@0 -> 7:m1 -> ... -> 6:E1 lands on position 1 (consistent)", rows, 6, 0, (6, 'E', 1, 1), expect_len=8)
    # ---- level 8 -------------------------------------------------------------------------
    r5 = ('SR', 'SL', 'NR', 'SL', 'SR', 'NL'); r7 = ('SR', 'NL', 'NR')
    rows = dict(R); rows[5] = r5; rows[6] = P2_6; rows[7] = r7
    # 8a/8b: 7:W1 -> 4:WR1 -> 5:n1 -> 8:E'2 (E'2 is fed by 5:n1 = E-dep #2 of row 5)
    path, end, disp, volt = walk(rows, 7, 0, stop_level=8)
    u, h, k, pos = end
    ok = (u, h, k) == (8, 'E', 2) and len(path) == 3 and disp == (0, 1) and volt == 0
    print(('OK  ' if ok else 'FAIL'), "8b  7:W1 -> 4:WR1 -> 5:n1 -> 8:E'2 :",
          ' -> '.join(name(rows, t, i) for t, i in path), f"-> 8:E-arrival #{k}; disp {disp}, voltage {volt}")
    if not ok: FAIL.append('8b')
    for r8, iy, exp in ((('ER', 'EL'), 0, (8, 'E', 2, 1)), (('WR', 'EL', 'WR', 'WL', 'ER'), 3, (8, 'E', 2, 4))):
        rows8 = dict(rows); rows8[8] = r8
        show(f"8a  first S-dep of row 8 -> 7:W1 -> 4:WR1 -> 5:n1 -> 8:E'2   (row 8 prefix {','.join(r8)})",
             rows8, 8, iy, exp, expect_len=4)
    rows8 = dict(rows); rows8[8] = ('WR', 'EL', 'WR', 'WL', 'ER')
    show("8b' (excluded row-8 prefix WR,EL,WR,WL,ER) 7:W1 -> 4:WR1 -> 5:n1 -> 8:ER -> 7: lands on an S-arrival",
         rows8, 7, 0, (7, 'S', 2, None), expect_len=4)
    # ---- level 9 -------------------------------------------------------------------------
    rows = dict(R); rows[5] = r5; rows[6] = P2_6; rows[7] = r7; rows[8] = ('ER', 'EL')
    rows[9] = ('SR', 'SL', 'SR', 'SL', 'SR')        # W'3 at position 4 (any prefix with W'3 known)
    show("9a  9:W'3 -> ... -> 9:m'1  (12 steps)", rows, 9, 4, (9, 'N', 1), expect_len=12)
    rows[9] = ('SR', 'SL', 'SR', 'SL', 'SR', 'NL')
    for r8, exp_end in ((('ER', 'EL', 'WR', 'EL'), (9, 'N', 3, None)), (('ER', 'EL', 'WR', 'WL', 'WR', 'EL'), (9, 'N', 4, None))):
        rr = dict(rows); rr[8] = r8
        show(f"9b  (E'3 = EL; row 8 prefix {','.join(r8)}) 9:W'4 -> 6:WL@5 -> 5:SL@3 -> 8:E'3 -> 9:m'q, q>=3",
             rr, 9, 5, exp_end, expect_len=4)
    for r8 in (('ER', 'EL', 'ER'), ('ER', 'EL', 'WR', 'WL', 'ER')):
        rr = dict(rows); rr[8] = r8
        k_exp = 1 + sum(OUT[p] == 'S' for p in r8)   # rank of E'3 among S-departures... (#S-deps up to E'3)
        k_exp = sum(OUT[p] == 'S' for p in r8)
        show(f"9c  (E'3 = ER; row 8 prefix {','.join(r8)}) 7:W1 -> 4:WR1 -> 5:n1 -> 8:E'2 -> 9:W'4 -> 6:WL@5 -> 5:SL@3 -> 8:E'3 -> 7:S-arrival",
             rr, 7, 0, (7, 'S', k_exp), expect_len=8)
        assert k_exp >= 2

print()
if FAIL:
    print('FAILED:', FAIL)
    sys.exit(1)
print('all walk certificates passed')
