#!/usr/bin/env python3
"""Enumerate coarse residue data for every growth-eight drift orbit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


REPRESENTATIVES = (
    (1, -1),
    (2, 0),
    (2, -2),
    (1, 3),
    (1, -3),
    (3, -3),
    (4, 0),
    (2, 4),
    (2, -4),
    (4, -4),
)

EXPECTED_SUMMARY = {
    (1, -1): (4, (1, 3, 5, 7), (2, 6), ((8,),), ((8,),)),
    (2, 0): (20, (0, 2, 4, 6, 8), (0, 4), ((2, 6), (4, 4), (6, 2)), ()),
    (2, -2): (
        10,
        (0, 2, 4, 6, 8),
        (0, 4),
        ((2, 6), (4, 4), (6, 2)),
        ((2, 6), (4, 4), (6, 2)),
    ),
    (1, 3): (24, (1, 3, 5, 7), (2, 6), ((8,),), ((2, 2, 4), (2, 4, 2), (4, 2, 2))),
    (1, -3): (24, (1, 3, 5, 7), (2, 6), ((8,),), ((2, 2, 4), (2, 4, 2), (4, 2, 2))),
    (3, -3): (
        1440,
        (1, 3, 5, 7),
        (2, 6),
        ((2, 2, 4), (2, 4, 2), (4, 2, 2)),
        ((2, 2, 4), (2, 4, 2), (4, 2, 2)),
    ),
    (4, 0): (16, (0, 2, 4, 6, 8), (0, 4), ((2, 2, 2, 2),), ()),
    (2, 4): (8, (2, 6), (0,), ((2, 6), (6, 2)), ((2, 2, 2, 2),)),
    (2, -4): (8, (2, 6), (0,), ((2, 6), (6, 2)), ((2, 2, 2, 2),)),
    (4, -4): (34, (0, 4, 8), (0,), ((2, 2, 2, 2),), ((2, 2, 2, 2),)),
}


def rotations(vector: tuple[int, int]) -> set[tuple[int, int]]:
    a, b = vector
    return {(a, b), (-b, a), (-a, -b), (b, -a)}


def admissible_drifts() -> set[tuple[int, int]]:
    return {
        (a, b)
        for a in range(-4, 5)
        for b in range(-4, 5)
        if (a, b) != (0, 0) and (a - b) % 2 == 0
    }


def categories(a: int, b: int) -> list[tuple[int | None, int | None, int]]:
    ax, by = abs(a), abs(b)
    result = []
    for rx in range(ax) if ax else (None,):
        for ry in range(by) if by else (None,):
            for checker in (0, 1):
                x_parities = {rx % 2} if ax and ax % 2 == 0 else {0, 1}
                y_parities = {ry % 2} if by and by % 2 == 0 else {0, 1}
                if any((xp + yp) % 2 == checker for xp in x_parities for yp in y_parities):
                    result.append((rx, ry, checker))
    return result


def residue_patterns(a: int, b: int) -> dict[str, object]:
    ax, by = abs(a), abs(b)
    cats = categories(a, b)
    x_signed = [0] * ax
    y_signed = [0] * by
    x_count = [0] * ax
    y_count = [0] * by
    checker_counts: set[int] = set()
    period_residues: set[int] = set()
    x_margins: set[tuple[int, ...]] = set()
    y_margins: set[tuple[int, ...]] = set()
    joint_matrices: set[tuple[int, ...]] = set()
    joint = [0] * (ax * by)
    pattern_count = 0

    def visit(index: int, remaining: int, even_count: int) -> None:
        nonlocal pattern_count
        if index == len(cats):
            if remaining:
                return
            if any(value % 4 != 2 for value in x_signed):
                return
            if any(value % 4 != 2 for value in y_signed):
                return
            pattern_count += 1
            checker_counts.add(even_count)
            period_residues.add((2 * (-(a + b + even_count) % 4)) % 8)
            if ax:
                x_margins.add(tuple(x_count))
            if by:
                y_margins.add(tuple(y_count))
            if ax and by:
                joint_matrices.add(tuple(joint))
            return

        rx, ry, checker = cats[index]
        sign = 1 if checker == 0 else -1
        for multiplicity in range(remaining + 1):
            if rx is not None:
                x_signed[rx] += sign * multiplicity
                x_count[rx] += multiplicity
            if ry is not None:
                y_signed[ry] += sign * multiplicity
                y_count[ry] += multiplicity
            if rx is not None and ry is not None:
                joint[rx * by + ry] += multiplicity
            visit(
                index + 1,
                remaining - multiplicity,
                even_count + (multiplicity if checker == 0 else 0),
            )
            if rx is not None:
                x_signed[rx] -= sign * multiplicity
                x_count[rx] -= multiplicity
            if ry is not None:
                y_signed[ry] -= sign * multiplicity
                y_count[ry] -= multiplicity
            if rx is not None and ry is not None:
                joint[rx * by + ry] -= multiplicity

    visit(0, 8, 0)

    if ax and by:
        canonical_matrices = {
            min(
                tuple(
                    matrix[((rx + sx) % ax) * by + ((ry + sy) % by)]
                    for rx in range(ax)
                    for ry in range(by)
                )
                for sx in range(ax)
                for sy in range(by)
            )
            for matrix in joint_matrices
        }
    else:
        canonical_matrices = set()

    return {
        "drift": [a, b],
        "category_count": len(cats),
        "p22_patterns": pattern_count,
        "even_checker_counts": sorted(checker_counts),
        "period_residues_mod_8": sorted(period_residues),
        "x_count_margins": [list(row) for row in sorted(x_margins)],
        "y_count_margins": [list(row) for row in sorted(y_margins)],
        "joint_count_matrices": (
            [list(row) for row in sorted(joint_matrices)]
            if ax * by <= 4
            else {"count": len(joint_matrices)}
        ),
        "joint_count_types_up_to_translation": (
            [list(row) for row in sorted(canonical_matrices)]
            if ax * by <= 4
            else {"count": len(canonical_matrices)}
        ),
    }


def axis_exact_row_refinement(modulus: int) -> dict[str, object]:
    row_types = []
    for row_parity in (0, 1):
        for mask in range(1, 1 << modulus):
            signs = [
                1 if (residue + row_parity) % 2 == 0 else -1
                for residue in range(modulus)
                if mask & (1 << residue)
            ]
            if sum(signs) % 4 == 0:
                row_types.append((row_parity, mask))

    residue_count = [0] * modulus
    residue_signed = [0] * modulus
    even_count = 0
    pattern_count = 0
    even_counts: set[int] = set()
    margins: set[tuple[int, ...]] = set()
    row_counts: set[int] = set()
    row_parity_counts: set[tuple[int, int]] = set()

    def visit(index: int, remaining: int, rows: int, parity_rows: list[int]) -> None:
        nonlocal even_count, pattern_count
        if index == len(row_types):
            if remaining or any(value % 4 != 2 for value in residue_signed):
                return
            pattern_count += 1
            even_counts.add(even_count)
            margins.add(tuple(residue_count))
            row_counts.add(rows)
            row_parity_counts.add(tuple(parity_rows))
            return

        row_parity, mask = row_types[index]
        size = mask.bit_count()
        for multiplicity in range(remaining // size + 1):
            added_even = 0
            for residue in range(modulus):
                if not mask & (1 << residue):
                    continue
                sign = 1 if (residue + row_parity) % 2 == 0 else -1
                residue_count[residue] += multiplicity
                residue_signed[residue] += sign * multiplicity
                if sign == 1:
                    added_even += multiplicity
            even_count += added_even
            parity_rows[row_parity] += multiplicity
            visit(
                index + 1,
                remaining - size * multiplicity,
                rows + multiplicity,
                parity_rows,
            )
            parity_rows[row_parity] -= multiplicity
            even_count -= added_even
            for residue in range(modulus):
                if not mask & (1 << residue):
                    continue
                sign = 1 if (residue + row_parity) % 2 == 0 else -1
                residue_count[residue] -= multiplicity
                residue_signed[residue] -= sign * multiplicity

    visit(0, 8, 0, [0, 0])
    return {
        "drift": [modulus, 0],
        "abstract_row_multisets": pattern_count,
        "even_checker_counts": sorted(even_counts),
        "x_count_margins": [list(row) for row in sorted(margins)],
        "occupied_row_counts": sorted(row_counts),
        "occupied_row_parity_counts": [
            list(row) for row in sorted(row_parity_counts)
        ],
        "period_residues_mod_8": sorted(
            {(2 * (-(modulus + value) % 4)) % 8 for value in even_counts}
        ),
    }


def audit() -> dict[str, object]:
    expected = admissible_drifts()
    orbits = [rotations(rep) for rep in REPRESENTATIVES]
    covered = set().union(*orbits)
    overlaps = [
        [i, j]
        for i in range(len(orbits))
        for j in range(i + 1, len(orbits))
        if orbits[i] & orbits[j]
    ]
    problems = []
    if covered != expected:
        problems.append(
            {
                "missing": sorted(expected - covered),
                "extra": sorted(covered - expected),
            }
        )
    if overlaps:
        problems.append({"overlapping_orbits": overlaps})

    cases = [residue_patterns(a, b) for a, b in REPRESENTATIVES]
    if any(case["p22_patterns"] == 0 for case in cases):
        problems.append("a listed orbit has no coarse P22 pattern")
    for case in cases:
        drift = tuple(case["drift"])
        actual = (
            case["p22_patterns"],
            tuple(case["even_checker_counts"]),
            tuple(case["period_residues_mod_8"]),
            tuple(tuple(row) for row in case["x_count_margins"]),
            tuple(tuple(row) for row in case["y_count_margins"]),
        )
        if actual != EXPECTED_SUMMARY[drift]:
            problems.append({"unexpected_case_summary": drift, "actual": actual})

    diagonal_two = next(case for case in cases if case["drift"] == [2, -2])
    expected_types = ((0, 2, 2, 4), (0, 2, 6, 0), (1, 3, 3, 1))
    actual_types = tuple(
        tuple(row) for row in diagonal_two["joint_count_types_up_to_translation"]
    )
    if actual_types != expected_types:
        problems.append({"unexpected_(2,-2)_types": actual_types})

    axis_refinements = [axis_exact_row_refinement(2), axis_exact_row_refinement(4)]
    axis_expected = {
        2: ((4,), ((4, 4),), (4,), ((1, 3), (3, 1)), (4,)),
        4: ((4,), ((2, 2, 2, 2),), (2, 3, 4), ((0, 2), (0, 3), (0, 4), (2, 0), (2, 2), (3, 0), (4, 0)), (0,)),
    }
    for refinement in axis_refinements:
        modulus = refinement["drift"][0]
        actual = (
            tuple(refinement["even_checker_counts"]),
            tuple(tuple(row) for row in refinement["x_count_margins"]),
            tuple(refinement["occupied_row_counts"]),
            tuple(tuple(row) for row in refinement["occupied_row_parity_counts"]),
            tuple(refinement["period_residues_mod_8"]),
        )
        if actual != axis_expected[modulus]:
            problems.append({"unexpected_axis_refinement": modulus, "actual": actual})

    return {
        "schema": "langton-growth8-residue-case-ledger-v1",
        "scope": "heading reset, strand-density bound, nonzero-coordinate P22 residue clauses, exact-row axis refinement, and period congruence",
        "admissible_drift_vectors": len(expected),
        "quarter_turn_orbits": len(orbits),
        "cases": cases,
        "axis_exact_row_refinements": axis_refinements,
        "problems": problems,
        "all_checks_passed": not problems,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit()
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    if not result["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
