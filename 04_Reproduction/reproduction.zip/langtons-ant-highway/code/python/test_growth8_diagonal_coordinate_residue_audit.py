from __future__ import annotations

import unittest

import growth8_diagonal_coordinate_residue_audit as audit


class DiagonalCoordinateResidueAuditTest(unittest.TestCase):
    def test_zero_component_uses_exact_coordinate_lines(self) -> None:
        direct = audit.direct_coordinate_audit("RRLL")

        self.assertEqual(direct["drift"], [2, 0])
        self.assertEqual(direct["x_fibres"], [0, 1])
        self.assertEqual(direct["y_fibres"], [-1, 0])
        self.assertTrue(direct["t3_column_parity"])
        self.assertTrue(direct["t4_row_parity"])
        self.assertTrue(direct["left_turn_fibre_parities_hold"])

    def test_standard_highway_and_growth8_boundaries(self) -> None:
        report = audit.audit(max_width=30)

        standard = report["standard_highway"]
        self.assertEqual(standard["drift"], [2, -2])
        self.assertEqual(standard["x_visit_counts"], [52, 52])
        self.assertEqual(standard["x_odd_class_counts"], [6, 6])
        self.assertEqual(standard["x_left_turn_counts"], [23, 23])
        self.assertTrue(standard["coordinate_congruences_hold"])
        self.assertGreater(report["general_kinematic_words_checked"], 1000)
        self.assertEqual(report["general_kinematic_failures"], 0)

        m3 = report["growth8_m3_boundary"]
        self.assertEqual(m3["additive_survivors"], 185)
        self.assertEqual(m3["coordinate_law_survivors"], 185)
        by_width = {row["width"]: row for row in m3["period_bounds"]}
        self.assertEqual(by_width[10]["minimum"], 54)
        self.assertEqual(by_width[10]["maximum"], 54)
        self.assertEqual(by_width[30]["minimum"], 134)
        self.assertEqual(by_width[30]["maximum"], 230)

        m4 = report["growth8_m4_skeleton"]
        self.assertTrue(m4["coordinate_law_feasible"])
        self.assertTrue(report["all_checks_passed"])


if __name__ == "__main__":
    unittest.main()
