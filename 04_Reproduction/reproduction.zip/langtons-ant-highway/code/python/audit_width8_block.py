"""Deterministic cross-audit of the relaxed width-eight block obstruction."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from verify_width8_block_indep import verify_relaxed
from width8_block_exclusion import explore_relaxed


ROOT = Path(__file__).resolve().parents[2]
CERTIFICATE = ROOT / "results" / "width8_block_certificate.json"
EXPECTED = {
    6: {
        "states": 71400, "transitions": 136392, "terminals": 18250,
        "rejected": 37302, "max_local_visits": 90,
        "exits": {
            "left:0": 2901, "left:2": 4554, "left:4": 4647,
            "left:6": 3746, "right:2": 5668, "right:4": 4495,
            "right:6": 4435, "right:8": 3652,
        },
    },
    7: {
        "states": 24712, "transitions": 46924, "terminals": 1188,
        "rejected": 12981, "max_local_visits": 90,
        "exits": {
            "left:0": 1600, "left:2": 3104, "left:4": 3128,
            "left:6": 2711, "right:2": 792, "right:4": 264,
            "right:8": 132,
        },
    },
    8: {
        "states": 20320, "transitions": 42004, "terminals": 0,
        "rejected": 9819, "max_local_visits": 90,
        "exits": {
            "left:0": 1586, "left:2": 3090, "left:4": 3114,
            "left:6": 2711,
        },
    },
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized_primary(columns: int):
    result = explore_relaxed(columns)
    assert result["terminal_events"] == result["terminal_states"], result
    return {
        "states": result["states"],
        "transitions": result["transitions"],
        "terminals": result["terminal_events"],
        "rejected": result["invalid_extreme"],
        "local_loops": result["local_loops"],
        "max_local_visits": result["max_cell_visits_between_outer_crossings"],
        "exits": {
            f"{side}:{line}": count
            for (side, line), count in sorted(result["exit_counts"].items())
        },
    }


def normalized_independent(columns: int):
    result = verify_relaxed(columns)
    assert result["terminal_events"] == result["terminal_states"], result
    return {
        "states": result["states"],
        "transitions": result["transitions"],
        "terminals": result["terminal_events"],
        "rejected": result["rejected"],
        "local_loops": result["local_loops"],
        "max_local_visits": result["max_local_visits"],
        "exits": {
            f"{side}:{line}": count
            for (side, line), count in sorted(result["exits"].items())
        },
    }


def main():
    certificate = json.loads(CERTIFICATE.read_text(encoding="utf-8"))
    assert certificate["schema"] == "langton-width8-eight-column-v1"
    rows = {}
    for columns, expected_without_loops in EXPECTED.items():
        expected = dict(expected_without_loops, local_loops=0)
        primary = normalized_primary(columns)
        independent = normalized_independent(columns)
        assert primary == expected, (columns, "primary", primary, expected)
        assert independent == expected, (
            columns, "independent", independent, expected
        )
        rows[str(columns)] = expected

    for entry in certificate["independent_enumerators"]:
        path = ROOT / entry["path"]
        assert sha256(path) == entry["sha256"], (path, sha256(path), entry)
    audit = certificate["cross_audit"]
    assert sha256(ROOT / audit["path"]) == audit["sha256"], audit
    assert audit["all_checks_passed"] is True
    assert certificate["certified_rows"] == rows

    row8 = rows["8"]
    local = certificate["local_lemma"]
    assert local["columns"] == 8
    assert local["reachable_boundary_states"] == row8["states"]
    assert local["nondeterministic_return_transitions"] == row8["transitions"]
    assert local["repeated_extremal_rejections"] == row8["rejected"]
    assert local["confined_local_cycles"] == row8["local_loops"]
    assert local["maximum_cell_visits_between_outer_crossings"] == row8["max_local_visits"]
    assert local["exit_counts"] == row8["exits"]
    assert local["right_exit_terminals"] == row8["terminals"]
    controls = certificate["positive_controls"]
    assert controls["six_columns_right_exit_terminals"] == rows["6"]["terminals"]
    assert controls["seven_columns_right_exit_terminals"] == rows["7"]["terminals"]

    print(json.dumps({
        "schema": certificate["schema"],
        "all_checks_passed": True,
        "scope": "flag-free arbitrary-outer-return width-eight block reachability",
        "rows": rows,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
