#!/usr/bin/env python3
"""Regression test for the odd-skew lifted-rank condition."""

from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("growth8_odd_skew_rank_parity_audit.py")


class GrowthEightOddSkewRankParityAuditTest(unittest.TestCase):
    def test_direct_flows_match_the_interlacing_formula(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--maximum-index", "3"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        report = json.loads(completed.stdout)
        for row in report["orientations"]:
            self.assertEqual(row["boundaries_checked"], 1944)
            self.assertEqual(row["rank_sign_counts"], [824, 1120])
            self.assertEqual(row["rank_survivors"], 824)
        self.assertTrue(report["all_checks_passed"])


if __name__ == "__main__":
    unittest.main()
