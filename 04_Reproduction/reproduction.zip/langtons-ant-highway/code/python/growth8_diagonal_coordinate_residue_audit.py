#!/usr/bin/env python3
"""Audit the coordinate-fibre consequences of the line-parity laws.

For drift ``(a,b)``, a coordinate is read modulo the absolute value of its
nonzero drift component.  If the component is zero, the fibres are the exact
coordinate lines instead.  The reversal identities imply that a fibre contains
an odd number of left turns precisely when its drift component is nonzero.  If
the stabilized word in each translation class starts with R and alternates,
this is equivalent to

    visits(fibre) - odd_classes(fibre) = 2 * [component != 0] (mod 4).

The code checks the direct identity on the standard highway and tests the new
congruences together with the transverse and longitudinal laws on two existing
growth-eight boundary models.  Boundary feasibility is only a regression check;
the line-parity proof is the all-period argument.
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Callable
from collections import Counter, defaultdict
from itertools import product
from pathlib import Path

from explore_chronology import STD, classes_of, walk


Vertex = tuple[int, int]


def coordinate_fibres(
    values: list[int], component: int
) -> tuple[list[int], Callable[[int], int]]:
    if component:
        modulus = abs(component)
        return list(range(modulus)), lambda value: value % modulus
    fibres = sorted(set(values))
    return fibres, lambda value: value


def direct_coordinate_audit(word: str) -> dict[str, object]:
    positions, _arrivals, heading, drift = walk(word)
    if heading != 0 or drift == (0, 0):
        raise ValueError("word must reset its heading and have nonzero drift")
    period = len(word)
    x_fibres, x_key = coordinate_fibres([x for x, _y in positions], drift[0])
    y_fibres, y_key = coordinate_fibres([y for _x, y in positions], drift[1])

    odd_x = Counter()
    odd_y = Counter()
    for phases in classes_of(positions, drift):
        if len(phases) & 1:
            x, y = positions[phases[0]]
            odd_x[x_key(x)] += 1
            odd_y[y_key(y)] += 1

    visits_x = Counter(x_key(x) for x, _y in positions)
    visits_y = Counter(y_key(y) for _x, y in positions)
    left_x = Counter(
        x_key(positions[phase][0])
        for phase, turn in enumerate(word)
        if turn == "L"
    )
    left_y = Counter(
        y_key(positions[phase][1])
        for phase, turn in enumerate(word)
        if turn == "L"
    )

    equal_vertical = Counter()
    horizontal_landings = Counter()
    equal_horizontal = Counter()
    vertical_landings = Counter()
    for phase, (x, y) in enumerate(positions):
        if phase + 1 < period:
            next_x, next_y = positions[phase + 1]
        else:
            next_x = positions[0][0] + drift[0]
            next_y = positions[0][1] + drift[1]
        next_turn = word[(phase + 1) % period]
        if next_x == x:
            equal_vertical[x_key(x)] += word[phase] == next_turn
            vertical_landings[y_key(next_y)] += 1
        else:
            equal_horizontal[y_key(y)] += word[phase] == next_turn
            horizontal_landings[x_key(next_x)] += 1

    x_reversal = int(drift[0] != 0)
    y_reversal = int(drift[1] != 0)
    t3 = all(
        equal_vertical[fibre] % 2
        == (horizontal_landings[fibre] + x_reversal) % 2
        for fibre in x_fibres
    )
    t4 = all(
        equal_horizontal[fibre] % 2
        == (vertical_landings[fibre] + y_reversal) % 2
        for fibre in y_fibres
    )
    left_parities = all(
        left_x[fibre] % 2 == x_reversal for fibre in x_fibres
    ) and all(left_y[fibre] % 2 == y_reversal for fibre in y_fibres)
    congruences = all(
        (visits_x[fibre] - odd_x[fibre]) % 4 == 2 * x_reversal
        for fibre in x_fibres
    ) and all(
        (visits_y[fibre] - odd_y[fibre]) % 4 == 2 * y_reversal
        for fibre in y_fibres
    )
    return {
        "period": period,
        "growth": word.count("R") - word.count("L"),
        "drift": list(drift),
        "x_fibres": x_fibres,
        "y_fibres": y_fibres,
        "x_visit_counts": [visits_x[fibre] for fibre in x_fibres],
        "y_visit_counts": [visits_y[fibre] for fibre in y_fibres],
        "x_odd_class_counts": [odd_x[fibre] for fibre in x_fibres],
        "y_odd_class_counts": [odd_y[fibre] for fibre in y_fibres],
        "x_left_turn_counts": [left_x[fibre] for fibre in x_fibres],
        "y_left_turn_counts": [left_y[fibre] for fibre in y_fibres],
        "t3_column_parity": t3,
        "t4_row_parity": t4,
        "left_turn_fibre_parities_hold": left_parities,
        "coordinate_congruences_hold": congruences,
    }


def audit_general_kinematics(max_period: int = 14) -> dict[str, int]:
    checked = 0
    failures = 0
    for period in range(2, max_period + 1, 2):
        for turns in product("LR", repeat=period):
            word = "".join(turns)
            _positions, _arrivals, heading, drift = walk(word)
            if heading != 0 or drift == (0, 0):
                continue
            checked += 1
            direct = direct_coordinate_audit(word)
            if not (
                direct["t3_column_parity"]
                and direct["t4_row_parity"]
                and direct["left_turn_fibre_parities_hold"]
            ):
                failures += 1
    return {
        "maximum_period": max_period,
        "words_checked": checked,
        "failures": failures,
    }


def parity_system(
    modulus: int, low: int, high: int, odd_classes: set[Vertex]
) -> tuple[bool, int]:
    """Solve the mod-four line laws after writing multiplicity=o+2z."""
    variables = [
        (level, lane)
        for level in range(low, high + 1)
        for lane in range(modulus)
    ]
    index = {variable: position for position, variable in enumerate(variables)}
    rows: list[int] = []

    omega_t = Counter(level for level, _lane in odd_classes)
    omega_u = Counter(
        (2 * lane - level) % (2 * modulus)
        for level, lane in odd_classes
    )

    def add(selected: list[Vertex], right: int) -> None:
        coefficients = sum(1 << index[variable] for variable in selected)
        rows.append(coefficients | ((right & 1) << len(variables)))

    # T1: odd levels are horizontal-arrival levels.
    for level in range(low, high + 1):
        right = omega_t[level] if level % 2 == 0 else 0
        add([(level, lane) for lane in range(modulus)], right)

    # T3/T4 coordinate residues.
    for residue in range(modulus):
        add(
            [(level, residue) for level in range(low, high + 1)],
            1,
        )
        add(
            [
                (level, lane)
                for level in range(low, high + 1)
                for lane in range(modulus)
                if (level - lane) % modulus == residue
            ],
            1,
        )

    # T2 longitudinal residues u=2r-t (mod 2m).
    for residue in range(2 * modulus):
        right = 1 if residue % 2 == 0 else 1 + omega_u[residue]
        add(
            [
                (level, lane)
                for level in range(low, high + 1)
                for lane in range(modulus)
                if (2 * lane - level) % (2 * modulus) == residue
            ],
            right,
        )

    rank = 0
    for column in range(len(variables)):
        pivot = next(
            (
                row
                for row in range(rank, len(rows))
                if (rows[row] >> column) & 1
            ),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for row in range(len(rows)):
            if row != rank and ((rows[row] >> column) & 1):
                rows[row] ^= rows[rank]
        rank += 1

    coefficient_mask = (1 << len(variables)) - 1
    inconsistent = any(
        (row & coefficient_mask) == 0
        and ((row >> len(variables)) & 1)
        for row in rows
    )
    return not inconsistent, len(variables) - rank


def audit_m3_boundary(max_width: int) -> dict[str, object]:
    tested = 0
    survivors = 0
    nullities: list[int] = []
    period_bounds: dict[int, list[int]] = defaultdict(list)
    for width in range(4, max_width + 1, 2):
        top = width - 1
        for horizontal in range(1, top, 2):
            for vertical in range(0, top, 2):
                if (horizontal - vertical) % 3:
                    continue
                if ((vertical - horizontal) // 3 - (width + 1)) % 4:
                    continue
                tested += 1
                k_value = (vertical - horizontal) // 3
                omega = Counter({-1: 3, top: 3, horizontal: 1, vertical: 1})
                prior_cut = 0
                cut_sum = 0
                for level in range(-1, top):
                    level_target = (
                        omega[level] if level % 2 else -omega[level]
                    ) % 4
                    cut_residue = (level_target - prior_cut) % 4
                    cut_sum += 4 if cut_residue == 0 else cut_residue
                    prior_cut = cut_residue
                top_target = (omega[top] if top % 2 else -omega[top]) % 4
                assert prior_cut == top_target
                period_bound = 2 * cut_sum
                assert period_bound == 4 * width + 12 * abs(k_value) + 2
                period_bounds[width].append(period_bound)
                odd = (
                    {(-1, lane) for lane in range(3)}
                    | {(top, lane) for lane in range(3)}
                    | {(horizontal, 0), (vertical, 0)}
                )
                feasible, nullity = parity_system(3, -1, top, odd)
                if feasible:
                    survivors += 1
                    nullities.append(nullity)
    return {
        "maximum_width": max_width,
        "additive_survivors": tested,
        "coordinate_law_survivors": survivors,
        "minimum_nullity": min(nullities) if nullities else None,
        "maximum_nullity": max(nullities) if nullities else None,
        "period_bound_formula": "N >= 4W+12|k|+2",
        "period_bounds": [
            {
                "width": width,
                "placements": len(values),
                "minimum": min(values),
                "maximum": max(values),
            }
            for width, values in sorted(period_bounds.items())
        ],
    }


def audit_m4_skeleton() -> dict[str, object]:
    odd = {
        (1, 3),
        (3, 2),
        (5, 0),
        (5, 1),
        (7, 0),
        (7, 3),
        (9, 2),
        (11, 1),
    }
    feasible, nullity = parity_system(4, 1, 11, odd)
    return {
        "width": 10,
        "period_of_recorded_skeleton": 64,
        "coordinate_law_feasible": feasible,
        "parity_system_nullity": nullity,
    }


def audit(max_width: int = 30) -> dict[str, object]:
    if max_width < 4 or max_width % 2:
        raise ValueError("max_width must be even and at least four")
    standard = direct_coordinate_audit(STD)
    general = audit_general_kinematics()
    m3 = audit_m3_boundary(max_width)
    m4 = audit_m4_skeleton()
    return {
        "schema": "langton-growth8-coordinate-fibre-audit-v2",
        "status": "bounded_evidence_not_proof",
        "coordinate_law": (
            "visits(fibre)-odd_classes(fibre)="
            "2*[drift component is nonzero] (mod 4)"
        ),
        "general_kinematic_maximum_period": general["maximum_period"],
        "general_kinematic_words_checked": general["words_checked"],
        "general_kinematic_failures": general["failures"],
        "standard_highway": standard,
        "growth8_m3_boundary": m3,
        "growth8_m4_skeleton": m4,
        "all_checks_passed": (
            standard["t3_column_parity"]
            and standard["t4_row_parity"]
            and standard["left_turn_fibre_parities_hold"]
            and standard["coordinate_congruences_hold"]
            and general["failures"] == 0
            and m3["additive_survivors"] == m3["coordinate_law_survivors"]
            and m4["coordinate_law_feasible"]
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-width", type=int, default=30)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = audit(args.max_width)
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
