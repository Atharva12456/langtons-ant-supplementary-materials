"""Exact top-boundary check for the primitive-growth-four cap-five lemma.

Depth is measured downward from the singleton top rail while the original
longitudinal coordinate x is retained.  Consequently a nonroot node at depth d
has self voltage (-1)^(d+1), and entering a child changes x by -1 at odd d and
by 0 at even d.  Stable events are still sorted by decreasing x.
"""

from fractions import Fraction
from itertools import combinations, product


def add(left, right):
    return left[0] + right[0], left[1] + right[1]


def sub(left, right):
    return left[0] - right[0], left[1] - right[1]


def val(line, parameter):
    return line[0] * parameter + line[1]


def top_self(depth):
    return -1 if depth % 2 == 0 else 1


def degree_rows(nodes, children, nonleaves):
    for support_tuple in combinations(range(nodes), nonleaves):
        support = frozenset(support_tuple)

        def rec(index, remaining, row):
            if index == nodes:
                if remaining == 0:
                    yield tuple(row)
                return
            if index not in support:
                yield from rec(index + 1, remaining, row + [0])
                return
            later = sum(position > index for position in support)
            for degree in range(1, remaining - later + 1):
                yield from rec(index + 1, remaining - degree, row + [degree])

        yield from rec(0, children, [])


def level_data(nodes, children, depth):
    wake = (nodes + children) & 1
    numerator = nodes + children + (wake if depth & 1 else -wake)
    if numerator % 4:
        return None
    nonleaves = numerator // 4
    if not 1 <= nonleaves <= min(nodes, children):
        return None
    return wake, nonleaves


def build_tree(degree_rows_by_depth, terminal_voltages):
    terminal_depth = len(degree_rows_by_depth) + 1
    voltages = {terminal_depth: list(terminal_voltages)}
    for depth in range(terminal_depth - 1, 0, -1):
        children = voltages[depth + 1]
        cursor = 0
        row = []
        for degree in degree_rows_by_depth[depth - 1]:
            total = (0, top_self(depth))
            for child in children[cursor:cursor + degree]:
                total = add(total, child)
            cursor += degree
            row.append(total)
        assert cursor == len(children)
        voltages[depth] = row

    bases = {1: [(0, 0)]}
    for depth, degrees in enumerate(degree_rows_by_depth, 1):
        children = voltages[depth + 1]
        cursor = 0
        next_bases = []
        shift = -1 if depth & 1 else 0
        for base, degree in zip(bases[depth], degrees):
            position = add(base, (0, shift))
            for _ in range(degree):
                next_bases.append(position)
                position = add(position, children[cursor])
                cursor += 1
        assert cursor == len(children)
        bases[depth + 1] = next_bases
    return voltages, bases


def affine_tree(degree_rows_by_depth, leaves):
    terminal_depth = len(degree_rows_by_depth) + 1
    terminal_count = sum(degree_rows_by_depth[-1])
    leaf_voltage = top_self(terminal_depth)
    variables = [node for node in range(terminal_count) if node not in leaves]

    provisional = [
        (0, leaf_voltage if node in leaves else 0)
        for node in range(terminal_count)
    ]
    provisional_voltages, _ = build_tree(degree_rows_by_depth, provisional)
    required_sum = 1 - provisional_voltages[1][0][1]

    if not variables:
        if required_sum:
            return None
        terminal = [(0, leaf_voltage)] * terminal_count
    elif len(variables) == 1:
        terminal = [
            (0, leaf_voltage if node in leaves else required_sum)
            for node in range(terminal_count)
        ]
    else:
        assert len(variables) == 2
        first, second = variables
        terminal = []
        for node in range(terminal_count):
            if node in leaves:
                terminal.append((0, leaf_voltage))
            elif node == first:
                terminal.append((1, 0))
            else:
                assert node == second
                terminal.append((-1, required_sum))

    voltages, bases = build_tree(degree_rows_by_depth, terminal)
    assert voltages[1][0] == (0, 1)
    return voltages, bases


def row_events(depth, degrees, bases, child_voltages):
    endpoint = "R" if depth & 1 else "L"
    middle = "L" if depth & 1 else "R"
    cursor = phase = 0
    events = []
    for base, degree in zip(bases, degrees):
        if degree == 0:
            events.append((base, phase, middle))
            phase += 1
            continue
        position = base
        events.append((position, phase, endpoint))
        phase += 1
        for child_number in range(degree):
            position = add(position, child_voltages[cursor])
            cursor += 1
            turn = endpoint if child_number + 1 == degree else middle
            events.append((position, phase, turn))
            phase += 1
    assert cursor == len(child_voltages)
    return events


def integer_samples(lines):
    roots = set()
    for left, right in combinations(lines, 2):
        slope = left[0] - right[0]
        if slope:
            roots.add(Fraction(right[1] - left[1], slope))
    roots = sorted(roots)
    samples = {0}
    for root in roots:
        floor = root.numerator // root.denominator
        samples.update((floor - 1, floor, floor + 1, floor + 2))
    for left, right in zip(roots, roots[1:]):
        candidate = left.numerator // left.denominator + 1
        if left < candidate < right:
            samples.add(candidate)
    if roots:
        samples.add(roots[0].numerator // roots[0].denominator - 2)
        samples.add(roots[-1].numerator // roots[-1].denominator + 2)
    return sorted(samples)


def alternating(length):
    return "RL" * (length // 2) + ("R" if length & 1 else "")


def subsequence(fixed, target):
    cursor = 0
    for symbol in fixed:
        cursor = target.find(symbol, cursor)
        if cursor < 0:
            return False
        cursor += 1
    return True


def inspect_skeleton(degrees_by_depth, leaves, next_children):
    tree = affine_tree(degrees_by_depth, leaves)
    if tree is None:
        return set(), []
    voltages, bases = tree
    terminal_depth = len(degrees_by_depth) + 1
    earlier = [
        row_events(depth, degrees, bases[depth], voltages[depth + 1])
        for depth, degrees in enumerate(degrees_by_depth, 1)
    ]

    endpoint = "R" if terminal_depth & 1 else "L"
    leaf_turn = "L" if terminal_depth & 1 else "R"
    fixed = []
    for node, (base, voltage) in enumerate(
        zip(bases[terminal_depth], voltages[terminal_depth])
    ):
        if node in leaves:
            fixed.append((base, 2 * node, leaf_turn))
        else:
            finish = sub(add(base, voltage), (0, top_self(terminal_depth)))
            fixed.append((base, 2 * node, endpoint))
            fixed.append((finish, 2 * node + 1, endpoint))

    lines = [event[0] for row in earlier for event in row]
    lines.extend(event[0] for event in fixed)
    regimes = set()
    survivors = []
    target = alternating(5 + next_children)
    for parameter in integer_samples(lines):
        if any(
            "".join(
                event[2]
                for event in sorted(
                    row, key=lambda event: (-val(event[0], parameter), event[1])
                )
            )
            != alternating(len(row))
            for row in earlier
        ):
            continue
        fixed_word = "".join(
            event[2]
            for event in sorted(
                fixed, key=lambda event: (-val(event[0], parameter), event[1])
            )
        )
        record = (
            tuple(val(line, parameter) for line in bases[terminal_depth]),
            tuple(val(line, parameter) for line in voltages[terminal_depth]),
            fixed_word,
            target,
        )
        regimes.add(record)
        if subsequence(fixed_word, target):
            survivors.append((parameter, record))
    return regimes, survivors


def main():
    skeletons = 0
    regimes = set()
    survivors = []
    for earliest in (2, 3, 4):
        for cuts in product(range(1, 6), repeat=earliest):
            if cuts[-1] != 5 or 5 in cuts[:-1]:
                continue
            nodes = 1
            even_wakes = odd_wakes = 0
            choices = []
            for depth, children in enumerate(cuts, 1):
                data = level_data(nodes, children, depth)
                if data is None:
                    break
                wake, nonleaves = data
                even_wakes += wake if depth % 2 == 0 else 0
                odd_wakes += wake if depth % 2 == 1 else 0
                if even_wakes > 1 or odd_wakes > 1:
                    break
                choices.append(tuple(degree_rows(nodes, children, nonleaves)))
                nodes = children
            else:
                terminal_depth = earliest + 1
                for rows in product(*choices):
                    for next_children in range(1, 6):
                        data = level_data(5, next_children, terminal_depth)
                        if data is None:
                            continue
                        wake, next_nonleaves = data
                        ew = even_wakes + (wake if terminal_depth % 2 == 0 else 0)
                        ow = odd_wakes + (wake if terminal_depth % 2 == 1 else 0)
                        if ew > 1 or ow > 1:
                            continue
                        leaf_count = 5 - next_nonleaves
                        if leaf_count < 3:
                            continue
                        for leaf_tuple in combinations(range(5), leaf_count):
                            skeletons += 1
                            found, hits = inspect_skeleton(
                                rows, frozenset(leaf_tuple), next_children
                            )
                            regimes.update(
                                (cuts, next_children) + regime for regime in found
                            )
                            survivors.extend(hits)

    expected = {
        (
            (3, 5),
            2,
            (-2, -1, 0, 1, -1),
            (2, 1, 1, -2, 1),
            "RLRLLRR",
            "RLRLRLR",
        ),
        (
            (3, 5),
            3,
            (-2, -1, 0, 1, -1),
            (2, 1, 1, -2, 1),
            "RLRLLRR",
            "RLRLRLRL",
        ),
    }
    assert skeletons == 1320
    assert regimes == expected, (regimes - expected, expected - regimes)
    assert not survivors
    print(
        {
            "schema": "primitive-g4-cap5-top-v1",
            "skeleton_leaf_choices": skeletons,
            "source_regimes": len(regimes),
            "survivors": 0,
            "status": "verified_zero",
        }
    )
    for row in sorted(regimes):
        print("SOURCE", row)


if __name__ == "__main__":
    main()


