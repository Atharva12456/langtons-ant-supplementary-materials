#!/usr/bin/env python3
"""Bounded regression for the extremal ``(4,-4)`` rank-sign exclusion.

The proof is an induction on transverse levels followed by an explicit block-
inversion count.  This program checks the finite parity systems and the closed
inversion formula over a range of moduli and even widths; it is not the proof.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


Block = tuple[str, int, int]


def source_key(block: Block) -> tuple[int, int, int]:
    kind, level, lane = block
    return level, lane, 0 if kind in ("W", "S") else 1


def target_vertex(block: Block, modulus: int) -> tuple[int, int]:
    kind, level, lane = block
    if kind == "W":
        return level - 1, (lane - 1) % modulus
    if kind == "E":
        return level + 1, (lane + 1) % modulus
    if kind == "S":
        return level - 1, lane
    if kind == "N":
        return level + 1, lane
    raise AssertionError(kind)


def target_key(block: Block, modulus: int) -> tuple[int, int, int]:
    level, lane = target_vertex(block, modulus)
    return level, lane, 0 if block[0] in ("W", "S") else 1


def strip_blocks(modulus: int, width: int) -> list[Block]:
    """Full odd block set between horizontal rails at levels 1 and width+1."""
    blocks = []
    for level in range(1, width + 2):
        for lane in range(modulus):
            kinds = ("W", "E") if level % 2 == 0 else ("S", "N")
            for kind in kinds:
                block = kind, level, lane
                target_level, _ = target_vertex(block, modulus)
                if 1 <= target_level <= width + 1:
                    blocks.append(block)
    return blocks


def inversion_count(blocks: list[Block], modulus: int) -> int:
    ordered = sorted(blocks, key=source_key)
    return sum(
        target_key(first, modulus) > target_key(second, modulus)
        for index, first in enumerate(ordered)
        for second in ordered[index + 1 :]
    )


def expected_inversion_count(modulus: int, width: int) -> int:
    return (
        modulus * modulus * width
        + modulus * modulus * (width - 1)
        + (modulus - 1) * width
    )


def parity_system(modulus: int, width: int, blocks: list[Block]) -> list[int]:
    """Return augmented GF(2) rows for in/out parity at every quotient vertex."""
    index = {block: position for position, block in enumerate(blocks)}
    rows = []
    for level in range(1, width + 2):
        for lane in range(modulus):
            vertex = level, lane
            boundary = int(level in (1, width + 1))
            outgoing = [block for block in blocks if block[1:] == vertex]
            incoming = [
                block
                for block in blocks
                if target_vertex(block, modulus) == vertex
            ]
            for incident in (outgoing, incoming):
                row = sum(1 << index[block] for block in incident)
                rows.append(row | (boundary << len(blocks)))
    return rows


def solve_gf2(rows: list[int], variable_count: int) -> tuple[int, int]:
    """Return a particular solution and the nullity of an augmented system."""
    rows = rows[:]
    pivots = []
    rank = 0
    for column in range(variable_count):
        pivot = next(
            (index for index in range(rank, len(rows)) if rows[index] >> column & 1),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for index in range(len(rows)):
            if index != rank and (rows[index] >> column & 1):
                rows[index] ^= rows[rank]
        pivots.append(column)
        rank += 1

    coefficient_mask = (1 << variable_count) - 1
    assert not any(
        (row & coefficient_mask) == 0 and row >> variable_count & 1
        for row in rows
    )
    particular = 0
    for row, pivot in zip(rows[:rank], pivots):
        if row >> variable_count & 1:
            particular |= 1 << pivot
    return particular, variable_count - rank


def local_correction(blocks: list[Block], modulus: int) -> int:
    vertices = {(block[1], block[2]) for block in blocks}
    incoming = {vertex: [] for vertex in vertices}
    outgoing = {vertex: [] for vertex in vertices}
    for block in blocks:
        outgoing[block[1], block[2]].append(block)
        incoming[target_vertex(block, modulus)].append(block)

    answer = 0
    for level, lane in vertices:
        vertex = level, lane
        excess = len(outgoing[vertex]) & 1
        if level % 2 == 0:
            positive_in = sum(block[0] == "N" for block in incoming[vertex]) & 1
            positive_out = sum(block[0] == "E" for block in outgoing[vertex]) & 1
            port_change = positive_in ^ positive_out
            answer ^= port_change & (excess ^ 1)
        else:
            positive_in = sum(block[0] == "E" for block in incoming[vertex]) & 1
            positive_out = sum(block[0] == "N" for block in outgoing[vertex]) & 1
            port_change = positive_in ^ positive_out
            answer ^= excess & (port_change ^ 1)
    return answer


def audit(max_modulus: int, max_width: int) -> dict[str, object]:
    rows = []
    for modulus in range(1, max_modulus + 1):
        for width in range(2, max_width + 1, 2):
            blocks = strip_blocks(modulus, width)
            particular, nullity = solve_gf2(
                parity_system(modulus, width, blocks), len(blocks)
            )
            full_mask = (1 << len(blocks)) - 1
            direct_inversions = inversion_count(blocks, modulus)
            expected_inversions = expected_inversion_count(modulus, width)
            assert particular == full_mask
            assert nullity == 0
            assert direct_inversions == expected_inversions
            assert direct_inversions % 2 == modulus % 2
            assert local_correction(blocks, modulus) == 0
            rows.append(
                {
                    "modulus": modulus,
                    "width": width,
                    "variables": len(blocks),
                    "nullity": nullity,
                    "inversions": direct_inversions,
                    "correction_mod_2": direct_inversions % 2,
                }
            )

    return {
        "schema": "langton-growth8-extremal-m4-rank-audit-v1",
        "status": "bounded_evidence_not_proof",
        "max_modulus": max_modulus,
        "max_even_width": max_width,
        "systems_checked": len(rows),
        "m4_correction_mod_2": 0,
        "m4_p3_left_rank_mod_2": 0,
        "m4_one_tour_left_rank_mod_2": 1,
        "rows": rows,
        "all_checks_passed": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-modulus", type=int, default=8)
    parser.add_argument("--max-width", type=int, default=20)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.max_modulus < 1:
        parser.error("--max-modulus must be positive")
    if args.max_width < 2 or args.max_width % 2:
        parser.error("--max-width must be a positive even integer")

    result = audit(args.max_modulus, args.max_width)
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")


if __name__ == "__main__":
    main()
