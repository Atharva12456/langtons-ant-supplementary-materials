#!/usr/bin/env python3
"""Audit and aggregate shards produced with ``--target-growth``."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


COUNTERS = (
    "nodes",
    "growth_prunes",
    "endpoint_prunes",
    "deficit_checks",
    "deficit_prunes",
    "deficit_endpoints_tested",
    "residue_checks",
    "residue_prunes",
    "leaves",
    "p3_checks",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def prefix_for_rank(rank: int, length: int) -> str:
    return "R" + "".join(
        "L" if rank & (1 << bit) else "R"
        for bit in range(length - 2, -1, -1)
    )


def prefix_is_valid(prefix: str) -> bool:
    x = y = 0
    direction = 0
    balance = 0
    last_turn: dict[tuple[int, int], int] = {}
    steps = ((0, 1), (1, 0), (0, -1), (-1, 0))
    for symbol in prefix:
        turn = 0 if symbol == "R" else 1
        previous = last_turn.get((x, y))
        if previous is not None and turn != 1 - previous:
            return False
        next_balance = balance + (1 if turn == 0 else -1)
        if next_balance < 0:
            return False
        last_turn[(x, y)] = turn
        balance = next_balance
        direction = (direction + (1 if turn == 0 else 3)) % 4
        dx, dy = steps[direction]
        x += dx
        y += dy
    return True


def audit(directory: Path) -> dict[str, object]:
    files = sorted(directory.glob("shard_*.json"))
    if not files:
        raise ValueError(f"no shard_*.json files in {directory}")

    problems: list[str] = []
    covered: list[int] = []
    hits: list[object] = []
    totals = {key: 0 for key in COUNTERS}
    core_seconds = 0.0
    period = prefix_length = rank_count = target_growth = None
    file_hashes = {}

    for path in files:
        record = json.loads(path.read_text(encoding="utf-8"))
        file_hashes[path.name] = sha256(path)
        if record.get("schema") != "positive-growth-periodic-residue-search-v2":
            problems.append(f"{path.name}: unexpected record schema")
        metadata = (
            record.get("period"),
            record.get("prefix_length"),
            record.get("total_rank_count"),
            record.get("target_growth"),
        )
        if period is None:
            period, prefix_length, rank_count, target_growth = metadata
        elif metadata != (period, prefix_length, rank_count, target_growth):
            problems.append(f"{path.name}: inconsistent metadata {metadata!r}")

        if not record.get("search_complete"):
            problems.append(f"{path.name}: search_complete is not true")
        if record.get("node_cap") is not None:
            problems.append(f"{path.name}: node_cap is not null")
        if record.get("deficit_depths") != []:
            problems.append(f"{path.name}: deficit rule was active")

        start, stop = record.get("rank_start"), record.get("rank_stop")
        expected = list(range(start, stop)) if isinstance(start, int) and isinstance(stop, int) else []
        results = record.get("results", [])
        actual = [item.get("rank") for item in results]
        if actual != expected:
            problems.append(f"{path.name}: result ranks do not match its interval")

        per_shard = {key: 0 for key in COUNTERS}
        shard_hits: list[object] = []
        for item in results:
            rank = item.get("rank")
            if isinstance(rank, int):
                covered.append(rank)
                if isinstance(prefix_length, int):
                    expected_prefix = prefix_for_rank(rank, prefix_length)
                    if item.get("prefix") != expected_prefix:
                        problems.append(f"{path.name}: wrong prefix at rank {rank}")
                    expected_validity = prefix_is_valid(expected_prefix)
                    if item.get("prefix_valid") is not expected_validity:
                        problems.append(
                            f"{path.name}: wrong prefix validity at rank {rank}"
                        )
            else:
                problems.append(f"{path.name}: invalid rank {rank!r}")
            for key in COUNTERS:
                value = item.get(key)
                if not isinstance(value, int):
                    problems.append(f"{path.name}: rank {rank} has invalid {key}")
                    value = 0
                per_shard[key] += value
            item_hits = item.get("hits")
            if not isinstance(item_hits, list):
                problems.append(f"{path.name}: rank {rank} hits is not a list")
            else:
                shard_hits.extend(item_hits)

        if shard_hits != record.get("hits"):
            problems.append(f"{path.name}: per-rank and shard hit lists differ")
        for key in COUNTERS:
            if per_shard[key] != record.get(key):
                problems.append(f"{path.name}: per-rank {key} sum differs")
            totals[key] += per_shard[key]
        hits.extend(shard_hits)
        core_seconds += float(record.get("seconds", 0.0))

    expected_coverage = list(range(rank_count)) if isinstance(rank_count, int) else []
    covered.sort()
    if covered != expected_coverage:
        problems.append(
            f"coverage has {len(covered)} entries; expected {len(expected_coverage)}"
        )
    if not isinstance(target_growth, int) or target_growth <= 0:
        problems.append(f"invalid target growth {target_growth!r}")
    elif target_growth % 4 or not isinstance(period, int) or target_growth > period:
        problems.append(f"target growth {target_growth!r} is incompatible with period")
    if not isinstance(period, int) or period <= 0:
        problems.append(f"invalid period {period!r}")
    if isinstance(prefix_length, int) and isinstance(rank_count, int):
        if rank_count != 1 << (prefix_length - 1):
            problems.append("prefix length and total rank count disagree")

    return {
        "schema": "langton-target-growth-search-audit-v1",
        "period": period,
        "target_growth": target_growth,
        "prefix_length": prefix_length,
        "total_rank_count": rank_count,
        "shards": len(files),
        "ranks_covered_exactly_once": covered == expected_coverage,
        "deficit_rule_active": False,
        **totals,
        "core_seconds": round(core_seconds, 3),
        "hits": hits,
        "highways_found": len(hits),
        "shard_sha256": file_hashes,
        "problems": problems,
        "all_checks_passed": not problems and not hits,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.directory)
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8", newline="\n")
    print(rendered, end="")
    if not result["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
