"""Deterministic cross-audit of the flag-free six-column obstruction."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from verify_width6_block_indep import verify_relaxed
from width6_block_exclusion import explore_relaxed


ROOT = Path(__file__).resolve().parents[2]
CERTIFICATE = ROOT / "results" / "width6_block_certificate.json"


EXPECTED = {
    1: {
        "states": 192, "transitions": 480, "terminals": 72,
        "rejected": 32, "max_local_visits": 2,
        "exits": {"left:0": 26, "left:2": 36, "left:4": 26,
                  "right:2": 22, "right:4": 28, "right:6": 22},
    },
    2: {
        "states": 3453, "transitions": 6951, "terminals": 1131,
        "rejected": 1136, "max_local_visits": 24,
        "exits": {"left:0": 356, "left:2": 465, "left:4": 365,
                  "right:2": 396, "right:4": 467, "right:6": 268},
    },
    3: {
        "states": 5208, "transitions": 7977, "terminals": 1867,
        "rejected": 2549, "max_local_visits": 30,
        "exits": {"left:0": 286, "left:2": 243, "left:4": 263,
                  "right:2": 583, "right:4": 740, "right:6": 544},
    },
    4: {
        "states": 633, "transitions": 900, "terminals": 102,
        "rejected": 333, "max_local_visits": 40,
        "exits": {"left:0": 40, "left:2": 86, "left:4": 72,
                  "right:2": 18, "right:4": 46, "right:6": 38},
    },
    5: {
        "states": 555, "transitions": 819, "terminals": 46,
        "rejected": 282, "max_local_visits": 58,
        "exits": {"left:0": 58, "left:2": 88, "left:4": 81,
                  "right:2": 23, "right:6": 23},
    },
    6: {
        "states": 357, "transitions": 555, "terminals": 0,
        "rejected": 172, "max_local_visits": 58,
        "exits": {"left:0": 38, "left:2": 78, "left:4": 69},
    },
}


def normalized_primary(columns):
    result = explore_relaxed(columns)
    assert result["terminal_events"] == result["terminal_states"], result
    return {
        "states": result["states"],
        "transitions": result["transitions"],
        "terminals": result["terminal_events"],
        "rejected": result["invalid_extreme"],
        "local_loops": result["local_loops"],
        "max_local_visits": result["max_cell_visits_between_outer_crossings"],
        "exits": {f"{side}:{line}": count
                  for (side, line), count in sorted(result["exit_counts"].items())},
    }


def normalized_independent(columns):
    result = verify_relaxed(columns)
    return {
        "states": result["states"],
        "transitions": result["transitions"],
        "terminals": result["terminals"],
        "rejected": result["rejected"],
        "local_loops": result["local_loops"],
        "max_local_visits": result["max_local_visits"],
        "exits": {f"{side}:{line}": count
                  for (side, line), count in sorted(result["exits"].items())},
    }


def main():
    certificate = json.loads(CERTIFICATE.read_text(encoding="utf-8"))
    assert certificate["schema"] == "langton-width6-six-column-v1"
    rows = {}
    for columns, expected_without_loops in EXPECTED.items():
        expected = dict(expected_without_loops, local_loops=0)
        primary = normalized_primary(columns)
        independent = normalized_independent(columns)
        assert primary == expected, (columns, "primary", primary, expected)
        assert independent == expected, (columns, "independent", independent, expected)
        rows[str(columns)] = expected

    assert certificate["certified_rows"] == rows
    for entry in certificate["independent_enumerators"]:
        path = ROOT / entry["path"]
        actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual_hash == entry["sha256"], (path, actual_hash, entry)
    audit = certificate["cross_audit"]
    audit_path = ROOT / audit["path"]
    actual_audit_hash = hashlib.sha256(audit_path.read_bytes()).hexdigest()
    assert actual_audit_hash == audit["sha256"], (actual_audit_hash, audit)
    assert audit["all_checks_passed"] is True

    row6 = rows["6"]
    local = certificate["local_lemma"]
    assert local["reachable_boundary_states"] == row6["states"]
    assert local["nondeterministic_return_transitions"] == row6["transitions"]
    assert local["repeated_extremal_rejections"] == row6["rejected"]
    assert local["confined_local_cycles"] == row6["local_loops"]
    assert local["maximum_cell_visits_between_outer_crossings"] == row6["max_local_visits"]
    assert local["exit_counts"] == row6["exits"]
    assert local["right_exit_terminals"] == row6["terminals"]
    terminal_counts = certificate["positive_controls"]["terminal_counts_by_columns"]
    assert terminal_counts == {
        key: value["terminals"] for key, value in rows.items()
    }
    print(json.dumps({
        "schema": "langton-width6-six-column-v1",
        "all_checks_passed": True,
        "scope": "flag-free arbitrary-outer-return blank-block reachability",
        "rows": rows,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
