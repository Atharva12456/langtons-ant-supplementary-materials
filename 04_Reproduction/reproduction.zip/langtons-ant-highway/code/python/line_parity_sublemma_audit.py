#!/usr/bin/env python3
"""Exhaustive check of the geometric sub-lemmas behind the mod-four theorem.

Sub-lemma A (reflect/continue rule).  Normalise so that arrival at level t is
horizontal exactly when t is odd (t = x+y).  Then for every ant step,
    at odd  t (horizontal arrival, vertical departure): R  <=>  t reverses,
    at even t (vertical arrival, horizontal departure): R  <=>  t continues.

Sub-lemma B (flow).  For any closed level walk, M_t - n_t = f_{t-1} - f_t,
hence rho_t = M_t + n_t = m_t (mod 2) automatically.

Sub-lemma C (levels alternate arrival axis).  t changes by exactly +-1 per move
and the move axis alternates, so arrival axis is a function of t mod 2.

These are checked on EVERY turn word of every even length up to a cap, with no
drift or P3 filter, so the sample is exhaustive rather than incidental.
"""

from __future__ import annotations

import sys
from collections import defaultdict
from itertools import product

DX = (1, 0, -1, 0)  # E,S,W,N ; R = +1
DY = (0, -1, 0, 1)


def main() -> None:
    cap = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    nA = nB = nC = 0
    failA = failB = failC = 0
    words_closed = 0
    for N in range(2, cap + 1, 2):
        for bits in product("RL", repeat=N):
            word = "".join(bits)
            for sh in range(4):
                x = y = 0
                h = sh
                pos = []
                heads = []
                for sym in word:
                    pos.append((x, y))
                    h = (h + 1) % 4 if sym == "R" else (h - 1) % 4
                    heads.append(h)
                    x += DX[h]
                    y += DY[h]
                if h != sh:
                    continue  # no heading reset
                d = (x, y)
                if d == (0, 0):
                    continue
                # only diagonal drifts with the x+y transverse form
                if d[0] != -d[1]:
                    continue
                words_closed += 1

                # ---- Sub-lemma C: arrival axis is a function of t mod 2 ----
                axis_by_parity = defaultdict(set)
                for j in range(N):
                    hin = heads[j - 1] if j else heads[N - 1]
                    t = pos[j][0] + pos[j][1]
                    axis_by_parity[t % 2].add(hin % 2)  # 0/2 = E/W horizontal
                nC += 1
                if any(len(v) > 1 for v in axis_by_parity.values()):
                    failC += 1
                    print("C FAIL", N, word, sh, dict(axis_by_parity))
                    continue
                # normalise: par(t)=1 means horizontal arrival
                horiz_parity = None
                for p, axes in axis_by_parity.items():
                    if 0 in axes:  # heading 0 or 2 = E/W = horizontal
                        horiz_parity = p
                if horiz_parity is None:
                    continue

                # ---- Sub-lemma A: reflect/continue rule ----
                for j in range(N):
                    t = pos[j][0] + pos[j][1]
                    prev = pos[j - 1] if j else (pos[N - 1][0] - d[0], pos[N - 1][1] - d[1])
                    nxt = pos[j + 1] if j + 1 < N else (pos[0][0] + d[0], pos[0][1] + d[1])
                    tin = 1 if t > prev[0] + prev[1] else -1
                    tout = 1 if nxt[0] + nxt[1] > t else -1
                    reverses = tin != tout
                    isR = word[j] == "R"
                    if t % 2 == horiz_parity:
                        expect = reverses
                    else:
                        expect = not reverses
                    nA += 1
                    if isR != expect:
                        failA += 1
                        print("A FAIL", N, word, sh, "phase", j)

                # ---- Sub-lemma B: flow identity ----
                up = defaultdict(int)
                down = defaultdict(int)
                M = defaultdict(int)
                n = defaultdict(int)
                mult = defaultdict(int)
                for j in range(N):
                    t = pos[j][0] + pos[j][1]
                    mult[t] += 1
                    nxt = pos[j + 1] if j + 1 < N else (pos[0][0] + d[0], pos[0][1] + d[1])
                    tn = nxt[0] + nxt[1]
                    if tn == t + 1:
                        up[t] += 1
                    else:
                        down[tn] += 1
                    prev = pos[j - 1] if j else (pos[N - 1][0] - d[0], pos[N - 1][1] - d[1])
                    tin = 1 if t > prev[0] + prev[1] else -1
                    tout = 1 if tn > t else -1
                    if tin == 1 and tout == -1:
                        M[t] += 1
                    if tin == -1 and tout == 1:
                        n[t] += 1
                for t in mult:
                    nB += 1
                    ok = (up.get(t, 0) == down.get(t, 0)) if (t in up or t in down) else True
                    lhs = M[t] - n[t]
                    rhs = up.get(t - 1, 0) - up.get(t, 0)
                    if lhs != rhs or mult[t] != up.get(t - 1, 0) + up.get(t, 0):
                        failB += 1
                        print("B FAIL", N, word, sh, t, lhs, rhs, mult[t])
                    if (M[t] + n[t]) % 2 != mult[t] % 2:
                        failB += 1
                        print("B PARITY FAIL", N, word, sh, t)

    print(f"closed diagonal-drift words tested: {words_closed}")
    print(f"sub-lemma A checks {nA}, failures {failA}")
    print(f"sub-lemma B checks {nB}, failures {failB}")
    print(f"sub-lemma C checks {nC}, failures {failC}")


if __name__ == "__main__":
    main()
