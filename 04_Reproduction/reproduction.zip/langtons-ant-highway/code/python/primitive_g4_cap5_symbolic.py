"""Exact symbolic exclusion of primitive-g4 prefixes with cut cap five.

The proved cap-four theorem says that, among the first four cuts, one has
multiplicity at least five.  Under cap five let j be its first occurrence.
This script exhausts j=2,3,4 (j=1 is arithmetically impossible), every cut
profile, every plane degree row, every choice of the next level's leaves, and
every integer order regime.  At least three frontier voltages are fixed leaf
voltages.  The root-voltage equation therefore leaves at most one free integer
parameter, so the unbounded order check is finite and exact.

The final-level test is deliberately relaxed: it asks only whether the fixed
leaf/end-point turn word embeds as a subsequence of the required alternating
word.  Interior events are allowed to be inserted anywhere.  Failure of this
relaxation is consequently a sound obstruction.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations, product


@dataclass(frozen=True)
class Aff:
    constant: int
    coeffs: tuple[int, ...]

    def __add__(self, other: "Aff") -> "Aff":
        return Aff(self.constant + other.constant,
                   tuple(a + b for a, b in zip(self.coeffs, other.coeffs)))

    def __sub__(self, other: "Aff") -> "Aff":
        return Aff(self.constant - other.constant,
                   tuple(a - b for a, b in zip(self.coeffs, other.coeffs)))


def const(value: int, variables: int) -> Aff:
    return Aff(value, (0,) * variables)


def var(index: int, variables: int) -> Aff:
    return Aff(0, tuple(1 if i == index else 0 for i in range(variables)))


def add_all(rows: list[Aff], variables: int) -> Aff:
    out = const(0, variables)
    for row in rows:
        out = out + row
    return out


def degree_rows(nodes: int, children: int, positives: int):
    """All ordered degree rows with the requested sum/support size."""
    for support in combinations(range(nodes), positives):
        support = set(support)

        def rec(index: int, left: int, row: list[int]):
            if index == nodes:
                if left == 0:
                    yield tuple(row)
                return
            if index not in support:
                row.append(0)
                yield from rec(index + 1, left, row)
                row.pop()
                return
            later = sum(i > index for i in support)
            for value in range(1, left - later + 1):
                row.append(value)
                yield from rec(index + 1, left - value, row)
                row.pop()

        yield from rec(0, children, [])


def level_data(nodes: int, children: int, depth: int):
    omega = (nodes + children) & 1
    numerator = nodes + children + (omega if depth & 1 else -omega)
    if numerator % 4:
        return None
    positives = numerator // 4
    if not 1 <= positives <= min(nodes, children):
        return None
    return omega, positives


def subsequence(word: str, target: str) -> bool:
    cursor = 0
    for symbol in word:
        cursor = target.find(symbol, cursor)
        if cursor < 0:
            return False
        cursor += 1
    return True


def substitute(expression: Aff, relation: tuple[int, ...]) -> tuple[int, int]:
    """Return (coefficient,constant) after the root relation.

    relation is either (), (fixed,), or (sum_constant,), with two variables
    represented as y0=k and y1=sum_constant-k.
    """
    if len(expression.coeffs) == 0:
        return 0, expression.constant
    if len(expression.coeffs) == 1:
        return 0, expression.constant + expression.coeffs[0] * relation[0]
    assert len(expression.coeffs) == 2 and len(relation) == 1
    a, b = expression.coeffs
    return a - b, expression.constant + b * relation[0]


def value(line: tuple[int, int], parameter: int) -> int:
    return line[0] * parameter + line[1]


def parameter_samples(lines: list[tuple[int, int]]) -> range:
    roots = []
    for left, right in combinations(lines, 2):
        slope = left[0] - right[0]
        intercept = left[1] - right[1]
        if slope:
            roots.append(Fraction(-intercept, slope))
    radius = 2
    if roots:
        radius += max((abs(root.numerator) + abs(root.denominator) - 1)
                      // abs(root.denominator) for root in roots)
    return range(-radius, radius + 1)


def target(length: int) -> str:
    return "RL" * (length // 2) + ("R" if length & 1 else "")


def exact_processed_levels(degrees_by_depth, voltages_by_depth,
                           bases_by_depth, relation):
    all_events = []
    for depth, degrees in enumerate(degrees_by_depth, 1):
        bases = bases_by_depth[depth]
        child_voltages = voltages_by_depth[depth + 1]
        cursor = 0
        phase = 0
        events = []
        endpoint = "R" if depth & 1 else "L"
        middle = "L" if depth & 1 else "R"
        leaf = middle
        for base, degree in zip(bases, degrees):
            if degree == 0:
                events.append((substitute(base, relation), phase, leaf))
                phase += 1
                continue
            position = base
            events.append((substitute(position, relation), phase, endpoint))
            phase += 1
            for child_index in range(degree):
                position = position + child_voltages[cursor]
                cursor += 1
                symbol = endpoint if child_index + 1 == degree else middle
                events.append((substitute(position, relation), phase, symbol))
                phase += 1
        all_events.append(events)
    return all_events


def build_symbolic(degrees_by_depth, terminal_leaf_set, terminal_depth):
    terminal_nodes = sum(degrees_by_depth[-1])
    nonleaves = [i for i in range(terminal_nodes) if i not in terminal_leaf_set]
    variables = len(nonleaves)
    terminal_sign = 1 if terminal_depth % 2 == 0 else -1
    terminal = []
    variable_index = 0
    for node in range(terminal_nodes):
        if node in terminal_leaf_set:
            terminal.append(const(terminal_sign, variables))
        else:
            terminal.append(var(variable_index, variables))
            variable_index += 1

    voltages = {terminal_depth: terminal}
    for depth in range(terminal_depth - 1, 0, -1):
        children = voltages[depth + 1]
        cursor = 0
        row = []
        sign = 1 if depth % 2 == 0 else -1
        for degree in degrees_by_depth[depth - 1]:
            group = children[cursor:cursor + degree]
            cursor += degree
            row.append(const(sign, variables) + add_all(group, variables))
        assert cursor == len(children)
        voltages[depth] = row

    root = voltages[1][0]
    if variables == 0:
        if root.constant != 1:
            return None
        relation = ()
    elif variables == 1:
        coefficient = root.coeffs[0]
        if coefficient not in (-1, 1):
            return None
        relation = ((1 - root.constant) // coefficient,)
        if root.constant + coefficient * relation[0] != 1:
            return None
    else:
        assert variables == 2 and root.coeffs == (1, 1)
        relation = (1 - root.constant,)

    bases = {1: [const(0, variables)]}
    for depth, degrees in enumerate(degrees_by_depth, 1):
        child_voltages = voltages[depth + 1]
        cursor = 0
        child_bases = []
        shift = 1 if depth & 1 else 0
        for base, degree in zip(bases[depth], degrees):
            position = base + const(shift, variables)
            for _ in range(degree):
                child_bases.append(position)
                position = position + child_voltages[cursor]
                cursor += 1
        assert cursor == len(child_voltages)
        bases[depth + 1] = child_bases
    return voltages, bases, relation, nonleaves


def check_skeleton(degrees_by_depth, next_children, next_positives,
                   terminal_leaf_set, terminal_depth):
    built = build_symbolic(degrees_by_depth, terminal_leaf_set, terminal_depth)
    if built is None:
        return False, None, ()
    voltages, bases, relation, nonleaves = built
    processed = exact_processed_levels(degrees_by_depth, voltages, bases, relation)

    leaf_sign = 1 if terminal_depth % 2 == 0 else -1
    endpoint = "R" if terminal_depth & 1 else "L"
    leaf_symbol = "L" if terminal_depth & 1 else "R"
    fixed = []
    for node, (base, voltage) in enumerate(zip(bases[terminal_depth],
                                               voltages[terminal_depth])):
        base_line = substitute(base, relation)
        if node in terminal_leaf_set:
            fixed.append((base_line, 2 * node, leaf_symbol))
        else:
            endpoint_line = substitute(
                base + voltage - const(leaf_sign, len(voltage.coeffs)), relation
            )
            fixed.append((base_line, 2 * node, endpoint))
            fixed.append((endpoint_line, 2 * node + 1, endpoint))

    lines = [event[0] for row in processed for event in row]
    lines.extend(event[0] for event in fixed)

    processed_candidates = set()
    for parameter in parameter_samples(lines):
        good = True
        for events in processed:
            stable = sorted(events, key=lambda event: (-value(event[0], parameter), event[1]))
            word = "".join(event[2] for event in stable)
            if word != target(len(word)):
                good = False
                break
        if not good:
            continue
        fixed_stable = sorted(fixed,
                              key=lambda event: (-value(event[0], parameter), event[1]))
        fixed_word = "".join(event[2] for event in fixed_stable)
        next_word = target(len(terminal_leaf_set) + 2 * next_positives
                           + (next_children - next_positives))
        # The expression above equals terminal_nodes+next_children.
        assert len(next_word) == len(voltages[terminal_depth]) + next_children
        record = (
            tuple(value(substitute(row, relation), parameter)
                  for row in bases[terminal_depth]),
            tuple(value(substitute(row, relation), parameter)
                  for row in voltages[terminal_depth]),
            fixed_word,
            next_word,
        )
        processed_candidates.add(record)
        if subsequence(fixed_word, next_word):
            witness = {
                "parameter": parameter,
                "fixed_word": fixed_word,
                "next_word": next_word,
                "bases": tuple(value(substitute(row, relation), parameter)
                               for row in bases[terminal_depth]),
                "voltages": tuple(value(substitute(row, relation), parameter)
                                  for row in voltages[terminal_depth]),
            }
            return True, witness, tuple(sorted(processed_candidates))
    return False, None, tuple(sorted(processed_candidates))


def main():
    skeletons = regimes = 0
    survivors = []
    candidate_rows = []
    processed_rows = set()
    for earliest in (2, 3, 4):
        for cuts in product(range(1, 6), repeat=earliest):
            if cuts[earliest - 1] != 5 or any(value == 5 for value in cuts[:earliest - 1]):
                continue
            nodes = 1
            even_wakes = odd_wakes = 0
            degree_options = []
            valid = True
            for depth, children in enumerate(cuts, 1):
                data = level_data(nodes, children, depth)
                if data is None:
                    valid = False
                    break
                omega, positives = data
                if omega:
                    if depth & 1:
                        odd_wakes += 1
                    else:
                        even_wakes += 1
                if even_wakes > 1 or odd_wakes > 1:
                    valid = False
                    break
                degree_options.append(tuple(degree_rows(nodes, children, positives)))
                nodes = children
            if not valid:
                continue

            terminal_depth = earliest + 1
            for degrees_by_depth in product(*degree_options):
                for next_children in range(1, 6):
                    data = level_data(5, next_children, terminal_depth)
                    if data is None:
                        continue
                    omega, next_positives = data
                    ew = even_wakes + (omega if terminal_depth % 2 == 0 else 0)
                    ow = odd_wakes + (omega if terminal_depth % 2 == 1 else 0)
                    if ew > 1 or ow > 1:
                        continue
                    leaf_count = 5 - next_positives
                    if leaf_count < 3:
                        continue
                    for terminal_leaf_set in combinations(range(5), leaf_count):
                        skeletons += 1
                        ok, witness, processed = check_skeleton(
                            degrees_by_depth, next_children, next_positives,
                            frozenset(terminal_leaf_set), terminal_depth,
                        )
                        for row in processed:
                            processed_rows.add((cuts, next_children) + row)
                        if ok:
                            survivors.append((cuts, degrees_by_depth, next_children,
                                              terminal_leaf_set, witness))
                        else:
                            candidate_rows.append((cuts, next_children, terminal_leaf_set))

    print({
        "schema": "primitive-g4-cap5-symbolic-v1",
        "skeleton_leaf_choices": skeletons,
        "rejected_by_exact_order_or_fixed_subsequence": len(candidate_rows),
        "distinct_exact_source_regimes": len(processed_rows),
        "survivors": len(survivors),
        "all_integer_order_regimes_checked": True,
        "status": (
            "computer_assisted_cap5_obstruction" if not survivors else "counterexample"
        ),
    })
    for row in sorted(processed_rows):
        print("SOURCE", row)
    for survivor in survivors[:10]:
        print("SURVIVOR", survivor)
    if survivors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
