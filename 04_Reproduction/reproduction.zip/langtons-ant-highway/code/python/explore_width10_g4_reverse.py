"""Reverse-search sparse growth-four wakes in the exact-W=10 relaxation.

This is an exploratory computation, not a theorem certificate.  It is the exact
time reverse of the arbitrary-same-boundary-return block model used by
``explore_width10_low_growth.py``.  The block is initially white, is confined to
``t=x+y in {0,...,10}``, and each in-block extremal cell may be visited at most
once.  Every exterior excursion is forgotten and may return at any geometrically
allowed line on the same side.

Instead of exploring every forward colouring, the search starts from every final
mask that is longitudinally periodic with period ``m``, has four black cells per
period, reaches both extremal lines, and satisfies the proved signed-residue,
positive-even-fibre, and full diagonal additive-weight conditions.  Langton's-ant
steps are then undone exactly.  The
search asks whether
any such target can lead back to a blank block and an allowed first entry from the
left.  A complete zero would concern only diagonal growth-four highways of exact
transverse width ``W=10``; it would not prove the universal ``g>=12`` statement.
"""
from __future__ import annotations

import argparse
from collections import deque
from itertools import combinations


NORTH, EAST, SOUTH, WEST = range(4)
RIGHT = (EAST, SOUTH, WEST, NORTH)
LEFT = (WEST, NORTH, EAST, SOUTH)
DX = (0, 1, 0, -1)
DT = (1, 1, -1, -1)
TOP = 10
HEIGHT = TOP + 1
LEFT_ENTRIES = tuple(range(2, TOP + 1, 2))
RIGHT_ENTRIES = tuple(range(0, TOP, 2))
LOCAL_LOOP = object()


def cell_index(column: int, line: int) -> int:
    return HEIGHT * column + line


def wake_base_valid(chosen: tuple[int, ...], period: int) -> bool:
    """Apply necessary extremal, P16, P22, and additive conditions."""
    points = tuple((index // HEIGHT, index % HEIGHT) for index in chosen)
    if not any(line == 0 for _, line in points):
        return False
    if not any(line == TOP for _, line in points):
        return False
    for coordinate in (0, 1):
        for residue in range(period):
            if coordinate == 0:
                fibre = tuple(
                    line for column, line in points
                    if column % period == residue
                )
            else:
                fibre = tuple(
                    line for column, line in points
                    if (line - column) % period == residue
                )
            if not fibre or len(fibre) % 2:
                return False
            signed = sum(1 if line % 2 == 0 else -1 for line in fibre)
            if signed % 4 != 2:
                return False
    # The full family of drift-periodic mod-four additive weights supplies the
    # transverse moment equations derived in full_additive_wake_audit.py.  These
    # are invariant under the unknown phase/start line in the normalized strip.
    if period == 1:
        signed_moment = sum(
            (1 if line % 2 == 0 else -1) * line
            for _column, line in points
        )
        if signed_moment % 4 != 3:
            return False
    elif period == 2:
        if any(line % 2 for _column, line in points):
            return False
        if sum(line // 2 for _column, line in points) % 4 != 3:
            return False
    else:
        raise ValueError("growth-four search supports only periods one and two")
    return True


def target_masks(columns: int, period: int, growth: int = 4,
                 necessary_filters: bool = True):
    """Yield repeated weight-growth masks, optionally with proved wake filters."""
    if columns < 2 * period:
        return
    for chosen in combinations(range(period * HEIGHT), growth):
        if necessary_filters and not wake_base_valid(chosen, period):
            continue
        base = 0
        for index in chosen:
            base |= 1 << index
        mask = 0
        for column in range(columns):
            residue = column % period
            for line in range(HEIGHT):
                if base & (1 << cell_index(residue, line)):
                    mask |= 1 << cell_index(column, line)
        yield mask


def extreme_part(mask: int, columns: int) -> int:
    result = 0
    for column in range(columns):
        result |= mask & (
            (1 << cell_index(column, 0))
            | (1 << cell_index(column, TOP))
        )
    return result


def reverse_segment(columns: int, black: int, extreme_seen: int,
                    side: int, landing: int):
    """Undo one deterministic in-block segment from an outer exit.

    ``side`` is -1 for a left exit and +1 for a right exit.  The returned tuple
    gives the colouring and extremal history before the segment, followed by the
    entry side, entry line, entry heading, and the number of undone cell turns.
    """
    if side == 1:
        column, line, heading = columns, landing, EAST
    else:
        column, line, heading = -1, landing, WEST

    local_states = set()
    visits = 0
    while True:
        state = (black, extreme_seen, column, line, heading)
        if state in local_states:
            return LOCAL_LOOP
        local_states.add(state)

        prior_column = column - DX[heading]
        prior_line = line - DT[heading]
        if prior_column < 0 or prior_column >= columns:
            if not 0 <= prior_line <= TOP:
                return None
            if prior_column < 0:
                if column != 0 or heading != EAST:
                    return None
                entry_side = -1
            else:
                if column != columns - 1 or heading != WEST:
                    return None
                entry_side = 1
            return black, extreme_seen, entry_side, line, heading, visits
        if not 0 <= prior_line <= TOP:
            return None

        column, line = prior_column, prior_line
        bit = 1 << cell_index(column, line)
        final_black = bool(black & bit)
        if line in (0, TOP):
            # An extremal cell starts white and is visited at most once, so its
            # colour and visit bit are both one precisely after its unique turn.
            if not final_black or not (extreme_seen & bit):
                return None
            extreme_seen ^= bit

        black ^= bit
        heading = LEFT[heading] if final_black else RIGHT[heading]
        visits += 1


def explore(columns: int, periods: tuple[int, ...],
            max_states: int | None = None, stop_on_hit: bool = False,
            necessary_filters: bool = True):
    queue = deque()
    seen = set()
    origins = {}
    target_count = source_count = 0

    for period in periods:
        for mask in target_masks(
            columns, period, necessary_filters=necessary_filters
        ):
            target_count += 1
            extremes = extreme_part(mask, columns)
            for landing in LEFT_ENTRIES:
                state = (mask, extremes, 1, landing)
                source_count += 1
                if state not in seen:
                    seen.add(state)
                    origins[state] = (period, mask, landing)
                    queue.append(state)

    processed = transitions = rejected = local_loops = initial_hits = 0
    max_visits = 0
    first_hit = None
    stopped_on_hit = False

    while queue:
        if max_states is not None and len(seen) > max_states:
            return {
                "complete": False,
                "columns": columns,
                "periods": periods,
                "targets": target_count,
                "sources": source_count,
                "states": len(seen),
                "queued": len(queue),
                "processed": processed,
                "transitions": transitions,
                "rejected": rejected,
                "local_loops": local_loops,
                "initial_hits": initial_hits,
                "max_visits": max_visits,
                "first_hit": first_hit,
            }

        state = queue.popleft()
        processed += 1
        black, extremes, side, landing = state
        result = reverse_segment(columns, black, extremes, side, landing)
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            rejected += 1
            continue

        black2, extremes2, entry_side, entry_line, heading, visits = result
        max_visits = max(max_visits, visits)
        if (
            black2 == 0
            and extremes2 == 0
            and entry_side == -1
            and heading == EAST
            and entry_line in LEFT_ENTRIES
        ):
            initial_hits += 1
            if first_hit is None:
                period, target, source_landing = origins[state]
                first_hit = {
                    "period": period,
                    "target_mask": hex(target),
                    "first_entry": entry_line,
                    "first_segment_exit_side": "right" if side == 1 else "left",
                    "first_segment_exit_landing": landing,
                    "target_final_exit_side": "right",
                    "target_final_exit_landing": source_landing,
                }
            if stop_on_hit:
                stopped_on_hit = True
                break

        if entry_side == -1:
            predecessor_side = -1
            predecessor_landings = RIGHT_ENTRIES
        else:
            predecessor_side = 1
            predecessor_landings = LEFT_ENTRIES

        for predecessor_landing in predecessor_landings:
            predecessor = (
                black2, extremes2, predecessor_side, predecessor_landing
            )
            transitions += 1
            if predecessor not in seen:
                seen.add(predecessor)
                origins[predecessor] = origins[state]
                queue.append(predecessor)

    return {
        "complete": not queue and not stopped_on_hit,
        "columns": columns,
        "periods": periods,
        "targets": target_count,
        "sources": source_count,
        "states": len(seen),
        "processed": processed,
        "transitions": transitions,
        "rejected": rejected,
        "local_loops": local_loops,
        "initial_hits": initial_hits,
        "max_visits": max_visits,
        "first_hit": first_hit,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--columns", type=int, default=4)
    parser.add_argument("--periods", type=int, nargs="+", default=(1, 2))
    parser.add_argument("--max-states", type=int, default=2_000_000)
    parser.add_argument("--stop-on-hit", action="store_true")
    parser.add_argument(
        "--relaxed-targets", action="store_true",
        help="omit necessary extremal/P16/P22/additive target filters (control only)",
    )
    args = parser.parse_args()
    result = explore(
        args.columns, tuple(args.periods), args.max_states or None,
        args.stop_on_hit, not args.relaxed_targets,
    )
    for key, value in result.items():
        print(f"{key}={value}")


if __name__ == "__main__":
    main()
