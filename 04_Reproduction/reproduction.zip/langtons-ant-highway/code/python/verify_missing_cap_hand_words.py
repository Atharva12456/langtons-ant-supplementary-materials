"""Brute-force checks of the finite word claims in the hand proof
odd_skew_missing_cap_offsets_five_six_2026-09-23.md.

Each claim is: 'among all alternating (R-first) words with the given port
counts, exactly these satisfy the displayed adjacency/order conditions'.
The conditions are exactly the ones derived in the text; this script only
confirms the finite bookkeeping.
"""

OUT = {'ER': 'S', 'EL': 'N', 'WR': 'N', 'WL': 'S',
       'NR': 'E', 'NL': 'W', 'SR': 'W', 'SL': 'E'}


def words(counts):
    """all R-first alternating words with the given port counts (recursive, no duplicates)."""
    rem = {p: n for p, n in counts.items() if n}
    total = sum(rem.values())
    seq = []

    def rec():
        i = len(seq)
        if i == total:
            yield tuple(seq)
            return
        for p in sorted(rem):
            if rem[p] and (p[1] == 'R') == (i % 2 == 0):
                rem[p] -= 1
                seq.append(p)
                yield from rec()
                seq.pop()
                rem[p] += 1
    yield from rec()


def pos(w, kind, k):
    """position of the k-th (1-based) event of a kind: ('arr',h) or ('dep',h)."""
    typ, h = kind
    idx = [i for i, p in enumerate(w) if (p[0] == h if typ == 'arr' else OUT[p] == h)]
    return idx[k - 1] if k <= len(idx) else None


def odd_counts(b, c, om):
    for nl in range(min(b, c) + 1):
        sl = b + c - 3 * nl - om
        if sl >= 0:
            yield {'NR': b - nl, 'NL': nl, 'SR': c - nl, 'SL': sl}


def even_counts(a, d, om):
    for er in range(min(a, d) + 1):
        wr = om + a + d - 3 * er
        if wr >= 0:
            yield {'ER': er, 'EL': a - er, 'WR': wr, 'WL': d - er}


def show(title, ws):
    print(title)
    for w in ws:
        print('    ', ','.join(w))
    return [tuple(w) for w in ws]


def nxt(w, i):
    return w[i + 1] if i is not None and i + 1 < len(w) else None


if __name__ == '__main__':
    # row 6
    for om6 in (0, 1):
        ws = [w for c in even_counts(1, 0, om6) for w in words(c)]
        assert show(f'row 6, omega5=1, omega6={om6}', ws) == [tuple(['WR', 'EL'] + ['WR'] * om6)]
    ws = [w for c in even_counts(1, 1, 0) for w in words(c)]
    assert sorted(show('row 6, omega5=0, omega6=0', ws)) == sorted([('WR', 'EL', 'WR', 'WL'), ('WR', 'WL', 'WR', 'EL')])

    # row 7 for order B: conditions used in the text:
    #  W2 is immediately followed by N3 (opposite turn); W1 immediately followed by SL if W1=SR (square lemma);
    #  (start rule and turn alternation are built into the enumeration).
    for om7 in (0, 1):
        good = []
        for c in odd_counts(3, 2, om7):
            for w in words(c):
                w2, n3, w1 = pos(w, ('dep', 'W'), 2), pos(w, ('arr', 'N'), 3), pos(w, ('dep', 'W'), 1)
                if n3 != w2 + 1 or w[w2][1] == w[n3][1]:
                    continue
                if w[w1] == 'SR' and nxt(w, w1) != 'SL':
                    continue
                good.append(w)
        exp = ('SR', 'SL', 'NR', 'NL', 'NR') + ('SL',) * (1 - om7)
        assert show(f'row 7 (order B), omega7={om7}', good) == [exp]

    # row 8: first S-departure is WL immediately followed by the first E-arrival ER (square lemma at 7)
    for om7 in (0, 1):
        d = 3 - om7
        for om8 in (0, 1):
            good = []
            for c in even_counts(2, d, om8):
                for w in words(c):
                    d1, e1 = pos(w, ('dep', 'S'), 1), pos(w, ('arr', 'E'), 1)
                    if d1 is None or e1 is None or w[d1] != 'WL' or e1 != d1 + 1 or w[e1] != 'ER':
                        continue
                    good.append(w)
            P = ('WR', 'WL', 'ER', 'EL') + (('WR', 'WL') if om7 == 0 else ()) + ('WR',) * om8
            Q = ('WR', 'WL', 'ER', 'WL', 'WR', 'EL') + ('WR',) * om8
            exp = sorted([P, Q]) if om7 == 0 else [P]
            assert sorted(show(f'row 8, omega7={om7}, omega8={om8}', good)) == exp

    # row 9 in family Q (upper cap): b = 3+omega8 north arrivals, c = 3 west departures.
    # Conditions: (Q1) first N-arrival precedes first W-departure; W2 immediately followed by N3, opposite turns.
    row9 = []
    for om8 in (0, 1):
        for om9 in (0, 1):
            for c in odd_counts(3 + om8, 3, om9):
                for w in words(c):
                    n1, w1 = pos(w, ('arr', 'N'), 1), pos(w, ('dep', 'W'), 1)
                    w2, n3 = pos(w, ('dep', 'W'), 2), pos(w, ('arr', 'N'), 3)
                    if not n1 < w1 or n3 != w2 + 1 or w[w2][1] == w[n3][1]:
                        continue
                    if w[w2] == 'NL':          # case I
                        assert w[:5] == ('NR', 'SL', 'SR', 'NL', 'NR'), w
                        print('   row 9 case I  ', ','.join(w))
                        row9.append((w, 'I'))
                    else:                      # case II; the text proves W1 is followed by W2 (opposite turn)
                        assert w[w2] == 'SR' and w[n3] == 'NL'
                        if nxt(w, w1) is None or pos(w, ('dep', 'W'), 2) != w1 + 1 or w[w1][1] == w[w2][1]:
                            print('   row 9 case II, killed at row 10 (W1 not followed by W2):', ','.join(w))
                            continue
                        assert w[:4] == ('NR', 'NL', 'SR', 'NL'), w
                        print('   row 9 case II ', ','.join(w))
                        row9.append((w, 'II'))

    # row 10 prefixes (4 east arrivals; d = number of south arrivals on row 9)
    def row10(w9, case):
        d = sum(p[0] == 'S' for p in w9)
        out = []
        for om10 in (0, 1):
            for c in even_counts(4, d, om10):
                for w in words(c):
                    e1, e2, e3 = (pos(w, ('arr', 'E'), k) for k in (1, 2, 3))
                    if case == 'I':
                        # E2 = EL; the feeder K of W1 = SR2 (2nd S-departure) is immediately followed by E2,
                        # so K = E1 = ER
                        if w[e2] != 'EL' or pos(w, ('dep', 'S'), 2) != e2 - 1 or w[e2 - 1] != 'ER':
                            continue
                    else:
                        # E3 = EL; E2 = ER immediately before E3; E2 feeds the first S-arrival of row 9 (= W2 = SR2)
                        if w[e3] != 'EL' or w[e2] != 'ER' or e3 != e2 + 1 or pos(w, ('dep', 'S'), 1) != e2:
                            continue
                    out.append(w)
        return out

    for w9, case in row9:
        ws = row10(w9, case)
        exp = ('WR', 'WL', 'ER', 'EL') if case == 'I' else ('WR', 'EL', 'ER', 'EL')
        assert all(w[:4] == exp for w in ws), ws
        print(f'   row 10 after row 9 {",".join(w9)} (case {case}): {len(ws)} words, all begin {",".join(exp)}')
    print('all word checks passed')
