#!/usr/bin/env python3
"""Run fixed-growth Java searches as a resumable queue of small rank shards."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

from aggregate_target_growth_shards import audit


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_checked(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
    )


def valid_existing_shard(
    path: Path,
    *,
    period: int,
    growth: int,
    prefix_length: int,
    start: int,
    stop: int,
) -> bool:
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return (
        record.get("period") == period
        and record.get("target_growth") == growth
        and record.get("prefix_length") == prefix_length
        and record.get("rank_start") == start
        and record.get("rank_stop") == stop
        and record.get("search_complete") is True
        and record.get("node_cap") is None
        and record.get("deficit_depths") == []
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--period", type=int, required=True)
    parser.add_argument("--target-growth", type=int, required=True)
    parser.add_argument("--prefix-length", type=int, default=12)
    parser.add_argument("--chunk-size", type=int, default=32)
    parser.add_argument("--workers", type=int, default=min(8, os.cpu_count() or 1))
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--summary", type=Path)
    args = parser.parse_args()

    if args.period < args.prefix_length:
        parser.error("period must be at least the prefix length")
    if args.target_growth <= 0 or args.target_growth % 4:
        parser.error("target growth must be a positive multiple of four")
    if args.target_growth > args.period:
        parser.error("target growth cannot exceed the period")
    if args.chunk_size <= 0 or args.workers <= 0:
        parser.error("chunk size and worker count must be positive")

    repo = Path(__file__).resolve().parents[2]
    source = repo / "code" / "java" / "PositiveGrowthResidueSearch.java"
    class_dir = repo / "build" / "target-growth-runner"
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    total_ranks = 1 << (args.prefix_length - 1)
    intervals = [
        (start, min(start + args.chunk_size, total_ranks))
        for start in range(0, total_ranks, args.chunk_size)
    ]
    source_hash = sha256(source)

    manifest_path = output_dir / "run_manifest.json"
    manifest_identity = {
        "schema": "langton-target-growth-shard-run-v1",
        "period": args.period,
        "target_growth": args.target_growth,
        "prefix_length": args.prefix_length,
        "chunk_size": args.chunk_size,
        "total_rank_count": total_ranks,
        "source": str(source.relative_to(repo)).replace("\\", "/"),
        "source_sha256": source_hash,
    }
    if manifest_path.exists():
        old_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        old_identity = {key: old_manifest.get(key) for key in manifest_identity}
        if old_identity != manifest_identity:
            raise SystemExit("existing run manifest does not match this search")
    else:
        manifest = {
            **manifest_identity,
            "started_utc": datetime.now(timezone.utc).isoformat(),
            "workers": args.workers,
            "java_command": "PositiveGrowthResidueSearch with deficit depths disabled",
            "status": "running",
        }
        manifest_path.write_text(
            json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n"
        )

    class_dir.mkdir(parents=True, exist_ok=True)
    run_checked(["javac", "-d", str(class_dir), str(source)], repo)

    pending = []
    for start, stop in intervals:
        path = output_dir / f"shard_{start:06d}_{stop:06d}.json"
        if path.exists():
            if not valid_existing_shard(
                path,
                period=args.period,
                growth=args.target_growth,
                prefix_length=args.prefix_length,
                start=start,
                stop=stop,
            ):
                raise SystemExit(f"existing shard is invalid or incompatible: {path}")
        else:
            pending.append((start, stop, path))

    started = time.monotonic()

    def search_one(start: int, stop: int, path: Path) -> tuple[int, int, float]:
        command = [
            "java",
            "-cp",
            str(class_dir),
            "PositiveGrowthResidueSearch",
            "--period",
            str(args.period),
            "--prefix-length",
            str(args.prefix_length),
            "--rank-start",
            str(start),
            "--rank-stop",
            str(stop),
            "--deficit-depths",
            "0",
            "--target-growth",
            str(args.target_growth),
            "--output",
            str(path),
        ]
        shard_started = time.monotonic()
        try:
            completed = run_checked(command, repo)
        except subprocess.CalledProcessError as error:
            (output_dir / f"failure_{start:06d}_{stop:06d}.stdout.log").write_text(
                error.stdout or "", encoding="utf-8", newline="\n"
            )
            (output_dir / f"failure_{start:06d}_{stop:06d}.stderr.log").write_text(
                error.stderr or "", encoding="utf-8", newline="\n"
            )
            raise
        if completed.stdout:
            (output_dir / f"shard_{start:06d}_{stop:06d}.stdout.log").write_text(
                completed.stdout, encoding="utf-8", newline="\n"
            )
        if completed.stderr:
            (output_dir / f"shard_{start:06d}_{stop:06d}.stderr.log").write_text(
                completed.stderr, encoding="utf-8", newline="\n"
            )
        return start, stop, time.monotonic() - shard_started

    completed_count = len(intervals) - len(pending)
    print(
        f"period={args.period} target_growth={args.target_growth} "
        f"shards={len(intervals)} resumed={completed_count} workers={args.workers}",
        flush=True,
    )
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(search_one, *item) for item in pending]
        for future in as_completed(futures):
            start, stop, seconds = future.result()
            completed_count += 1
            elapsed = time.monotonic() - started
            print(
                f"completed={completed_count}/{len(intervals)} "
                f"ranks=[{start},{stop}) shard_seconds={seconds:.1f} "
                f"elapsed_seconds={elapsed:.1f}",
                flush=True,
            )

    result = audit(output_dir)
    if args.summary is not None:
        summary = args.summary.resolve()
        summary.parent.mkdir(parents=True, exist_ok=True)
        summary.write_text(
            json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n"
        )

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest.update(
        {
            "status": "complete",
            "completed_utc": datetime.now(timezone.utc).isoformat(),
            "shards": len(intervals),
            "aggregate_all_checks_passed": result["all_checks_passed"],
            "highways_found": result["highways_found"],
        }
    )
    manifest_path.write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print(json.dumps(result, indent=2), flush=True)
    if not result["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
