#!/usr/bin/env python3
"""Independent direct-walk verifier for primitive_g4_projected_tours.py.

This implementation does not construct plane trees or weak child compositions.
For each profile it recursively consumes the prescribed upward and downward uses
of every transverse cut, thereby enumerating the literal positive ``+/-1`` walks.
The theorem scope remains bounded and conditional on ``f_c <= 3``.
"""

from __future__ import annotations

import argparse
import json
from itertools import product


EXPECTED = {
    4: (2, 24, 6, 1),
    6: (6, 360, 60, 0),
    8: (12, 3_888, 498, 0),
    10: (20, 37_584, 4_008, 0),
    12: (30, 347_976, 32_430, 0),
}


def profiles(width: int):
    for interior in product((1, 2, 3), repeat=width - 2):
        f = (1,) + interior + (1,)
        counts = [f[0]] + [f[t - 1] + f[t] for t in range(1, width)] + [f[-1]]
        odd = []
        valid = True
        for t, count in enumerate(counts):
            epsilon = count & 1
            target = epsilon if t % 2 == 0 else (-epsilon) % 4
            if count % 4 != target:
                valid = False
                break
            if epsilon:
                odd.append(t)
        if valid and len(odd) == 4 and sum(t % 2 == 0 for t in odd) == 3:
            yield f


def classify(steps: list[int]) -> tuple[bool, bool]:
    x = y = 0
    xs: list[int] = []
    levels: list[int] = []
    signs: list[int] = []
    previous = steps[-1]
    for phase, step in enumerate(steps):
        xs.append(x)
        levels.append(x + y)
        right = previous != step if phase % 2 == 0 else previous == step
        signs.append(1 if right else -1)
        if phase % 2:
            x += step
        else:
            y += step
        previous = step
    if (x, y) != (1, -1) or sum(signs) != 4:
        return False, False
    groups: dict[int, list[int]] = {}
    for phase, level in enumerate(levels):
        groups.setdefault(level, []).append(phase)
    for phases in groups.values():
        charge = 0
        for phase in sorted(phases, key=lambda i: (-xs[i], i)):
            charge += signs[phase]
            if charge < 0:
                return True, False
    return True, True


def audit(width: int) -> dict[str, int | str]:
    profile_count = raw = endpoint_growth = survivors = 0
    for f in profiles(width):
        profile_count += 1
        upward = list(f)
        downward = list(f)
        steps: list[int] = []

        def visit(level: int) -> None:
            nonlocal raw, endpoint_growth, survivors
            if len(steps) == 2 * sum(f):
                if level != 0:
                    return
                raw += 1
                endpoint_ok, lower_ok = classify(steps)
                if endpoint_ok:
                    endpoint_growth += 1
                    survivors += int(lower_ok)
                return
            if level < width and upward[level]:
                upward[level] -= 1
                steps.append(1)
                visit(level + 1)
                steps.pop()
                upward[level] += 1
            if level > 0 and downward[level - 1]:
                downward[level - 1] -= 1
                steps.append(-1)
                visit(level - 1)
                steps.pop()
                downward[level - 1] += 1

        visit(0)
    return {
        "schema": "langton-primitive-g4-projected-independent-v1",
        "width": width,
        "weak_profiles": profile_count,
        "raw_tours": raw,
        "endpoint_growth_tours": endpoint_growth,
        "lower_prefix_survivors": survivors,
        "scope": "bounded_conditional_projected_model",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-width", type=int, default=4)
    parser.add_argument("--max-width", type=int, default=12)
    args = parser.parse_args()
    for width in range(args.min_width, args.max_width + 1, 2):
        row = audit(width)
        actual = (
            row["weak_profiles"], row["raw_tours"],
            row["endpoint_growth_tours"], row["lower_prefix_survivors"],
        )
        if width in EXPECTED and actual != EXPECTED[width]:
            raise AssertionError((width, actual, EXPECTED[width]))
        print(json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
