#!/usr/bin/env python3
"""Exact small-range search for nonlinear local Langton invariants.

This is a research audit, not a theorem about invariants of arbitrary range.  It
tests the following deliberately finite ansatz over both Z/2 and Z/4, first with
translation-invariant coefficients and then with coefficients periodic modulo two
in both coordinates:

* a global sum of the black-cell indicator and every black-pair indicator whose
  canonical displacement lies in [-2,2]^2; and
* a pose correction depending on the heading, an algebraic-normal-form monomial
  of degree at most two in the 3x3 black neighbourhood of the ant, and (in the
  second ansatz) the ant-position residue modulo two.

The first global sum is translation invariant.  In the second ansatz its cell and
pair coefficients may also depend on the anchor-cell residue modulo two.

Every one-step identity is expanded exactly as a multilinear polynomial in the
Boolean cell variables.  Thus the reported nullspaces have no sampled-state or
finite-box qualification; only the radius/degree ansatz is bounded.
"""

from __future__ import annotations

from itertools import combinations

from z3 import Int, Or, Solver, Sum, sat


DIRS = ((0, 1), (1, 0), (0, -1), (-1, 0))
POSE_OFFSETS = tuple((x, y) for x in range(-1, 2) for y in range(-1, 2))
PAIR_DISPLACEMENTS = tuple(
    (x, y)
    for x in range(-2, 3)
    for y in range(-2, 3)
    if (x, y) != (0, 0) and (x > 0 or (x == 0 and y > 0))
)
POSE_FEATURES = (
    ((),)
    + tuple((offset,) for offset in POSE_OFFSETS)
    + tuple(combinations(POSE_OFFSETS, 2))
)


def setup_variables() -> tuple[tuple[tuple[int, int], ...], dict[tuple[int, int], int]]:
    offsets = {(0, 0)}
    for dx, dy in PAIR_DISPLACEMENTS:
        offsets.add((dx, dy))
        offsets.add((-dx, -dy))
    offsets.update(POSE_OFFSETS)
    for mx, my in DIRS:
        offsets.update((mx + ox, my + oy) for ox, oy in POSE_OFFSETS)
    ordered = tuple(sorted(offsets))
    return ordered, {offset: index for index, offset in enumerate(ordered)}


OFFSETS, OFFSET_INDEX = setup_variables()
ZERO_BIT = 1 << OFFSET_INDEX[(0, 0)]


def unknowns() -> tuple[tuple[str, object, object], ...]:
    values: list[tuple[str, object, object]] = [("cell", None, None)]
    values.extend(("pair", displacement, None) for displacement in PAIR_DISPLACEMENTS)
    values.extend(
        ("pose", heading, feature)
        for heading in range(4)
        for feature in POSE_FEATURES
    )
    return tuple(values)


UNKNOWNS = unknowns()
PAIR_INDICES = tuple(
    index for index, item in enumerate(UNKNOWNS) if item[0] == "pair"
)
NONCONSTANT_POSE_INDICES = tuple(
    index
    for index, item in enumerate(UNKNOWNS)
    if item[0] == "pose" and item[2]
)
POSE_CONSTANT_INDEX = {
    int(item[1]): index
    for index, item in enumerate(UNKNOWNS)
    if item[0] == "pose" and not item[2]
}


def gf2_mul(left: set[int], right: set[int]) -> set[int]:
    result: set[int] = set()
    for first in left:
        for second in right:
            product = first | second
            if product in result:
                result.remove(product)
            else:
                result.add(product)
    return result


def gf2_bit(offset: tuple[int, int], flipped: bool = False) -> set[int]:
    result = {1 << OFFSET_INDEX[offset]}
    if flipped and offset == (0, 0):
        result.add(0)
    return result


def gf2_feature(
    center: tuple[int, int], feature: tuple[tuple[int, int], ...], flipped: bool = False
) -> set[int]:
    result = {0}
    for ox, oy in feature:
        result = gf2_mul(
            result, gf2_bit((center[0] + ox, center[1] + oy), flipped)
        )
    return result


def gf2_columns() -> list[list[set[int]]]:
    columns: list[list[set[int]]] = []
    for kind, parameter, feature in UNKNOWNS:
        by_heading: list[set[int]] = []
        for heading in range(4):
            polynomial: set[int] = set()
            if kind == "cell":
                polynomial = {0}
            elif kind == "pair":
                dx, dy = parameter  # type: ignore[misc]
                polynomial = {
                    1 << OFFSET_INDEX[(dx, dy)],
                    1 << OFFSET_INDEX[(-dx, -dy)],
                }
            else:
                pose_heading = int(parameter)
                if pose_heading == heading:
                    polynomial ^= gf2_feature((0, 0), feature)  # type: ignore[arg-type]
                right_heading = (heading + 1) % 4
                left_heading = (heading - 1) % 4
                if pose_heading == right_heading:
                    after = gf2_feature(DIRS[right_heading], feature, True)  # type: ignore[arg-type]
                    polynomial ^= after
                    polynomial ^= gf2_mul({ZERO_BIT}, after)
                if pose_heading == left_heading:
                    after = gf2_feature(DIRS[left_heading], feature, True)  # type: ignore[arg-type]
                    polynomial ^= gf2_mul({ZERO_BIT}, after)
            by_heading.append(polynomial)
        columns.append(by_heading)
    return columns


def gf2_nullspace() -> list[int]:
    equations: dict[tuple[int, int], int] = {}
    for column, by_heading in enumerate(gf2_columns()):
        for heading, polynomial in enumerate(by_heading):
            for monomial in polynomial:
                equations[(heading, monomial)] = equations.get((heading, monomial), 0) ^ (
                    1 << column
                )
    pivots: dict[int, int] = {}
    for row in equations.values():
        while row:
            pivot = row.bit_length() - 1
            if pivot in pivots:
                row ^= pivots[pivot]
            else:
                pivots[pivot] = row
                break
    free = [index for index in range(len(UNKNOWNS)) if index not in pivots]
    basis: list[int] = []
    for free_index in free:
        vector = 1 << free_index
        for pivot in sorted(pivots):
            if (pivots[pivot] & vector).bit_count() & 1:
                vector |= 1 << pivot
        basis.append(vector)
    return basis


Polynomial4 = dict[int, int]


def z4_add(left: Polynomial4, right: Polynomial4, scale: int = 1) -> Polynomial4:
    result = dict(left)
    for monomial, coefficient in right.items():
        result[monomial] = (result.get(monomial, 0) + scale * coefficient) % 4
        if not result[monomial]:
            del result[monomial]
    return result


def z4_mul(left: Polynomial4, right: Polynomial4) -> Polynomial4:
    result: Polynomial4 = {}
    for first, first_coefficient in left.items():
        for second, second_coefficient in right.items():
            monomial = first | second
            result[monomial] = (
                result.get(monomial, 0) + first_coefficient * second_coefficient
            ) % 4
    return {monomial: coefficient for monomial, coefficient in result.items() if coefficient}


def z4_bit(offset: tuple[int, int], flipped: bool = False) -> Polynomial4:
    if flipped and offset == (0, 0):
        return {0: 1, ZERO_BIT: 3}
    return {1 << OFFSET_INDEX[offset]: 1}


def z4_feature(
    center: tuple[int, int], feature: tuple[tuple[int, int], ...], flipped: bool = False
) -> Polynomial4:
    result = {0: 1}
    for ox, oy in feature:
        result = z4_mul(
            result, z4_bit((center[0] + ox, center[1] + oy), flipped)
        )
    return result


def z4_columns() -> list[list[Polynomial4]]:
    b0 = {ZERO_BIT: 1}
    one_minus_b0 = {0: 1, ZERO_BIT: 3}
    columns: list[list[Polynomial4]] = []
    for kind, parameter, feature in UNKNOWNS:
        by_heading: list[Polynomial4] = []
        for heading in range(4):
            polynomial: Polynomial4 = {}
            if kind == "cell":
                polynomial = {0: 1, ZERO_BIT: 2}
            elif kind == "pair":
                dx, dy = parameter  # type: ignore[misc]
                neighbours = z4_add(z4_bit((dx, dy)), z4_bit((-dx, -dy)))
                polynomial = z4_mul({0: 1, ZERO_BIT: 2}, neighbours)
            else:
                pose_heading = int(parameter)
                if pose_heading == heading:
                    polynomial = z4_add(
                        polynomial, z4_feature((0, 0), feature), -1  # type: ignore[arg-type]
                    )
                right_heading = (heading + 1) % 4
                left_heading = (heading - 1) % 4
                if pose_heading == right_heading:
                    after = z4_feature(DIRS[right_heading], feature, True)  # type: ignore[arg-type]
                    polynomial = z4_add(polynomial, z4_mul(one_minus_b0, after))
                if pose_heading == left_heading:
                    after = z4_feature(DIRS[left_heading], feature, True)  # type: ignore[arg-type]
                    polynomial = z4_add(polynomial, z4_mul(b0, after))
            by_heading.append(polynomial)
        columns.append(by_heading)
    return columns


def z4_solver() -> tuple[Solver, list[object]]:
    equations: dict[tuple[int, int], list[tuple[int, int]]] = {}
    for column, by_heading in enumerate(z4_columns()):
        for heading, polynomial in enumerate(by_heading):
            for monomial, coefficient in polynomial.items():
                equations.setdefault((heading, monomial), []).append((column, coefficient))
    variables = [Int(f"coefficient_{index}") for index in range(len(UNKNOWNS))]
    solver = Solver()
    for variable in variables:
        solver.add(variable >= 0, variable <= 3)
    for equation in equations.values():
        solver.add(Sum([coefficient * variables[index] for index, coefficient in equation]) % 4 == 0)
    return solver, variables


def residue_add(
    residue: tuple[int, int], offset: tuple[int, int]
) -> tuple[int, int]:
    return (residue[0] + offset[0]) % 2, (residue[1] + offset[1]) % 2


def period_two_unknowns() -> tuple[tuple[str, tuple[int, int], object, object], ...]:
    residues = tuple((x, y) for x in range(2) for y in range(2))
    values: list[tuple[str, tuple[int, int], object, object]] = []
    values.extend(("cell", residue, None, None) for residue in residues)
    values.extend(
        ("pair", residue, displacement, None)
        for residue in residues
        for displacement in PAIR_DISPLACEMENTS
    )
    values.extend(
        ("pose", residue, heading, feature)
        for residue in residues
        for heading in range(4)
        for feature in POSE_FEATURES
    )
    return tuple(values)


PERIOD_TWO_UNKNOWNS = period_two_unknowns()
PERIOD_TWO_PAIR_INDICES = tuple(
    index for index, item in enumerate(PERIOD_TWO_UNKNOWNS) if item[0] == "pair"
)


def period_two_gf2_has_pair_solution() -> bool:
    residues = tuple((x, y) for x in range(2) for y in range(2))
    equations: dict[tuple[tuple[int, int], int, int], int] = {}
    for column, (kind, anchor, parameter, feature) in enumerate(PERIOD_TWO_UNKNOWNS):
        for start_residue in residues:
            for heading in range(4):
                polynomial: set[int] = set()
                if kind == "cell":
                    if anchor == start_residue:
                        polynomial = {0}
                elif kind == "pair":
                    dx, dy = parameter  # type: ignore[misc]
                    if anchor == start_residue:
                        polynomial ^= {1 << OFFSET_INDEX[(dx, dy)]}
                    if residue_add(anchor, (dx, dy)) == start_residue:
                        polynomial ^= {1 << OFFSET_INDEX[(-dx, -dy)]}
                else:
                    pose_heading = int(parameter)
                    if anchor == start_residue and pose_heading == heading:
                        polynomial ^= gf2_feature((0, 0), feature)  # type: ignore[arg-type]
                    right_heading = (heading + 1) % 4
                    left_heading = (heading - 1) % 4
                    if (
                        anchor == residue_add(start_residue, DIRS[right_heading])
                        and pose_heading == right_heading
                    ):
                        after = gf2_feature(DIRS[right_heading], feature, True)  # type: ignore[arg-type]
                        polynomial ^= after
                        polynomial ^= gf2_mul({ZERO_BIT}, after)
                    if (
                        anchor == residue_add(start_residue, DIRS[left_heading])
                        and pose_heading == left_heading
                    ):
                        polynomial ^= gf2_mul(
                            {ZERO_BIT}, gf2_feature(DIRS[left_heading], feature, True)  # type: ignore[arg-type]
                        )
                for monomial in polynomial:
                    key = start_residue, heading, monomial
                    equations[key] = equations.get(key, 0) ^ (1 << column)

    pivots: dict[int, int] = {}
    for row in equations.values():
        while row:
            pivot = row.bit_length() - 1
            if pivot in pivots:
                row ^= pivots[pivot]
            else:
                pivots[pivot] = row
                break
    free = [
        index for index in range(len(PERIOD_TWO_UNKNOWNS)) if index not in pivots
    ]
    for free_index in free:
        vector = 1 << free_index
        for pivot in sorted(pivots):
            if (pivots[pivot] & vector).bit_count() & 1:
                vector |= 1 << pivot
        if any(vector >> index & 1 for index in PERIOD_TWO_PAIR_INDICES):
            return True
    return False


def period_two_z4_has_pair_solution() -> bool:
    residues = tuple((x, y) for x in range(2) for y in range(2))
    b0 = {ZERO_BIT: 1}
    one_minus_b0 = {0: 1, ZERO_BIT: 3}
    toggle_sign = {0: 1, ZERO_BIT: 2}
    equations: dict[
        tuple[tuple[int, int], int, int], list[tuple[int, int]]
    ] = {}
    for column, (kind, anchor, parameter, feature) in enumerate(PERIOD_TWO_UNKNOWNS):
        for start_residue in residues:
            for heading in range(4):
                polynomial: Polynomial4 = {}
                if kind == "cell":
                    if anchor == start_residue:
                        polynomial = toggle_sign
                elif kind == "pair":
                    dx, dy = parameter  # type: ignore[misc]
                    neighbours: Polynomial4 = {}
                    if anchor == start_residue:
                        neighbours = z4_add(neighbours, z4_bit((dx, dy)))
                    if residue_add(anchor, (dx, dy)) == start_residue:
                        neighbours = z4_add(neighbours, z4_bit((-dx, -dy)))
                    polynomial = z4_mul(toggle_sign, neighbours)
                else:
                    pose_heading = int(parameter)
                    if anchor == start_residue and pose_heading == heading:
                        polynomial = z4_add(
                            polynomial, z4_feature((0, 0), feature), -1  # type: ignore[arg-type]
                        )
                    right_heading = (heading + 1) % 4
                    left_heading = (heading - 1) % 4
                    if (
                        anchor == residue_add(start_residue, DIRS[right_heading])
                        and pose_heading == right_heading
                    ):
                        after = z4_feature(DIRS[right_heading], feature, True)  # type: ignore[arg-type]
                        polynomial = z4_add(
                            polynomial, z4_mul(one_minus_b0, after)
                        )
                    if (
                        anchor == residue_add(start_residue, DIRS[left_heading])
                        and pose_heading == left_heading
                    ):
                        after = z4_feature(DIRS[left_heading], feature, True)  # type: ignore[arg-type]
                        polynomial = z4_add(polynomial, z4_mul(b0, after))
                for monomial, coefficient in polynomial.items():
                    key = start_residue, heading, monomial
                    equations.setdefault(key, []).append((column, coefficient))

    variables = [
        Int(f"period_two_coefficient_{index}")
        for index in range(len(PERIOD_TWO_UNKNOWNS))
    ]
    solver = Solver()
    for variable in variables:
        solver.add(variable >= 0, variable <= 3)
    for equation in equations.values():
        solver.add(
            Sum([coefficient * variables[index] for index, coefficient in equation])
            % 4
            == 0
        )
    solver.add(Or([variables[index] != 0 for index in PERIOD_TWO_PAIR_INDICES]))
    return solver.check() == sat


def main() -> None:
    basis = gf2_nullspace()
    assert len(basis) == 2
    expected_mod2 = {
        frozenset((0, POSE_CONSTANT_INDEX[1], POSE_CONSTANT_INDEX[3])),
        frozenset(POSE_CONSTANT_INDEX.values()),
    }
    actual_mod2 = {
        frozenset(index for index in range(len(UNKNOWNS)) if vector >> index & 1)
        for vector in basis
    }
    assert actual_mod2 == expected_mod2

    solver, variables = z4_solver()
    solver.push()
    solver.add(Or([variables[index] != 0 for index in PAIR_INDICES]))
    assert solver.check() != sat
    solver.pop()

    assert not period_two_gf2_has_pair_solution()
    assert not period_two_z4_has_pair_solution()

    solver.push()
    solver.add(Or([variables[index] != 0 for index in NONCONSTANT_POSE_INDICES]))
    assert solver.check() != sat
    solver.pop()

    # With pairs and nonconstant pose terms absent, every solution must be a
    # multiple of black_count - heading plus a global constant.
    cell = variables[0]
    deviations = [
        (variables[POSE_CONSTANT_INDEX[heading]]
         - variables[POSE_CONSTANT_INDEX[0]] + heading * cell) % 4 != 0
        for heading in range(1, 4)
    ]
    solver.push()
    solver.add(Or(deviations))
    assert solver.check() != sat
    solver.pop()

    print("schema=langton-local-pair-invariant-audit-v1")
    print(f"boolean_variables={len(OFFSETS)}")
    print(f"unknown_coefficients={len(UNKNOWNS)}")
    print(f"pair_displacements={len(PAIR_DISPLACEMENTS)}")
    print(f"pose_features_per_heading={len(POSE_FEATURES)}")
    print("mod2_nullity=2")
    print("mod2_only=constant,black_parity_plus_heading_axis")
    print("mod4_pair_solution=false")
    print("mod4_nonconstant_pose_solution=false")
    print("mod4_only=constant,black_count_minus_heading")
    print(f"period_two_unknown_coefficients={len(PERIOD_TWO_UNKNOWNS)}")
    print("period_two_mod2_pair_solution=false")
    print("period_two_mod4_pair_solution=false")
    print("all_checks_passed=true")


if __name__ == "__main__":
    main()
