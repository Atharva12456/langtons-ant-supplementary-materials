"""Finite-window regression for the analytic primitive cap-four obstruction.

The proof is the voltage-unbounded case split in
``research-notes/primitive_cap4_analytic_2026-08-20.md``.  This script is only a
reproducibility audit: it enumerates every exact-P3 frontier whose individual
subtree voltages lie in ``[-B,B]`` and checks that the symbolic depth-three table
is exact in that window and that no state reaches depth four.
"""

from __future__ import annotations

import argparse
import itertools
from functools import lru_cache


State = tuple[tuple[int, ...], tuple[int, ...]]


def alternating_word(length: int) -> tuple[int, ...]:
    return tuple(1 if index % 2 == 0 else -1 for index in range(length))


@lru_cache(None)
def positive_compositions(total: int, parts: int) -> tuple[tuple[int, ...], ...]:
    if parts == 0:
        return ((),) if total == 0 else ()
    if parts == 1:
        return ((total,),) if total >= 1 else ()
    rows = []
    for first in range(1, total - parts + 2):
        for tail in positive_compositions(total - first, parts - 1):
            rows.append((first,) + tail)
    return tuple(rows)


@lru_cache(None)
def bounded_compositions(
    length: int, total: int, bound: int
) -> tuple[tuple[int, ...], ...]:
    if length == 0:
        return ((),) if total == 0 else ()
    if length == 1:
        return ((total,),) if -bound <= total <= bound else ()
    rows = []
    low = max(-bound, total - bound * (length - 1))
    high = min(bound, total + bound * (length - 1))
    for first in range(low, high + 1):
        for tail in bounded_compositions(length - 1, total - first, bound):
            rows.append((first,) + tail)
    return tuple(rows)


def child_counts(parents: int, depth: int):
    """Yield every (children, nonleaves) allowed by exact alternating charge."""
    for children in range(1, 5):
        omega = (parents + children) & 1
        numerator = (
            parents + children + omega
            if depth & 1
            else parents + children - omega
        )
        if numerator % 4:
            continue
        nonleaves = numerator // 4
        if 1 <= nonleaves <= min(parents, children):
            yield children, nonleaves


def degree_rows(
    voltages: tuple[int, ...], epsilon: int, children: int, nonleaves: int
):
    required = tuple(index for index, value in enumerate(voltages) if value != epsilon)
    optional = tuple(index for index, value in enumerate(voltages) if value == epsilon)
    extra = nonleaves - len(required)
    if not 0 <= extra <= len(optional):
        return
    for chosen in itertools.combinations(optional, extra):
        positions = tuple(sorted(required + chosen))
        for parts in positive_compositions(children, len(positions)):
            row = [0] * len(voltages)
            for position, degree in zip(positions, parts):
                row[position] = degree
            yield tuple(row)


def extend(state: State, depth: int, bound: int):
    bases, voltages = state
    epsilon = -1 if depth & 1 else 1
    first_sign = 1 if depth & 1 else -1
    middle_sign = -first_sign
    for children, nonleaves in child_counts(len(voltages), depth):
        for degrees in degree_rows(voltages, epsilon, children, nonleaves):
            choices = []
            for voltage, degree in zip(voltages, degrees):
                rows = bounded_compositions(degree, voltage - epsilon, bound)
                if not rows:
                    break
                choices.append(rows)
            else:
                for grouped in itertools.product(*choices):
                    events = []
                    child_bases = []
                    child_voltages = []
                    plane_order = 0
                    for base, degree, group in zip(bases, degrees, grouped):
                        if degree == 0:
                            events.append((base, plane_order, -first_sign))
                            plane_order += 1
                            continue
                        position = base
                        events.append((position, plane_order, first_sign))
                        plane_order += 1
                        for index, voltage in enumerate(group):
                            child_bases.append(position + (1 if depth & 1 else 0))
                            child_voltages.append(voltage)
                            position += voltage
                            sign = first_sign if index + 1 == degree else middle_sign
                            events.append((position, plane_order, sign))
                            plane_order += 1
                    stable = tuple(
                        sign for _base, _order, sign in
                        sorted(events, key=lambda item: (-item[0], item[1]))
                    )
                    if stable == alternating_word(len(stable)):
                        yield tuple(child_bases), tuple(child_voltages)


def expected_depth_three(bound: int) -> set[State]:
    expected = {
        ((1, 2, 2, 3), (2, 0, 1, 0)),
        ((1, 2, 3, 2), (2, 1, -1, 1)),
        ((3, 3, 4, 3), (0, 1, 0, 2)),
        ((3, 4, 3, 3), (1, -1, 1, 2)),
        ((2, 2), (0, 0)),
    }
    for parameter in range(2 - bound, 2):
        expected.add(
            ((2, parameter, 2), (parameter - 2, 2 - parameter, 0))
        )
        expected.add(
            ((2, 2, parameter), (0, parameter - 2, 2 - parameter))
        )
    return expected


def audit(bound: int):
    if bound < 3:
        raise ValueError("the symbolic-window assertion requires bound >= 3")
    states: set[State] = {((0,), (1,))}
    counts = []
    for depth in range(1, 4):
        states = {
            child
            for state in states
            for child in extend(state, depth, bound)
        }
        counts.append(len(states))
    expected = expected_depth_three(bound)
    assert states == expected, (
        "depth-three mismatch",
        sorted(states - expected),
        sorted(expected - states),
    )
    depth_four = {
        child
        for state in states
        for child in extend(state, 4, bound)
    }
    assert not depth_four, sorted(depth_four)[:10]
    return {
        "bound": bound,
        "depth_counts": counts + [0],
        "depth_three_fixed": 5,
        "depth_three_parametric": 2 * bound,
        "depth_four": 0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bounds", default="3,5,10,20")
    args = parser.parse_args()
    bounds = [int(item) for item in args.bounds.split(",")]
    for bound in bounds:
        print(audit(bound))
    print("status=all_assertions_passed; theorem_is_analytic_not_bounded")


if __name__ == "__main__":
    main()
