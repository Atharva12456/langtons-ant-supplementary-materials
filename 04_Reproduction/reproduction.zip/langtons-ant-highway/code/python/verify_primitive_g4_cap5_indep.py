"""Independent exact check of the primitive-g4 cap-five obstruction.

This implementation does not import the primary symbolic enumerator.  It uses
one-parameter affine pairs directly, derives the terminal voltage sum from the
bottom-root voltage, and samples one integer from every order cell cut out by
the exact rational crossing points.
"""

from fractions import Fraction
from itertools import combinations, product


def plus(left, right):
    return left[0] + right[0], left[1] + right[1]


def minus(left, right):
    return left[0] - right[0], left[1] - right[1]


def scalar_value(line, parameter):
    return line[0] * parameter + line[1]


def ordered_degrees(nodes, children, nonleaves):
    """Generate ordered nonnegative rows of sum children and support size p."""
    for support_tuple in combinations(range(nodes), nonleaves):
        support = frozenset(support_tuple)

        def visit(index, remaining, row):
            if index == nodes:
                if remaining == 0:
                    yield tuple(row)
                return
            if index not in support:
                yield from visit(index + 1, remaining, row + [0])
                return
            later = sum(position > index for position in support)
            for degree in range(1, remaining - later + 1):
                yield from visit(index + 1, remaining - degree, row + [degree])

        yield from visit(0, children, [])


def count_row(nodes, children, depth):
    wake = (nodes + children) & 1
    signed = wake if depth & 1 else -wake
    numerator = nodes + children + signed
    if numerator % 4:
        return None
    nonleaves = numerator // 4
    if not 1 <= nonleaves <= min(nodes, children):
        return None
    return wake, nonleaves


def build_numeric_tree(degree_rows, terminal_voltages):
    """Return voltage and base rows as affine pairs (slope, intercept)."""
    terminal_depth = len(degree_rows) + 1
    voltages = {terminal_depth: list(terminal_voltages)}
    for depth in range(terminal_depth - 1, 0, -1):
        child_row = voltages[depth + 1]
        cursor = 0
        sign = 1 if depth % 2 == 0 else -1
        row = []
        for degree in degree_rows[depth - 1]:
            total = (0, sign)
            for child in child_row[cursor:cursor + degree]:
                total = plus(total, child)
            cursor += degree
            row.append(total)
        assert cursor == len(child_row)
        voltages[depth] = row

    bases = {1: [(0, 0)]}
    for depth, degrees in enumerate(degree_rows, 1):
        child_row = voltages[depth + 1]
        cursor = 0
        next_bases = []
        child_offset = 1 if depth & 1 else 0
        for base, degree in zip(bases[depth], degrees):
            position = plus(base, (0, child_offset))
            for _ in range(degree):
                next_bases.append(position)
                position = plus(position, child_row[cursor])
                cursor += 1
        assert cursor == len(child_row)
        bases[depth + 1] = next_bases
    return voltages, bases


def affine_tree(degree_rows, leaf_nodes):
    terminal_depth = len(degree_rows) + 1
    terminal_count = sum(degree_rows[-1])
    sign = 1 if terminal_depth % 2 == 0 else -1
    variable_nodes = [node for node in range(terminal_count) if node not in leaf_nodes]

    # With all variable voltages temporarily zero, the depth-one voltage is C.
    provisional = [(0, sign if node in leaf_nodes else 0)
                   for node in range(terminal_count)]
    provisional_voltages, _ = build_numeric_tree(degree_rows, provisional)
    constant = provisional_voltages[1][0][1]
    required_sum = 1 - constant

    if not variable_nodes:
        if required_sum:
            return None
        terminal = [(0, sign)] * terminal_count
    elif len(variable_nodes) == 1:
        terminal = [(0, sign if node in leaf_nodes else required_sum)
                    for node in range(terminal_count)]
    else:
        assert len(variable_nodes) == 2
        first, second = variable_nodes
        terminal = []
        for node in range(terminal_count):
            if node in leaf_nodes:
                terminal.append((0, sign))
            elif node == first:
                terminal.append((1, 0))
            else:
                assert node == second
                terminal.append((-1, required_sum))

    voltages, bases = build_numeric_tree(degree_rows, terminal)
    assert voltages[1][0] == (0, 1)
    return voltages, bases


def row_events(depth, degrees, bases, child_voltages):
    events = []
    cursor = 0
    phase_rank = 0
    endpoint = "R" if depth & 1 else "L"
    middle = "L" if depth & 1 else "R"
    for base, degree in zip(bases, degrees):
        if degree == 0:
            events.append((base, phase_rank, middle))
            phase_rank += 1
            continue
        position = base
        events.append((position, phase_rank, endpoint))
        phase_rank += 1
        for child_number in range(degree):
            position = plus(position, child_voltages[cursor])
            cursor += 1
            turn = endpoint if child_number + 1 == degree else middle
            events.append((position, phase_rank, turn))
            phase_rank += 1
    assert cursor == len(child_voltages)
    return events


def integer_order_samples(lines):
    roots = set()
    for left, right in combinations(lines, 2):
        slope = left[0] - right[0]
        if slope:
            roots.add(Fraction(right[1] - left[1], slope))
    roots = sorted(roots)
    samples = {0}
    for root in roots:
        low = root.numerator // root.denominator
        samples.update((low - 1, low, low + 1, low + 2))
    for left, right in zip(roots, roots[1:]):
        candidate = left.numerator // left.denominator + 1
        if left < candidate < right:
            samples.add(candidate)
    if roots:
        samples.add(roots[0].numerator // roots[0].denominator - 2)
        samples.add(roots[-1].numerator // roots[-1].denominator + 2)
    return sorted(samples)


def alternating(length):
    return "".join("R" if index % 2 == 0 else "L" for index in range(length))


def embeds(fixed, target):
    index = 0
    for symbol in fixed:
        while index < len(target) and target[index] != symbol:
            index += 1
        if index == len(target):
            return False
        index += 1
    return True


def inspect_skeleton(degree_rows, leaf_nodes, next_children):
    tree = affine_tree(degree_rows, leaf_nodes)
    if tree is None:
        return set(), []
    voltages, bases = tree
    terminal_depth = len(degree_rows) + 1
    exact_rows = []
    for depth, degrees in enumerate(degree_rows, 1):
        exact_rows.append(row_events(
            depth, degrees, bases[depth], voltages[depth + 1]
        ))

    terminal_sign = 1 if terminal_depth % 2 == 0 else -1
    endpoint = "R" if terminal_depth & 1 else "L"
    leaf_turn = "L" if terminal_depth & 1 else "R"
    fixed = []
    for node, (base, voltage) in enumerate(zip(
            bases[terminal_depth], voltages[terminal_depth])):
        if node in leaf_nodes:
            fixed.append((base, 2 * node, leaf_turn))
        else:
            finish = minus(plus(base, voltage), (0, terminal_sign))
            fixed.append((base, 2 * node, endpoint))
            fixed.append((finish, 2 * node + 1, endpoint))

    all_lines = [event[0] for row in exact_rows for event in row]
    all_lines.extend(event[0] for event in fixed)
    regimes = set()
    survivors = []
    terminal_target = alternating(5 + next_children)
    for parameter in integer_order_samples(all_lines):
        if any("".join(event[2] for event in sorted(
                row, key=lambda event: (-scalar_value(event[0], parameter), event[1])
        )) != alternating(len(row)) for row in exact_rows):
            continue
        stable_fixed = sorted(
            fixed, key=lambda event: (-scalar_value(event[0], parameter), event[1])
        )
        fixed_word = "".join(event[2] for event in stable_fixed)
        record = (
            tuple(scalar_value(line, parameter) for line in bases[terminal_depth]),
            tuple(scalar_value(line, parameter) for line in voltages[terminal_depth]),
            fixed_word,
            terminal_target,
        )
        regimes.add(record)
        if embeds(fixed_word, terminal_target):
            survivors.append((parameter, record))
    return regimes, survivors


def main():
    skeleton_count = 0
    all_regimes = set()
    all_survivors = []
    for earliest in (2, 3, 4):
        for cuts in product(range(1, 6), repeat=earliest):
            if cuts[-1] != 5 or 5 in cuts[:-1]:
                continue
            nodes = 1
            even_wakes = odd_wakes = 0
            degree_choices = []
            for depth, children in enumerate(cuts, 1):
                data = count_row(nodes, children, depth)
                if data is None:
                    break
                wake, nonleaves = data
                even_wakes += wake if depth % 2 == 0 else 0
                odd_wakes += wake if depth % 2 == 1 else 0
                if even_wakes > 1 or odd_wakes > 1:
                    break
                degree_choices.append(tuple(ordered_degrees(nodes, children, nonleaves)))
                nodes = children
            else:
                terminal_depth = earliest + 1
                for degree_rows in product(*degree_choices):
                    for next_children in range(1, 6):
                        data = count_row(5, next_children, terminal_depth)
                        if data is None:
                            continue
                        wake, next_nonleaves = data
                        ew = even_wakes + (wake if terminal_depth % 2 == 0 else 0)
                        ow = odd_wakes + (wake if terminal_depth % 2 == 1 else 0)
                        if ew > 1 or ow > 1:
                            continue
                        leaf_count = 5 - next_nonleaves
                        if leaf_count < 3:
                            continue
                        for leaf_tuple in combinations(range(5), leaf_count):
                            skeleton_count += 1
                            regimes, survivors = inspect_skeleton(
                                degree_rows, frozenset(leaf_tuple), next_children
                            )
                            for regime in regimes:
                                all_regimes.add((cuts, next_children) + regime)
                            if survivors:
                                all_survivors.append((cuts, degree_rows, leaf_tuple,
                                                      next_children, survivors))

    print({
        "schema": "primitive-g4-cap5-independent-v1",
        "skeleton_leaf_choices": skeleton_count,
        "distinct_exact_source_regimes": len(all_regimes),
        "survivors": len(all_survivors),
        "status": "verified_zero" if not all_survivors else "counterexample",
    })
    for row in sorted(all_regimes):
        print("SOURCE", row)
    if all_survivors:
        for row in all_survivors[:10]:
            print("SURVIVOR", row)
        raise SystemExit(1)


if __name__ == "__main__":
    main()

