"""An upper missing cap at drift (1,-3) cannot have offsets 5-9, 11 and 12 all non-wake.

Upper inward offsets, headings rotated by 180 degrees. The missing cap fixes

    0: WR
    1: NR
    2: (empty)

Offsets 3 and 4 are enumerated with both wake values (the known cap rows
3: SR,SL and 4: WR,WL,ER appear as the only survivors). Offsets 5-9, 11 and 12
are non-wake; offset 10 takes both wake values. Every later row is enumerated
from the flow and excess equations and right/left alternation. A word is
discarded only for a violated zero-displacement return while it is built, a
witnessed finite same-cell first return to the wrong event (no quotient-cycle
extrapolation), or an infeasible upper-cap lifted clock

    tau(target) = tau(source) + 1 + N*lambda,   N >= 6,   same-cell gaps >= 4.

No P22, rank or moment condition is used; those enter only when the lemma is
applied to a wake family. The frontier is empty at offset 12, so the lemma
holds at every period and every width.

Run from the repository root:
    python code/python/verify_upper_missing_quiet_5_12_lemma.py
It writes results/upper_missing_quiet_5_12_checks_2026-09-23.json.
"""
from collections import Counter
from pathlib import Path
import json

import z3

from verify_lower_fat123_a0_102_exclusion import (row_counts, successors,
                                                  witnessed_bad_return, words)

SCHEDULE = {5: (0,), 6: (0,), 7: (0,), 8: (0,), 9: (0,), 10: (0, 1), 11: (0,), 12: (0,)}
EXPECTED = [2, 1, 1, 2, 3, 2, 5, 4, 6, 0]


def upper_clock_feasible(rows, succ):
    n = z3.Int('N')
    tau = {(t, i): z3.Int(f'tau_{t}_{i}') for t, r in rows.items() for i in range(len(r))}
    s = z3.SolverFor('QF_LIA')
    s.add(n >= 6)
    for (t, i), (u, j, v) in succ.items():
        s.add(tau[u, j] - tau[t, i] == 1 + v * n)
    for t, r in rows.items():
        for i in range(len(r) - 1):
            s.add(tau[t, i + 1] - tau[t, i] >= 4)
    res = s.check()
    if res == z3.unknown:
        raise RuntimeError(s.reason_unknown())
    return res == z3.sat


def verify():
    states = [{0: ('WR',), 1: ('NR',), 2: ()}]
    history = []
    for t in range(3, 13):
        nxt, st = [], Counter()
        for rows in states:
            for wake in SCHEDULE.get(t, (0, 1)):
                for cnt in row_counts(rows, t, wake):
                    st['count_rows'] += 1
                    for w in words(rows, t, cnt):
                        st['words'] += 1
                        child = {**rows, t: w}
                        succ = successors(child)
                        assert succ is not None
                        if witnessed_bad_return(child, succ) is not None:
                            st['return_rejected'] += 1
                        elif not upper_clock_feasible(child, succ):
                            st['clock_rejected'] += 1
                        else:
                            nxt.append(child)
        states = nxt
        history.append({'offset': t, 'wakes': list(SCHEDULE.get(t, (0, 1))), **st, 'survivors': len(states)})
        print(history[-1], flush=True)
    assert [h['survivors'] for h in history] == EXPECTED, history
    return {
        'claim': 'An upper missing cap at drift (1,-3) with offsets 5-9, 11, 12 non-wake is impossible at every period',
        'not_used': ['P22', 'rank', 'moment', 'quotient-cycle extrapolation', 'period/width/row-length bounds'],
        'history': history,
        'all_checks_passed': True,
    }


if __name__ == '__main__':
    report = verify()
    out = Path(__file__).resolve().parents[2] / 'results' / 'upper_missing_quiet_5_12_checks_2026-09-23.json'
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
