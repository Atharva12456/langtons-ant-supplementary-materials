#!/usr/bin/env python3
"""Regression for the rank condition at drift (2,4) and (2,-4).

The proof reduces the directed-edge multiplicities modulo two.  This program
solves those finite systems directly, computes the port-permutation and local
signs, and compares them with the closed boundary-interlacing formula.  The
finite range checked here is evidence for the algebraic proof, not a period or
width search.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path


Block = tuple[str, int, int]
Vertex = tuple[int, int]


def target(block: Block, vertical_sign: int) -> Vertex:
    """Target in (r,t), where t=2x-y or 2x+y."""
    kind, lane, level = block
    if kind == "E":
        return 1 - lane, level + 2
    if kind == "W":
        return 1 - lane, level - 2
    if kind == "N":
        return lane, level + vertical_sign
    if kind == "S":
        return lane, level - vertical_sign
    raise AssertionError(kind)


def source_key(block: Block) -> tuple[int, int, int]:
    kind, lane, level = block
    return level, lane, int(kind in "EN")


def target_key(block: Block, vertical_sign: int) -> tuple[int, int, int]:
    lane, level = target(block, vertical_sign)
    return level, lane, int(block[0] in "EN")


def strip_blocks(low: int, high: int, vertical_sign: int) -> list[Block]:
    blocks = []
    for level in range(low, high + 1):
        for lane in range(2):
            kinds = "WE" if (lane + level) % 2 == 0 else "SN"
            for kind in kinds:
                block = kind, lane, level
                _target_lane, target_level = target(block, vertical_sign)
                if low <= target_level <= high:
                    blocks.append(block)
    return blocks


def parity_rows(
    boundary: set[Vertex],
    low: int,
    high: int,
    blocks: list[Block],
    vertical_sign: int,
) -> list[int]:
    index = {block: position for position, block in enumerate(blocks)}
    rows = []
    for level in range(low, high + 1):
        for lane in range(2):
            vertex = lane, level
            right = int(vertex in boundary)
            outgoing = [block for block in blocks if block[1:] == vertex]
            incoming = [
                block
                for block in blocks
                if target(block, vertical_sign) == vertex
            ]
            for incident in (outgoing, incoming):
                coefficients = sum(1 << index[block] for block in incident)
                rows.append(coefficients | (right << len(blocks)))
    return rows


def solve_unique(rows: list[int], variable_count: int) -> int:
    rows = rows[:]
    pivots = []
    rank = 0
    for column in range(variable_count):
        pivot = next(
            (
                index
                for index in range(rank, len(rows))
                if (rows[index] >> column) & 1
            ),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for index in range(len(rows)):
            if index != rank and ((rows[index] >> column) & 1):
                rows[index] ^= rows[rank]
        pivots.append(column)
        rank += 1

    coefficient_mask = (1 << variable_count) - 1
    assert not any(
        (row & coefficient_mask) == 0 and ((row >> variable_count) & 1)
        for row in rows
    )
    assert rank == variable_count
    solution = 0
    for row, pivot in zip(rows[:rank], pivots):
        if (row >> variable_count) & 1:
            solution |= 1 << pivot
    return solution


def edge_sign(blocks: set[Block], vertical_sign: int) -> int:
    ordered = sorted(blocks, key=source_key)
    return sum(
        target_key(first, vertical_sign) > target_key(second, vertical_sign)
        for index, first in enumerate(ordered)
        for second in ordered[index + 1 :]
    ) & 1


def local_sign(
    blocks: set[Block], boundary: set[Vertex], vertical_sign: int
) -> int:
    outgoing: dict[Vertex, list[Block]] = defaultdict(list)
    incoming: dict[Vertex, list[Block]] = defaultdict(list)
    for block in blocks:
        outgoing[block[1:]].append(block)
        incoming[target(block, vertical_sign)].append(block)

    answer = 0
    for vertex in set(outgoing) | set(incoming) | boundary:
        lane, level = vertex
        excess = int(vertex in boundary)
        positive = (
            sum(block[0] in "EN" for block in outgoing[vertex])
            + sum(block[0] in "EN" for block in incoming[vertex])
        ) & 1
        if (lane + level) % 2 == 0:
            answer ^= positive & (excess ^ 1)
        else:
            answer ^= excess & (positive ^ 1)
    return answer


def direct_blocks(
    boundary: set[Vertex], vertical_sign: int, margin: int
) -> set[Block]:
    low = min(level for _lane, level in boundary) - margin
    high = max(level for _lane, level in boundary) + margin
    blocks = strip_blocks(low, high, vertical_sign)
    bits = solve_unique(
        parity_rows(boundary, low, high, blocks, vertical_sign), len(blocks)
    )
    return {
        block for position, block in enumerate(blocks) if (bits >> position) & 1
    }


def flow_value(
    blocks: set[Block], boundary: set[Vertex], vertical_sign: int
) -> int:
    return edge_sign(blocks, vertical_sign) ^ local_sign(
        blocks, boundary, vertical_sign
    )


def direct_value(boundary: set[Vertex], vertical_sign: int, margin: int) -> int:
    selected = direct_blocks(boundary, vertical_sign, margin)
    return flow_value(selected, boundary, vertical_sign)


def interlacing(first: tuple[int, int], second: tuple[int, int]) -> int:
    return sum(left < right for left in first for right in second) & 1


def expected_value(pairs: tuple[tuple[int, int], ...]) -> int:
    """The minority pair is pairs[0]; the other three form the six-class lane."""
    return sum(
        interlacing(pairs[first], pairs[second])
        for first in range(1, 4)
        for second in range(first + 1, 4)
    ) & 1


def skew_weight(x: int, y: int, sign: int) -> int:
    """The extra drift-periodic four-corner weight for d=(2,4*sign)."""
    checker = 1 if (x + y) % 2 == 0 else -1
    return checker * (x // 2 - sign * (y // 4)) % 4


def weight_monodromy(x: int, y: int, sign: int) -> int:
    """Integrate the north-heading potential from p to p+(2,4*sign)."""
    value = 0
    northeast = 1 + 2 * sign
    southeast = 1 - 2 * sign
    for _ in range(abs(northeast)):
        if northeast > 0:
            value += -skew_weight(x, y, sign) + skew_weight(x + 1, y, sign)
            x, y = x + 1, y + 1
        else:
            value -= -skew_weight(x - 1, y - 1, sign) + skew_weight(
                x, y - 1, sign
            )
            x, y = x - 1, y - 1
    for _ in range(abs(southeast)):
        if southeast > 0:
            value += skew_weight(x, y - 1, sign) - skew_weight(
                x + 1, y - 1, sign
            )
            x, y = x + 1, y - 1
        else:
            value -= skew_weight(x - 1, y, sign) - skew_weight(x, y, sign)
            x, y = x - 1, y + 1
    return value % 4


def moment_value(pairs: tuple[tuple[int, int], ...]) -> int:
    residues = (0, 0, 1, 3)
    sums = [
        sum((level - residues[index]) // 4 for level in pair)
        for index, pair in enumerate(pairs)
    ]
    return (sums[0] - sums[1] + sums[2] + sums[3]) % 4


def audit(max_index: int, margin: int) -> dict[str, object]:
    if max_index < 3:
        raise ValueError("max_index must be at least 3")
    if margin < 2:
        raise ValueError("margin must be at least 2")

    # After translating the residue labels, P22 has a doubled point in one
    # lane at t=0 mod 4 and doubled points in the other lane at t=0,1,3 mod 4.
    specifications = ((0, 0), (1, 0), (1, 1), (1, 3))
    choices = [
        list(
            itertools.combinations(
                (residue + 4 * index for index in range(max_index + 1)), 2
            )
        )
        for _lane, residue in specifications
    ]

    configurations = 0
    values = [0, 0]
    orientation_rows = []
    segment_table_checks = 0
    additive_weight_checks = 0
    for vertical_sign, drift in ((-1, [2, 4]), (1, [2, -4])):
        sign = -vertical_sign
        for x in range(-8, 9):
            for y in range(-8, 9):
                assert (
                    skew_weight(x, y, sign)
                    + skew_weight(x + 1, y, sign)
                    + skew_weight(x, y + 1, sign)
                    + skew_weight(x + 1, y + 1, sign)
                ) % 4 == 0
                assert skew_weight(x + 2, y + 4 * sign, sign) == skew_weight(
                    x, y, sign
                )
                additive_weight_checks += 2
                if (x + y) % 2 == 0:
                    assert weight_monodromy(x, y, sign) == 3
                    additive_weight_checks += 1

        segment_boundary = {
            (kind, index): {
                (lane, residue + 4 * index),
                (lane, residue + 4 * index + 4),
            }
            for kind, (lane, residue) in enumerate(specifications)
            for index in range(-3, 4)
        }
        segments = {
            key: direct_blocks(boundary, vertical_sign, margin)
            for key, boundary in segment_boundary.items()
        }
        for kind in range(4):
            actual = flow_value(
                segments[kind, 0], segment_boundary[kind, 0], vertical_sign
            )
            assert actual == int(vertical_sign == 1)
            segment_table_checks += 1
        for first in range(4):
            for second in range(first, 4):
                for delta in range(-3, 4):
                    first_key = first, 0
                    second_key = second, delta
                    combined_blocks = segments[first_key] ^ segments[second_key]
                    combined_boundary = (
                        segment_boundary[first_key] ^ segment_boundary[second_key]
                    )
                    cross = flow_value(
                        combined_blocks, combined_boundary, vertical_sign
                    )
                    cross ^= flow_value(
                        segments[first_key],
                        segment_boundary[first_key],
                        vertical_sign,
                    )
                    cross ^= flow_value(
                        segments[second_key],
                        segment_boundary[second_key],
                        vertical_sign,
                    )
                    expected_cross = 0
                    if first != second and first > 0 and delta in (-1, 0):
                        expected_cross = 1
                    if (
                        vertical_sign == 1
                        and first == second
                        and abs(delta) == 1
                    ):
                        expected_cross = 1
                    assert cross == expected_cross
                    segment_table_checks += 1

        orientation_count = 0
        orientation_values = [0, 0]
        rank_moment_counts = {
            "rank_0_moment_false": 0,
            "rank_0_moment_true": 0,
            "rank_1_moment_false": 0,
            "rank_1_moment_true": 0,
        }
        for pairs in itertools.product(*choices):
            boundary = {
                (specifications[index][0], level)
                for index in range(4)
                for level in pairs[index]
            }
            direct = direct_value(boundary, vertical_sign, margin)
            expected = expected_value(pairs)
            assert direct == expected
            bases = [
                (lane, sign * (2 * lane - level))
                for index, (lane, _residue) in enumerate(specifications)
                for level in pairs[index]
            ]
            direct_moment = (sum(skew_weight(x, y, sign) for x, y in bases) + 3) % 4
            moment_ok = moment_value(pairs) == (-sign) % 4
            assert (direct_moment == 0) == moment_ok
            configurations += 1
            orientation_count += 1
            values[direct] += 1
            orientation_values[direct] += 1
            rank_moment_counts[
                f"rank_{direct}_moment_{str(moment_ok).lower()}"
            ] += 1
        orientation_rows.append(
            {
                "drift": drift,
                "configurations": orientation_count,
                "rank_values": orientation_values,
                "rank_moment_counts": rank_moment_counts,
            }
        )

    return {
        "schema": "langton-growth8-skew-rank-parity-audit-v1",
        "status": "bounded_evidence_not_proof",
        "maximum_chain_index": max_index,
        "exterior_margin": margin,
        "orientations": orientation_rows,
        "configurations_checked": configurations,
        "segment_table_checks": segment_table_checks,
        "additive_weight_checks": additive_weight_checks,
        "rank_values": values,
        "closed_formula": "I_12 + I_13 + I_23 (mod 2)",
        "additive_moment": "S_A - S_0 + S_1 + S_3 = -s (mod 4)",
        "all_checks_passed": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-index", type=int, default=3)
    parser.add_argument("--margin", type=int, default=2)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = audit(args.max_index, args.margin)
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
