"""Exact bounded exploration of diagonal width-six periodic traces.

This is research code, not an all-period certificate.  It observes the ant on the
odd transverse lines 1, 3, and 5 of the normalized strip t=x+y in {0,...,6}.
Every macro step contains two turns and is generated directly from the Langton rule.

The DFS enforces ordinary alternation at each physical cell.  At every closed,
positive-growth, positive-drift leaf that reaches both extremes it applies the full
stabilized translation-class criterion.  Therefore a hit is a genuine periodic
trace admitted by finite support; a zero result excludes only the requested finite
macro-period range.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import time

from explore_chronology import walk
from verify_extremal import p3_valid


NORTH, EAST, SOUTH, WEST = range(4)
DX = (0, 1, 0, -1)
DY = (1, 0, -1, 0)
STATE_NAMES = {
    (1, NORTH): "LN",
    (1, SOUTH): "LS",
    (3, NORTH): "MN",
    (3, SOUTH): "MS",
    (5, NORTH): "UN",
    (5, SOUTH): "US",
}
START = (1, NORTH)


@dataclass(frozen=True)
class Transition:
    target: tuple[int, int]
    delta_ell: int
    turns: str
    even_line: int
    even_offset: int


def turned(heading: int, turn: str) -> int:
    return (heading + (1 if turn == "R" else -1)) % 4


def generate_transitions() -> dict[tuple[int, int], tuple[Transition, ...]]:
    """Derive the complete two-turn macro table from unit-step geometry."""
    table: dict[tuple[int, int], list[Transition]] = {
        state: [] for state in STATE_NAMES
    }
    for state in table:
        line, arrival = state
        for first in "RL":
            h1 = turned(arrival, first)
            x1, y1 = DX[h1], line + DY[h1]
            even_line = x1 + y1
            if not 0 <= even_line <= 6 or even_line % 2:
                continue
            for second in "RL":
                # Leaving an extremal line by L would leave the strip.  Keeping
                # this as a geometric test also independently forces R there.
                h2 = turned(h1, second)
                x2, y2 = x1 + DX[h2], y1 + DY[h2]
                next_line = x2 + y2
                target = (next_line, h2)
                if target not in table:
                    continue
                table[state].append(
                    Transition(target, x2, first + second, even_line, x1)
                )
    return {state: tuple(items) for state, items in table.items()}


TRANSITIONS = generate_transitions()


def _put(last_turn: dict[tuple[int, int], str], cell: tuple[int, int], turn: str):
    old = last_turn.get(cell)
    if old == turn:
        return None, False
    last_turn[cell] = turn
    return old, True


def _undo(last_turn: dict[tuple[int, int], str], cell: tuple[int, int], old):
    if old is None:
        del last_turn[cell]
    else:
        last_turn[cell] = old


def stabilized_groups(word: str, points: list[tuple[int, int]], drift):
    """Return exact P3 groups keyed by (transverse line, x residue)."""
    n = len(word)
    m = drift[0]
    if m <= 0 or drift != (m, -m):
        raise ValueError(drift)
    groups = {}
    for phase, (x, y) in enumerate(points):
        residue = x % m
        level = (x - residue) // m
        groups.setdefault((x + y, residue), []).append(
            (phase - n * level, word[phase])
        )
    return groups


def search_macro_period(macros: int, node_cap: int = 0, keep: int = 10,
                        required_drift: int = 0):
    nodes = leaves = p3_checks = 0
    extremal_pass = starts_r_pass = odd_identity_pass = 0
    turns: list[str] = []
    last_turn: dict[tuple[int, int], str] = {}
    hits: list[str] = []
    examples = []
    failures = Counter()
    best_defect = None
    best_word = None
    capped = False
    start_time = time.perf_counter()

    def dfs(depth, state, ell, growth, used_top):
        nonlocal nodes, leaves, p3_checks, extremal_pass, starts_r_pass
        nonlocal odd_identity_pass, best_defect, best_word, capped
        if capped:
            return
        nodes += 1
        if node_cap and nodes > node_cap:
            capped = True
            return
        remaining = macros - depth
        if required_drift and not (ell - remaining <= required_drift <= ell + remaining):
            return
        if ell + remaining <= 0:
            return
        if growth + 2 * remaining <= 0:
            return
        if depth == macros:
            if (state != START or ell <= 0 or growth <= 0 or not used_top
                    or (required_drift and ell != required_drift)):
                return
            leaves += 1
            word = "".join(turns)
            points, _arrivals, hfinal, drift = walk(word)
            if hfinal != NORTH or drift != (ell, -ell):
                raise AssertionError((state, ell, hfinal, drift, word))
            # ``walk`` starts its coordinates at the based odd-line cell, so its
            # transverse values are shifted down by one from the macro table's
            # labels 0,...,6.  Only the range and the two relative extremes matter.
            transverse = [x + y for x, y in points]
            low, high = min(transverse), max(transverse)
            if high - low != 6:
                raise AssertionError((min(transverse), max(transverse), word))
            groups = stabilized_groups(word, points, drift)
            ordered = {
                key: [symbol for _key, symbol in sorted(entries)]
                for key, entries in groups.items()
            }
            extreme_ok = all(
                len(sequence) == 1
                for (line, _residue), sequence in ordered.items()
                if line in (low, high)
            )
            if extreme_ok:
                extremal_pass += 1
            start_l = sum(sequence[0] == "L" for sequence in ordered.values())
            nonalt = sum(
                any(a == b for a, b in zip(sequence, sequence[1:]))
                for sequence in ordered.values()
            )
            defect = (start_l + nonalt, start_l, nonalt)
            if best_defect is None or defect < best_defect:
                best_defect, best_word = defect, word
            if start_l == 0:
                starts_r_pass += 1
            odd_ok = growth == sum(len(sequence) & 1 for sequence in ordered.values())
            if odd_ok:
                odd_identity_pass += 1
            signature = tuple(sorted(
                (line, "starts_L")
                for (line, _), sequence in ordered.items() if sequence[0] == "L"
            ) + sorted(
                (line, "nonalternating")
                for (line, _), sequence in ordered.items()
                if any(a == b for a, b in zip(sequence, sequence[1:]))
            ))
            failures[signature] += 1
            if len(examples) < keep and (start_l == 0 or odd_ok):
                examples.append((word, growth, drift, defect, odd_ok, extreme_ok))
            # The direct grouped criterion is checked at every leaf.  The
            # extremal and odd-class identities remain diagnostics, not search
            # assumptions.  Any apparent hit is then cross-checked by the
            # general pairwise-class implementation.
            p3_checks += 1
            fast_ok = start_l == 0 and nonalt == 0
            if fast_ok:
                ok, checked_drift, _points, _arrivals = p3_valid(word)
                if checked_drift != drift:
                    raise AssertionError((checked_drift, drift))
                if not ok:
                    raise AssertionError(("fast/general P3 disagreement", word))
                if len(hits) < keep:
                    hits.append(word)
            return

        line, _arrival = state
        odd_cell = (line, ell)
        for transition in TRANSITIONS[state]:
            old1, ok1 = _put(last_turn, odd_cell, transition.turns[0])
            if not ok1:
                continue
            even_cell = (transition.even_line, ell + transition.even_offset)
            old2, ok2 = _put(last_turn, even_cell, transition.turns[1])
            if ok2:
                turns.append(transition.turns)
                dfs(
                    depth + 1,
                    transition.target,
                    ell + transition.delta_ell,
                    growth + transition.turns.count("R") - transition.turns.count("L"),
                    used_top or transition.even_line == 6,
                )
                turns.pop()
                _undo(last_turn, even_cell, old2)
            _undo(last_turn, odd_cell, old1)

    dfs(0, START, 0, 0, False)
    return {
        "macros": macros,
        "period": 2 * macros,
        "nodes": nodes,
        "leaves": leaves,
        "p3_checks": p3_checks,
        "extremal_pass": extremal_pass,
        "starts_r_pass": starts_r_pass,
        "odd_identity_pass": odd_identity_pass,
        "hits": hits,
        "examples": examples,
        "failure_counts": failures,
        "best_defect": best_defect,
        "best_word": best_word,
        "capped": capped,
        "seconds": time.perf_counter() - start_time,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-macros", type=int, default=3)
    parser.add_argument("--max-macros", type=int, default=18)
    parser.add_argument("--drift", type=int, default=0)
    parser.add_argument("--node-cap", type=int, default=0)
    parser.add_argument("--show-table", action="store_true")
    parser.add_argument("--diagnostics", action="store_true")
    args = parser.parse_args()

    if args.show_table:
        for state, transitions in TRANSITIONS.items():
            for transition in transitions:
                print(
                    f"{STATE_NAMES[state]} -> {STATE_NAMES[transition.target]} "
                    f"delta={transition.delta_ell:+d} turns={transition.turns} "
                    f"even={transition.even_line} offset={transition.even_offset:+d}"
                )

    for macros in range(args.min_macros, args.max_macros + 1):
        result = search_macro_period(
            macros, node_cap=args.node_cap, required_drift=args.drift
        )
        print(
            "P={macros:2d} N={period:3d} nodes={nodes:12,d} leaves={leaves:10,d} "
            "p3-checks={p3_checks:9,d} ext={extremal_pass:9,d} "
            "starts-R={starts_r_pass:7,d} odd-id={odd_identity_pass:7,d} "
            "hits={hit_count:2d} capped={capped} sec={seconds:8.3f}".format(
                hit_count=len(result["hits"]), **result
            )
        )
        print(f"  best-defect={result['best_defect']} word={result['best_word']}")
        if args.diagnostics:
            for example in result["examples"]:
                print(f"  EXAMPLE {example}")
            for signature, count in result["failure_counts"].most_common(10):
                print(f"  FAIL {count:9,d} {signature}")
        for word in result["hits"]:
            print(f"  HIT {word}")


if __name__ == "__main__":
    main()
