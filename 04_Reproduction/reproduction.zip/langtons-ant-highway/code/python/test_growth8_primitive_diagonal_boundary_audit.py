#!/usr/bin/env python3

import unittest

from growth8_primitive_diagonal_boundary_audit import audit


class PrimitiveDiagonalBoundaryAuditTest(unittest.TestCase):
    def test_default_window(self) -> None:
        report = audit(maximum_width=20, margin=3)
        self.assertTrue(report["all_checks_passed"])
        self.assertEqual(report["additive_family_generators"], 2)
        self.assertEqual(report["moment_formula"], "sum (-1)^t t = 3 (mod 4)")
        self.assertEqual(report["rank_formula"], "E+L = |O|/2 (mod 2)")
        self.assertGreater(report["unique_flow_checks"], 0)

        first = report["widths"][0]
        self.assertEqual(first["width"], 10)
        self.assertEqual(first["p22_boundaries"], 44)
        self.assertEqual(first["moment_survivors"], 22)
        self.assertEqual(first["rank_sign_counts"], [22, 0])


if __name__ == "__main__":
    unittest.main()
