"""Audit all drift-periodic mod-four additive weights in diagonal geometry.

The complete local charge criterion proved in the research notes says that a cell
weight ``w`` has an ant-state potential precisely when ``4w=0`` and every unit
square has zero four-corner sum.  P22 uses a useful subfamily of such weights.  This
script enumerates the *entire* family after quotienting by a diagonal drift
``d=(m,-m)`` and tests the resulting endpoint equations.

This is an invariant-discovery audit, not a theorem certificate.  In coordinates
``r=x mod m`` and ``t=x+y``, the local equation is

    w[r,t] + w[r+1,t+1] + w[r,t+1] + w[r+1,t+2] = 0 (mod 4).

Two consecutive transverse rows determine the whole weight.  If ``A_t`` is the
sum of row ``t`` over ``r``, the potential monodromy along ``(m,-m)`` is
``A_t-A_(t+1)``.  Hence a wake base set ``S`` for a period beginning at transverse
coordinate ``p_t`` must satisfy

    sum_{(r,t) in S} w[r,t] + A_{p_t} - A_{p_t+1} = 0 (mod 4)

for every enumerated weight.
"""
from __future__ import annotations

import argparse
import itertools
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
from explore_chronology import STD, analyse, classes_of, walk  # noqa: E402


def extend_weight(period: int, first_line: int, last_line: int,
                  initial: tuple[int, ...]) -> dict[tuple[int, int], int]:
    """Extend two consecutive quotient rows by the corner recurrence."""
    assert len(initial) == 2 * period
    values = {
        (residue, first_line + offset): initial[offset * period + residue]
        for offset in range(2)
        for residue in range(period)
    }
    for line in range(first_line, last_line - 1):
        for target_residue in range(period):
            prior_residue = (target_residue - 1) % period
            values[target_residue, line + 2] = (
                -values[prior_residue, line]
                - values[target_residue, line + 1]
                - values[prior_residue, line + 1]
            ) % 4
    return values


def all_weights(period: int, first_line: int, last_line: int):
    for initial in itertools.product(range(4), repeat=2 * period):
        yield initial, extend_weight(period, first_line, last_line, initial)


def corner_valid(weight: dict[tuple[int, int], int], period: int,
                 first_line: int, last_line: int) -> bool:
    for line in range(first_line, last_line - 1):
        for residue in range(period):
            if (
                weight[residue, line]
                + weight[(residue + 1) % period, line + 1]
                + weight[residue, line + 1]
                + weight[(residue + 1) % period, line + 2]
            ) % 4:
                return False
    return True


def endpoint_value(weight: dict[tuple[int, int], int], period: int,
                   bases: tuple[tuple[int, int], ...], start_line: int) -> int:
    strand_sum = sum(weight[x % period, x + y] for x, y in bases)
    row_here = sum(weight[residue, start_line] for residue in range(period))
    row_next = sum(
        weight[residue, start_line + 1] for residue in range(period)
    )
    return (strand_sum + row_here - row_next) % 4


def odd_class_bases(word: str) -> tuple[tuple[int, int], ...]:
    points, _arrivals, _heading, drift = walk(word)
    bases = []
    total_excess = 0
    for indices in classes_of(points, drift):
        excess = sum(1 if word[index] == "R" else -1 for index in indices)
        assert excess in (0, 1)
        assert bool(excess) == bool(len(indices) % 2)
        total_excess += excess
        if excess:
            bases.append(points[indices[0]])
    assert total_excess == word.count("R") - word.count("L")
    return tuple(bases)


def audit_word(word: str, expected_period: int) -> dict[str, object]:
    report = analyse(word, "audit")
    drift = tuple(report["drift"])
    if drift != (expected_period, -expected_period):
        raise ValueError(f"expected {(expected_period, -expected_period)}, got {drift}")
    bases = odd_class_bases(word)
    points, _arrivals, _heading, _drift = walk(word)
    start_line = sum(points[0])
    transverse = [x + y for x, y in bases] + [start_line, start_line + 1]
    first_line, last_line = min(transverse) - 2, max(transverse) + 2
    failures = []
    weight_count = 0
    for initial, weight in all_weights(expected_period, first_line, last_line):
        weight_count += 1
        assert corner_valid(weight, expected_period, first_line, last_line)
        value = endpoint_value(
            weight, expected_period, bases, start_line
        )
        if value:
            failures.append((initial, value))
    return {
        "drift": drift,
        "period": len(word),
        "growth": word.count("R") - word.count("L"),
        "wake_bases": bases,
        "weight_count": weight_count,
        "endpoint_failures": len(failures),
        "first_failure": failures[0] if failures else None,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--show-all", action="store_true")
    args = parser.parse_args()
    cases = (
        (
            "g4 primitive-diagonal near-model",
            "LLLRLRRRRLRRRR",
            1,
        ),
        (
            "g4 even-diagonal near-model",
            "LLLRLRRRRLLLLRLRRRRLRRRR",
            2,
        ),
        ("standard period-104 highway", STD, 2),
    )
    for name, word, period in cases:
        result = audit_word(word, period)
        print(name)
        for key, value in result.items():
            if args.show_all or key not in ("wake_bases",):
                print(f"  {key}={value}")


if __name__ == "__main__":
    main()
