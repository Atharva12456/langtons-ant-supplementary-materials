#!/usr/bin/env python3
"""Bounded regression for the mixed-checker two-lane rank identity.

The accompanying proof is a finite-support gadget argument.  This program checks
the mixed gadget table and reconstructs every parity flow in a bounded strip; it is
not used as an unbounded proof oracle.
"""

from __future__ import annotations

import argparse
import itertools
import json
from math import comb

from even_diagonal_rank_parity_audit import inversion_parity


Block = tuple[str, int, int]
Vertex = tuple[int, int]


def target_vertex(block: Block) -> Vertex:
    kind, level, lane = block
    if kind == "W":
        return level - 1, 1 - lane
    if kind == "E":
        return level + 1, 1 - lane
    if kind == "S":
        return level - 1, lane
    if kind == "N":
        return level + 1, lane
    raise AssertionError(kind)


def correction(active: set[Block]) -> int:
    vertices = {(level, lane) for _kind, level, lane in active}
    vertices.update(target_vertex(block) for block in active)
    outgoing = {vertex: [] for vertex in vertices}
    incoming = {vertex: [] for vertex in vertices}
    for block in active:
        outgoing[block[1], block[2]].append(block)
        incoming[target_vertex(block)].append(block)

    local = 0
    for level, lane in vertices:
        vertex = level, lane
        excess = len(outgoing[vertex]) & 1
        if level % 2 == 0:
            positive_in = sum(block[0] == "N" for block in incoming[vertex]) & 1
            positive_out = sum(block[0] == "E" for block in outgoing[vertex]) & 1
            port_change = positive_in ^ positive_out
            local ^= port_change & (excess ^ 1)
        else:
            positive_in = sum(block[0] == "E" for block in incoming[vertex]) & 1
            positive_out = sum(block[0] == "N" for block in outgoing[vertex]) & 1
            port_change = positive_in ^ positive_out
            local ^= excess & (port_change ^ 1)
    return inversion_parity(active) ^ local


def c_gadget(level: int, lane: int) -> set[Block]:
    return {
        ("N", level, lane),
        ("S", level + 2, lane),
        ("W", level + 1, 1 - lane),
        ("E", level + 1, 1 - lane),
    }


def q_gadget(level: int, lane: int) -> set[Block]:
    return {
        ("S", level, lane),
        ("N", level, lane),
        ("E", level - 1, lane),
        ("W", level + 1, lane),
    }


def connector(level: int) -> set[Block]:
    assert level % 2 == 0
    return {
        ("E", level, 0),
        ("E", level, 1),
        ("S", level + 1, 0),
        ("S", level + 1, 1),
    }


def cross_value(first: set[Block], second: set[Block]) -> int:
    return correction(first ^ second) ^ correction(first) ^ correction(second)


def audit_mixed_table() -> int:
    checked = 0
    base = 1
    for lane_c, lane_q in itertools.product(range(2), repeat=2):
        for separation in range(-12, 14, 2):
            observed = cross_value(
                c_gadget(base, lane_c), q_gadget(base + separation, lane_q)
            )
            assert observed == int(separation in (0, 2))
            checked += 1
    assert correction(connector(-20)) == 1
    return checked + 1


def reconstruct(odd: frozenset[Vertex], width: int):
    lo, hi = 0, width + 2
    boundary = {
        (level, lane): int((level, lane) in odd)
        for level in range(lo, hi + 1)
        for lane in range(2)
    }
    east: dict[Vertex, int] = {}
    north: dict[Vertex, int] = {}
    for lane in range(2):
        previous = 0
        for level in range(0, hi + 1, 2):
            value = previous ^ boundary.get((level - 1, 1 - lane), 0) ^ boundary[level, lane]
            east[level, lane] = value
            previous = value
        previous = 0
        for level in range(1, hi + 1, 2):
            value = previous ^ boundary.get((level - 1, lane), 0) ^ boundary[level, lane]
            north[level, lane] = value
            previous = value

    active: set[Block] = set()
    for level in range(lo, hi + 1):
        for lane in range(2):
            if level % 2 == 0:
                if boundary[level, lane] ^ east.get((level, lane), 0):
                    active.add(("W", level, lane))
                if east.get((level, lane), 0):
                    active.add(("E", level, lane))
            else:
                if boundary[level, lane] ^ north.get((level, lane), 0):
                    active.add(("S", level, lane))
                if north.get((level, lane), 0):
                    active.add(("N", level, lane))
    vertex_set = set(boundary)
    if any(target_vertex(block) not in vertex_set for block in active):
        return None
    incoming = {vertex: 0 for vertex in vertex_set}
    outgoing = {vertex: 0 for vertex in vertex_set}
    for block in active:
        outgoing[block[1], block[2]] += 1
        incoming[target_vertex(block)] += 1
    if any((incoming[vertex] ^ outgoing[vertex]) & 1 for vertex in vertex_set):
        return None
    if any((outgoing[vertex] & 1) != boundary[vertex] for vertex in vertex_set):
        return None
    return active


def formula(odd: frozenset[Vertex]) -> int | None:
    q = tuple(sum(level % 2 == 0 and lane == r for level, lane in odd) for r in range(2))
    c = tuple(sum(level % 2 == 1 and lane == r for level, lane in odd) for r in range(2))
    parities = {count & 1 for count in q + c}
    if len(parities) != 1:
        return None
    sector = next(iter(parities))
    same_type = sum(comb(count, 2) for count in q + c) & 1
    interlacing = sum(
        level_c < level_q
        for level_c, _lane_c in odd
        for level_q, _lane_q in odd
        if level_c % 2 == 1 and level_q % 2 == 0
    ) & 1
    return same_type ^ interlacing ^ sector


def audit_bounded_flows(width: int) -> int:
    vertices = tuple(
        (level, lane) for level in range(width + 3) for lane in range(2)
    )
    checked = 0
    for selector in range(1 << len(vertices)):
        odd = frozenset(
            vertex for index, vertex in enumerate(vertices) if selector >> index & 1
        )
        active = reconstruct(odd, width)
        if active is None:
            continue
        expected = formula(odd)
        assert expected is not None
        assert correction(active) == expected
        checked += 1
    return checked


def additive_weight(x: int, y: int) -> int:
    checker = 1 if (x + y) % 2 == 0 else -1
    return checker * (x // 2 + y // 2) % 4


def additive_weight_audit() -> int:
    checked = 0
    for x in range(-8, 9):
        for y in range(-8, 9):
            assert (
                additive_weight(x, y)
                + additive_weight(x + 1, y)
                + additive_weight(x, y + 1)
                + additive_weight(x + 1, y + 1)
            ) % 4 == 0
            assert additive_weight(x + 2, y - 2) == additive_weight(x, y)
            checked += 2
            if (x + y) % 2 == 0:
                value = 0
                here_x, here_y = x, y
                for _step in range(2):
                    value += additive_weight(here_x, here_y - 1)
                    value -= additive_weight(here_x + 1, here_y - 1)
                    here_x, here_y = here_x + 1, here_y - 1
                assert value % 4 == 3
                checked += 1

    for level in range(-12, 13):
        for lane in range(2):
            representative = additive_weight(lane, level - lane)
            expected = (
                (1 if level % 2 == 0 else -1) * (level // 2)
                - int(level % 2 == 0 and lane == 1)
            ) % 4
            assert representative == expected
            checked += 1
    return checked


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--width", type=int, default=5)
    args = parser.parse_args()
    if not 1 <= args.width <= 7:
        parser.error("--width must lie in 1..7")
    table_checks = audit_mixed_table()
    flow_checks = audit_bounded_flows(args.width)
    weight_checks = additive_weight_audit()
    print(json.dumps({
        "schema": "langton-mixed-checker-rank-parity-audit-v1",
        "status": "bounded_evidence_not_proof",
        "width": args.width,
        "mixed_table_checks": table_checks,
        "finite_flow_checks": flow_checks,
        "additive_weight_checks": weight_checks,
        "all_checks_passed": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
