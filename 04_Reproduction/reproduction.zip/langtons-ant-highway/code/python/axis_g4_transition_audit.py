#!/usr/bin/env python3
"""Reproduce the sharp axis-g=4 transition-system obstruction.

The first object is not one ant period: it is a P3-compatible union of two
literal square-lattice successor circuits on the d=(2,0) quotient, with total
winding one and total turn excess four.  Cross-splicing the two circuits gives
the familiar one-circuit near-model, but creates one P3 defect.  A disjoint
RRRRLLLL zero-voltage circuit shows that the *number* of P3-compatible successor
circuits has no fixed parity.

These examples delimit a candidate proof route; none is a periodic highway.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass


DIRS = ((0, 1), (1, 0), (0, -1), (-1, 0))
DRIFT = (2, 0)


@dataclass(frozen=True)
class Event:
    phase: int
    x: int
    y: int
    arrival: int
    turn: str
    circuit: str


def representative_level(x: int, y: int) -> tuple[tuple[int, int], int]:
    residue = x % 2
    level = (x - residue) // 2
    return (residue, y), level


def stable_groups(events: list[Event], period: int) -> dict[tuple[int, int], str]:
    groups: dict[tuple[int, int], list[tuple[int, str]]] = defaultdict(list)
    for event in events:
        representative, level = representative_level(event.x, event.y)
        groups[representative].append((event.phase - period * level, event.turn))
    return {
        representative: "".join(turn for _, turn in sorted(entries))
        for representative, entries in groups.items()
    }


def p3_valid(groups: dict[tuple[int, int], str]) -> bool:
    return all(
        word.startswith("R")
        and all(left != right for left, right in zip(word, word[1:]))
        for word in groups.values()
    )


def check_circuit(events: list[Event], voltage: int) -> None:
    for current, following in zip(events, events[1:]):
        new_heading = (current.arrival + (1 if current.turn == "R" else -1)) % 4
        dx, dy = DIRS[new_heading]
        assert (current.x + dx, current.y + dy, new_heading) == (
            following.x,
            following.y,
            following.arrival,
        )
    last = events[-1]
    first = events[0]
    new_heading = (last.arrival + (1 if last.turn == "R" else -1)) % 4
    dx, dy = DIRS[new_heading]
    assert (last.x + dx, last.y + dy, new_heading) == (
        first.x + voltage * DRIFT[0],
        first.y,
        first.arrival,
    )


def circuit_edges(
    events: list[Event], voltage: int
) -> Counter[tuple[tuple[int, int], tuple[int, int]]]:
    edges: Counter[tuple[tuple[int, int], tuple[int, int]]] = Counter()
    for current, following in zip(events, events[1:]):
        edges[((current.x, current.y), (following.x, following.y))] += 1
    edges[
        (
            (events[-1].x, events[-1].y),
            (events[0].x + voltage * DRIFT[0], events[0].y),
        )
    ] += 1
    return edges


def walk_word(word: str) -> tuple[list[Event], tuple[int, int], int]:
    x = y = heading = 0
    events: list[Event] = []
    for phase, turn in enumerate(word):
        events.append(Event(phase, x, y, heading, turn, "word"))
        heading = (heading + (1 if turn == "R" else -1)) % 4
        dx, dy = DIRS[heading]
        x += dx
        y += dy
    return events, (x, y), heading


def p3_violation_score(groups: dict[tuple[int, int], str]) -> int:
    return sum(
        int(word[0] != "R")
        + sum(left == right for left, right in zip(word, word[1:]))
        for word in groups.values()
    )


def main() -> None:
    lower = [
        Event(0, 2, -1, 3, "R", "lower"),
        Event(1, 2, 0, 0, "R", "lower"),
        Event(2, 3, 0, 1, "R", "lower"),
        Event(3, 3, -1, 2, "R", "lower"),
    ]
    upper = [
        Event(4, 0, 0, 2, "L", "upper"),
        Event(5, 1, 0, 1, "L", "upper"),
        Event(6, 1, 1, 0, "R", "upper"),
        Event(7, 2, 1, 1, "R", "upper"),
    ]
    check_circuit(lower, 0)
    check_circuit(upper, 1)
    two_circuit_groups = stable_groups(lower + upper, 8)
    assert p3_valid(two_circuit_groups)
    assert two_circuit_groups == {
        (0, -1): "R",
        (0, 0): "RL",
        (0, 1): "R",
        (1, -1): "R",
        (1, 0): "RL",
        (1, 1): "R",
    }
    assert sum(1 if event.turn == "R" else -1 for event in lower + upper) == 4

    near_word = "RLRRLRRR"
    near_events, endpoint, heading = walk_word(near_word)
    assert endpoint == DRIFT and heading == 0
    assert circuit_edges(lower, 0) + circuit_edges(upper, 1) == circuit_edges(
        near_events, 1
    )
    near_groups = stable_groups(near_events, len(near_word))
    assert p3_violation_score(near_groups) == 1

    zero_word = "RRRRLLLL"
    zero_events, zero_endpoint, zero_heading = walk_word(zero_word)
    assert zero_endpoint == (0, 0) and zero_heading == 0
    zero_groups = stable_groups(zero_events, len(zero_word))
    assert p3_valid(zero_groups)
    assert all(len(word) == 2 for word in zero_groups.values())

    shifted_zero = [
        Event(
            event.phase + 8,
            event.x,
            event.y + 10,
            event.arrival,
            event.turn,
            "zero",
        )
        for event in zero_events
    ]
    three_circuit_groups = stable_groups(lower + upper + shifted_zero, 16)
    assert p3_valid(three_circuit_groups)
    assert sum(
        1 if event.turn == "R" else -1
        for event in lower + upper + shifted_zero
    ) == 4
    assert len({event.circuit for event in lower + upper}) == 2
    assert len({event.circuit for event in lower + upper + shifted_zero}) == 3

    print("schema=langton-axis-g4-transition-audit-v1")
    print("two_circuit_p3=true")
    print("two_circuit_total_voltage=1")
    print("two_circuit_growth=4")
    print("cross_spliced_one_circuit_p3_violations=1")
    print("zero_voltage_RRRRLLLL_p3=true")
    print("three_circuit_p3=true")
    print("successor_circuit_parity_fixed=false")
    print("periodic_highway_found=false")
    print("all_checks_passed=true")


if __name__ == "__main__":
    main()
