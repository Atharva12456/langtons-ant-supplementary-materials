#!/usr/bin/env python3
"""Audit the additive and rank boundary at growth-eight drift ``(1,-1)``.

The accompanying argument classifies every drift-periodic mod-four additive
weight and proves the one-lane segment formula for the parity-flow sign. This
program checks those algebraic statements and enumerates a bounded collection of
endpoint placements. The bounded width sweep is a regression, not an exclusion.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path


Block = tuple[str, int]


def checker(x: int, y: int) -> int:
    return 1 if (x + y) % 2 == 0 else -1


def family_weight(x: int, y: int, coefficient: int, residue: int) -> int:
    return checker(x, y) * (coefficient * (x + y) + residue) % 4


def north_monodromy(weight, x: int, y: int) -> int:
    """Integrate the north-heading potential along ``(1,-1)``."""
    return (weight(x, y - 1) - weight(x + 1, y - 1)) % 4


def audit_weight_family() -> int:
    checks = 0
    for coefficient, residue in itertools.product(range(4), repeat=2):
        weight = lambda x, y: family_weight(  # noqa: E731
            x, y, coefficient, residue
        )
        for x in range(-4, 5):
            for y in range(-4, 5):
                assert (
                    weight(x, y)
                    + weight(x + 1, y)
                    + weight(x, y + 1)
                    + weight(x + 1, y + 1)
                ) % 4 == 0
                assert weight(x + 1, y - 1) == weight(x, y)
                checks += 2
                if (x + y) % 2 == 0:
                    expected = (coefficient + 2 * residue) % 4
                    assert north_monodromy(weight, x, y) == expected
                    checks += 1
    return checks


def target(block: Block) -> int:
    kind, level = block
    return level - 1 if kind in "WS" else level + 1


def source_key(block: Block) -> tuple[int, int]:
    kind, level = block
    return level, int(kind in "EN")


def target_key(block: Block) -> tuple[int, int]:
    return target(block), int(block[0] in "EN")


def interval_blocks(low: int, high: int) -> set[Block]:
    blocks = set()
    for level in range(low, high + 1):
        for kind in ("WE" if level % 2 == 0 else "SN"):
            block = kind, level
            if low <= target(block) <= high:
                blocks.add(block)
    return blocks


def flow_blocks(boundary: set[int]) -> set[Block]:
    """Construct the unique finite flow by pairing consecutive endpoints."""
    ordered = sorted(boundary)
    assert len(ordered) % 2 == 0
    active: set[Block] = set()
    for low, high in zip(ordered[::2], ordered[1::2]):
        active.symmetric_difference_update(interval_blocks(low, high))
    return active


def solve_bounded(boundary: set[int], margin: int) -> tuple[set[Block], int]:
    """Solve the finite GF(2) in/out system and return its nullity."""
    low = min(boundary) - margin
    high = max(boundary) + margin
    blocks = sorted(interval_blocks(low, high), key=source_key)
    index = {block: position for position, block in enumerate(blocks)}
    rows = []
    for level in range(low, high + 1):
        outgoing = [block for block in blocks if block[1] == level]
        incoming = [block for block in blocks if target(block) == level]
        for incident in (outgoing, incoming):
            coefficients = sum(1 << index[block] for block in incident)
            rows.append(coefficients | (int(level in boundary) << len(blocks)))

    rank = 0
    pivots = []
    for column in range(len(blocks)):
        pivot = next(
            (row for row in range(rank, len(rows)) if (rows[row] >> column) & 1),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for row in range(len(rows)):
            if row != rank and ((rows[row] >> column) & 1):
                rows[row] ^= rows[rank]
        pivots.append(column)
        rank += 1

    coefficient_mask = (1 << len(blocks)) - 1
    assert not any(
        (row & coefficient_mask) == 0 and ((row >> len(blocks)) & 1)
        for row in rows
    )
    solution = 0
    for row, pivot in zip(rows[:rank], pivots):
        if (row >> len(blocks)) & 1:
            solution |= 1 << pivot
    active = {
        block for position, block in enumerate(blocks) if (solution >> position) & 1
    }
    return active, len(blocks) - rank


def direct_sign(active: set[Block], boundary: set[int]) -> int:
    ordered = sorted(active, key=source_key)
    edge_sign = sum(
        target_key(first) > target_key(second)
        for index, first in enumerate(ordered)
        for second in ordered[index + 1 :]
    ) & 1

    outgoing: dict[int, list[Block]] = defaultdict(list)
    incoming: dict[int, list[Block]] = defaultdict(list)
    for block in active:
        outgoing[block[1]].append(block)
        incoming[target(block)].append(block)

    local_sign = 0
    for level in set(outgoing) | set(incoming) | boundary:
        excess = int(level in boundary)
        positive = (
            sum(block[0] in "EN" for block in outgoing[level])
            + sum(block[0] in "EN" for block in incoming[level])
        ) & 1
        if level % 2 == 0:
            local_sign ^= positive & (excess ^ 1)
        else:
            local_sign ^= excess & (positive ^ 1)
    return edge_sign ^ local_sign


def check_flow(active: set[Block], boundary: set[int]) -> None:
    vertices = set(boundary)
    for block in active:
        vertices.add(block[1])
        vertices.add(target(block))
    for level in vertices:
        outgoing = sum(block[1] == level for block in active) & 1
        incoming = sum(target(block) == level for block in active) & 1
        expected = int(level in boundary)
        assert outgoing == expected
        assert incoming == expected


def segment_table(margin: int) -> tuple[int, int]:
    pairs = tuple(itertools.combinations(range(-3, 5), 2))
    values: dict[tuple[int, int], int] = {}
    checks = 0
    unique_checks = 0
    for pair in pairs:
        boundary = set(pair)
        active = flow_blocks(boundary)
        check_flow(active, boundary)
        solved, nullity = solve_bounded(boundary, margin)
        assert nullity == 0
        assert solved == active
        unique_checks += 1
        value = direct_sign(active, boundary)
        assert value == 1
        values[pair] = value
        checks += 1

    for first_index, first in enumerate(pairs):
        for second in pairs[first_index + 1 :]:
            if set(first) & set(second):
                continue
            boundary = set(first) ^ set(second)
            active = flow_blocks(boundary)
            solved, nullity = solve_bounded(boundary, margin)
            assert nullity == 0
            assert solved == active
            unique_checks += 1
            combined = direct_sign(active, boundary)
            cross = combined ^ values[first] ^ values[second]
            assert cross == 0
            checks += 1
    return checks, unique_checks


def boundary_rows(width: int):
    horizontal_levels = tuple(range(3, width + 1, 2))
    vertical_levels = tuple(range(2, width + 1, 2))
    for horizontal_count, vertical_count in ((3, 5), (5, 3), (7, 1)):
        for extra_horizontal in itertools.combinations(
            horizontal_levels, horizontal_count - 2
        ):
            for vertical in itertools.combinations(vertical_levels, vertical_count):
                boundary = {1, width + 1, *extra_horizontal, *vertical}
                assert len(boundary) == 8
                yield horizontal_count, vertical_count, boundary


def signed_count(boundary: set[int]) -> int:
    return sum(1 if level % 2 == 0 else -1 for level in boundary) % 4


def signed_moment(boundary: set[int]) -> int:
    return sum(
        (1 if level % 2 == 0 else -1) * level for level in boundary
    ) % 4


def audit_width(width: int) -> dict[str, object]:
    split_counts: dict[tuple[int, int], list[int]] = defaultdict(lambda: [0, 0])
    total = 0
    survivors = 0
    rank_counts = [0, 0]
    for horizontal_count, vertical_count, boundary in boundary_rows(width):
        assert signed_count(boundary) == 2
        total += 1
        split_counts[horizontal_count, vertical_count][0] += 1
        if signed_moment(boundary) != 3:
            continue
        survivors += 1
        split_counts[horizontal_count, vertical_count][1] += 1
        active = flow_blocks(boundary)
        check_flow(active, boundary)
        sign = direct_sign(active, boundary)
        assert sign == (len(boundary) // 2) % 2
        rank_counts[sign] += 1

    return {
        "width": width,
        "p22_boundaries": total,
        "moment_survivors": survivors,
        "rank_sign_counts": rank_counts,
        "splits": [
            {
                "horizontal_vertical": list(split),
                "p22_boundaries": counts[0],
                "moment_survivors": counts[1],
            }
            for split, counts in sorted(split_counts.items())
        ],
    }


def audit(maximum_width: int, margin: int) -> dict[str, object]:
    if maximum_width < 10 or maximum_width % 2:
        raise ValueError("maximum_width must be an even integer at least ten")
    if margin < 2:
        raise ValueError("margin must be at least two")

    weights = audit_weight_family()
    segment_checks, unique_checks = segment_table(margin)
    widths = [audit_width(width) for width in range(10, maximum_width + 1, 2)]
    return {
        "schema": "langton-growth8-primitive-diagonal-boundary-audit-v1",
        "status": "bounded_evidence_not_proof",
        "maximum_width": maximum_width,
        "exterior_margin": margin,
        "additive_family_generators": 2,
        "weight_family_checks": weights,
        "segment_table_checks": segment_checks,
        "unique_flow_checks": unique_checks,
        "moment_formula": "sum (-1)^t t = 3 (mod 4)",
        "rank_formula": "E+L = |O|/2 (mod 2)",
        "widths": widths,
        "all_checks_passed": all(
            row["moment_survivors"] * 2 == row["p22_boundaries"]
            and row["rank_sign_counts"] == [row["moment_survivors"], 0]
            for row in widths
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--maximum-width", type=int, default=20)
    parser.add_argument("--margin", type=int, default=3)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = audit(args.maximum_width, args.margin)
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
