#!/usr/bin/env python3
"""Bounded exact SMT search for primitive-diagonal growth-four highways.

The model uses literal one-cell Langton dynamics for a fixed ant period ``N`` and
transverse width ``W`` with drift ``(1,-1)``.  It imposes the complete stabilised
periodic-realisability order, not merely same-cell alternation: within each class
``t=x+y`` the key is ``phase - N*x``, and key rank must be R,L,R,L,... .

The proved extremal theorem is added as a redundant prune: the minimum and maximum
transverse classes each occur exactly once.  The signed residue equation is also
stated explicitly.  SAT models are independently replayed before being reported.

UNSAT is only a bounded result for the requested ``(N,W)`` row.  It is not an
all-period exclusion, and solver output is not a proof certificate unless a
separately checkable proof artifact is produced.
"""

from __future__ import annotations

import argparse
import json
import time

import z3


DX = (1, 0, -1, 0)  # E,S,W,N
DY = (0, -1, 0, 1)


def select(values: tuple[int, ...], index: z3.ArithRef) -> z3.ArithRef:
    answer: z3.ArithRef = z3.IntVal(values[-1])
    for value in range(len(values) - 2, -1, -1):
        answer = z3.If(index == value, values[value], answer)
    return answer


def replay(word: str) -> tuple[tuple[int, int], int, list[tuple[int, int]]]:
    heading = 3 if word.startswith("N:") else 1
    symbols = word[2:]
    x = y = 0
    positions: list[tuple[int, int]] = []
    for symbol in symbols:
        positions.append((x, y))
        heading = (heading + (1 if symbol == "R" else -1)) % 4
        x += DX[heading]
        y += DY[heading]
    return (x, y), heading, positions


def p3_valid(symbols: str, positions: list[tuple[int, int]], period: int) -> bool:
    groups: dict[int, list[int]] = {}
    for phase, (x, y) in enumerate(positions):
        groups.setdefault(x + y, []).append(phase)
    for phases in groups.values():
        ordered = sorted(phases, key=lambda phase: phase - period * positions[phase][0])
        if "".join(symbols[phase] for phase in ordered) != "RL" * (len(ordered) // 2) + (
            "R" if len(ordered) % 2 else ""
        ):
            return False
    return True


def solve(period: int, width: int, timeout_ms: int) -> dict[str, object]:
    if period <= 0 or period % 2 or width <= 0:
        raise ValueError((period, width))
    solver = z3.Solver()
    if timeout_ms:
        solver.set(timeout=timeout_ms)

    right = [z3.Bool(f"right_{i}") for i in range(period)]
    heading = [z3.Int(f"heading_{i}") for i in range(period + 1)]
    x = [z3.Int(f"x_{i}") for i in range(period + 1)]
    y = [z3.Int(f"y_{i}") for i in range(period + 1)]
    low = z3.Int("low")

    solver.add(x[0] == 0, y[0] == 0)
    solver.add(z3.Or(heading[0] == 1, heading[0] == 3))
    for phase in range(period):
        solver.add(heading[phase] >= 0, heading[phase] < 4)
        solver.add(
            heading[phase + 1]
            == z3.If(right[phase], (heading[phase] + 1) % 4, (heading[phase] + 3) % 4)
        )
        solver.add(x[phase + 1] == x[phase] + select(DX, heading[phase + 1]))
        solver.add(y[phase + 1] == y[phase] + select(DY, heading[phase + 1]))

    solver.add(heading[period] == heading[0])
    solver.add(x[period] == 1, y[period] == -1)
    solver.add(z3.Sum([z3.If(value, 1, -1) for value in right]) == 4)

    transverse = [x[i] + y[i] for i in range(period)]
    solver.add(low <= 0, low + width >= 0)
    solver.add(*[z3.And(low <= value, value <= low + width) for value in transverse])
    solver.add(z3.Or(*[value == low for value in transverse]))
    solver.add(z3.Or(*[value == low + width for value in transverse]))
    # With phase zero vertically incident, diagonal extremal rigidity puts both
    # (same-parity) extreme lines in the horizontal-arrival checker sector.
    solver.add(low % 2 == 1)

    # Complete stabilised rank condition for d=(1,-1).
    key = [z3.IntVal(i) - period * x[i] for i in range(period)]
    for i in range(period):
        rank = z3.Sum(
            [
                z3.If(
                    z3.And(transverse[j] == transverse[i], key[j] < key[i]),
                    1,
                    0,
                )
                for j in range(period)
                if j != i
            ]
        )
        solver.add(right[i] == (rank % 2 == 0))

    counts = []
    odd_classes = []
    for offset in range(width + 1):
        count = z3.Sum(
            [z3.If(transverse[i] == low + offset, 1, 0) for i in range(period)]
        )
        counts.append(count)
        odd_classes.append(count % 2)
        solver.add(count > 0)
        # Local port balance plus a start-R alternating class gives n=epsilon
        # mod 4 at horizontal-arrival classes and n=-epsilon at vertical ones.
        # Since low is odd, even offsets are horizontal and odd offsets vertical.
        if offset % 2 == 0:
            solver.add(count % 4 == count % 2)
        else:
            solver.add(count % 4 == 3 * (count % 2))
    solver.add(counts[0] == 1, counts[-1] == 1)
    solver.add(z3.Sum(odd_classes) == 4)
    signed_odd = z3.Sum(
        [
            z3.If((low + offset) % 2 == 0, odd_classes[offset], -odd_classes[offset])
            for offset in range(width + 1)
        ]
    )
    solver.add(signed_odd % 4 == 2)

    started = time.perf_counter()
    status = solver.check()
    elapsed = time.perf_counter() - started
    result: dict[str, object] = {
        "schema": "langton-primitive-g4-smt-v1",
        "period": period,
        "width": width,
        "status": str(status),
        "seconds": elapsed,
        "bounded_only": True,
    }
    if status == z3.unknown:
        result["reason_unknown"] = solver.reason_unknown()
    elif status == z3.sat:
        model = solver.model()
        initial = model.eval(heading[0]).as_long()
        symbols = "".join("R" if z3.is_true(model.eval(value)) else "L" for value in right)
        tagged = ("N:" if initial == 3 else "S:") + symbols
        endpoint, final_heading, positions = replay(tagged)
        if endpoint != (1, -1) or final_heading != initial:
            raise AssertionError((endpoint, final_heading, initial))
        if symbols.count("R") - symbols.count("L") != 4:
            raise AssertionError(symbols)
        if not p3_valid(symbols, positions, period):
            raise AssertionError("model failed independent P3 replay")
        transverse_values = [px + py for px, py in positions]
        if max(transverse_values) - min(transverse_values) != width:
            raise AssertionError(transverse_values)
        result.update(
            {
                "initial_heading": initial,
                "word": symbols,
                "transverse_min": min(transverse_values),
                "transverse_max": max(transverse_values),
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("period", type=int)
    parser.add_argument("width", type=int)
    parser.add_argument("--timeout-ms", type=int, default=0)
    args = parser.parse_args()
    print(json.dumps(solve(args.period, args.width, args.timeout_ms), sort_keys=True))


if __name__ == "__main__":
    main()
