#!/usr/bin/env python3
"""Cross-audit the bounded f<=3 primitive-g4 projected-tour certificate."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import primitive_g4_projected_tours as primary
import verify_primitive_g4_projected_indep as independent


ROOT = Path(__file__).resolve().parents[2]
CERTIFICATE = ROOT / "results" / "primitive_g4_projected_w12.json"
SOURCES = (
    ROOT / "code" / "python" / "primitive_g4_projected_tours.py",
    ROOT / "code" / "python" / "verify_primitive_g4_projected_indep.py",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def counts(row: dict[str, object]) -> tuple[int, int, int, int]:
    return (
        int(row["weak_profiles"]), int(row["raw_tours"]),
        int(row["endpoint_growth_tours"]), int(row["lower_prefix_survivors"]),
    )


def main() -> None:
    certificate = json.loads(CERTIFICATE.read_text(encoding="utf-8"))
    expected_rows = {
        int(width): (
            row["weak_profiles"], row["raw_tours"],
            row["endpoint_growth_tours"], row["lower_prefix_survivors"],
        )
        for width, row in certificate["certified_rows"].items()
    }
    source_hashes = {item["path"]: item["sha256"] for item in certificate["implementations"]}
    for source in SOURCES:
        relative = source.relative_to(ROOT).as_posix()
        if digest(source) != source_hashes[relative]:
            raise AssertionError((relative, digest(source), source_hashes[relative]))

    checked: dict[str, dict[str, int]] = {}
    for width in sorted(expected_rows):
        first = primary.audit_width(width)
        second = independent.audit(width)
        if counts(first) != expected_rows[width] or counts(second) != expected_rows[width]:
            raise AssertionError((width, counts(first), counts(second), expected_rows[width]))
        checked[str(width)] = {
            "weak_profiles": counts(first)[0],
            "raw_tours": counts(first)[1],
            "endpoint_growth_tours": counts(first)[2],
            "lower_prefix_survivors": counts(first)[3],
        }
    print(json.dumps({
        "schema": "langton-primitive-g4-projected-cross-audit-v1",
        "all_checks_passed": True,
        "scope": "bounded_conditional_projected_model",
        "rows": checked,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
