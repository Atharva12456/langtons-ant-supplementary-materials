"""Exact relaxed block classifier for diagonal transverse width eight.

The strip has transverse coordinate ``t=x+y`` in ``0,...,8``.  A state retains
all colours in a finite block, once-entry status for its physical extremal cells,
and the inward boundary pose.  After an outer exit every exterior detail is
forgotten and every geometrically possible same-boundary return is allowed.  This
strictly over-approximates an actual ant orbit.

The eight-column zero is a finite computer-assisted premise.  Its use to exclude
a periodic highway requires the separate global bridge proved in the manuscript;
enumerator completeness is not formalized in Lean.
"""
from __future__ import annotations

import argparse
from collections import Counter, deque


NORTH, EAST, SOUTH, WEST = range(4)
RIGHT = (EAST, SOUTH, WEST, NORTH)
LEFT = (WEST, NORTH, EAST, SOUTH)
MAX_LINE = 8
LINE_COUNT = MAX_LINE + 1
LEFT_ENTRIES = tuple(range(2, MAX_LINE + 1, 2))
RIGHT_ENTRIES = tuple(range(0, MAX_LINE, 2))
LOCAL_LOOP = object()


def cell_index(column: int, line: int) -> int:
    return LINE_COUNT * column + line


def advance_inside(columns: int, black: int, extreme_seen: int,
                   column: int, line: int, heading: int):
    """Run literal cell dynamics to an outer exit or a forbidden repeat."""
    visits = 0
    local_states = set()
    while True:
        if not (0 <= column < columns and 0 <= line <= MAX_LINE):
            raise AssertionError((columns, column, line, heading))
        local_state = (black, extreme_seen, column, line, heading)
        if local_state in local_states:
            return LOCAL_LOOP
        local_states.add(local_state)

        bit = 1 << cell_index(column, line)
        if line in (0, MAX_LINE):
            if extreme_seen & bit:
                return None
            extreme_seen |= bit

        was_black = bool(black & bit)
        black ^= bit
        heading = LEFT[heading] if was_black else RIGHT[heading]
        visits += 1

        old_column = column
        if heading == EAST:
            column += 1
            line += 1
        elif heading == WEST:
            column -= 1
            line -= 1
        elif heading == NORTH:
            line += 1
        else:
            line -= 1

        if column < 0:
            return black, extreme_seen, "left", line, visits
        if column >= columns:
            return black, extreme_seen, "right", line, visits
        if heading in (NORTH, SOUTH) and column != old_column:
            raise AssertionError((old_column, column, heading))


def explore_relaxed(columns: int):
    """Explore the complete arbitrary-outer-return boundary state graph."""
    initial = [(0, 0, entry, EAST) for entry in LEFT_ENTRIES]
    queue = deque(initial)
    seen = set(initial)
    terminal_states = set()
    terminal_events = 0
    transition_count = 0
    invalid_extreme = 0
    exit_counts = Counter()
    max_cell_visits = 0
    local_loops = 0

    while queue:
        black, extreme_seen, line, heading = queue.popleft()
        column = 0 if heading == EAST else columns - 1
        result = advance_inside(
            columns, black, extreme_seen, column, line, heading
        )
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            invalid_extreme += 1
            continue

        black2, extreme2, side, landing, visits = result
        max_cell_visits = max(max_cell_visits, visits)
        exit_counts[(side, landing)] += 1
        if side == "right":
            terminal_events += 1
            terminal_states.add((black2, extreme2, landing))
            entries = ((entry, WEST) for entry in RIGHT_ENTRIES)
        else:
            entries = ((entry, EAST) for entry in LEFT_ENTRIES)

        for entry, next_heading in entries:
            state = (black2, extreme2, entry, next_heading)
            transition_count += 1
            if state not in seen:
                seen.add(state)
                queue.append(state)

    return {
        "columns": columns,
        "states": len(seen),
        "transitions": transition_count,
        "terminal_events": terminal_events,
        "terminal_states": len(terminal_states),
        "invalid_extreme": invalid_extreme,
        "exit_counts": exit_counts,
        "max_cell_visits_between_outer_crossings": max_cell_visits,
        "local_loops": local_loops,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-columns", type=int, default=7)
    parser.add_argument("--max-columns", type=int, default=8)
    args = parser.parse_args()
    for columns in range(args.min_columns, args.max_columns + 1):
        result = explore_relaxed(columns)
        print(
            "columns={columns} states={states:,} transitions={transitions:,} "
            "terminal_events={terminal_events:,} terminal_states={terminal_states:,} "
            "invalid_extreme={invalid_extreme:,} local_loops={local_loops:,} "
            "max_inner_visits={max_cell_visits_between_outer_crossings}"
            .format(**result)
        )
        print(f"  exits={dict(sorted(result['exit_counts'].items()))}")


if __name__ == "__main__":
    main()
