"""Bounded blank-column crossing graph for a width-six strip.

Unlike width four, the exact local entry automaton has reachable cycles, so this
module does not claim to enumerate the unbounded edge relation.  It exhausts all
extremal-singleton boundary signatures through a requested odd length, constructs
every compatible initially white seven-cell column edge in that finite window, and
reports directed strongly connected components.  The output is diagnostic evidence
for the all-period width-six problem, never an exclusion certificate by itself.
"""
from __future__ import annotations

import argparse
from itertools import product


EAST, SOUTH, WEST, NORTH = range(4)


def turn(heading: int, black: int) -> int:
    return (heading + (3 if black else 1)) % 4


def run_inside(bits: list[int], transverse: int, heading: int):
    while True:
        if not 0 <= transverse <= 6:
            raise AssertionError((bits, transverse, heading))
        old = bits[transverse]
        bits[transverse] ^= 1
        heading = turn(heading, old)
        if heading == EAST:
            return "right", transverse + 1
        if heading == WEST:
            return "left", transverse - 1
        transverse += 1 if heading == NORTH else -1


def compatible(left: tuple[int, ...], right: tuple[int, ...], initial_mask: int = 0):
    if not left or not right or len(left) % 2 == 0 or len(right) % 2 == 0:
        return None
    bits = [(initial_mask >> line) & 1 for line in range(7)]
    li, ri = 1, 0
    transverse, heading = left[0], EAST
    while True:
        side, landing = run_inside(bits, transverse, heading)
        if side == "right":
            if ri >= len(right) or ri % 2 or right[ri] != landing:
                return None
            ri += 1
            if ri == len(right):
                if li != len(left):
                    return None
                return sum(bit << line for line, bit in enumerate(bits))
            transverse, heading = right[ri], WEST
            ri += 1
        else:
            if li >= len(left) or li % 2 != 1 or left[li] != landing:
                return None
            li += 1
            if li >= len(left) or li % 2:
                return None
            transverse, heading = left[li], EAST
            li += 1


def _side_words(count: int, ordinary: tuple[int, int], exceptional: int):
    """Sequences with ordinary choices and at most one exceptional event."""
    for values in product(ordinary, repeat=count):
        yield values
    for special in range(count):
        for values in product(ordinary, repeat=count - 1):
            out = list(values)
            out.insert(special, exceptional)
            yield tuple(out)


def signatures(length: int):
    if length <= 0 or length % 2 == 0:
        raise ValueError(length)
    plus_count = (length + 1) // 2
    minus_count = (length - 1) // 2
    for plus in _side_words(plus_count, (2, 4), 6):
        for minus in _side_words(minus_count, (2, 4), 0):
            sequence = []
            for index in range(length):
                sequence.append(plus[index // 2] if index % 2 == 0
                                else minus[index // 2])
            yield tuple(sequence)


def bounded_graph(max_length: int):
    vertices = [
        signature
        for length in range(1, max_length + 1, 2)
        for signature in signatures(length)
    ]
    edges = []
    for left, right in product(vertices, repeat=2):
        mask = compatible(left, right)
        if mask is not None:
            edges.append((left, right, mask))
    return vertices, edges


def generated_graph(max_length: int):
    """Generate compatible edges directly, allowing repeated entry states.

    The length cap makes the recursion finite even though the width-six entry
    automaton has genuine cycles.  This is much smaller than the Cartesian-product
    check at larger caps.  For caps through seven the two methods are required to
    agree exactly.
    """
    edges = set()
    calls = 0

    def visit(bits_tuple, transverse, heading, flags, left, right):
        nonlocal calls
        calls += 1
        bits = list(bits_tuple)
        side, landing = run_inside(bits, transverse, heading)
        bits_tuple = tuple(bits)
        lp, lm, rp, rm = flags
        if side == "right":
            if landing == 6 and rp:
                return
            right2 = right + (landing,)
            if len(right2) > max_length:
                return
            rp2 = rp or landing == 6
            edges.add((left, right2, sum(bit << line for line, bit in enumerate(bits))))
            if len(right2) == max_length:
                return
            for entry in (0, 2, 4):
                if entry == 0 and rm:
                    continue
                visit(bits_tuple, entry, WEST,
                      (lp, lm, rp2, rm or entry == 0),
                      left, right2 + (entry,))
        else:
            if landing == 0 and lm:
                return
            left2 = left + (landing,)
            if len(left2) >= max_length:
                return
            lm2 = lm or landing == 0
            for entry in (2, 4, 6):
                if entry == 6 and lp:
                    continue
                visit(bits_tuple, entry, EAST,
                      (lp or entry == 6, lm2, rp, rm),
                      left2 + (entry,), right)

    blank = (0,) * 7
    for first in (2, 4, 6):
        visit(blank, first, EAST, (first == 6, False, False, False),
              (first,), ())
    return edges, calls


def strongly_connected(edges):
    adjacency = {}
    reverse = {}
    for source, target, _mask in edges:
        adjacency.setdefault(source, set()).add(target)
        adjacency.setdefault(target, set())
        reverse.setdefault(target, set()).add(source)
        reverse.setdefault(source, set())

    seen = set()
    order = []

    def visit(vertex):
        if vertex in seen:
            return
        seen.add(vertex)
        for target in adjacency[vertex]:
            visit(target)
        order.append(vertex)

    for vertex in adjacency:
        visit(vertex)

    components = []
    seen.clear()

    def collect(vertex, component):
        if vertex in seen:
            return
        seen.add(vertex)
        component.add(vertex)
        for source in reverse[vertex]:
            collect(source, component)

    for vertex in reversed(order):
        if vertex not in seen:
            component = set()
            collect(vertex, component)
            components.append(component)

    cyclic = []
    for component in components:
        if len(component) > 1 or any(
            target == vertex
            for vertex in component for target in adjacency[vertex]
        ):
            cyclic.append(component)
    return cyclic, adjacency


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-length", type=int, default=7)
    parser.add_argument("--show-components", action="store_true")
    parser.add_argument("--direct", action="store_true",
                        help="use direct bounded recursion instead of all pairs")
    args = parser.parse_args()
    if args.direct:
        edge_set, calls = generated_graph(args.max_length)
        edges = sorted(edge_set)
        vertices = sorted({source for source, _target, _mask in edges}
                          | {target for _source, target, _mask in edges})
        print(f"direct_recursion_calls={calls}")
    else:
        vertices, edges = bounded_graph(args.max_length)
        if args.max_length <= 7:
            generated, calls = generated_graph(args.max_length)
            assert generated == set(edges), (generated - set(edges), set(edges) - generated)
            print(f"direct_crosscheck=true recursion_calls={calls}")
    cyclic, adjacency = strongly_connected(edges)
    print(
        f"max_length={args.max_length} signatures={len(vertices)} "
        f"compatible_edges={len(edges)} cyclic_components={len(cyclic)} "
        f"cyclic_vertices={sum(map(len, cyclic))}"
    )
    masks = {}
    for _source, _target, mask in edges:
        masks[mask] = masks.get(mask, 0) + 1
    print("final_masks=" + repr({f"{mask:07b}": count for mask, count in sorted(masks.items())}))
    if args.show_components:
        for index, component in enumerate(sorted(cyclic, key=lambda item: (len(item), sorted(item)))):
            print(f"SCC {index} size={len(component)}")
            for vertex in sorted(component, key=lambda item: (len(item), item)):
                targets = sorted(adjacency[vertex] & component,
                                 key=lambda item: (len(item), item))
                print(f"  {vertex} -> {targets}")


if __name__ == "__main__":
    main()
