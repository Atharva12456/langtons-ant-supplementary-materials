#!/usr/bin/env python3
"""Regression for the checker-pure `(2,-2)`, growth-eight exclusion.

The theorem is the cardinality-free two-lane run argument in
``research-notes/growth8_checker_pure_exclusion_2026-08-20.md``.  This script
checks its lane arithmetic and every finite pure gadget chain in a configurable
window.  It is not an unbounded proof oracle.
"""

from __future__ import annotations

import argparse
import itertools
import json
from math import comb

from even_diagonal_rank_parity_audit import (
    boundary_count,
    c_gadget,
    inversion_parity,
    q_gadget,
    run_count,
    toggle_gadget,
)


def charge_solutions() -> set[tuple[int, int]]:
    solutions = set()
    for sign in (-1, 1):
        for first in range(9):
            second = 8 - first
            if sign * first % 4 == 2 and sign * second % 4 == 2:
                solutions.add((first, second))
    return solutions


def audit_chains(length: int) -> int:
    levels = tuple(1 + 2 * index for index in range(length))
    checked = 0
    for gadget in (c_gadget, q_gadget):
        for flat in itertools.product(range(2), repeat=2 * length):
            lane_bits = (flat[:length], flat[length:])
            boundaries = tuple(boundary_count(bits) for bits in lane_bits)
            if sorted(boundaries) != [2, 6]:
                continue
            blocks = set()
            for lane, bits in enumerate(lane_bits):
                for level, bit in zip(levels, bits):
                    if bit:
                        toggle_gadget(blocks, gadget(level, lane))
            runs = tuple(run_count(bits) for bits in lane_bits)
            assert boundaries == tuple(2 * count for count in runs)
            formula = sum(comb(count, 2) for count in boundaries) % 2
            assert formula == 0
            assert inversion_parity(blocks) == formula
            checked += 1
    return checked


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chain-length", type=int, default=7)
    args = parser.parse_args()
    if not 5 <= args.chain_length <= 10:
        parser.error("--chain-length must lie in 5..10")
    solutions = charge_solutions()
    assert solutions == {(2, 6), (6, 2)}
    assert all((comb(a, 2) + comb(b, 2)) % 2 == 0 for a, b in solutions)
    checked = audit_chains(args.chain_length)
    assert checked > 0
    print(json.dumps({
        "schema": "langton-growth8-checker-pure-audit-v1",
        "status": "bounded_regression_of_analytic_proof",
        "chain_length": args.chain_length,
        "lane_count_solutions": sorted(solutions),
        "finite_chain_checks": checked,
        "all_checks_passed": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
