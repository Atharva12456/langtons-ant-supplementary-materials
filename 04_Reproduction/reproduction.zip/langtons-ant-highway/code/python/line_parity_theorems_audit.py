#!/usr/bin/env python3
"""Direct turn-count verification of four line-parity theorems.

All counts below are over ALL TIME (the bi-infinite periodic trace), which for a
translation class equals the count over one period window, because the period
events of a class are in bijection with the visits to any single cell of it.

Normalise by rotation so the drift is d = (m,-m), m > 0.  Put t = x+y
(transverse, constant along d) and u = x-y (longitudinal).  Both change by
exactly +-1 at every move.  Level parity determines the arrival axis.

  T1  TRANSVERSE LEVEL PARITY
      at every horizontal-arrival level:  #L is even
      at every vertical-arrival   level:  #R is even

  T2  LONGITUDINAL LINE PARITY
      on every u-line whose cells sit at horizontal-arrival levels:  #R is odd
      on every u-line whose cells sit at vertical-arrival   levels:  #L is odd

  T3  COLUMN PARITY (x-walk)
      in every column x = v, the number of vertical moves whose flanking turns
      are EQUAL is even    [when N/2 is odd; in general = (nu+1) mod 2]

  T4  ROW PARITY (y-walk)
      in every row y = w, the number of horizontal moves whose flanking turns
      are EQUAL is even    [same proviso]

T1 and T2 are proved from the reflection/continue rule plus flow.  T3 and T4 are
the same argument applied to the x- and y-walks, which advance only on moves of
one axis.  This script checks all four numerically.
"""

from __future__ import annotations

from collections import defaultdict

DX = (1, 0, -1, 0)  # E,S,W,N ; R = +1
DY = (0, -1, 0, 1)


def run_ant(steps, seed_black=()):
    black = set(seed_black)
    x = y = 0
    h = 3
    trace = []
    for _ in range(steps):
        if (x, y) in black:
            turn = "L"
            black.discard((x, y))
            h = (h - 1) % 4
        else:
            turn = "R"
            black.add((x, y))
            h = (h + 1) % 4
        trace.append(((x, y), turn))
        x += DX[h]
        y += DY[h]
    return trace


def rot(p, k):
    x, y = p
    for _ in range(k % 4):
        x, y = -y, x
    return p if k % 4 == 0 else (x, y)


def find_highway(trace, period=104, lo=200):
    for s in range(lo, len(trace) - 2 * period):
        (x0, y0), _ = trace[s]
        (x1, y1), _ = trace[s + period]
        d = (x1 - x0, y1 - y0)
        if d == (0, 0):
            continue
        if all(
            (trace[s + period + k][0][0] - trace[s + k][0][0],
             trace[s + period + k][0][1] - trace[s + k][0][1]) == d
            and trace[s + period + k][1] == trace[s + k][1]
            for k in range(period)
        ):
            return s, d
    return None, None


def analyse(window, d, label, verbose=False):
    N = len(window)
    m = d[0]
    pos = [p for p, _ in window]
    turns = [t for _, t in window]

    def prv(j):
        return pos[j - 1] if j else (pos[N - 1][0] - d[0], pos[N - 1][1] - d[1])

    axis = defaultdict(set)
    for j in range(N):
        p, q = prv(j), pos[j]
        axis[(q[0] + q[1]) % 2].add("H" if p[1] == q[1] else "V")
    assert all(len(v) == 1 for v in axis.values()), axis
    horiz_par = [par for par, s in axis.items() if s == {"H"}][0]
    shift = 1 - horiz_par

    def lev(p):
        return p[0] + p[1] + shift

    fails = []

    # ---- T1 : per transverse level ----
    perlev = defaultdict(lambda: [0, 0])  # t -> [#R, #L]
    for j in range(N):
        t = lev(pos[j])
        perlev[t][0 if turns[j] == "R" else 1] += 1
    for t, (nr, nl) in sorted(perlev.items()):
        if t % 2:                       # horizontal arrival
            if nl % 2:
                fails.append(f"T1 level t={t} (H): #L={nl} odd")
        else:
            if nr % 2:
                fails.append(f"T1 level t={t} (V): #R={nr} odd")

    # ---- T2 : per longitudinal line ----
    # count over all time = count over the period events of each class,
    # since each u-line meets each class in exactly one cell.
    perline = defaultdict(lambda: [0, 0])
    for j in range(N):
        x, y = pos[j]
        # class key of this event; the u-line is determined mod 2m by x-y
        perline[(x - y) % (2 * m)][0 if turns[j] == "R" else 1] += 1
    for key, (nr, nl) in sorted(perline.items()):
        # the levels on this line all share one parity
        sample = [lev(pos[j]) for j in range(N) if (pos[j][0] - pos[j][1]) % (2 * m) == key]
        pars = {s % 2 for s in sample}
        assert len(pars) == 1, (key, pars)
        par = pars.pop()
        if par == 1:
            if nr % 2 == 0:
                fails.append(f"T2 u-line {key} (H levels): #R={nr} even")
        else:
            if nl % 2 == 0:
                fails.append(f"T2 u-line {key} (V levels): #L={nl} odd/even mismatch nl={nl}")

    # ---- T3 : per column ----
    # nu_v = number of horizontal moves landing in column class v (= x-walk
    # visits to that column over all time).  Claim: rho^x_v = nu_v + 1 (mod 2).
    col = defaultdict(int)
    nucol = defaultdict(int)
    for j in range(N):
        nxtp = pos[j + 1] if j + 1 < N else (pos[0][0] + d[0], pos[0][1] + d[1])
        if nxtp[0] != pos[j][0]:
            nucol[nxtp[0] % m] += 1     # horizontal move landing here
            continue
        after = turns[j + 1] if j + 1 < N else turns[0]
        if turns[j] == after:
            col[pos[j][0] % m] += 1
    for c in sorted(set(col) | set(nucol)):
        if (col[c] % 2) != ((nucol[c] + 1) % 2):
            fails.append(f"T3 column {c}: rho={col[c]} nu={nucol[c]} (want rho=nu+1 mod 2)")

    # ---- T4 : per row ----
    row = defaultdict(int)
    nurow = defaultdict(int)
    for j in range(N):
        nxtp = pos[j + 1] if j + 1 < N else (pos[0][0] + d[0], pos[0][1] + d[1])
        if nxtp[1] != pos[j][1]:
            nurow[nxtp[1] % m] += 1
            continue
        after = turns[j + 1] if j + 1 < N else turns[0]
        if turns[j] == after:
            row[pos[j][1] % m] += 1
    for c in sorted(set(row) | set(nurow)):
        if (row[c] % 2) != ((nurow[c] + 1) % 2):
            fails.append(f"T4 row {c}: rho={row[c]} nu={nurow[c]} (want rho=nu+1 mod 2)")

    if verbose:
        print(f"  levels: " + ", ".join(
            f"t={t}{'H' if t%2 else 'V'}:R{v[0]}L{v[1]}" for t, v in sorted(perlev.items())))
        print(f"  u-lines: " + ", ".join(f"{k}:R{v[0]}L{v[1]}" for k, v in sorted(perline.items())))
        print(f"  T3 col rho={dict(col)} nu={dict(nucol)}   T4 row rho={dict(row)} nu={dict(nurow)}")
    return fails


def main() -> None:
    import random

    trials = []
    trials.append(("empty", ()))
    rng = random.Random(20260818)
    while len(trials) < 26:
        k = rng.randint(1, 9)
        cells = tuple({(rng.randint(-4, 4), rng.randint(-4, 4)) for _ in range(k)})
        trials.append((f"seed{len(trials)}", cells))

    total_fail = 0
    checked = 0
    for name, seed in trials:
        trace = run_ant(60000, seed)
        s, d0 = find_highway(trace)
        if s is None:
            print(f"{name}: no period-104 highway found, skipped")
            continue
        for k in range(4):
            dd = rot(d0, k)
            if dd[0] > 0 and dd[0] == -dd[1]:
                break
        else:
            print(f"{name}: drift {d0} not diagonal, skipped")
            continue
        window = [(rot(p, k), t) for (p, t) in trace[s : s + 104]]
        d = rot(d0, k)
        fails = analyse(window, d, name, verbose=(name == "empty"))
        checked += 1
        if fails:
            total_fail += 1
            print(f"{name}: raw drift {d0} -> {d}   FAILURES:")
            for f in fails:
                print("    ", f)
        else:
            print(f"{name}: raw drift {d0} -> {d}   all four theorems OK")
    print(f"\nchecked {checked} highways, {total_fail} with any failure")


if __name__ == "__main__":
    main()
