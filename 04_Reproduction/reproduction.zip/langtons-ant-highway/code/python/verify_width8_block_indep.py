"""Independent set/compass verifier for the width-eight block classifier.

This implementation imports no project dynamics and no primary width-eight module.
It uses immutable sets of cells, compass-letter headings, and depth-first traversal.
All exterior history is deliberately forgotten after each outer exit, and every
geometrically possible same-boundary return is allowed.
"""
from __future__ import annotations

import argparse
from collections import Counter


RIGHT_TURN = {"N": "E", "E": "S", "S": "W", "W": "N"}
LEFT_TURN = {value: key for key, value in RIGHT_TURN.items()}
TOP = 8
LEFT_ENTRY_ROWS = (2, 4, 6, 8)
RIGHT_ENTRY_ROWS = (0, 2, 4, 6)
LOCAL_LOOP = object()


def run_until_outside(columns, black_cells, used_extremes,
                      column, row, direction):
    black = set(black_cells)
    used = set(used_extremes)
    local_states = set()
    cell_visits = 0

    while 0 <= column < columns:
        state = (frozenset(black), frozenset(used), column, row, direction)
        if state in local_states:
            return LOCAL_LOOP
        local_states.add(state)

        if not 0 <= row <= TOP:
            raise AssertionError((column, row, direction))
        cell = (column, row)
        if row in (0, TOP):
            if cell in used:
                return None
            used.add(cell)

        if cell in black:
            black.remove(cell)
            direction = LEFT_TURN[direction]
        else:
            black.add(cell)
            direction = RIGHT_TURN[direction]
        cell_visits += 1

        if direction == "E":
            column += 1
            row += 1
        elif direction == "W":
            column -= 1
            row -= 1
        elif direction == "N":
            row += 1
        else:
            row -= 1

    side = "left" if column < 0 else "right"
    return frozenset(black), frozenset(used), side, row, cell_visits


def verify_relaxed(columns):
    pending = [
        (frozenset(), frozenset(), 0, row, "E")
        for row in LEFT_ENTRY_ROWS
    ]
    visited = set(pending)
    terminal_states = set()
    terminal_events = 0
    exits = Counter()
    transitions = 0
    rejected = 0
    local_loops = 0
    max_local_visits = 0

    while pending:
        black, used, column, row, direction = pending.pop()
        result = run_until_outside(
            columns, black, used, column, row, direction
        )
        if result is LOCAL_LOOP:
            local_loops += 1
            continue
        if result is None:
            rejected += 1
            continue

        black2, used2, side, landing, local_visits = result
        max_local_visits = max(max_local_visits, local_visits)
        exits[(side, landing)] += 1
        if side == "right":
            terminal_events += 1
            terminal_states.add((black2, used2, landing))
            choices = [
                (columns - 1, entry, "W") for entry in RIGHT_ENTRY_ROWS
            ]
        else:
            choices = [(0, entry, "E") for entry in LEFT_ENTRY_ROWS]

        for next_column, entry, next_direction in choices:
            next_state = (
                black2, used2, next_column, entry, next_direction
            )
            transitions += 1
            if next_state not in visited:
                visited.add(next_state)
                pending.append(next_state)

    return {
        "columns": columns,
        "states": len(visited),
        "transitions": transitions,
        "terminal_events": terminal_events,
        "terminal_states": len(terminal_states),
        "rejected": rejected,
        "local_loops": local_loops,
        "max_local_visits": max_local_visits,
        "exits": exits,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-columns", type=int, default=7)
    parser.add_argument("--max-columns", type=int, default=8)
    args = parser.parse_args()
    for columns in range(args.min_columns, args.max_columns + 1):
        result = verify_relaxed(columns)
        print(
            "independent columns={columns} states={states:,} transitions={transitions:,} "
            "terminal_events={terminal_events:,} terminal_states={terminal_states:,} "
            "rejected={rejected:,} local_loops={local_loops:,} "
            "max_local_visits={max_local_visits}"
            .format(**result)
        )
        print(f"  exits={dict(sorted(result['exits'].items()))}")


if __name__ == "__main__":
    main()
