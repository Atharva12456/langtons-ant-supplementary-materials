"""Independent unpruned local-domain audit for positive-skew caps.

Uses geometrically computed edge targets, a separate multiset-interleaving
word generator, physical finite first-return witnesses, and Z3 integer clocks.
N>0 has no upper bound. Strict row order only; no P22 or growth filter.
"""
from pathlib import Path
from collections import Counter
import argparse, json, time, hashlib
import z3

HEADINGS = 'NESW'
VECTORS = {'N':(0,1),'E':(1,0),'S':(0,-1),'W':(-1,0)}

def outgoing(port):
    return HEADINGS[(HEADINGS.index(port[0]) + (1 if port[1]=='R' else -1))%4]

def edge(t, port):
    dx,dy=VECTORS[outgoing(port)]
    return t+3*dx-dy, dx

def counts(rows, t, wake):
    east=sum(outgoing(p)=='E' for p in rows.get(t-3,()))
    west=sum(p[0]=='W' for p in rows.get(t-3,()))
    south=sum(outgoing(p)=='S' for p in rows.get(t-1,()))
    north=sum(p[0]=='N' for p in rows.get(t-1,()))
    if t%2:
        assert south==west==0
        for er in range(east+1):
            el=east-er;wr=north-el;wl=er+wr-el-wake
            if min(wr,wl)>=0:
                yield {'ER':er,'EL':el,'WR':wr,'WL':wl}
    else:
        assert east==north==0
        for nl in range(west+1):
            sr=west-nl;sl=south-sr;nr=wake+nl+sl-sr
            if min(sl,nr)>=0:
                yield {'NR':nr,'NL':nl,'SR':sr,'SL':sl}

def permutations(multiset):
    n=sum(multiset.values())
    if not n:
        yield ();return
    for p in sorted(multiset):
        if multiset[p]:
            multiset[p]-=1
            for tail in permutations(multiset):yield (p,)+tail
            multiset[p]+=1

def words(c):
    right={p:n for p,n in c.items() if p[1]=='R'}
    left={p:n for p,n in c.items() if p[1]=='L'}
    assert sum(right.values())-sum(left.values()) in (0,1)
    for r in permutations(right):
        for l in permutations(left):
            result=[]
            for i in range(len(l)):result.extend((r[i],l[i]))
            result.extend(r[len(l):]);yield tuple(result)

def successors(rows):
    result={}
    for t,w in rows.items():
        ordinals=Counter()
        for i,p in enumerate(w):
            u,copy=edge(t,p);h=outgoing(p)
            ordinal=ordinals[h];ordinals[h]+=1
            if u in rows:
                targets=[j for j,q in enumerate(rows[u]) if q[0]==h]
                assert ordinal<len(targets)
                result[(t,i)]=((u,targets[ordinal]),copy)
        for h in HEADINGS:
            dx,dy=VECTORS[h];u=t+3*dx-dy
            if u in rows:
                assert ordinals[h]==sum(p[0]==h for p in rows[u])
    return result

def wrong_first_return(rows, succ):
    # A truncation only keeps extra candidates; it never constitutes rejection.
    limit=max(64,2*sum(map(len,rows.values())))
    for start in sorted(succ):
        q=start;x,y=0,-start[0];path=[(q,x,y)]
        for step in range(1,limit+1):
            if q not in succ:break
            dx,dy=VECTORS[outgoing(rows[q[0]][q[1]])]
            x+=dx;y+=dy;q,copy=succ[q]
            path.append((q,x,y))
            if (x,y)==(0,-start[0]):
                if q!=(start[0],start[1]+1):
                    return {'start':start,'endpoint':q,'steps':step,'path':path}
                break
    return None

def clock_possible(rows,succ):
    solver=z3.Solver()
    period=z3.Int('N');solver.add(period>0)
    clocks={q:z3.Int(f'tau_{q[0]}_{q[1]}') for t,w in rows.items() for q in [(t,i) for i in range(len(w))]}
    for q,(r,voltage) in succ.items():solver.add(clocks[r]==clocks[q]+1-period*voltage)
    for t,w in rows.items():
        for i in range(len(w)-1):solver.add(clocks[t,i+1]>clocks[t,i])
    result=solver.check()
    assert result!=z3.unknown
    return result==z3.sat

def run(profile,depth):
    seeds={'guard':{0:('NR',),1:('WR',),2:('NR',)},
           'missing':{0:('NR',),1:('WR',),2:()},
           'thin':{0:('NR',),1:('WR','WL'),2:('NR','SL')}}
    states=[seeds[profile]];stages=[];started=time.time();sample_witnesses=[]
    for t in range(3,depth+1):
        survivors=[];tally=Counter()
        for rows in states:
            for wake in (0,1):
                for c in counts(rows,t,wake):
                    tally['count_vectors']+=1
                    for w in words(c):
                        tally['all_raw_words']+=1;new={**rows,t:w};succ=successors(new)
                        bad=wrong_first_return(new,succ)
                        if bad:
                            tally['physical_rejects']+=1
                            if len(sample_witnesses)<20:sample_witnesses.append({'rows':new,'witness':bad})
                        elif not clock_possible(new,succ):tally['z3_unsat_clocks']+=1
                        else:survivors.append(new)
        stages.append({'level':t,'parents':len(states),'survivors':len(survivors),'complete':True,**tally})
        states=survivors;print(json.dumps(stages[-1]),flush=True)
        if not states:break
    return {'profile':profile,'drift':[1,3],'gauge':'t=3x-y; min0 vertical',
            'N':'positive integer, unbounded; no congruence or event-count bound',
            'order':'strict; no imposed ≥4 gap','P22':False,'growth_filter':False,
            'adjacency_pruning':False,'stages':stages,'frontier_closed':not states,
            'seconds':time.time()-started,'z3_version':z3.get_version_string(),
            'sample_witnesses':sample_witnesses,
            'surviving_words':states}

def thin_expected(c,e,f):
    return {0:('NR',),1:('WR','WL'),2:('NR','SL'),
            3:('WR','WL','ER','WL'),4:('SR','SL','SR'),
            5:('ER','WL','ER')+('WL',)*(1-c),
            6:('NR','NL','SR','NL')+('NR','SL')*(3-c)+('NR',)*e,
            7:('WR','WL','WR','EL')+('WR','WL')*(3-c+e-f)+('WR',)*f}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--profiles',nargs='+',choices=('missing','guard','thin'),
                        default=('missing','guard','thin'))
    args=parser.parse_args()
    depths={'missing':4,'guard':7,'thin':7}
    results=[run(profile,depths[profile]) for profile in args.profiles]
    for result in results:
        if result['profile']!='thin':
            assert result['frontier_closed']
        else:
            canonical=lambda rows:tuple((t,tuple(w)) for t,w in sorted(rows.items()))
            assert {canonical(r) for r in result['surviving_words']}=={
                canonical(thin_expected(c,e,f))
                for c in (0,1) for e in (0,1) for f in (0,1)}
    report={'results':results,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    output=Path(__file__).resolve().parents[2]/'results'/(
        'positive_skew_cap_reduction_'+'_'.join(args.profiles)+'_audit.json')
    output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('INDEPENDENT POSITIVE-SKEW CAP REDUCTION CHECK: PASS',flush=True)
