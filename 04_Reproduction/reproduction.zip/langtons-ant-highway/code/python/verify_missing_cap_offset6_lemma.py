"""Every missing cap at drift (1,-3) has a wake at inward offset six, at either end.

The missing cap fixes the three extreme rows 0: WR, 1: NR, 2: (empty) in its own
inward coordinates (headings rotated by 180 degrees at the upper end). Offset six
is taken non-wake; every other offset takes both wake values. Rows are enumerated
from the flow and excess equations and right/left alternation. A word is discarded
only for a violated zero-displacement return while it is built, a witnessed finite
same-cell first return to the wrong event (no quotient-cycle extrapolation), or an
infeasible lifted clock

    tau(target) = tau(source) + 1 + SIGN*N*lambda,   N >= 6,   same-cell gaps >= 4,

with SIGN=-1 at the lower cap and +1 at the upper cap. No P22, rank or moment
condition and no bound on period, width or row length is used. Both frontiers
become empty (level ten at the lower cap, offset twelve at the upper cap).

Run from code/python:
    python verify_missing_cap_offset6_lemma.py
It writes results/missing_cap_offset6_checks_2026-09-23.json.
"""
from collections import Counter
from pathlib import Path
import json

import z3

from verify_lower_fat123_a0_102_exclusion import (row_counts, successors,
                                                  witnessed_bad_return, words)

EXPECTED = {-1: [2, 1, 2, 3, 8, 4, 14, 0], 1: [2, 1, 2, 3, 8, 6, 23, 21, 88, 0]}


def clock_feasible(rows, succ, sign):
    n = z3.Int('N')
    tau = {(t, i): z3.Int(f'tau_{t}_{i}') for t, r in rows.items() for i in range(len(r))}
    s = z3.SolverFor('QF_LIA')
    s.add(n >= 6)
    for (t, i), (u, j, v) in succ.items():
        s.add(tau[u, j] - tau[t, i] == 1 + sign * v * n)
    for t, r in rows.items():
        for i in range(len(r) - 1):
            s.add(tau[t, i + 1] - tau[t, i] >= 4)
    res = s.check()
    if res == z3.unknown:
        raise RuntimeError(s.reason_unknown())
    return res == z3.sat


def run(sign):
    states = [{0: ('WR',), 1: ('NR',), 2: ()}]
    history = []
    t = 2
    while states:
        t += 1
        nxt, st = [], Counter()
        for rows in states:
            for wake in ((0,) if t == 6 else (0, 1)):
                for cnt in row_counts(rows, t, wake):
                    st['count_rows'] += 1
                    for w in words(rows, t, cnt):
                        st['words'] += 1
                        child = {**rows, t: w}
                        succ = successors(child)
                        assert succ is not None
                        if witnessed_bad_return(child, succ) is not None:
                            st['return_rejected'] += 1
                        elif not clock_feasible(child, succ, sign):
                            st['clock_rejected'] += 1
                        else:
                            nxt.append(child)
        states = nxt
        history.append({'offset': t, **st, 'survivors': len(states)})
        print('sign', sign, history[-1], flush=True)
        assert t <= 14
    assert [h['survivors'] for h in history] == EXPECTED[sign], history
    return history


def main():
    cases = [{'cap': 'lower missing', 'sign': -1, 'history': run(-1)},
             {'cap': 'upper missing', 'sign': 1, 'history': run(1)}]
    report = {
        'claim': 'Every missing cap at drift (1,-3), lower or upper, has a wake at inward offset six',
        'not_used': ['P22', 'rank', 'moment', 'quotient-cycle extrapolation', 'period/width/row-length bounds'],
        'cases': cases,
        'all_checks_passed': True,
    }
    out = Path(__file__).resolve().parents[2] / 'results' / 'missing_cap_offset6_checks_2026-09-23.json'
    out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'cases'}, indent=2))


if __name__ == '__main__':
    main()
