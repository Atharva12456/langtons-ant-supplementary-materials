#!/usr/bin/env python3
"""Audit the lifted-rank condition at drift `(1,3)` and `(1,-3)`.

The quotient parity flow is solved directly over GF(2).  The program checks its
elementary segment interactions and compares every bounded P22-plus-moment
boundary with the closed endpoint-interlacing formula.  These finite checks are
regressions for the segment proof, not a search over ant periods.
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path


Block = tuple[str, int]


def target(block: Block, sign: int) -> int:
    kind, level = block
    if kind == "E":
        return level + 3
    if kind == "W":
        return level - 3
    if kind == "N":
        return level - sign
    if kind == "S":
        return level + sign
    raise AssertionError(kind)


def source_key(block: Block) -> tuple[int, int]:
    kind, level = block
    return level, int(kind in "EN")


def target_key(block: Block, sign: int) -> tuple[int, int]:
    return target(block, sign), int(block[0] in "EN")


def strip_blocks(low: int, high: int, sign: int) -> list[Block]:
    blocks = []
    for level in range(low, high + 1):
        kinds = "WE" if level % 2 == 0 else "SN"
        for kind in kinds:
            block = kind, level
            if low <= target(block, sign) <= high:
                blocks.append(block)
    return blocks


def solve_unique(
    boundary: set[int], sign: int, margin: int
) -> tuple[list[Block], int]:
    low = min(boundary) - margin
    high = max(boundary) + margin
    blocks = strip_blocks(low, high, sign)
    index = {block: position for position, block in enumerate(blocks)}
    rows = []
    for level in range(low, high + 1):
        right = int(level in boundary)
        outgoing = [block for block in blocks if block[1] == level]
        incoming = [block for block in blocks if target(block, sign) == level]
        for incident in (outgoing, incoming):
            coefficients = sum(1 << index[block] for block in incident)
            rows.append(coefficients | (right << len(blocks)))

    rank = 0
    pivots = []
    for column in range(len(blocks)):
        pivot = next(
            (row for row in range(rank, len(rows)) if (rows[row] >> column) & 1),
            None,
        )
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for row in range(len(rows)):
            if row != rank and ((rows[row] >> column) & 1):
                rows[row] ^= rows[rank]
        pivots.append(column)
        rank += 1

    coefficient_mask = (1 << len(blocks)) - 1
    assert not any(
        (row & coefficient_mask) == 0 and ((row >> len(blocks)) & 1)
        for row in rows
    )
    assert rank == len(blocks)
    solution = 0
    for row, pivot in zip(rows[:rank], pivots):
        if (row >> len(blocks)) & 1:
            solution |= 1 << pivot
    return blocks, solution


def direct_sign(
    blocks: list[Block], solution: int, boundary: set[int], sign: int
) -> int:
    selected = [
        block
        for position, block in enumerate(blocks)
        if (solution >> position) & 1
    ]
    ordered = sorted(selected, key=source_key)
    edge_sign = sum(
        target_key(first, sign) > target_key(second, sign)
        for index, first in enumerate(ordered)
        for second in ordered[index + 1 :]
    ) & 1

    outgoing: dict[int, list[Block]] = defaultdict(list)
    incoming: dict[int, list[Block]] = defaultdict(list)
    for block in selected:
        outgoing[block[1]].append(block)
        incoming[target(block, sign)].append(block)
    local_sign = 0
    for level in set(outgoing) | set(incoming) | boundary:
        excess = int(level in boundary)
        positive = (
            sum(block[0] in "EN" for block in outgoing[level])
            + sum(block[0] in "EN" for block in incoming[level])
        ) & 1
        if level % 2 == 0:
            local_sign ^= positive & (excess ^ 1)
        else:
            local_sign ^= excess & (positive ^ 1)
    return edge_sign ^ local_sign


def flow_sign(boundary: set[int], sign: int, margin: int) -> int:
    blocks, solution = solve_unique(boundary, sign, margin)
    return direct_sign(blocks, solution, boundary, sign)


def interlacing(first: tuple[int, ...], second: tuple[int, ...]) -> int:
    return sum(left < right for left in first for right in second) & 1


def ordering_fibres(
    levels_by_residue: tuple[tuple[int, ...], ...], sign: int
) -> tuple[tuple[int, ...], ...]:
    if sign == 1:
        return levels_by_residue
    return tuple(
        tuple(3 * level + residue for level in levels)
        for residue, levels in enumerate(levels_by_residue)
    )


def expected_sign(
    levels_by_residue: tuple[tuple[int, ...], ...], sign: int
) -> int:
    fibres = ordering_fibres(levels_by_residue, sign)
    return sum(
        interlacing(fibres[first], fibres[second])
        for first in range(3)
        for second in range(first + 1, 3)
    ) & 1


def boundary_records(maximum_index: int, sign: int):
    target_moment = (2 - sign) % 4
    for counts in sorted(set(itertools.permutations((4, 2, 2)))):
        choices = []
        for residue, count in enumerate(counts):
            rows = []
            for levels in itertools.combinations(
                range(-maximum_index, maximum_index + 1), count
            ):
                epsilons = tuple(
                    1 if (level + residue) % 2 == 0 else -1
                    for level in levels
                )
                if sum(epsilons) % 4 != 2:
                    continue
                moment = sum(
                    epsilon * level
                    for epsilon, level in zip(epsilons, levels)
                ) % 4
                rows.append((levels, moment))
            choices.append(rows)
        for rows in itertools.product(*choices):
            if sum(row[1] for row in rows) % 4 != target_moment:
                continue
            levels_by_residue = tuple(row[0] for row in rows)
            boundary = {
                3 * level - sign * residue
                for residue, levels in enumerate(levels_by_residue)
                for level in levels
            }
            assert len(boundary) == 8
            yield boundary, levels_by_residue


def segment_table(sign: int, margin: int) -> int:
    pairs = tuple(itertools.combinations(range(-2, 3), 2))
    segments = {}
    values = {}
    checks = 0
    for residue in range(3):
        for pair in pairs:
            boundary = {3 * level - sign * residue for level in pair}
            blocks, solution = solve_unique(boundary, sign, margin)
            segments[residue, pair] = (blocks, solution, boundary)
            value = direct_sign(blocks, solution, boundary, sign)
            assert value == int(sign == -1)
            values[residue, pair] = value
            checks += 1

    for first_residue in range(3):
        for second_residue in range(first_residue, 3):
            for first_pair in pairs:
                for second_pair in pairs:
                    first_boundary = segments[first_residue, first_pair][2]
                    second_boundary = segments[second_residue, second_pair][2]
                    if first_boundary & second_boundary:
                        continue
                    combined_boundary = first_boundary ^ second_boundary
                    combined = flow_sign(combined_boundary, sign, margin)
                    cross = combined ^ values[first_residue, first_pair]
                    cross ^= values[second_residue, second_pair]
                    if first_residue == second_residue:
                        expected = 0
                    else:
                        fibres = ordering_fibres(
                            tuple(
                                first_pair if residue == first_residue
                                else second_pair if residue == second_residue
                                else ()
                                for residue in range(3)
                            ),
                            sign,
                        )
                        expected = interlacing(
                            fibres[first_residue], fibres[second_residue]
                        )
                    assert cross == expected
                    checks += 1
    return checks


def audit(maximum_index: int, margin: int) -> dict[str, object]:
    if maximum_index < 3:
        raise ValueError("maximum_index must be at least three")
    if margin < 4:
        raise ValueError("margin must be at least four")

    orientations = []
    for sign in (1, -1):
        counts = [0, 0]
        checked = 0
        for boundary, levels_by_residue in boundary_records(maximum_index, sign):
            direct = flow_sign(boundary, sign, margin)
            expected = expected_sign(levels_by_residue, sign)
            assert direct == expected
            counts[direct] += 1
            checked += 1
        orientations.append(
            {
                "drift": [1, 3 * sign],
                "boundaries_checked": checked,
                "rank_sign_counts": counts,
                "rank_survivors": counts[0],
                "segment_table_checks": segment_table(sign, margin),
            }
        )

    return {
        "schema": "langton-growth8-odd-skew-rank-parity-audit-v1",
        "status": "bounded_evidence_not_proof",
        "maximum_index": maximum_index,
        "exterior_margin": margin,
        "orientations": orientations,
        "required_rank_sign": 0,
        "all_checks_passed": all(row["rank_survivors"] > 0 for row in orientations),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--maximum-index", type=int, default=3)
    parser.add_argument("--margin", type=int, default=5)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = audit(args.maximum_index, args.margin)
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
