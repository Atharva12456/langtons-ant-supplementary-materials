#!/usr/bin/env python3
"""DP over the primitive-diagonal transverse level system (growth four).

State: (cut index t, f_t, number of wake levels so far, number of those at odd t).
Transitions enforce, at each level t:
    m_t = f_{t-1} + f_t
    mod-four level theorem     (t odd -> m = 0,1 mod 4 ; t even -> m = 0,3 mod 4)
    reflection non-negativity  |f_{t-1} - f_t| <= rho_t
with rho_t = ceil(m_t/2) for t odd, floor(m_t/2) for t even.

Boundary: levels are 1..W+1, both extremal levels odd (horizontal arrival) with
m = 1, so f_1 = f_W = 1 and f_0 = f_{W+1} = 0.

Acceptance: exactly four wake (odd-multiplicity) levels, of which exactly three
are at odd t.  That 3-1 split is *derived*, not assumed: N = sum m_t = a + 3b
(mod 4) where a+b=4 counts wake levels by parity, and N = 2 (mod 4) because the
N/2 horizontal moves have odd net displacement 1.  Only (a,b) = (3,1) and (1,3)
satisfy a - b = 2 (mod 4), and both extremal wake levels are at odd t, so a >= 2.

Also reports the minimum period N = 2 sum f_t over all feasible profiles.
"""

from __future__ import annotations

import sys


def solve(W: int, verbose: bool = False):
    if W % 2:
        return None
    # backward cap: f_{t} <= 3 f_{t+1} + 1, anchored at f_W = 1
    cap = [0] * (W + 2)
    cap[W] = 1
    for t in range(W - 1, 0, -1):
        cap[t] = 3 * cap[t + 1] + 1
    # forward cap
    fwd = [0] * (W + 2)
    fwd[1] = 1
    for t in range(2, W + 1):
        fwd[t] = 3 * fwd[t - 1] + 1
    for t in range(1, W + 1):
        cap[t] = min(cap[t], fwd[t])
    cap[1] = cap[W] = 1

    # dp[(f, wake, wake_odd)] -> min sum of f so far (cuts 1..t)
    INF = float("inf")
    # start at t = 1 : level 1 has m = f_1 = 1, odd t, wake
    dp = {(1, 1, 1): 1}
    best_profile = {(1, 1, 1): [1]}

    for t in range(2, W + 1):
        ndp = {}
        nprof = {}
        t_odd = (t % 2 == 1)
        for (u, wk, wko), s in dp.items():
            lo = max(1, (u - 1 + 2) // 3)
            hi = min(cap[t], 3 * u + 1)
            for v in range(lo, hi + 1):
                m = u + v
                if t_odd:
                    if m % 4 not in (0, 1):
                        continue
                    r = (m + 1) // 2
                else:
                    if m % 4 not in (0, 3):
                        continue
                    r = m // 2
                if abs(u - v) > r:
                    continue
                nwk, nwko = wk, wko
                if m % 2:
                    nwk += 1
                    if t_odd:
                        nwko += 1
                    if nwk > 4 or nwko > 3:
                        continue
                key = (v, nwk, nwko)
                ns = s + v
                if key not in ndp or ns < ndp[key]:
                    ndp[key] = ns
                    if verbose:
                        nprof[key] = best_profile[(u, wk, wko)] + [v]
        dp = ndp
        best_profile = nprof
        if not dp:
            return (0, None, None)

    # close at level W+1 : m = f_W = 1, odd t (W+1 odd since W even), wake level
    results = []
    for (u, wk, wko), s in dp.items():
        if u != 1:
            continue
        m = u  # f_W + f_{W+1} = 1 + 0
        if m % 4 not in (0, 1):
            continue
        r = (m + 1) // 2
        if abs(u - 0) > r:
            continue
        nwk, nwko = wk + 1, wko + 1
        if nwk != 4 or nwko != 3:
            continue
        N = 2 * s
        if N % 4 != 2:
            continue
        results.append((N, best_profile.get((u, wk, wko))))
    if not results:
        return (0, None, None)
    results.sort()
    return (len(results), results[0][0], results[0][1])


def main() -> None:
    wmax = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    verbose = "-v" in sys.argv
    for W in range(2, wmax + 1, 2):
        out = solve(W, verbose=verbose)
        count, minN, prof = out
        if count == 0:
            print(f"W={W:3d}: INFEASIBLE")
        else:
            print(f"W={W:3d}: feasible, {count} accepting states, min N = {minN}"
                  + (f", profile f={prof}" if prof else ""))


if __name__ == "__main__":
    main()
