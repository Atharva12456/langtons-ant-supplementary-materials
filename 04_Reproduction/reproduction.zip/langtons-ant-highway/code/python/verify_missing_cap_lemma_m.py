"""Brute-force confirmation of the combinatorial Lemma M for all odd-row counts with
2<=b<=7 north arrivals, 2<=c<=6 west departures, both excesses: no R-first alternating word has
 (H2) N2 immediately after W2 with opposite turn, (H3) N2 is not W3, and
 (S)  W1=SR implies the next event is SL."""
import sys
sys.dont_write_bytecode = True
from verify_missing_cap_hand_words import words, pos, odd_counts
bad = 0; tested = 0
for b in range(2, 8):
    for c in range(2, 7):
        for om in (0, 1):
            for cnt in odd_counts(b, c, om):
                for w in words(cnt):
                    tested += 1
                    w1, w2, w3 = (pos(w, ('dep', 'W'), k) for k in (1, 2, 3))
                    n2 = pos(w, ('arr', 'N'), 2)
                    if n2 != w2 + 1 or w[w2][1] == w[n2][1]:
                        continue
                    if w3 is not None and n2 == w3:
                        continue
                    if w[w1] == 'SR' and (w1 + 1 >= len(w) or w[w1 + 1] != 'SL'):
                        continue
                    bad += 1; print('counterexample', b, c, om, w)
print('words tested', tested, 'words satisfying all hypotheses', bad)

if bad:
    raise AssertionError(f'{bad} counterexamples to Lemma M')
