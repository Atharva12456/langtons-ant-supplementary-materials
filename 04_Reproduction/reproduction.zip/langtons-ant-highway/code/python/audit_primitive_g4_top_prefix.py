#!/usr/bin/env python3
"""Exact symbolic audit of the top-rooted primitive-g4 exclusion.

The input is the analytic row-two normal form.  Parameters are never bounded:
leaf equations are solved over the integers, and every affine coordinate-order
cell on the resulting point or line is checked exactly.  The final large-cut
cases are discharged by the two parameter-free endpoint gaps used in the hand
proof.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
from itertools import combinations, permutations
import json
from pathlib import Path


Expr = tuple[int, int, int]  # alpha coefficient, beta coefficient, constant
Line = tuple[int, int]       # parameter coefficient, constant


ZERO: Expr = (0, 0, 0)
ALPHA: Expr = (1, 0, 0)
BETA: Expr = (0, 1, 0)


def const(value: int) -> Expr:
    return 0, 0, value


def sub(left: Expr, right: Expr) -> Expr:
    return tuple(a - b for a, b in zip(left, right))  # type: ignore[return-value]


def add(left: Expr, right: Expr) -> Expr:
    return tuple(a + b for a, b in zip(left, right))  # type: ignore[return-value]


def evaluate(expr: Expr, alpha: int, beta: int) -> int:
    return expr[0] * alpha + expr[1] * beta + expr[2]


def alternating(length: int) -> str:
    return "RL" * (length // 2) + ("R" if length & 1 else "")


def is_subsequence(fixed: str, target: str) -> bool:
    cursor = 0
    for symbol in fixed:
        cursor = target.find(symbol, cursor)
        if cursor < 0:
            return False
        cursor += 1
    return True


def extended_gcd(a: int, b: int) -> tuple[int, int, int]:
    if b == 0:
        sign = 1 if a >= 0 else -1
        return abs(a), sign, 0
    g, x, y = extended_gcd(b, a % b)
    return g, y, x - (a // b) * y


def ceil_div(numerator: int, denominator: int) -> int:
    return -((-numerator) // denominator)


def impose_lower(
    lower: int | None, upper: int | None, slope: int, intercept: int, bound: int
) -> tuple[int | None, int | None] | None:
    """Intersect slope*t+intercept >= bound with an integer interval."""
    rhs = bound - intercept
    if slope == 0:
        return (lower, upper) if rhs <= 0 else None
    if slope > 0:
        value = ceil_div(rhs, slope)
        lower = value if lower is None else max(lower, value)
    else:
        value = rhs // slope
        upper = value if upper is None else min(upper, value)
    if lower is not None and upper is not None and lower > upper:
        return None
    return lower, upper


def impose_upper(
    lower: int | None, upper: int | None, slope: int, intercept: int, bound: int
) -> tuple[int | None, int | None] | None:
    """Intersect slope*t+intercept <= bound with an integer interval."""
    return impose_lower(lower, upper, -slope, -intercept, -bound)


@dataclass(frozen=True)
class Domain:
    alpha_lower: int
    beta_upper: int | None = None


@dataclass(frozen=True)
class Form:
    name: str
    cuts: int
    q: tuple[Expr, ...]
    r: tuple[Expr, ...]
    domain: Domain

    @property
    def bases(self) -> tuple[Expr, ...]:
        return self.q[:-1] + self.r[:-1]

    @property
    def voltages(self) -> tuple[Expr, ...]:
        rows = (self.q, self.r)
        return tuple(sub(row[index + 1], row[index])
                     for row in rows for index in range(len(row) - 1))


@dataclass(frozen=True)
class ParametricSolution:
    alpha: Line
    beta: Line
    lower: int | None
    upper: int | None


def forms() -> tuple[Form, ...]:
    out: list[Form] = []
    for order in permutations((ALPHA, ZERO, const(-1))):
        out.append(Form("5a", 5, (const(-2), ZERO),
                        (const(-1),) + order + (ZERO,), Domain(1)))
    for order in permutations((ZERO, const(-1))):
        out.append(Form("5b", 5, (const(-2), ALPHA, ZERO),
                        (const(-1),) + order + (ZERO,), Domain(0)))

    for order in permutations((ALPHA, ZERO, const(-1), BETA)):
        out.append(Form("6a", 6, (const(-2), ZERO),
                        (const(-1),) + order + (ZERO,), Domain(1, -2)))
    for order in permutations((ZERO, const(-1), BETA)):
        out.append(Form("6b", 6, (const(-2), ALPHA, ZERO),
                        (const(-1),) + order + (ZERO,), Domain(0, -2)))
    for order in permutations((ALPHA, ZERO, const(-1))):
        out.append(Form("6c", 6, (const(-2), BETA, ZERO),
                        (const(-1),) + order + (ZERO,), Domain(1, -2)))
    for q_order in permutations((ALPHA, BETA)):
        for r_order in permutations((ZERO, const(-1))):
            out.append(Form("6d", 6, (const(-2),) + q_order + (ZERO,),
                            (const(-1),) + r_order + (ZERO,), Domain(0, -2)))
    return tuple(out)


def solve_leaf_equations(
    equations: tuple[Expr, ...], domain: Domain
) -> ParametricSolution | None:
    """Solve expr=1 over integers; all surviving systems have rank one or two."""
    rows: list[tuple[int, int, int]] = []
    for a, b, c in equations:
        row = a, b, 1 - c
        if a == b == 0:
            if row[2] != 0:
                return None
            continue
        if row not in rows:
            rows.append(row)
    if not rows:
        if domain.beta_upper is None:
            return ParametricSolution((1, 0), (0, 0), domain.alpha_lower, None)
        raise AssertionError("unexpected two-dimensional rank-zero leaf system")

    first = rows[0]
    independent = next(
        (row for row in rows[1:] if first[0] * row[1] != row[0] * first[1]),
        None,
    )
    if independent is not None:
        determinant = first[0] * independent[1] - independent[0] * first[1]
        alpha = Fraction(first[2] * independent[1] - independent[2] * first[1], determinant)
        beta = Fraction(first[0] * independent[2] - independent[0] * first[2], determinant)
        if alpha.denominator != 1 or beta.denominator != 1:
            return None
        a0, b0 = int(alpha), int(beta)
        if any(a * a0 + b * b0 != c for a, b, c in rows):
            return None
        if a0 < domain.alpha_lower:
            return None
        if domain.beta_upper is not None and b0 > domain.beta_upper:
            return None
        return ParametricSolution((0, a0), (0, b0), 0, 0)

    a, b, c = first
    g, x, y = extended_gcd(a, b)
    if c % g:
        return None
    scale = c // g
    alpha = (b // g, x * scale)
    beta = (-a // g, y * scale)
    if any(
        a1 * alpha[0] + b1 * beta[0] != 0
        or a1 * alpha[1] + b1 * beta[1] != c1
        for a1, b1, c1 in rows
    ):
        return None
    bounds = impose_lower(None, None, alpha[0], alpha[1], domain.alpha_lower)
    if bounds is None:
        return None
    lower, upper = bounds
    if domain.beta_upper is not None:
        bounds = impose_upper(lower, upper, beta[0], beta[1], domain.beta_upper)
        if bounds is None:
            return None
        lower, upper = bounds
    return ParametricSolution(alpha, beta, lower, upper)


def affine_equality_feasible(expr: Expr, value: int, domain: Domain) -> bool:
    """Whether expr=value has an integral solution in the form's domain."""
    shifted = add(expr, const(1 - value))
    if shifted == const(1):
        return True
    return solve_leaf_equations((shifted,), domain) is not None


def leaf_system_feasible(equations: tuple[Expr, ...], domain: Domain) -> bool:
    """Whether all listed voltage expressions can equal the leaf voltage +1."""
    nontrivial = tuple(expr for expr in equations if expr != const(1))
    if not nontrivial:
        return True
    return solve_leaf_equations(nontrivial, domain) is not None


def line(expr: Expr, solution: ParametricSolution) -> Line:
    return (
        expr[0] * solution.alpha[0] + expr[1] * solution.beta[0],
        expr[0] * solution.alpha[1] + expr[1] * solution.beta[1] + expr[2],
    )


def samples(lines: tuple[Line, ...], solution: ParametricSolution) -> tuple[int, ...]:
    roots: set[Fraction] = set()
    for left, right in combinations(lines, 2):
        slope = left[0] - right[0]
        if slope:
            for offset in (-1, 0, 1):
                roots.add(Fraction(right[1] - left[1] + offset, slope))
    candidates = {0}
    for root in roots:
        floor = root.numerator // root.denominator
        candidates.update((floor - 1, floor, floor + 1, floor + 2))
    ordered = sorted(roots)
    for left, right in zip(ordered, ordered[1:]):
        candidate = left.numerator // left.denominator + 1
        if left < candidate < right:
            candidates.add(candidate)
    if ordered:
        candidates.add(ordered[0].numerator // ordered[0].denominator - 2)
        candidates.add(ordered[-1].numerator // ordered[-1].denominator + 2)
    if solution.lower is not None:
        candidates.update((solution.lower, solution.lower + 1))
    if solution.upper is not None:
        candidates.update((solution.upper - 1, solution.upper))
    return tuple(sorted(
        value for value in candidates
        if (solution.lower is None or value >= solution.lower)
        and (solution.upper is None or value <= solution.upper)
    ))


def fixed_word(
    bases: tuple[int, ...], voltages: tuple[int, ...], leaves: frozenset[int]
) -> str:
    events: list[tuple[int, int, str]] = []
    for node, (base, voltage) in enumerate(zip(bases, voltages)):
        if node in leaves:
            events.append((base, 2 * node, "L"))
        else:
            events.append((base, 2 * node, "R"))
            events.append((base + voltage - 1, 2 * node + 1, "R"))
    return "".join(symbol for _x, _phase, symbol in sorted(
        events, key=lambda event: (-event[0], event[1])
    ))


def positive_compositions(total: int, parts: int):
    if parts == 1:
        yield (total,)
        return
    for first in range(1, total - parts + 2):
        for rest in positive_compositions(total - first, parts - 1):
            yield (first,) + rest


def interior_fits(
    phase: int, upper: tuple[int, int], lower: tuple[int, int] | None
) -> bool:
    """Whether an integer-coordinate event can lie in this stable-order gap."""
    upper_x, upper_phase = upper
    if lower is None:
        return True
    lower_x, lower_phase = lower
    if upper_x - lower_x >= 2:
        return True
    if upper_x - lower_x == 1:
        return phase > upper_phase or phase < lower_phase
    assert upper_x == lower_x and upper_phase < lower_phase
    return upper_phase < phase < lower_phase


def matching_exists(options: tuple[tuple[int, ...], ...], gaps: frozenset[int]) -> bool:
    if len(options) != len(gaps):
        return False
    ordered = sorted(
        (tuple(gap for gap in row if gap in gaps) for row in options),
        key=len,
    )
    matched: dict[int, int] = {}

    def place(event: int, seen: set[int]) -> bool:
        for gap in ordered[event]:
            if gap in seen:
                continue
            seen.add(gap)
            previous = matched.get(gap)
            if previous is None or place(previous, seen):
                matched[gap] = event
                return True
        return False

    return all(place(event, set()) for event in range(len(ordered)))


def exact_row_feasible(
    bases: tuple[int, ...], voltages: tuple[int, ...],
    leaves: frozenset[int], children: int,
) -> bool:
    """Place all omitted odd-row L events by exact integer gap matching."""
    support = tuple(index for index in range(len(bases)) if index not in leaves)
    for parts in positive_compositions(children, len(support)):
        degrees = [0] * len(bases)
        for index, degree in zip(support, parts):
            degrees[index] = degree
        phase = 0
        fixed_r: list[tuple[int, int]] = []
        fixed_l: list[tuple[int, int]] = []
        interior_phases: list[int] = []
        for node, (base, voltage, degree) in enumerate(zip(bases, voltages, degrees)):
            if degree == 0:
                fixed_l.append((base, phase))
                phase += 1
                continue
            fixed_r.append((base, phase))
            phase += 1
            for _ in range(degree - 1):
                interior_phases.append(phase)
                phase += 1
            fixed_r.append((base + voltage - 1, phase))
            phase += 1
        fixed_r.sort(key=lambda event: (-event[0], event[1]))
        l_count = len(fixed_l) + len(interior_phases)
        if l_count not in (len(fixed_r), len(fixed_r) - 1):
            raise AssertionError("turn count does not match an alternating row")
        gap_count = l_count
        occupied: set[int] = set()
        valid = True
        for event in fixed_l:
            key = (-event[0], event[1])
            before = sum((-x, p) < key for x, p in fixed_r)
            if before == 0:
                valid = False
                break
            gap = before - 1
            if gap >= gap_count or gap in occupied:
                valid = False
                break
            occupied.add(gap)
        if not valid:
            continue
        open_gaps = frozenset(set(range(gap_count)) - occupied)
        options = []
        for interior_phase in interior_phases:
            allowed = []
            for gap in open_gaps:
                lower = fixed_r[gap + 1] if gap + 1 < len(fixed_r) else None
                if interior_fits(interior_phase, fixed_r[gap], lower):
                    allowed.append(gap)
            options.append(tuple(allowed))
        if matching_exists(tuple(options), open_gaps):
            return True
    return False


def audit_case(all_forms: tuple[Form, ...], cuts: int, next_cuts: tuple[int, ...]):
    selected = tuple(form for form in all_forms if form.cuts == cuts)
    records = set()
    survivors = []
    for next_cut in next_cuts:
        nodes = cuts
        omega = (nodes + next_cut) & 1
        numerator = nodes + next_cut + omega  # row three is odd
        assert numerator % 4 == 0
        nonleaves = numerator // 4
        leaf_count = nodes - nonleaves
        for form in selected:
            for leaf_tuple in combinations(range(nodes), leaf_count):
                leaf_set = frozenset(leaf_tuple)
                solution = solve_leaf_equations(
                    tuple(form.voltages[index] for index in leaf_tuple), form.domain
                )
                if solution is None:
                    continue
                endpoints = tuple(
                    add(add(base, voltage), const(-1))
                    for base, voltage in zip(form.bases, form.voltages)
                )
                coordinate_lines = tuple(
                    line(expr, solution) for expr in form.bases + endpoints
                )
                for parameter in samples(coordinate_lines, solution):
                    alpha = solution.alpha[0] * parameter + solution.alpha[1]
                    beta = solution.beta[0] * parameter + solution.beta[1]
                    bases = tuple(evaluate(expr, alpha, beta) for expr in form.bases)
                    voltages = tuple(evaluate(expr, alpha, beta) for expr in form.voltages)
                    if any(voltages[index] != 1 for index in leaf_set):
                        raise AssertionError("leaf equation solver lost an equality")
                    word = fixed_word(bases, voltages, leaf_set)
                    record = (next_cut, bases, voltages, tuple(sorted(set(range(nodes)) - leaf_set)), word)
                    records.add(record)
                    if exact_row_feasible(bases, voltages, leaf_set, next_cut):
                        survivors.append((form.name, parameter, record))
    return records, survivors


def audit_large_six_node_cases(all_forms: tuple[Form, ...]) -> dict[str, object]:
    """Check the parameter-free U1/U2 obstructions after the six-node row.

    Node zero can never be a leaf.  If the last node is a nonleaf, its final R
    at x=-1 and node zero's first R at x=-2 leave no stable-order slot for an
    L (U1).  If both nodes at the Q/R block junction are nonleaves, their
    consecutive R anchors coincide at x=-1 (U2).
    """
    selected = tuple(form for form in all_forms if form.cuts == 6)
    assert len(selected) == 40
    count_table = {
        2: 2, 5: 3, 6: 3, 9: 4, 10: 4,
        13: 5, 14: 5, 17: 6, 18: 6,
    }
    for children, nonleaves in count_table.items():
        omega = (6 + children) & 1
        assert (6 + children + omega) // 4 == nonleaves

    two_leaf_families = []
    for form in selected:
        q_nodes = len(form.q) - 1
        junction_left = q_nodes - 1
        junction_right = q_nodes
        last = 5

        # The first node is nonleaf in every allowed parameter domain.
        assert not affine_equality_feasible(form.voltages[0], 1, form.domain)
        assert junction_right < last

        endpoint = lambda index: add(  # noqa: E731 - compact symbolic assertion
            add(form.bases[index], form.voltages[index]), const(-1)
        )
        assert form.bases[0] == const(-2)
        assert endpoint(last) == const(-1)       # U1, left stable anchor
        assert endpoint(junction_left) == const(-1)
        assert form.bases[junction_right] == const(-1)  # U2, right anchor

        # At f3=9 or 10 there are exactly two leaves.  U1 forces the last
        # node to be one leaf; U2 forces a junction node to be the other.
        # The left junction node cannot be a leaf in any normal form.
        assert not affine_equality_feasible(
            form.voltages[junction_left], 1, form.domain
        )
        forced_leaves = (junction_right, last)
        if not leaf_system_feasible(
            tuple(form.voltages[index] for index in forced_leaves), form.domain
        ):
            continue

        # Exactly six affine orders survive the leaf equations.  Both leaves
        # are at x=-1, and no fixed R anchor of an intervening nonleaf can tie
        # at x=-1.  They are therefore consecutive L turns in stable order.
        assert all(form.bases[index] == const(-1) for index in forced_leaves)
        for index in range(junction_right + 1, last):
            assert not affine_equality_feasible(form.bases[index], -1, form.domain)
            assert not affine_equality_feasible(endpoint(index), -1, form.domain)
        two_leaf_families.append((form.name, form.q, form.r, forced_leaves))

    assert len(two_leaf_families) == 6

    # At f3=13 or 14 there is one leaf.  U1 forces it to be node five, leaving
    # both distinct junction nodes nonleaf; U2 then contradicts alternation.
    # At f3=17 or 18 there are no leaves, so U1 applies immediately.
    return {
        "two_leaf_affine_orders": len(two_leaf_families),
        "excluded_next_cuts": [9, 10, 13, 14, 17, 18],
        "obstructions": ["U1_final_to_first_gap", "U2_block_junction_gap"],
    }


def main() -> None:
    all_forms = forms()
    assert sum(form.cuts == 5 for form in all_forms) == 8
    assert sum(form.cuts == 6 for form in all_forms) == 40

    five_next = (2, 3, 6, 7, 10, 11, 14, 15)
    five_records, five_survivors = audit_case(all_forms, 5, five_next)
    assert not five_survivors
    assert {
        (bases, voltages, support, word)
        for next_cut, bases, voltages, support, word in five_records
        if next_cut in (2, 3)
    } == {
        ((-2, -1, 0, 1, -1), (2, 1, 1, -2, 1), (0, 3), "RLRLLRR")
    }
    five_representative_counts = {
        next_cut: sum(row[0] == next_cut for row in five_records)
        for next_cut in five_next
    }
    assert five_representative_counts == {
        2: 1, 3: 1, 6: 12, 7: 12, 10: 41, 11: 41, 14: 34, 15: 34,
    }

    six_two_records, six_two_survivors = audit_case(all_forms, 6, (2,))
    assert not six_two_survivors
    assert {
        (bases, voltages, support, word)
        for _next, bases, voltages, support, word in six_two_records
    } == {
        ((-2, -1, 0, 1, -2, -1), (2, 1, 1, -3, 1, 1), (0, 3), "RLRLLRLR")
    }

    six_records, six_survivors = audit_case(all_forms, 6, (5, 6))
    assert not six_survivors
    assert {word for *_rest, word in six_records} == {
        "RLRLLRRRR",
        "RRRRLLRLR",
        "RLRRLRRLR",
        "RLRRRLRLR",
        "RLRLRRRLR",
    }

    large_cases = audit_large_six_node_cases(all_forms)

    headline = {
        "schema": "primitive-g4-top-tree-exclusion-v1",
        "row2_forms": {5: 8, 6: 40},
        "excluded_next_cuts": {
            5: list(five_next),
            6: [2, 5, 6] + large_cases["excluded_next_cuts"],
        },
        "order_cell_representatives_f2_5": five_representative_counts,
        "large_six_node_cases": large_cases,
        "claim": "primitive_diagonal_growth_four_excluded",
        "fixed_words": {
            "f2=6": sorted({row[-1] for row in six_two_records | six_records}),
        },
        "survivors": 0,
        "parameter_bound": None,
        "all_checks_passed": True,
    }
    root = Path(__file__).resolve().parents[2]
    certificate = json.loads(
        (root / "results" / "primitive_g4_top_prefix_certificate.json")
        .read_text(encoding="utf-8")
    )
    assert certificate["schema"] == headline["schema"]
    assert certificate["affine_form_counts"] == {
        "f2_is_5": 8,
        "f2_is_6": 40,
    }
    assert certificate["excluded_next_cuts"] == {
        "f2_is_5": list(five_next),
        "f2_is_6": [2, 5, 6, 9, 10, 13, 14, 17, 18],
    }
    assert certificate["order_cell_representatives_f2_is_5"] == {
        str(key): value for key, value in five_representative_counts.items()
    }
    assert certificate["claim"] == {
        "result": "primitive_diagonal_growth_four_excluded",
        "forced_prefix_before_contradiction": [1, 3, 6],
        "remaining_f3_values": [],
    }
    assert certificate["large_six_node_cases"] == large_cases
    assert certificate["fixed_words_f2_is_6"] == headline["fixed_words"]["f2=6"]
    assert certificate["parameter_bound"] is None
    assert certificate["survivors"] == 0
    expected_hash = certificate["files"][
        "code/python/audit_primitive_g4_top_prefix.py"
    ]
    actual_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert actual_hash == expected_hash
    print(headline)


if __name__ == "__main__":
    main()
