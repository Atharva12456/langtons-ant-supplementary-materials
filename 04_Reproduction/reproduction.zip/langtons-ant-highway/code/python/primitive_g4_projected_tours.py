#!/usr/bin/env python3
"""Bounded projected-tour audit for primitive-diagonal growth four.

The search deliberately forgets ordinary same-cell chronology.  It retains only
the transverse walk, endpoint ``(1,-1)``, growth four, the proved mod-four level
profile, and the lower half of stabilized chronology (all per-level prefix charges
are nonnegative).  A zero therefore excludes this weaker projected model only for
the requested widths and the explicit crossing cap ``f_c <= 3``.

For a fixed crossing profile, a positive transverse excursion is the contour of a
rooted plane tree whose number of vertices at depth ``c+1`` is ``f_c``.  Weak
compositions of successive level sizes enumerate those trees exactly once.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations, product


KNOWN = {
    4: (2, 24, 6, 1),
    6: (6, 360, 60, 0),
    8: (12, 3_888, 498, 0),
    10: (20, 37_584, 4_008, 0),
    12: (30, 347_976, 32_430, 0),
    14: (42, 3_166_776, 265_860, 0),
}


def weak_compositions(total: int, parts: int):
    if parts == 1:
        yield (total,)
        return
    for bars in combinations(range(total + parts - 1), parts - 1):
        points = (-1,) + bars + (total + parts - 1,)
        yield tuple(points[i + 1] - points[i] - 1 for i in range(parts))


def admissible_profiles(width: int):
    """Generate every weak f<=3 profile satisfying the proved level laws."""
    for middle in product((1, 2, 3), repeat=width - 2):
        profile = (1,) + middle + (1,)
        multiplicities = (
            (profile[0],)
            + tuple(profile[t - 1] + profile[t] for t in range(1, width))
            + (profile[-1],)
        )
        odd_levels: list[int] = []
        for level, count in enumerate(multiplicities):
            odd = count & 1
            required = odd if level % 2 == 0 else (-odd) % 4
            if count % 4 != required:
                break
            if odd:
                odd_levels.append(level)
        else:
            if len(odd_levels) == 4 and sum(t % 2 == 0 for t in odd_levels) == 3:
                yield profile


def transverse_steps(profile: tuple[int, ...], allocations) -> list[int]:
    children: list[list[tuple[int, ...]]] = []
    for counts in allocations:
        cursor = 0
        row: list[tuple[int, ...]] = []
        for count in counts:
            row.append(tuple(range(cursor, cursor + count)))
            cursor += count
        children.append(row)

    steps = [1]

    def visit(depth: int, node: int) -> None:
        if depth < len(children) + 1:
            for child in children[depth - 1][node]:
                steps.append(1)
                visit(depth + 1, child)
                steps.append(-1)

    visit(1, 0)
    steps.append(-1)
    return steps


def classify(steps: list[int]) -> tuple[bool, bool]:
    """Return (endpoint_and_growth, all_lower_prefixes_nonnegative)."""
    period = len(steps)
    x = y = 0
    xs: list[int] = []
    levels: list[int] = []
    turns: list[int] = []
    previous = steps[-1]
    for phase, step in enumerate(steps):
        xs.append(x)
        levels.append(x + y)
        right = (previous != step) if phase % 2 == 0 else (previous == step)
        turns.append(1 if right else -1)
        if phase % 2 == 0:
            y += step
        else:
            x += step
        previous = step
    if (x, y) != (1, -1) or sum(turns) != 4:
        return False, False

    by_level: dict[int, list[int]] = {}
    for phase, level in enumerate(levels):
        by_level.setdefault(level, []).append(phase)
    for phases in by_level.values():
        balance = 0
        for phase in sorted(phases, key=lambda i: (-xs[i], i)):
            balance += turns[phase]
            if balance < 0:
                return True, False
    return True, True


def audit_width(width: int) -> dict[str, int | str | bool]:
    profiles = tuple(admissible_profiles(width))
    raw = endpoint_growth = lower = 0
    endpoint_profiles = 0
    for profile in profiles:
        # The endpoint condition depends only on the profile.  Retain the count
        # explicitly, while still classifying every tree for an implementation
        # cross-check against the direct-walk verifier.
        if sum((1 if c % 2 == 0 else -1) * value for c, value in enumerate(profile)) == -1:
            endpoint_profiles += 1
        choices = [
            tuple(weak_compositions(profile[depth], profile[depth - 1]))
            for depth in range(1, width)
        ]
        for allocations in product(*choices):
            raw += 1
            endpoint_ok, lower_ok = classify(transverse_steps(profile, allocations))
            if endpoint_ok:
                endpoint_growth += 1
                lower += int(lower_ok)
    return {
        "schema": "langton-primitive-g4-projected-v1",
        "width": width,
        "crossing_cap": 3,
        "weak_profiles": len(profiles),
        "endpoint_profiles": endpoint_profiles,
        "raw_tours": raw,
        "endpoint_growth_tours": endpoint_growth,
        "lower_prefix_survivors": lower,
        "scope": "bounded_conditional_projected_model",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-width", type=int, default=4)
    parser.add_argument("--max-width", type=int, default=12)
    parser.add_argument("--assert-known", action="store_true")
    args = parser.parse_args()
    if args.min_width < 4 or args.min_width % 2 or args.max_width % 2:
        raise ValueError((args.min_width, args.max_width))
    for width in range(args.min_width, args.max_width + 1, 2):
        row = audit_width(width)
        if args.assert_known and width in KNOWN:
            expected = KNOWN[width]
            actual = (
                row["weak_profiles"], row["raw_tours"],
                row["endpoint_growth_tours"], row["lower_prefix_survivors"],
            )
            if actual != expected:
                raise AssertionError((width, actual, expected))
        print(json.dumps(row, sort_keys=True))


if __name__ == "__main__":
    main()
