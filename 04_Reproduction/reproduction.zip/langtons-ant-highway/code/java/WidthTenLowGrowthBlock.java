import java.util.Arrays;

/**
 * Memory-efficient research explorer for the exact-W=10 diagonal final-wake test.
 *
 * <p>This is a diagnostic, not a theorem certificate.  It explores the same
 * arbitrary-same-boundary-return relaxation as the Python block classifiers, for
 * t=x+y in {0,...,10}.  At every right exit it tests whether the settled block
 * mask is longitudinally periodic with period m and has fundamental-domain weight
 * g.  The target pairs are g=4 with m<=2 and g=8 with m<=4; g=12 rows are positive
 * controls.  A capped run is evidence only.  Even a complete zero would apply
 * only to diagonal highways confined to this full eleven-line strip; wider and
 * non-diagonal highways are outside the model.</p>
 */
public final class WidthTenLowGrowthBlock {
    private static final int TOP = 10;
    private static final int HEIGHT = 11;
    private static final int NORTH = 0, EAST = 1, SOUTH = 2, WEST = 3;
    private static final int[] RIGHT = {EAST, SOUTH, WEST, NORTH};
    private static final int[] LEFT = {WEST, NORTH, EAST, SOUTH};
    private static final int[] LEFT_ENTRIES = {2, 4, 6, 8, 10};
    private static final int[] RIGHT_ENTRIES = {0, 2, 4, 6, 8};

    private final int columns;
    private final int maxStates;
    private final StateSet seen;
    private final long[] queueLo;
    private final long[] queueHi;
    private final int[] queueMeta;
    private int stateCount;
    private int processed;

    private long transitions;
    private long terminalEvents;
    private long rejected;
    private long localLoops;
    private int maxVisits;
    private final long[][] compatible = new long[13][7];
    private final long[][] wakeFiltered = new long[13][7];

    private WidthTenLowGrowthBlock(int columns, int maxStates) {
        if (columns <= 0 || columns > 8) {
            throw new IllegalArgumentException(
                "columns must be at most 8: the packed extreme mask has 16 bits"
            );
        }
        this.columns = columns;
        this.maxStates = maxStates;
        this.seen = new StateSet(maxStates);
        this.queueLo = new long[maxStates];
        this.queueHi = new long[maxStates];
        this.queueMeta = new int[maxStates];
    }

    private static int meta(int extremes, int line, int heading) {
        return extremes | (line << 16) | (heading << 20);
    }

    private static int extremes(int meta) { return meta & 0xffff; }
    private static int line(int meta) { return (meta >>> 16) & 15; }
    private static int heading(int meta) { return (meta >>> 20) & 3; }

    private boolean add(long lo, long hi, int meta) {
        if (!seen.add(lo, hi, meta)) return true;
        if (stateCount >= maxStates) return false;
        queueLo[stateCount] = lo;
        queueHi[stateCount] = hi;
        queueMeta[stateCount] = meta;
        stateCount++;
        return true;
    }

    private boolean bit(long lo, long hi, int index) {
        return index < 64
            ? ((lo >>> index) & 1L) != 0
            : ((hi >>> (index - 64)) & 1L) != 0;
    }

    private Result advance(long lo, long hi, int extremeMask,
                           int column, int line, int heading) {
        long[] localLo = new long[256];
        long[] localHi = new long[256];
        int[] localRest = new int[256];
        int localSize = 0;
        int visits = 0;

        while (true) {
            int rest = extremeMask | (column << 16) | (line << 20) | (heading << 24);
            for (int i = 0; i < localSize; i++) {
                if (localLo[i] == lo && localHi[i] == hi && localRest[i] == rest) {
                    return Result.loop();
                }
            }
            if (localSize == localLo.length) {
                localLo = Arrays.copyOf(localLo, localSize * 2);
                localHi = Arrays.copyOf(localHi, localSize * 2);
                localRest = Arrays.copyOf(localRest, localSize * 2);
            }
            localLo[localSize] = lo;
            localHi[localSize] = hi;
            localRest[localSize] = rest;
            localSize++;

            int cell = HEIGHT * column + line;
            if (line == 0 || line == TOP) {
                int extremeBit = 1 << (2 * column + (line == TOP ? 1 : 0));
                if ((extremeMask & extremeBit) != 0) return Result.rejected();
                extremeMask |= extremeBit;
            }

            boolean wasBlack = bit(lo, hi, cell);
            if (cell < 64) lo ^= 1L << cell;
            else hi ^= 1L << (cell - 64);
            heading = wasBlack ? LEFT[heading] : RIGHT[heading];
            visits++;

            switch (heading) {
                case EAST -> { column++; line++; }
                case WEST -> { column--; line--; }
                case NORTH -> line++;
                case SOUTH -> line--;
                default -> throw new AssertionError(heading);
            }
            if (column < 0) return Result.exit(lo, hi, extremeMask, false, line, visits);
            if (column >= columns) return Result.exit(lo, hi, extremeMask, true, line, visits);
            if (line < 0 || line > TOP) throw new AssertionError("out of strip");
        }
    }

    private int periodicWeight(long lo, long hi, int period) {
        if (columns < 2 * period) return -1;
        for (int column = period; column < columns; column++) {
            for (int row = 0; row < HEIGHT; row++) {
                if (bit(lo, hi, HEIGHT * column + row)
                    != bit(lo, hi, HEIGHT * (column - period) + row)) return -1;
            }
        }
        int weight = 0;
        for (int column = 0; column < period; column++) {
            for (int row = 0; row < HEIGHT; row++) {
                if (bit(lo, hi, HEIGHT * column + row)) weight++;
            }
        }
        return weight;
    }

    /** Necessary extremal occupancy plus P16/P22 wake conditions. */
    private boolean wakeNecessary(long lo, long hi, int period, int growth) {
        if (periodicWeight(lo, hi, period) != growth) return false;
        boolean bottom = false, top = false;
        for (int column = 0; column < period; column++) {
            bottom |= bit(lo, hi, HEIGHT * column);
            top |= bit(lo, hi, HEIGHT * column + TOP);
        }
        if (!bottom || !top) return false;
        for (int coordinate = 0; coordinate < 2; coordinate++) {
            for (int residue = 0; residue < period; residue++) {
                int count = 0, signed = 0;
                for (int column = 0; column < period; column++) {
                    for (int line = 0; line < HEIGHT; line++) {
                        if (!bit(lo, hi, HEIGHT * column + line)) continue;
                        int value = coordinate == 0 ? column : line - column;
                        if (Math.floorMod(value, period) != residue) continue;
                        count++;
                        signed += (line & 1) == 0 ? 1 : -1;
                    }
                }
                if (count == 0 || (count & 1) != 0
                    || Math.floorMod(signed, 4) != 2) return false;
            }
        }
        return true;
    }

    private static String maskHex(long lo, long hi) {
        return String.format("0x%x%016x", hi, lo);
    }

    private boolean explore() {
        for (int entry : LEFT_ENTRIES) {
            if (!add(0, 0, meta(0, entry, EAST))) return false;
        }

        while (processed < stateCount) {
            long lo = queueLo[processed];
            long hi = queueHi[processed];
            int packed = queueMeta[processed++];
            int heading = heading(packed);
            int column = heading == EAST ? 0 : columns - 1;
            Result result = advance(
                lo, hi, extremes(packed), column, line(packed), heading
            );
            if (result.kind == 1) { rejected++; continue; }
            if (result.kind == 2) { localLoops++; continue; }
            maxVisits = Math.max(maxVisits, result.visits);

            int[] entries;
            int nextHeading;
            if (result.right) {
                terminalEvents++;
                for (int m = 1; m <= 6; m++) {
                    int weight = periodicWeight(result.lo, result.hi, m);
                    if ((weight == 4 && m <= 2)
                        || (weight == 8 && m <= 4)
                        || weight == 12) {
                        long prior = compatible[weight][m]++;
                        if (prior == 0) {
                            System.out.printf(
                                "first_compatible_terminal growth=%d period=%d event=%d%n",
                                weight, m, terminalEvents
                            );
                        }
                        if (wakeNecessary(result.lo, result.hi, m, weight)) {
                            long filteredPrior = wakeFiltered[weight][m]++;
                            if (filteredPrior == 0) {
                                System.out.printf(
                                    "first_wake_filtered_terminal growth=%d period=%d "
                                    + "event=%d mask=%s%n",
                                    weight, m, terminalEvents,
                                    maskHex(result.lo, result.hi)
                                );
                            }
                        }
                    }
                }
                entries = RIGHT_ENTRIES;
                nextHeading = WEST;
            } else {
                entries = LEFT_ENTRIES;
                nextHeading = EAST;
            }
            for (int entry : entries) {
                transitions++;
                if (!add(result.lo, result.hi,
                         meta(result.extremeMask, entry, nextHeading))) {
                    return false;
                }
            }
            if (stateCount % 1_000_000 < 5 && processed % 100_000 == 0) {
                System.err.printf("states=%d processed=%d terminals=%d%n",
                                  stateCount, processed, terminalEvents);
            }
        }
        return true;
    }

    private void report(boolean complete) {
        System.out.println("complete=" + complete);
        System.out.println("columns=" + columns);
        System.out.println("states=" + stateCount);
        System.out.println("processed=" + processed);
        System.out.println("transitions=" + transitions);
        System.out.println("terminal_events=" + terminalEvents);
        System.out.println("rejected=" + rejected);
        System.out.println("local_loops=" + localLoops);
        System.out.println("max_visits=" + maxVisits);
        for (int growth : new int[] {4, 8, 12}) {
            for (int period = 1; period < compatible[growth].length; period++) {
                if (compatible[growth][period] != 0 || growth < 12) {
                    System.out.printf("compatible_g%d_m%d=%d%n",
                                      growth, period, compatible[growth][period]);
                    System.out.printf("wake_filtered_g%d_m%d=%d%n",
                                      growth, period, wakeFiltered[growth][period]);
                }
            }
        }
    }

    public static void main(String[] args) {
        int columns = 8;
        int maxStates = 10_000_000;
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--columns" -> columns = Integer.parseInt(args[++i]);
                case "--max-states" -> maxStates = Integer.parseInt(args[++i]);
                default -> throw new IllegalArgumentException(args[i]);
            }
        }
        WidthTenLowGrowthBlock explorer = new WidthTenLowGrowthBlock(columns, maxStates);
        boolean complete = explorer.explore();
        explorer.report(complete);
    }

    private static final class Result {
        final int kind; // 0 exit, 1 rejected, 2 local loop
        final long lo, hi;
        final int extremeMask;
        final boolean right;
        final int landing, visits;

        private Result(int kind, long lo, long hi, int extremeMask,
                       boolean right, int landing, int visits) {
            this.kind = kind;
            this.lo = lo;
            this.hi = hi;
            this.extremeMask = extremeMask;
            this.right = right;
            this.landing = landing;
            this.visits = visits;
        }
        static Result rejected() { return new Result(1, 0, 0, 0, false, 0, 0); }
        static Result loop() { return new Result(2, 0, 0, 0, false, 0, 0); }
        static Result exit(long lo, long hi, int extremeMask,
                           boolean right, int landing, int visits) {
            return new Result(0, lo, hi, extremeMask, right, landing, visits);
        }
    }

    /** Open-addressed primitive triple set sized once to avoid resize peaks. */
    private static final class StateSet {
        private final long[] lo;
        private final long[] hi;
        private final int[] meta;
        private final byte[] used;
        private final int mask;

        StateSet(int maximumEntries) {
            long needed = Math.max(16L, (long) Math.ceil(maximumEntries / 0.68));
            int capacity = 1;
            while (capacity < needed) {
                if (capacity >= (1 << 30)) throw new IllegalArgumentException("too many states");
                capacity <<= 1;
            }
            lo = new long[capacity];
            hi = new long[capacity];
            meta = new int[capacity];
            used = new byte[capacity];
            mask = capacity - 1;
        }

        boolean add(long a, long b, int c) {
            int slot = (int) mix(a ^ Long.rotateLeft(b, 23) ^ ((long) c << 32)) & mask;
            while (used[slot] != 0) {
                if (lo[slot] == a && hi[slot] == b && meta[slot] == c) return false;
                slot = (slot + 1) & mask;
            }
            used[slot] = 1;
            lo[slot] = a;
            hi[slot] = b;
            meta[slot] = c;
            return true;
        }

        private static long mix(long z) {
            z = (z ^ (z >>> 30)) * 0xbf58476d1ce4e5b9L;
            z = (z ^ (z >>> 27)) * 0x94d049bb133111ebL;
            return z ^ (z >>> 31);
        }
    }
}
