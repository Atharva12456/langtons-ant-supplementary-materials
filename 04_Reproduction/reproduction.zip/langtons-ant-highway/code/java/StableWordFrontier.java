import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * Exhaustive finite-prefix frontier for stable words at drift (1,-3).
 *
 * Ports: 0=ER 1=EL 2=WR 3=WL 4=NR 5=NL 6=SR 7=SL (even code = right turn).
 * Arrival heading: E,E,W,W,N,N,S,S.  Departure heading: S,N,N,S,E,W,W,E.
 * Headings: 0=E 1=W 2=N 3=S. Level shift E+3 W-3 N+1 S-1. Voltage E+1 W-1.
 * Clock: tau(target) = tau(source) + 1 + SIGN*N*voltage, N >= NMIN, same-row gaps >= 4.
 */
public class StableWordFrontier {
    static final String[] NAME = {"ER", "EL", "WR", "WL", "NR", "NL", "SR", "SL"};
    static final int[] HEAD = {0, 0, 1, 1, 2, 2, 3, 3};
    static final int[] OUT = {3, 2, 2, 3, 0, 1, 1, 0};
    static final int[] SHIFT = {3, -3, 1, -1};
    static final int[] VOLT = {1, -1, 0, 0};

    static int SIGN = -1;
    static long NMIN = 6;
    static boolean EXTRAP = true;
    static boolean STRONG = false;
    static boolean CYCLE = false;
    static final AtomicLong CYCLE_REJ = new AtomicLong();
    static final AtomicLong RESIDUE_REJ = new AtomicLong();
    static WakeRule RULE;

    // ------------------------------------------------------------ wake rules
    interface WakeRule { boolean ok(int[] wakeLevels, int n, int t); }

    static class P22Rule implements WakeRule {
        public boolean ok(int[] lv, int n, int t) {
            if (n > 8) return false;
            int[][] f = new int[3][2];
            for (int i = 0; i < n; i++) f[lv[i] % 3][lv[i] % 2]++;
            for (int big = 0; big < 3; big++) {
                boolean good = true;
                for (int r = 0; r < 3 && good; r++) {
                    int e = f[r][0], o = f[r][1];
                    if (r == big) {
                        if (e + o > 4 || e > 3 || o > 3 || (e + o == 4 && !(e == 1 || e == 3))) good = false;
                    } else if (e + o > 2 || (e > 0 && o > 0)) good = false;
                }
                if (good) return true;
            }
            return false;
        }
    }

    /** Allowed wake prefixes: a list of complete allowed wake sets; prefix (levels <= t) must match one. */
    static class SetRule implements WakeRule {
        final List<int[]> sets = new ArrayList<>();
        final P22Rule p22 = new P22Rule();
        final ConcurrentHashMap<Integer, Set<String>> cache = new ConcurrentHashMap<>();
        SetRule(Path file) throws IOException {
            for (String line : Files.readAllLines(file)) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] tok = line.split("[ ,]+");
                int[] s = new int[tok.length];
                for (int i = 0; i < tok.length; i++) s[i] = Integer.parseInt(tok[i]);
                Arrays.sort(s);
                sets.add(s);
            }
        }
        static String key(int[] lv, int n, int t) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < n; i++) if (lv[i] <= t) b.append(lv[i]).append(',');
            return b.toString();
        }
        Set<String> prefixes(int t) {
            return cache.computeIfAbsent(t, tt -> {
                Set<String> h = new HashSet<>();
                for (int[] s : sets) h.add(key(s, s.length, tt));
                return h;
            });
        }
        public boolean ok(int[] lv, int n, int t) {
            if (!p22.ok(lv, n, t)) return false;
            int[] sorted = Arrays.copyOf(lv, n);
            Arrays.sort(sorted);
            return prefixes(t).contains(key(sorted, n, t));
        }
    }

    // ----------------------------------------------------------------- state
    static final class State {
        final byte[][] rows;
        State(byte[][] r) { rows = r; }
        int top() { return rows.length - 1; }
    }

    static String fmt(State s) {
        StringBuilder b = new StringBuilder();
        for (int t = 0; t < s.rows.length; t++) {
            if (t > 0) b.append('|');
            for (int i = 0; i < s.rows[t].length; i++) {
                if (i > 0) b.append(',');
                b.append(NAME[s.rows[t][i]]);
            }
        }
        return b.toString();
    }

    static State parse(String line) {
        String[] parts = line.trim().split("\\|", -1);
        byte[][] rows = new byte[parts.length][];
        for (int t = 0; t < parts.length; t++) {
            if (parts[t].isEmpty()) { rows[t] = new byte[0]; continue; }
            String[] tok = parts[t].split(",");
            rows[t] = new byte[tok.length];
            for (int i = 0; i < tok.length; i++) rows[t][i] = (byte) Arrays.asList(NAME).indexOf(tok[i]);
        }
        return new State(rows);
    }

    // ---------------------------------------------------------------- counts
    static List<int[]> rowCounts(byte[][] rows, int t, int wake) {
        List<int[]> out = new ArrayList<>();
        int a = 0, b = 0, c = 0, d = 0;
        if (t - 3 >= 0) for (byte p : rows[t - 3]) { if (OUT[p] == 0) a++; if (HEAD[p] == 1) c++; }
        if (t - 1 >= 0) for (byte p : rows[t - 1]) { if (OUT[p] == 2) b++; if (HEAD[p] == 3) d++; }
        if (t % 2 == 0) {
            if (b != 0 || c != 0) return out;
            for (int er = 0; er <= Math.min(a, d); er++) {
                int wr = wake + a + d - 3 * er;
                if (wr < 0) continue;
                out.add(new int[]{er, a - er, wr, d - er, 0, 0, 0, 0});
            }
        } else {
            if (a != 0 || d != 0) return out;
            for (int nl = 0; nl <= Math.min(b, c); nl++) {
                int sl = b + c - 3 * nl - wake;
                if (sl < 0) continue;
                out.add(new int[]{0, 0, 0, 0, b - nl, nl, c - nl, sl});
            }
        }
        return out;
    }

    // ------------------------------------------------------ successor arrays
    /** succ[t][i] = packed (u, j, v) or -1 if the target row is not built. Returns null on ordinal overflow. */
    static int[][][] successors(byte[][] rows) {
        int L = rows.length;
        // arrivals by heading per row
        int[][][] arr = new int[L][4][];
        for (int t = 0; t < L; t++) {
            int[] cnt = new int[4];
            for (byte p : rows[t]) cnt[HEAD[p]]++;
            for (int h = 0; h < 4; h++) arr[t][h] = new int[cnt[h]];
            int[] k = new int[4];
            for (int i = 0; i < rows[t].length; i++) { int h = HEAD[rows[t][i]]; arr[t][h][k[h]++] = i; }
        }
        int[][][] succ = new int[L][][];
        for (int t = 0; t < L; t++) {
            succ[t] = new int[rows[t].length][];
            int[] dep = new int[4];
            for (int i = 0; i < rows[t].length; i++) {
                int h = OUT[rows[t][i]];
                int k = dep[h]++;
                int u = t + SHIFT[h];
                if (u < 0 || u >= L) { succ[t][i] = null; continue; }
                if (k >= arr[u][h].length) return null;
                succ[t][i] = new int[]{u, arr[u][h][k], VOLT[h]};
            }
        }
        return succ;
    }

    // ---------------------------------------------------- first-return test
    static boolean badReturn(byte[][] rows, int[][][] succ) {
        int L = rows.length;
        int total = 0;
        int[] base = new int[L];
        for (int t = 0; t < L; t++) { base[t] = total; total += rows[t].length; }
        int[] levelOf = new int[total], indexOf = new int[total];
        for (int t = 0; t < L; t++) for (int i = 0; i < rows[t].length; i++) { levelOf[base[t] + i] = t; indexOf[base[t] + i] = i; }
        int[] seenStep = new int[total];
        long[] seenCopy = new long[total];
        int[] mark = new int[total];
        int stamp = 0;
        int[] trNode = new int[total + 1], trStep = new int[total + 1];
        long[] trCopy = new long[total + 1];
        for (int t = 0; t < L; t++) {
            for (int i = 0; i < rows[t].length; i++) {
                stamp++;
                int ct = t, ci = i; long copy = 0; int step = 0, ntr = 0;
                while (true) {
                    int[] s = succ[ct][ci];
                    if (s == null) break;
                    int u = s[0], j = s[1];
                    long ncopy = copy + s[2];
                    int nstep = step + 1;
                    if (u == t && ncopy == 0) {
                        if (j != i + 1) return true;
                        break;
                    }
                    int id = base[u] + j;
                    if (mark[id] == stamp) {
                        if (!EXTRAP) break;
                        int ostep = seenStep[id];
                        long ocopy = seenCopy[id];
                        int clen = nstep - ostep;
                        long cvol = ncopy - ocopy;
                        if (cvol != 0) {
                            long bestStep = Long.MAX_VALUE; int bestIdx = -1;
                            for (int q = 0; q < ntr; q++) {
                                if (trStep[q] < ostep) continue;
                                int nd = trNode[q];
                                if (levelOf[nd] != t) continue;
                                long k = trCopy[q];
                                if (Math.floorMod(-k, cvol) == 0) {
                                    long laps = Math.floorDiv(-k, cvol);
                                    long st = trStep[q] + laps * clen;
                                    if (laps >= 0 && st > 0 && st < bestStep) { bestStep = st; bestIdx = indexOf[nd]; }
                                }
                            }
                            if (bestIdx >= 0 && bestIdx != i + 1) return true;
                        }
                        break;
                    }
                    mark[id] = stamp; seenStep[id] = nstep; seenCopy[id] = ncopy;
                    trNode[ntr] = id; trStep[ntr] = nstep; trCopy[ntr] = ncopy; ntr++;
                    ct = u; ci = j; copy = ncopy; step = nstep;
                }
            }
        }
        return false;
    }


    /** The successor map over one period is a single cycle through every event with lower-cap voltage +1.
     *  Hence a closed cycle inside a prefix must contain every event of the prefix, have no upward
     *  departure anywhere, and carry voltage SIGN==-1 ? +1 : -1. */
    static boolean closedCycleBad(byte[][] rows, int[][][] succ) {
        int L = rows.length, total = 0;
        int[] base = new int[L];
        for (int t = 0; t < L; t++) { base[t] = total; total += rows[t].length; }
        int[] color = new int[total];
        for (int t = 0; t < L; t++) for (int i = 0; i < rows[t].length; i++) {
            int id = base[t] + i;
            if (color[id] != 0) continue;
            ArrayList<Integer> path = new ArrayList<>();
            int ct = t, ci = i, cid = id;
            while (true) {
                if (color[cid] == 2) break;
                if (color[cid] == 1) {
                    // closed cycle found starting at cid
                    int len = 0; long vol = 0; int x = cid, xt = -1, xi = -1;
                    // walk the cycle
                    int wt = -1, wi = -1;
                    for (int q = path.indexOf(cid); q < path.size(); q++) {
                        int nd = path.get(q);
                        int lt = 0; while (lt + 1 < L && base[lt + 1] <= nd) { if (rows[lt + 1].length == 0 && base[lt + 1] == nd) { lt++; continue; } lt++; }
                        // decode level robustly
                        int lv = -1;
                        for (int u = 0; u < L; u++) if (nd >= base[u] && nd < base[u] + rows[u].length) { lv = u; break; }
                        int ix = nd - base[lv];
                        vol += succ[lv][ix][2];
                        len++;
                    }
                    if (len != total) return true;
                    long want = (SIGN == -1) ? 1 : -1;
                    if (vol != want) return true;
                    break;
                }
                color[cid] = 1; path.add(cid);
                int[] s = succ[ct][ci];
                if (s == null) break;
                ct = s[0]; ci = s[1]; cid = base[ct] + ci;
            }
            for (int v : path) color[v] = 2;
        }
        return false;
    }

    // ----------------------------------------------- parametric clock (exact)
    /** Constraints T_v >= T_u + A + B*N. Feasible iff some integer N >= NMIN has no positive cycle. */
    static boolean clockOk(byte[][] rows, int[][][] succ) {
        int L = rows.length;
        int total = 0;
        int[] base = new int[L];
        for (int t = 0; t < L; t++) { base[t] = total; total += rows[t].length; }
        ArrayList<long[]> edges = new ArrayList<>();
        for (int t = 0; t < L; t++) {
            for (int i = 0; i < rows[t].length; i++) {
                int[] s = succ[t][i];
                if (s != null) {
                    int a = base[t] + i, b = base[s[0]] + s[1];
                    long B = (long) SIGN * s[2];
                    edges.add(new long[]{a, b, 1, B});      // T_b >= T_a + 1 + B N
                    edges.add(new long[]{b, a, -1, -B});    // T_a >= T_b - 1 - B N
                }
                if (i + 1 < rows[t].length) edges.add(new long[]{base[t] + i, base[t] + i + 1, 4, 0});
            }
        }
        long N = NMIN;
        int V = total;
        long[] dist = new long[V];
        int[] pred = new int[V];
        for (int iter = 0; iter < 100000; iter++) {
            Arrays.fill(dist, 0);
            Arrays.fill(pred, -1);
            int last = -1;
            for (int round = 0; round < V; round++) {
                last = -1;
                for (int e = 0; e < edges.size(); e++) {
                    long[] ed = edges.get(e);
                    int u = (int) ed[0], v = (int) ed[1];
                    long w = ed[2] + ed[3] * N;
                    if (dist[u] + w > dist[v]) { dist[v] = dist[u] + w; pred[v] = e; last = v; }
                }
                if (last < 0) break;
            }
            if (last < 0) return true;
            // extract a positive cycle from the predecessor graph
            long[] AB = findCycle(pred, edges, V);
            if (AB == null) throw new IllegalStateException("no cycle in predecessor graph");
            long A = AB[0], B = AB[1];
            if (A + B * N <= 0) throw new IllegalStateException("extracted cycle not positive");
            if (B >= 0) return false;
            // A + B*N <= 0 with B < 0  <=>  N >= A/(-B)  <=>  N >= ceil(A/(-B))
            long need = -Math.floorDiv(-A, -B);
            if (need <= N) throw new IllegalStateException("no progress");
            N = need;
        }
        throw new IllegalStateException("clock iteration limit");
    }


    static long[] findCycle(int[] pred, ArrayList<long[]> edges, int V) {
        int[] color = new int[V];
        for (int s0 = 0; s0 < V; s0++) {
            if (color[s0] != 0) continue;
            int x = s0;
            ArrayList<Integer> path = new ArrayList<>();
            while (x >= 0 && color[x] == 0) { color[x] = 1; path.add(x); x = pred[x] < 0 ? -1 : (int) edges.get(pred[x])[0]; }
            if (x >= 0 && color[x] == 1) {
                long A = 0, B = 0; int y = x;
                do { long[] ed = edges.get(pred[y]); A += ed[2]; B += ed[3]; y = (int) ed[0]; } while (y != x);
                return new long[]{A, B};
            }
            for (int v : path) color[v] = 2;
        }
        return null;
    }


    /**
     * Strong clock: same-row gaps are positive multiples of 4, N = 2 (mod 4), N >= number of events.
     * Row residues c_t (mod 4) must satisfy c_target - c_source = 1 + 2v (mod 4).  With T = 4S + c and
     * N = 4K + 2 the system is again a parametric difference system in S with parameter K.
     */
    static boolean strongClockOk(byte[][] rows, int[][][] succ) {
        int L = rows.length;
        // union-find with offsets mod 4 over rows
        int[] par = new int[L], off = new int[L];
        for (int t = 0; t < L; t++) { par[t] = t; off[t] = 0; }
        int total = 0;
        int[] base = new int[L];
        for (int t = 0; t < L; t++) { base[t] = total; total += rows[t].length; }
        for (int t = 0; t < L; t++) for (int i = 0; i < rows[t].length; i++) {
            int[] s = succ[t][i];
            if (s == null) continue;
            int d = Math.floorMod(1 + 2 * s[2], 4); // c_u - c_t
            int ra = t, oa = 0; while (par[ra] != ra) { oa += off[ra]; ra = par[ra]; }
            int rb = s[0], ob = 0; while (par[rb] != rb) { ob += off[rb]; rb = par[rb]; }
            // c_t = c_ra + oa ; c_u = c_rb + ob
            if (ra == rb) { if (Math.floorMod(ob - oa - d, 4) != 0) { RESIDUE_REJ.incrementAndGet(); return false; } }
            else { par[rb] = ra; off[rb] = Math.floorMod(oa + d - ob, 4); }
        }
        int[] c = new int[L];
        for (int t = 0; t < L; t++) { int r = t, o = 0; while (par[r] != r) { o += off[r]; r = par[r]; } c[t] = Math.floorMod(o, 4); }
        ArrayList<long[]> edges = new ArrayList<>();
        for (int t = 0; t < L; t++) for (int i = 0; i < rows[t].length; i++) {
            int[] s = succ[t][i];
            if (s != null) {
                int a = base[t] + i, b = base[s[0]] + s[1];
                long num = 1 + 2L * SIGN * s[2] - c[s[0]] + c[t];
                if (Math.floorMod(num, 4) != 0) throw new IllegalStateException("residue bookkeeping");
                long A = num / 4, B = (long) SIGN * s[2];
                edges.add(new long[]{a, b, A, B});
                edges.add(new long[]{b, a, -A, -B});
            }
            if (i + 1 < rows[t].length) edges.add(new long[]{base[t] + i, base[t] + i + 1, 1, 0});
        }
        long nmin = Math.max(NMIN, total);
        long K = -Math.floorDiv(-(nmin - 2), 4);
        return paramFeasible(edges, total, K);
    }

    static boolean paramFeasible(ArrayList<long[]> edges, int V, long N0) {
        long N = N0;
        long[] dist = new long[V];
        int[] pred = new int[V];
        for (int iter = 0; iter < 100000; iter++) {
            Arrays.fill(dist, 0);
            Arrays.fill(pred, -1);
            int last = -1;
            for (int round = 0; round < V; round++) {
                last = -1;
                for (int e = 0; e < edges.size(); e++) {
                    long[] ed = edges.get(e);
                    int u = (int) ed[0], v = (int) ed[1];
                    long w = ed[2] + ed[3] * N;
                    if (dist[u] + w > dist[v]) { dist[v] = dist[u] + w; pred[v] = e; last = v; }
                }
                if (last < 0) break;
            }
            if (last < 0) return true;
            long[] AB = findCycle(pred, edges, V);
            if (AB == null) throw new IllegalStateException("no cycle in predecessor graph");
            long A = AB[0], B = AB[1];
            if (A + B * N <= 0) throw new IllegalStateException("extracted cycle not positive");
            if (B >= 0) return false;
            long need = -Math.floorDiv(-A, -B);
            if (need <= N) throw new IllegalStateException("no progress");
            N = need;
        }
        throw new IllegalStateException("clock iteration limit");
    }

    // ------------------------------------------------- word generation (DFS)
    static int[] boundaryReturn(byte[][] old, int newT, int port, int outOrd) {
        // returns {head, ordinal, copy} or null (unknown) ; {-1} means BAD
        int h = OUT[port];
        int u = newT + SHIFT[h];
        if (u < 0 || u >= old.length || u == newT) return null;
        int[] arrIdx = arrivals(old[u], h);
        if (outOrd >= arrIdx.length) return new int[]{-1};
        int qt = u, qi = arrIdx[outOrd];
        long copy = VOLT[h];
        HashSet<Long> seen = new HashSet<>();
        while (seen.add(((long) qt << 32) | qi)) {
            int p = old[qt][qi];
            int hh = OUT[p];
            int nt = qt + SHIFT[hh];
            int k = 0;
            for (int x = 0; x <= qi; x++) if (OUT[old[qt][x]] == hh) k++;
            k--;
            long ncopy = copy + VOLT[hh];
            if (nt == newT) return new int[]{HEAD_OF_ARRIVAL(hh), k, (int) ncopy};
            if (nt < 0 || nt >= old.length) return null;
            int[] a2 = arrivals(old[nt], hh);
            if (k >= a2.length) return new int[]{-1};
            qt = nt; qi = a2[k]; copy = ncopy;
        }
        return null;
    }
    static int HEAD_OF_ARRIVAL(int dirHeading) { return dirHeading; }

    static int[] arrivals(byte[] row, int h) {
        int n = 0;
        for (byte p : row) if (HEAD[p] == h) n++;
        int[] r = new int[n];
        n = 0;
        for (int i = 0; i < row.length; i++) if (HEAD[row[i]] == h) r[n++] = i;
        return r;
    }

    interface WordSink { void accept(byte[] w); }

    static void words(byte[][] old, int t, int[] counts, WordSink sink) {
        // old has length t (levels 0..t-1)
        int[] choices = new int[8]; int nc = 0;
        for (int p = 0; p < 8; p++) if (counts[p] > 0) choices[nc++] = p;
        int[] depTot = new int[4];
        for (int x = 0; x < nc; x++) depTot[OUT[choices[x]]] += counts[choices[x]];
        int[][][] arcs = new int[8][][];
        for (int x = 0; x < nc; x++) {
            int p = choices[x];
            int n = depTot[OUT[p]];
            arcs[p] = new int[n][];
            for (int i = 0; i < n; i++) arcs[p][i] = boundaryReturn(old, t, p, i);
        }
        int length = 0;
        for (int p = 0; p < 8; p++) length += counts[p];
        int[] rem = counts.clone();
        byte[] seq = new byte[length];
        int[] usedIn = new int[4], usedOut = new int[4];
        dfs(0, length, -1, -1, choices, nc, rem, seq, usedIn, usedOut, arcs, sink);
    }

    static void dfs(int i, int length, int reqHead, int reqOrd, int[] choices, int nc, int[] rem, byte[] seq,
                    int[] usedIn, int[] usedOut, int[][][] arcs, WordSink sink) {
        if (i == length) { if (reqHead < 0) sink.accept(seq.clone()); return; }
        boolean right = (i % 2 == 0);
        for (int x = 0; x < nc; x++) {
            int p = choices[x];
            if (rem[p] == 0 || ((p % 2 == 0) != right)) continue;
            int head = HEAD[p], h = OUT[p];
            if (reqHead >= 0 && (head != reqHead || usedIn[head] != reqOrd)) continue;
            int[] arc = arcs[p][usedOut[h]];
            if (arc != null && arc[0] == -1 && arc.length == 1) continue;
            rem[p]--; usedIn[head]++; usedOut[h]++; seq[i] = (byte) p;
            int nh = -1, no = -1; boolean ok = true;
            if (arc != null && arc.length == 3 && arc[2] == 0) {
                nh = arc[0]; no = arc[1];
                if (no < usedIn[nh]) ok = false;
            }
            if (ok) dfs(i + 1, length, nh, no, choices, nc, rem, seq, usedIn, usedOut, arcs, sink);
            usedOut[h]--; usedIn[head]--; rem[p]++;
        }
    }

    // --------------------------------------------------------------- expand
    static final class Stats {
        final AtomicLong countRows = new AtomicLong(), words = new AtomicLong(), ordinalBad = new AtomicLong(),
                ret = new AtomicLong(), clock = new AtomicLong(), surv = new AtomicLong(), ruleSkip = new AtomicLong();
        public String toString() {
            return String.format("count_rows=%d words=%d ordinal_bad=%d return_rejected=%d clock_rejected=%d rule_skip=%d survivors=%d",
                    countRows.get(), words.get(), ordinalBad.get(), ret.get(), clock.get(), ruleSkip.get(), surv.get());
        }
    }

    static int[] wakeLevels(byte[][] rows, int extraLevel, int extraWake, int[] outN) {
        int[] lv = new int[rows.length + 1]; int n = 0;
        for (int t = 0; t < rows.length; t++) if (rows[t].length % 2 == 1) lv[n++] = t;
        if (extraWake == 1) lv[n++] = extraLevel;
        outN[0] = n;
        return lv;
    }

    static void expand(State s, int t, Integer forced, Stats st, ConcurrentLinkedQueue<State> out) {
        byte[][] rows = s.rows;
        for (int wake = 0; wake <= 1; wake++) {
            if (forced != null && forced != wake) continue;
            int[] nn = new int[1];
            int[] lv = wakeLevels(rows, t, wake, nn);
            boolean ok = RULE.ok(lv, nn[0], t);
            if (!ok) { st.ruleSkip.incrementAndGet(); continue; }
            for (int[] cnt : rowCounts(rows, t, wake)) {
                st.countRows.incrementAndGet();
                words(rows, t, cnt, w -> {
                    st.words.incrementAndGet();
                    byte[][] child = Arrays.copyOf(rows, t + 1);
                    child[t] = w;
                    int[][][] succ = successors(child);
                    if (succ == null) { st.ordinalBad.incrementAndGet(); return; }
                    if (badReturn(child, succ)) { st.ret.incrementAndGet(); return; }
                    if (CYCLE && closedCycleBad(child, succ)) { CYCLE_REJ.incrementAndGet(); st.ret.incrementAndGet(); return; }
                    if (!clockOk(child, succ) || (STRONG && !strongClockOk(child, succ))) { st.clock.incrementAndGet(); return; }
                    st.surv.incrementAndGet();
                    out.add(new State(child));
                });
            }
        }
    }

    public static void main(String[] args) throws Exception {
        String seedFile = null, rule = "p22", outPrefix = "frontier";
        int depth = 10, threads = Runtime.getRuntime().availableProcessors();
        Map<Integer, Integer> forced = new HashMap<>();
        for (int k = 0; k < args.length; k++) {
            switch (args[k]) {
                case "--seed": seedFile = args[++k]; break;
                case "--depth": depth = Integer.parseInt(args[++k]); break;
                case "--sign": SIGN = Integer.parseInt(args[++k]); break;
                case "--nmin": NMIN = Long.parseLong(args[++k]); break;
                case "--threads": threads = Integer.parseInt(args[++k]); break;
                case "--rule": rule = args[++k]; break;
                case "--out": outPrefix = args[++k]; break;
                case "--noextrap": EXTRAP = false; break;
                case "--strong": STRONG = true; break;
                case "--cycle": CYCLE = true; break;
                case "--wake": { String[] kv = args[++k].split("="); forced.put(Integer.parseInt(kv[0]), Integer.parseInt(kv[1])); break; }
                default: throw new IllegalArgumentException(args[k]);
            }
        }
        RULE = rule.equals("p22") ? new P22Rule() : rule.equals("none") ? (WakeRule) ((lv, n, tt) -> true) : new SetRule(Paths.get(rule));
        List<State> states = new ArrayList<>();
        for (String line : Files.readAllLines(Paths.get(seedFile))) if (!line.trim().isEmpty() && !line.startsWith("#")) states.add(parse(line));
        for (State s : states) {
            int[][][] succ = successors(s.rows);
            if (succ == null || badReturn(s.rows, succ) || !clockOk(s.rows, succ)) throw new IllegalStateException("bad seed " + fmt(s));
        }
        int start = states.get(0).rows.length;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        long t0 = System.currentTimeMillis();
        for (int t = start; t <= depth && !states.isEmpty(); t++) {
            final int tt = t;
            Stats st = new Stats();
            ConcurrentLinkedQueue<State> out = new ConcurrentLinkedQueue<>();
            List<Future<?>> fs = new ArrayList<>();
            Integer fw = forced.get(t);
            for (State s : states) fs.add(pool.submit(() -> expand(s, tt, fw, st, out)));
            for (Future<?> f : fs) f.get();
            List<State> next = new ArrayList<>(out);
            next.sort(Comparator.comparing(StableWordFrontier::fmt));
            states = next;
            System.out.printf("level=%d %s residue_rej=%d cycle_rej=%d frontier=%d seconds=%.1f%n", t, st, RESIDUE_REJ.getAndSet(0), CYCLE_REJ.getAndSet(0), states.size(), (System.currentTimeMillis() - t0) / 1000.0);
            System.out.flush();
            try (PrintWriter pw = new PrintWriter(new FileWriter(outPrefix + "_L" + t + ".txt"))) {
                for (State s : states) pw.println(fmt(s));
            }
        }
        pool.shutdown();
    }
}
