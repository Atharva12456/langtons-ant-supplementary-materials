"""Exact finite examples used by the selected full-proof paper."""
from pathlib import Path
import importlib.util, json

base=Path(__file__).resolve().parent
repo=base.parents[1]
helper=base/'verify_nomonotone.py'
if not helper.exists(): helper=repo/'code/python/verify_nomonotone.py'
spec=importlib.util.spec_from_file_location('nomonotone',helper)
nomonotone=importlib.util.module_from_spec(spec)
spec.loader.exec_module(nomonotone)
black=set(); x=y=q=0; prev=(0,0,0); witnesses={}
for t in range(12000):
    pos=(x,y)
    old=prev
    if pos in black:
        q=(q-1)%4; black.remove(pos)
    else:
        q=(q+1)%4; black.add(pos)
    prev=nomonotone.evk(black)
    delta=tuple(a-b for a,b in zip(prev,old))
    if delta not in witnesses:
        witnesses[delta]={'step':t,'position':pos,'before':old,'after':prev}
    x+=nomonotone.DX[q]; y+=nomonotone.DY[q]
    if len(witnesses)==8: break
assert len(witnesses)==8
assert all(tuple(-v for v in d) in witnesses for d in witnesses)
assert nomonotone.rank3(list(witnesses))==3

word=('RRRRLLRLLRRRRLLRRRRLLRLRRR'
      'RLRLLLLRRRRLRRLRRRRLLLLRLR'
      'RRRLRRRRLLLLRLRRRRLRLLRRLL'
      'LLRRLLRRRRLLRRLRLLRLLRLRLL')
assert len(word)==104
classes={}; x=y=q=0
for i,c in enumerate(word):
    lane=x%2; level=(x-lane)//2
    classes.setdefault((x+y,lane),[]).append((level,i,c))
    q=(q+(1 if c=='R' else -1))%4
    x+=nomonotone.DX[q]; y+=nomonotone.DY[q]
assert (x,y,q)==(2,-2,0)
seed=set(); rows=[]
for (t,r),events in sorted(classes.items()):
    stable=sorted(events,key=lambda e:(-e[0],e[1]))
    symbols=''.join(e[2] for e in stable)
    assert symbols=='RL'*(len(symbols)//2)+('R' if len(symbols)%2 else '')
    lo=min(e[0] for e in events); hi=max(e[0] for e in events)
    levels=[]
    for n in range(lo,hi):
        boundary=[e for e in stable if e[0]<=n]
        if boundary[0][2]=='L':
            seed.add((r+2*n,t-r-2*n)); levels.append(n)
    rows.append({'t':t,'r':r,'min_level':lo,'max_level':hi,'stable_word':symbols,'black_seed_levels':levels})
assert len(classes)==22 and len(seed)==11
assert sum(len(row['stable_word'])%2 for row in rows)==12
black=set(seed); x=y=q=0
for i in range(10400):
    c='L' if (x,y) in black else 'R'
    assert c==word[i%104]
    if c=='L': black.remove((x,y)); q=(q-1)%4
    else: black.add((x,y)); q=(q+1)%4
    x+=nomonotone.DX[q]; y+=nomonotone.DY[q]
assert (x,y,q,len(black))==(200,-200,0,1211)
report={'graph_witnesses':[{'delta':d,**witnesses[d]} for d in sorted(witnesses)],
        'standard_word':word,'classes':rows,'seed':sorted(seed),
        'simulation_periods':100,'final_state':{'x':x,'y':y,'heading':q,'black_cells':len(black)}}
(base/'example_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
