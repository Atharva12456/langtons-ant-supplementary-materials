# Coverage and review record

Research snapshot: 4 September 2026.

## Coverage

“Complete” means the core manuscript's mathematical result families and detailed
arguments plus the eight later chronology notes. It does not mean every duplicate
draft, source-code line, or raw shard is printed in the paper. The source archive
preserves the notebooks and selected implementations/certificates. Large raw
shard directories remain in the original repository. The twenty-page document
is an overview, not twenty pages of complete proofs.

| Material | Overview section | Detailed source / section |
|---|---:|---|
| Rule, finite support, conditional scope | 1 | Setup and introduction |
| Exact criterion, stable sorting, seed | 2 | Constructive realisability |
| Tait graph, surgery, bridges, non-monotonicity | 3 | Tait-graph conjugacy |
| Heading invariant, charges, endpoint decomposition | 4 | Additive charges |
| Even winding, positive mod-four growth | 5 | Even-winding theorem |
| Signed residues, density, coordinate-fibre visits | 6 | Residue and growth-eight sections |
| Axis/even-diagonal growth-four signs | 7 | Growth-four exclusions |
| Line parity and collision chains | 8 | Parity and collision sections |
| Extremal rigidity, widths 2/4/6/8, six masks, fixed drift | 9 | Transverse section and width-four appendix |
| Primitive ranks, second line, tree and 8/40 certificate | 10 | Last growth-four drift |
| All ten growth-eight orbits and axis refinements | 11 | Complete arithmetic ledger |
| Mixed, odd-skew, saturated-skew, primitive moments | 12 | Growth-eight boundary |
| Conditional full rails; relaxed partial rails | 13 | Boundary and later chronology |
| Exact upper-cap words; N≥8W+40 | 14 | m4 partial-rail cap-order note |
| Odd-skew caps and surviving parameter families | 15 | Three August31/September3 odd-skew notes |
| Selected cylinder cycles and waits | 16 | September3 cylinder note |
| Axis-two cycles and coupled returns | 17 | September3 axis note |
| Detour charges and drift-period bounds | 18 | September4 first-entry note |
| General N≤48; targeted growth8 N≤60 | 19 | Search and reproducibility sections |
| Standard104 seed, Lean boundary, open questions | 20 | Worked example and final sections |

Cap-three, cap-four and cap-five obstructions are retained as restricted
predecessors in the overview/provenance; their full original proofs remain in
the source archive. The journal records failed bounded-offset, local pumping,
frontier monotonicity, and additive-only routes. Inclusion in the archive does
not promote those failed approaches into theorems.

## Review rounds and substantive corrections



**Scope corrections.** Corrected the overbroad whole-orbit exclusion
at drift(4,-4): only full rails are excluded, and all ten growth-eight orbits
retain unresolved cases. Kept the three-lane full-rail hypotheses explicit.
Replaced “four occupied rows” with “four wake-bearing rows” at axis drift2.
Identified and incorporated the missing August31–September4 chronology.
Separated general-growth period48 coverage from targeted growth8 period60.

**Primitive-growth-four corrections.** The proof uses the 8/40 affine
normal forms using the fixed-anchor gap argument. The exact top-prefix audit
passed with zero survivors and no parameter bound. A separately written bounded
coordinate regression produced exactly 26 instantiated five-child frontiers and
260 six-child frontiers, matching the forms without extras or omissions.

The original fixed-word table was incomplete. The claim that all its words
failed abstract subsequence embedding was also wrong: the actual obstruction
is an unavailable integer stable-order gap. The replacement proof gives
all 8/40 families and every admissible third cut. This supplies the
primitive growth-four exclusion and computer-assisted consequence g≥8.
No stronger theorem excluding every primitive-drift trace was introduced.
The older independent cap-five enumeration is not described as an independent
verification of the whole new top-prefix classification.

**Further scope corrections.** The overview corrections include:
the signed integer endpoint decomposition D=S+(T_d−1)A; the unresolved
status of partial-rail data; the unchanged-root-colour hypothesis in the
heading-reversal lemma; odd-skew cap definitions and growth assumptions;
endpoint/interlacing/row-state definitions; the excluded width18 witness;
and the period congruence supporting the strict diagonal lower bound.

The displayed 104-step word has 22 translation
classes, 12 odd, exact stable alternation, and precisely the listed 11-cell
seed. A 100-period simulation ended at (200,−200) with 1211 black cells.

**Final corrections.** Minor final changes explicitly defined U_j and
used “longitudinal coordinates,” rather than “keys,” for the fixed anchors.

## Historical verification record

The statements below describe the earlier September release and its exports.
They do not certify the current supplementary delivery or a new PDF/HTML export.

- Both LaTeX documents compile. Final logs are checked for undefined references,
  duplicate labels and overfull boxes.
- Every PDF page is rendered and visually inspected. Automated checks cover
  page sizes, text bounds, empty pages and replacement characters.
- The 20-page content count excludes title, abstract and bibliography.
- All six targeted period summaries have successful audit status, complete
  rank coverage and zero hits. Table values were checked directly against JSON,
  including the restored residue-check counts for periods50–56.
- The large exhaustive searches were not rerun during compilation.
- Lean source is included; no new end-to-end formalisation or clean Lean build
  was performed for that release.
- The top-prefix implementation and analytic reduction remain trusted parts
  of a computer-assisted proof. The theorem is not formally checked end to end.
- Later cap/detour notes received a source/scope review, not independent
  line-by-line verification of every long case calculation.
- HTML is regenerated and statically checked. Live visual inspection was
  blocked by the browser's local-file URL policy; no bypass was attempted.
  The PDFs are the visually verified outputs.

The compilation claims neither STS eligibility, journal acceptance, universal
eventual periodicity, complete periodic classification, nor g≥12.
