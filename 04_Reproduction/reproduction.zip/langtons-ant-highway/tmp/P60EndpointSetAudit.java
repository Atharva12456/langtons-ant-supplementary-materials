public final class P60EndpointSetAudit {
    public static void main(String[] args) {
        for (int x = -4; x <= 4; x++) {
            for (int y = -4; y <= 4; y++) {
                if (PositiveGrowthP60EndpointSearch.p60AllowedEndpoint(x, y)) {
                    System.out.println(x + "," + y);
                }
            }
        }
    }
}
