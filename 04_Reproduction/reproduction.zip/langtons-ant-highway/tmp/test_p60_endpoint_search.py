#!/usr/bin/env python3
"""Cross-check the dedicated period-60 endpoint-pruned search."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "tmp" / "p60-endpoint-test-classes"


def run(class_name: str) -> dict[str, object]:
    output = subprocess.check_output(
        [
            "java", "-cp", str(BUILD), class_name,
            "--period", "20", "--prefix-length", "8",
            "--rank-start", "0", "--rank-stop", "128",
            "--target-growth", "8",
        ],
        cwd=ROOT,
        text=True,
    )
    return json.loads(output)


def structural(record: dict[str, object]) -> dict[str, object]:
    ignored = {"seconds", "pruning", "endpoint_restriction"}
    answer = {key: value for key, value in record.items() if key not in ignored}
    for row in answer["results"]:
        row.pop("seconds", None)
    return answer


def main() -> None:
    BUILD.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [
            "javac", "-d", str(BUILD),
            str(ROOT / "code" / "java" / "PositiveGrowthResidueSearch.java"),
            str(ROOT / "tmp" / "PositiveGrowthP60EndpointSearch.java"),
            str(ROOT / "tmp" / "P60EndpointSetAudit.java"),
            str(ROOT / "tmp" / "P60KinematicReachabilityAudit.java"),
        ],
        cwd=ROOT,
        check=True,
    )
    endpoints = set(
        subprocess.check_output(
            ["java", "-cp", str(BUILD), "P60EndpointSetAudit"],
            cwd=ROOT,
            text=True,
        ).splitlines()
    )
    assert endpoints == {
        "-2,-2", "-2,0", "-2,2", "0,-2",
        "0,2", "2,-2", "2,0", "2,2",
    }
    subprocess.run(
        ["java", "-cp", str(BUILD), "P60KinematicReachabilityAudit"],
        cwd=ROOT,
        check=True,
    )
    assert structural(run("PositiveGrowthP60EndpointSearch")) == structural(
        run("PositiveGrowthResidueSearch")
    )
    print("all_checks_passed=true")


if __name__ == "__main__":
    main()
