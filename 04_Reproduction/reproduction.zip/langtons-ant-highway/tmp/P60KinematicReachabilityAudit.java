import java.util.HashMap;
import java.util.Map;

/** Exhaustive small-depth audit of the joint heading/displacement/growth table. */
public final class P60KinematicReachabilityAudit {
    private static final int[] DX = {0, 1, 0, -1};
    private static final int[] DY = {1, 0, -1, 0};
    private static final int[] ENDPOINT_X = {-2, -2, -2, 0, 0, 2, 2, 2};
    private static final int[] ENDPOINT_Y = {-2, 0, 2, -2, 2, -2, 0, 2};

    private static long key(int x, int y, int growth) {
        return ((long) (x + 32) << 16)
                | ((long) (y + 32) << 8)
                | (growth + 32);
    }

    private static void enumerate(
            int remaining,
            int direction,
            int x,
            int y,
            int growth,
            int minimum,
            Map<Long, Integer> output) {
        if (remaining == 0) {
            if (direction == 0) {
                output.merge(key(x, y, growth), minimum, Math::max);
            }
            return;
        }
        int right = (direction + 1) & 3;
        enumerate(remaining - 1, right,
                x + DX[right], y + DY[right], growth + 1,
                Math.min(minimum, growth + 1), output);
        int left = (direction + 3) & 3;
        enumerate(remaining - 1, left,
                x + DX[left], y + DY[left], growth - 1,
                Math.min(minimum, growth - 1), output);
    }

    public static void main(String[] args) {
        for (int remaining = 0; remaining <= 10; remaining++) {
            for (int direction = 0; direction < 4; direction++) {
                Map<Long, Integer> brute = new HashMap<>();
                enumerate(remaining, direction, 0, 0, 0, 0, brute);
                for (int x = -remaining; x <= remaining; x++) {
                    for (int y = -remaining; y <= remaining; y++) {
                        for (int growth = -remaining; growth <= remaining; growth++) {
                            boolean expected = brute.containsKey(key(x, y, growth));
                            boolean actual = PositiveGrowthP60EndpointSearch
                                    .kinematicallyReachableForAudit(
                                            remaining, direction, x, y, growth);
                            if (actual != expected) {
                                throw new AssertionError(
                                        remaining + "," + direction + ","
                                                + x + "," + y + "," + growth);
                            }
                        }
                    }
                }
                for (int x = -12; x <= 12; x++) {
                    for (int y = -12; y <= 12; y++) {
                        for (int growth = 0; growth <= 18; growth++) {
                            boolean expected = false;
                            for (int endpoint = 0;
                                    endpoint < ENDPOINT_X.length; endpoint++) {
                                Integer bestMinimum = brute.get(key(
                                        ENDPOINT_X[endpoint] - x,
                                        ENDPOINT_Y[endpoint] - y,
                                        8 - growth));
                                expected |= bestMinimum != null
                                        && bestMinimum >= -growth;
                            }
                            boolean actual = PositiveGrowthP60EndpointSearch
                                    .p60StateReachableForAudit(
                                            remaining, direction, x, y, growth);
                            if (actual != expected) {
                                throw new AssertionError(
                                        "state " + remaining + "," + direction + ","
                                                + x + "," + y + "," + growth);
                            }
                        }
                    }
                }
            }
        }
        System.out.println("all_checks_passed=true");
    }
}
