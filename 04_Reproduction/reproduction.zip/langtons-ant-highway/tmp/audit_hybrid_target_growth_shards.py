#!/usr/bin/env python3
"""Audit exact target-growth shards produced by more than one engine."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path


COUNTERS = (
    "nodes", "growth_prunes", "endpoint_prunes", "deficit_checks",
    "deficit_prunes", "deficit_endpoints_tested", "residue_checks",
    "residue_prunes", "leaves", "p3_checks",
)


@dataclass(frozen=True)
class EngineDirectory:
    label: str
    directory: Path
    allowed_deficit_depths: tuple[int, ...]
    require_endpoint_restriction: bool = False


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def prefix_for_rank(rank: int, length: int) -> str:
    return "R" + "".join(
        "L" if rank & (1 << bit) else "R"
        for bit in range(length - 2, -1, -1)
    )


def prefix_is_valid(prefix: str) -> bool:
    x = y = direction = balance = 0
    last_turn: dict[tuple[int, int], int] = {}
    steps = ((0, 1), (1, 0), (0, -1), (-1, 0))
    for symbol in prefix:
        turn = 0 if symbol == "R" else 1
        previous = last_turn.get((x, y))
        if previous is not None and turn != 1 - previous:
            return False
        balance += 1 if turn == 0 else -1
        if balance < 0:
            return False
        last_turn[x, y] = turn
        direction = (direction + (1 if turn == 0 else 3)) % 4
        dx, dy = steps[direction]
        x += dx
        y += dy
    return True


def audit(engines: tuple[EngineDirectory, ...]) -> dict[str, object]:
    if not engines:
        raise ValueError("at least one engine directory is required")
    problems: list[str] = []
    covered: list[int] = []
    hits: list[object] = []
    totals = {key: 0 for key in COUNTERS}
    core_seconds = 0.0
    period = prefix_length = rank_count = target_growth = None
    file_hashes: dict[str, str] = {}
    engine_shards = {engine.label: 0 for engine in engines}

    for engine in engines:
        files = sorted(engine.directory.glob("shard_*.json"))
        for path in files:
            engine_shards[engine.label] += 1
            name = f"{engine.label}:{path.name}"
            try:
                record = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as error:
                problems.append(f"{name}: unreadable record: {error}")
                continue
            file_hashes[name] = sha256(path)
            if record.get("schema") != "positive-growth-periodic-residue-search-v2":
                problems.append(f"{name}: unexpected record schema")
            metadata = (
                record.get("period"), record.get("prefix_length"),
                record.get("total_rank_count"), record.get("target_growth"),
            )
            if period is None:
                period, prefix_length, rank_count, target_growth = metadata
            elif metadata != (period, prefix_length, rank_count, target_growth):
                problems.append(f"{name}: inconsistent metadata {metadata!r}")
            if record.get("search_complete") is not True:
                problems.append(f"{name}: search_complete is not true")
            if record.get("node_cap") is not None:
                problems.append(f"{name}: node_cap is not null")
            if tuple(record.get("deficit_depths", ())) != engine.allowed_deficit_depths:
                problems.append(f"{name}: unexpected deficit depths")
            if (
                engine.require_endpoint_restriction
                and record.get("period") == 60
                and record.get("target_growth") == 8
                and "only the eight" not in record.get("endpoint_restriction", "")
            ):
                problems.append(f"{name}: endpoint restriction is not recorded")

            start, stop = record.get("rank_start"), record.get("rank_stop")
            expected = (
                list(range(start, stop))
                if isinstance(start, int) and isinstance(stop, int)
                else []
            )
            results = record.get("results", [])
            if [row.get("rank") for row in results] != expected:
                problems.append(f"{name}: result ranks do not match interval")
            per_shard = {key: 0 for key in COUNTERS}
            shard_hits: list[object] = []
            for row in results:
                rank = row.get("rank")
                if not isinstance(rank, int):
                    problems.append(f"{name}: invalid rank {rank!r}")
                    continue
                covered.append(rank)
                expected_prefix = prefix_for_rank(rank, int(prefix_length))
                if row.get("prefix") != expected_prefix:
                    problems.append(f"{name}: wrong prefix at rank {rank}")
                if row.get("prefix_valid") is not prefix_is_valid(expected_prefix):
                    problems.append(f"{name}: wrong prefix validity at rank {rank}")
                for key in COUNTERS:
                    value = row.get(key)
                    if not isinstance(value, int):
                        problems.append(f"{name}: rank {rank} has invalid {key}")
                        value = 0
                    per_shard[key] += value
                item_hits = row.get("hits")
                if not isinstance(item_hits, list):
                    problems.append(f"{name}: rank {rank} hits is not a list")
                else:
                    shard_hits.extend(item_hits)
            if shard_hits != record.get("hits"):
                problems.append(f"{name}: per-rank and shard hits differ")
            for key in COUNTERS:
                if per_shard[key] != record.get(key):
                    problems.append(f"{name}: per-rank {key} sum differs")
                totals[key] += per_shard[key]
            hits.extend(shard_hits)
            core_seconds += float(record.get("seconds", 0.0))

    expected_coverage = (
        list(range(rank_count)) if isinstance(rank_count, int) else []
    )
    covered.sort()
    if covered != expected_coverage:
        problems.append(
            f"coverage has {len(covered)} entries; expected {len(expected_coverage)}"
        )
    if not isinstance(prefix_length, int) or not isinstance(rank_count, int):
        problems.append("invalid prefix metadata")
    elif rank_count != 1 << (prefix_length - 1):
        problems.append("prefix length and rank count disagree")
    if (
        not isinstance(target_growth, int) or target_growth <= 0
        or target_growth % 4 or not isinstance(period, int)
        or target_growth > period
    ):
        problems.append("invalid period or target growth")

    return {
        "schema": "langton-hybrid-target-growth-search-audit-v1",
        "period": period,
        "target_growth": target_growth,
        "prefix_length": prefix_length,
        "total_rank_count": rank_count,
        "shards": sum(engine_shards.values()),
        "engine_shards": engine_shards,
        "ranks_covered_exactly_once": covered == expected_coverage,
        **totals,
        "core_seconds": round(core_seconds, 3),
        "hits": hits,
        "highways_found": len(hits),
        "shard_sha256": file_hashes,
        "problems": problems,
        "all_checks_passed": not problems and not hits,
    }

