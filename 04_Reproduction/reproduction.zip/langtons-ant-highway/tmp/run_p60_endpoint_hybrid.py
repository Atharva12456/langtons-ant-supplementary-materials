#!/usr/bin/env python3
"""Resume period 60 with the ledger-aware engine and retain original shards."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_hybrid_target_growth_shards import EngineDirectory, audit


PERIOD = 60
GROWTH = 8
PREFIX = 12
ORIGINAL_CHUNK = 8
OPTIMIZED_CHUNK = 1
TOTAL = 1 << (PREFIX - 1)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def intervals(total: int = TOTAL, chunk: int = ORIGINAL_CHUNK):
    return tuple((start, min(start + chunk, total)) for start in range(0, total, chunk))


def valid_shard(path: Path, period: int, growth: int, prefix: int,
                start: int, stop: int, deficits: tuple[int, ...]) -> bool:
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return (
        record.get("period") == period
        and record.get("target_growth") == growth
        and record.get("prefix_length") == prefix
        and record.get("rank_start") == start
        and record.get("rank_stop") == stop
        and tuple(record.get("deficit_depths", ())) == deficits
        and record.get("search_complete") is True
        and record.get("node_cap") is None
        and [row.get("rank") for row in record.get("results", ())]
            == list(range(start, stop))
    )


def reusable_single_ranks(
    directory: Path,
    covered: set[int],
    *,
    total: int = TOTAL,
    period: int = PERIOD,
    growth: int = GROWTH,
    prefix: int = PREFIX,
    deficits: tuple[int, ...] = (),
) -> set[int]:
    result = set()
    for start, stop in intervals(total=total, chunk=OPTIMIZED_CHUNK):
        path = directory / f"shard_{start:06d}_{stop:06d}.json"
        if not valid_shard(
            path, period, growth, prefix, start, stop, deficits
        ):
            continue
        if start in covered or start in result:
            raise ValueError(
                f"reusable rank overlap at {start} in {directory}"
            )
        result.add(start)
    return result


def reuse_directory_deficits(
    directory: Path,
    *,
    period: int = PERIOD,
    growth: int = GROWTH,
    prefix: int = PREFIX,
) -> tuple[int, ...]:
    manifest_path = directory / "RUN_MANIFEST.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(
            f"missing or invalid reuse manifest in {directory}"
        ) from error
    if (
        manifest.get("period") != period
        or manifest.get("target_growth") != growth
        or manifest.get("prefix_length") != prefix
    ):
        raise ValueError(f"incompatible reuse manifest in {directory}")
    try:
        deficits = tuple(int(value) for value in manifest.get("deficit_depths", ()))
    except (TypeError, ValueError) as error:
        raise ValueError(f"invalid deficit list in reuse manifest {directory}") from error
    if any(value <= 0 or value >= period for value in deficits):
        raise ValueError(f"invalid deficit list in reuse manifest {directory}")
    return deficits


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--existing-dir", type=Path, required=True)
    parser.add_argument("--reuse-dir", type=Path, action="append", default=[])
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=min(10, os.cpu_count() or 1))
    parser.add_argument("--deficit-depths", default="")
    parser.add_argument("--summary", type=Path, required=True)
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("workers must be positive")
    deficits = tuple(
        int(value) for value in args.deficit_depths.split(",") if value.strip()
    )

    repo = Path(__file__).resolve().parents[1]
    existing = (repo / args.existing_dir).resolve() if not args.existing_dir.is_absolute() else args.existing_dir
    reuse = tuple(
        (repo / path).resolve() if not path.is_absolute() else path.resolve()
        for path in args.reuse_dir
    )
    reuse_deficits = tuple(
        reuse_directory_deficits(directory) for directory in reuse
    )
    output = (repo / args.output_dir).resolve() if not args.output_dir.is_absolute() else args.output_dir
    summary = (repo / args.summary).resolve() if not args.summary.is_absolute() else args.summary
    source = repo / "tmp" / "PositiveGrowthP60EndpointSearch.java"
    original_source = repo / "code" / "java" / "PositiveGrowthResidueSearch.java"
    ledger = repo / "research-notes" / "growth8_case_ledger_2026-08-22.md"
    classes = repo / "tmp" / "p60-endpoint-runner-classes"
    output.mkdir(parents=True, exist_ok=True)
    classes.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["javac", "-d", str(classes), str(source)],
        cwd=repo,
        check=True,
    )

    manifest = {
        "schema": "p60-hybrid-endpoint-run-v1",
        "period": PERIOD,
        "target_growth": GROWTH,
        "prefix_length": PREFIX,
        "original_chunk_size": ORIGINAL_CHUNK,
        "optimized_chunk_size": OPTIMIZED_CHUNK,
        "workers": args.workers,
        "deficit_depths": list(deficits),
        "existing_directory": str(existing),
        "reuse_directories": [str(path) for path in reuse],
        "reuse_deficit_depths": [list(values) for values in reuse_deficits],
        "output_directory": str(output),
        "original_source_sha256": sha256(original_source),
        "endpoint_source_sha256": sha256(source),
        "case_ledger_sha256": sha256(ledger),
    }
    manifest_path = output / "RUN_MANIFEST.json"
    if manifest_path.exists():
        prior = json.loads(manifest_path.read_text(encoding="utf-8"))
        if prior != manifest:
            raise RuntimeError("run manifest differs from the requested configuration")
    else:
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    original_done = set()
    covered_ranks = set()
    for start, stop in intervals(chunk=ORIGINAL_CHUNK):
        name = f"shard_{start:06d}_{stop:06d}.json"
        old_path = existing / name
        if valid_shard(old_path, PERIOD, GROWTH, PREFIX, start, stop, ()):
            original_done.add((start, stop))
            covered_ranks.update(range(start, stop))

    reused_done: list[set[int]] = []
    for directory, directory_deficits in zip(reuse, reuse_deficits):
        ranks = reusable_single_ranks(
            directory, covered_ranks, deficits=directory_deficits
        )
        reused_done.append(ranks)
        covered_ranks.update(ranks)

    optimized_done = set()
    missing = []
    for start, stop in intervals(chunk=OPTIMIZED_CHUNK):
        if start in covered_ranks:
            continue
        name = f"shard_{start:06d}_{stop:06d}.json"
        new_path = output / name
        if valid_shard(new_path, PERIOD, GROWTH, PREFIX, start, stop, deficits):
            optimized_done.add((start, stop))
            covered_ranks.update(range(start, stop))
        else:
            missing.append((start, stop, new_path))

    print(
        f"original_shards={len(original_done)} "
        f"reused_ranks={sum(map(len, reused_done))} "
        f"optimized_ranks={len(optimized_done)} "
        f"covered_ranks={len(covered_ranks)}/{TOTAL} "
        f"missing_ranks={len(missing)} workers={args.workers}",
        flush=True,
    )

    def run_one(start: int, stop: int, path: Path):
        command = [
            "java", "-cp", str(classes), "PositiveGrowthP60EndpointSearch",
            "--period", str(PERIOD),
            "--prefix-length", str(PREFIX),
            "--rank-start", str(start), "--rank-stop", str(stop),
            "--target-growth", str(GROWTH),
            "--deficit-depths", ",".join(map(str, deficits)) if deficits else "0",
            "--output", str(path),
        ]
        began = time.monotonic()
        completed = subprocess.run(
            command, cwd=repo, text=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
        )
        if completed.returncode:
            raise RuntimeError(
                f"ranks [{start},{stop}) failed: {completed.stderr[-2000:]}"
            )
        if not valid_shard(path, PERIOD, GROWTH, PREFIX, start, stop, deficits):
            raise RuntimeError(f"ranks [{start},{stop}) produced an invalid shard")
        return start, stop, time.monotonic() - began

    completed_count = len(covered_ranks)
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(run_one, *item) for item in missing]
        for future in as_completed(futures):
            start, stop, seconds = future.result()
            completed_count += 1
            print(
                f"completed_ranks={completed_count}/{TOTAL} "
                f"ranks=[{start},{stop}) shard_seconds={seconds:.1f}",
                flush=True,
            )

    engines = [EngineDirectory("original", existing, ())]
    engines.extend(
        EngineDirectory(
            f"endpoint_reuse_{index}", directory, directory_deficits,
            require_endpoint_restriction=True,
        )
        for index, (directory, directory_deficits)
        in enumerate(zip(reuse, reuse_deficits))
    )
    engines.append(EngineDirectory(
        "endpoint", output, deficits,
        require_endpoint_restriction=True,
    ))
    report = audit(tuple(engines))
    report["run_manifest_sha256"] = sha256(manifest_path)
    report["original_source_sha256"] = manifest["original_source_sha256"]
    report["endpoint_source_sha256"] = manifest["endpoint_source_sha256"]
    report["reused_manifest_sha256"] = {
        str(directory): sha256(directory / "RUN_MANIFEST.json")
        for directory in reuse
        if (directory / "RUN_MANIFEST.json").is_file()
    }
    summary.parent.mkdir(parents=True, exist_ok=True)
    summary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)
    if not report["all_checks_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
