# Lifetime interlacement and the row/column touch graph

Date: 2026-07-14  
Status: exact finite reduction plus an explicitly unresolved periodic boundary completion. No universal closure is claimed.

## 1. Finite chord-matrix identity

Consider a finite chronological list of cell-visit events. Pair some event
positions into actual consecutive R-to-L visits to the same physical cell;
leave all other positions as singletons. Label the pairs by `1,...,m` and the
singletons by `1,...,u`. If pair `i` has endpoints `a_i<b_i`, let `A` be its
binary interlacement matrix:

\[
A_{ki}=1
\quad\Longleftrightarrow\quad
a_i<a_k<b_i<b_k\ \text{ or }\ a_k<a_i<b_k<b_i.
\tag{1.1}
\]

Let `W_{ji}=1` exactly when singleton event `j` lies in `[a_i,b_i)`.  Let
`G_P` map a pair label to the row-column incidence edge of its physical cell,
and let `G_U` do the same for a singleton.  Let `H` be the incidence boundary
from cell edges to row and column vertices.

For each `i`, the parity vector of event labels in `[a_i,b_i)` is

\[
e_i+\sum_{k:A_{ki}=1}e_k+\sum_{j:W_{ji}=1}f_j.
\tag{1.2}
\]

Indeed, pair `i` contributes its first endpoint; a different pair contributes
one endpoint exactly when its chord interlaces chord `i`; and a singleton
contributes exactly when it lies inside.  Mapping labels to their physical
cells automatically cancels different pair labels belonging to the same cell.

The two endpoints of the lifetime are the same cell and have the same heading
type by the HV partition. P27 therefore makes the physical odd-visit chain
Eulerian. Column by column, (1.2) gives the exact matrix identity

\[
\boxed{H\bigl(G_P(I+A)+G_UW\bigr)=0.}
\tag{1.3}
\]

This is a finite theorem, not a heuristic. It is the linear-algebra form of
P29. It also shows the precise role of unmatched boundary or wake events: they
are the inhomogeneous term `G_UW`.

## 2. Double-occurrence case and the touch graph

First suppose there are no singleton events and every paired label occurs
exactly twice on one closed temporal circuit `C`. Identifying the two
occurrences of each label produces a connected 4-regular multigraph `F` for
which `C` is an Euler circuit.

At a paired Langton cell, both arrivals have the same H/V type. Consequently
the four temporal half-edges consist of two horizontal and two vertical
half-edges. Select the circuit-partition transition that joins H to H and V to
V. Call the resulting circuit partition `P_HV`.

The touch graph `Tch(P_HV)` has:

- one vertex for every horizontal or vertical smoothed circuit; and
- one edge for every paired lifetime, joining the H circuit and V circuit
  incident at that cell.

It is bipartite. A fundamental circuit of the temporal Euler circuit at a
lifetime vertex is exactly one of the two intervals between its occurrences.
Its image in the touch graph is the row-column cycle appearing in P29.

In fact `P_HV` uses the `psi_C` transition at every lifetime vertex.  The two
P-paired occurrences have the same arrival H/V type; hence their two incoming
half-edges have one orientation and their two outgoing half-edges have the
other orientation.  Pairing H/H and V/V therefore pairs the two entrances and
the two exits.  In this special closed Langton setting, the modified binary
interlacement matrix is exactly `I+A`, with a 1 on every diagonal; no
additional `phi`-column modification is needed.

The modified-interlacement theorem for 4-regular graphs now applies: the rows
of the appropriate modified interlacement matrix span the full binary cycle
space of `Tch(P_HV)`, and its nullity is the circuit-partition count minus the
component count. Thus, in the closed double-occurrence case, the lifetime
cycles are not merely individual constraints; collectively they generate the
whole touch-graph cycle space.

This use of circuit nullity is based on Lorenzo Traldi's exact touch-graph
formulation.  The identification with raw `I+A` is justified here by the
preceding `psi_C` observation; it is not a statement about arbitrary circuit
partitions.

## 3. What positive growth changes

For a positive-growth repeating trace, P3 pairs every L occurrence with the
preceding R in its stabilized physical class but leaves exactly `g` R
occurrences unmatched.  On the translation phase circle, identify the two
phase occurrences of every P pair.  This gives a connected temporal graph
`F_partial` in which paired lifetimes are 4-valent vertices and wake events
are degree-2 vertices.  The phase circle is an Euler tour of this mixed-degree
graph.  At a matched vertex perform H/H and V/V smoothing, and at a wake
vertex cut the H and V half-edges apart.  Then:

- every paired lifetime gives a 4-valent temporal vertex;
- every wake R gives a degree-2 vertex with one H and one V temporal
  half-edge; and
- H/H and V/V smoothing terminates at those degree-2 wake ports.

The smoothed objects are therefore horizontal/vertical paths and circuits,
not only circuits.  There are `g` H ports and `g` V ports.  Every open
orientation component has two ports, so there are exactly `g/2` open H paths
and `g/2` open V paths, in addition to an a priori unbounded number `c` of
closed H/V circuits.

Define the **boundary touch graph** `T_boundary` as follows.  Its vertices are
all open and closed smoothed components.  Every matched lifetime is an edge
between its incident H and V components, and every wake event is a
distinguished wake edge between its H and V open components.  The wake-edge
subgraph `W` has `g` open-component vertices in total (`g/2` H and `g/2` V),
`g` edges, and degree two at every vertex.  Hence it
is a disjoint union of `kappa` even cycles.  The complete temporal tour shows
that `T_boundary` is connected.

There is now an exact, rather than schematic, use of Traldi's theorem.
Suppress the `g` degree-2 wake vertices of `F_partial`.  The result is a
connected 4-regular multigraph `F_0` with the phase circle as an Euler circuit.
The H/V transition at each remaining vertex gives a circuit partition
`P_0`.  Passing through a suppressed wake switch joins an H open trail to a V
open trail, so

\[
\boxed{Tch(P_0)=T_{\rm boundary}/W,}
\tag{3.1}
\]

where every connected cycle component of `W` is contracted to one vertex.
If `c` is the number of closed H/V circuits, then

\[
|V(Tch(P_0))|=c+\kappa,\qquad
\dim Z(Tch(P_0))=m-c-\kappa+1.
\tag{3.2}
\]

Project a physical lifetime discrepancy row by deleting its `g` wake-edge
coordinates.  Its lifted interval may traverse the phase circle several
times, but every extra full traversal meets each paired lifetime twice, so it
contributes zero on the matched coordinates.  The projected row is therefore
exactly the image of a fundamental circuit of the Euler circuit of `F_0`.
Traldi's fundamental-circuit theorem proves

\[
\boxed{
\text{the projected physical lifetime rows span }Z(Tch(P_0)).}
\tag{3.3}
\]

This is the rigorous positive-growth circuit-nullity statement.  It does
**not** say that the lifetime rows span the full boundary touch graph.  The
contraction map gives an exact sequence whose kernel is `Z(W)`, of dimension
`kappa`.  As

\[
\dim Z(T_{\rm boundary})=m-c+1,
\tag{3.4}
\]

the physical lifetime rows have codimension at most `kappa` in that full
cycle space; deciding which wake-cycle directions they contain is the
remaining boundary problem.

The translation levels of the paired endpoints are still essential before
the wake coordinates are deleted.  They turn ordinary chord interlacement
into the finite Laurent-voltage identity

\[
H(t)\left(G_P(t)M(t)+G_U(t)W(t)\right)=0
\quad\text{over }\mathbf F_2[t,t^{-1}],
\tag{3.5}
\]

where `M(t)` is the voltage-aware `psi`-modified interlacement matrix.
Equation (1.3) proves every finite lift.  Equations (3.1)--(3.3) identify its
ordinary matched-coordinate specialization; the unresolved part is the
`kappa`-dimensional wake-cycle kernel, not the contracted touch graph.

## 4. A corrected failed shortcut

It is false that diagonal drift and `g=4` leave only two H paths and two V
paths. They leave two **open** paths of each orientation, but there may also be
arbitrarily many closed smoothed circuits. A finite horizontal circuit can
backtrack on one exact row using parallel temporal edge copies; it need not
wind around the translation cylinder. The vertical statement is identical.

These closed circuits are the touch-graph manifestation of the same unbounded
data as the even stabilized classes that P22 does not count (a literal
one-to-one correspondence is not asserted). Hence the four wake ports do not
bound the size of the touch graph, its cycle rank, or the nullity of the
modified interlacement matrix. Any argument that silently discards the closed
H/V circuits is invalid.

For `g=4` there are exactly two open H paths and two open V paths.  The
wake-edge subgraph is therefore either one 4-cycle (`kappa=1`) or two doubled
H--V edges (`kappa=2`).  Both are valid 2-regular bipartite multigraphs; they
are not contradictions.  Moreover, the signed residue skeleton labels wake
cells by coordinate residues, whereas `W` groups them by smoothed trail
components.  No theorem presently identifies those two vertex partitions.

## 5. Exact next lemma required

The highest-value periodic lemma is now:

> Control the `kappa` wake-cycle directions and the unbounded closed H/V
> circuits in the voltage-aware boundary touch graph, using lattice labels or
> signed mod-four data, strongly enough to contradict both possible `g=4`
> wake subgraphs.

The general Cohn-Lempel/Traldi circuit-nullity equality alone cannot supply
such a restriction.  It proves the full spanning statement after contracting
the wake cycles, but does not select lifts through `Z(W)` and does not bound
the extra closed coordinate circuits. The needed input must use the
square-lattice embedding, exact arrival directions, translation voltages, or
the signed mod-four charges.

### Targeted standard-trace check

For the standard period-104 trace, the exact phase-cylinder construction has

\[
m=46,\quad g=12,\quad c=5,\quad\kappa=1.
\]

Consequently (3.2) predicts contracted touch-cycle rank
`46-5-1+1=41`.  The projected lifetime-row matrix has exact binary rank 41.
The full boundary touch graph has cycle rank `46-5+1=42`, while the full
lifetime-row matrix still has rank 41.  Thus the standard trace itself
exhibits the missing one-dimensional wake cycle and disproves the shortcut
that the physical lifetime rows always span the full boundary cycle space.

## 6. References used for this reduction

- Lorenzo Traldi, *Binary nullity, Euler circuits and interlace polynomials*,
  arXiv:0903.4405.
- Lorenzo Traldi, *Interlacement in 4-regular graphs: a new approach using
  nonsymmetric matrices*, arXiv:1204.0482.
- Lorenzo Traldi, *Circuit partitions and signed interlacement in 4-regular
  graphs*, arXiv:1607.04233.

These references prove the general circuit-nullity and touch-graph row-space
statements. Their application to Langton's positive-growth boundary ports and
translation voltages is the new, unfinished part recorded here.
