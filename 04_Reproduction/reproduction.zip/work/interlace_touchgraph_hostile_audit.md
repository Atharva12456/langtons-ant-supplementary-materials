# Hostile audit: interlacement, touch graphs, and four wake ports

Date: 2026-07-14  
Scope: the abstract finite graph-theory claims in `interlace_touchgraph_notes.md`.  This note does **not** assert that any abstract word below is realized by a Langton-ant orbit.

## Verdict

The closed double-occurrence construction is sound at the level of **distinct
lifetime labels**.  Traldi's fundamental-circuit theorem then says that one
fundamental circuit per 4-valent lifetime vertex maps onto a spanning set of
the binary cycle space of the touch graph.

There is, however, a necessary correction to Sections 2--3 of the source
note.  The touch graph has one edge per lifetime label, whereas P29 applies a
further map that may identify several lifetime edges with one physical cell
edge and several smoothed components with one exact row or column.  Therefore
a fundamental circuit's touch-graph image is not literally the P29
row--column cycle.  Its **pushforward** is that cycle.  Traldi proves spanning
before this pushforward; afterwards it proves spanning only of the image of
the touch-cycle space.  It does not prove that the physical row--column graph
has no additional cycle directions.

For positive growth, the contracted boundary theorem stated in (3.1)--(3.3)
is correct after making the same labeled-lifetime qualification.  It gives no
rank bound depending only on `g`.  With `g=4`, an exact family of abstract
words has arbitrarily many closed smoothed circuits and arbitrarily large
contracted touch-cycle rank.

## 1. Closed double-occurrence construction

Let `C` be a cyclic word in which each of `m` labels occurs exactly twice.
Subdivide the circle at the `2m` occurrences and identify the two occurrences
of each label.  The quotient `F` is a connected 4-regular multigraph:

1. each occurrence supplies an incoming and an outgoing temporal half-edge,
   so its identified pair has four half-edges;
2. the quotient remains connected because it is the image of a circle; and
3. the temporal circle uses every subdivided arc exactly once, so it is an
   Euler circuit of `F`.

Loops and parallel edges are allowed, as they must be in the standard
4-regular-graph formulation.

At two visits to the same square, the arrival axes agree: returning to one
square takes an even number of lattice steps, while the ant changes movement
axis at every turn.  Thus a lifetime vertex has exactly two H half-edges and
two V half-edges.  Joining H--H and V--V is a legitimate circuit-partition
transition `P_HV`.  Each resulting circuit stays on one exact row or one
exact column, so the labeled touch graph has

* one vertex for every individual H or V smoothed circuit, and
* one edge for every lifetime label, between its incident H and V circuits.

It is therefore a bipartite multigraph.  Different smoothed H circuits can
occupy the same physical row, and different lifetime labels can represent
the same physical cell.  These are distinct in the touch graph.

For a label `i`, choose either of the two `i`-to-`i` subtrails of the Euler
circuit and close it at `i`.  Under the touch-graph map its binary edge vector
is

\[
e_i+\sum_{k:\,k\text{ interlaces }i}e_k,
\]

namely row `i` of `I+A`: edge `i` is used at the closing transition, and a
different edge `k` is crossed an odd number of times exactly when one
occurrence of `k` lies in the chosen interval.  In this Langton H/V partition
the transition is `psi_C`, which accounts for the diagonal 1.

Traldi's fundamental-circuit theorem applies exactly here.  For a connected
4-regular `F`, the images of one fundamental circuit at every vertex span
`Z(Tch(P_HV); F_2)`.  Consequently, if `p=|P_HV|` is the number of smoothed
circuits,

\[
\operatorname{rank}_{\mathbf F_2}(I+A)=m-p+1,
\qquad
\operatorname{nullity}_{\mathbf F_2}(I+A)=p-1.
\]

This is the touch-graph circuit-nullity equality.  The relevant primary
statements are Traldi's touch-graph definition and fundamental-circuit
spanning theorem in [arXiv:1607.04233](https://arxiv.org/abs/1607.04233), and
the modified-interlacement/core-space formulation in
[arXiv:1204.0482](https://arxiv.org/abs/1204.0482).  The extended
Cohn--Lempel equality is in
[arXiv:0903.4405](https://arxiv.org/abs/0903.4405).

### Coordinate pushforward

Let `pi` identify each individual H (respectively V) smoothed circuit with
its physical row (respectively column), and each lifetime edge with its
physical cell edge.  Then

\[
\pi_*\bigl((I+A)_i\bigr)
\]

is the P29 row--column cycle.  Because `pi_*` can identify and cancel edges,
it need not preserve rank or be onto the full cycle space of the coordinate
graph.  The strongest automatic conclusion is

\[
\operatorname{span}\{\pi_*((I+A)_i)\}
=\pi_* Z(Tch(P_HV)),
\]

not equality with every cycle of the physical row--column graph.

## 2. Correct boundary theorem

Now allow `g` singleton wake events.  At a paired label retain H--H/V--V
smoothing.  At a wake vertex cut its one H and one V half-edge apart.  There
are `g/2` open H components and `g/2` open V components, but there may also
be arbitrarily many closed components.

Define the labeled boundary touch graph `T` with one vertex per individual
open or closed smoothed component, one edge per paired lifetime, and one
distinguished edge per wake event.  Let `W` be the subgraph of wake edges.
Every open component has two wake ends, so `W` is a disjoint union of
`kappa` even cycles.  In the phase-circle construction `T` is connected.

For lifetime `i`, the exact labeled interval vector is

\[
r_i=e_i+\sum_{k:A_{ik}=1}e_k+
       \sum_{j:W_{ji}=1}f_j.
\]

The endpoint-token argument says precisely that `r_i` is a cycle of `T`.
Suppressing every degree-2 wake vertex in the temporal graph reconnects H to
V at each wake switch and gives a connected 4-regular graph.  Its H/V circuit
partition has touch graph

\[
T/W,
\]

where each connected component of the wake subgraph is contracted.  Deleting
the wake coordinates sends `r_i` to row `i` of `I+A`, and Traldi gives

\[
\operatorname{span}\{r_i\vert_{E(T)\setminus E(W)}\}
= Z(T/W;\mathbf F_2).
\]

If `m` is the number of paired lifetimes and `c` the number of closed H/V
components, then

\[
\begin{aligned}
\dim Z(T)&=m-c+1,\\
\dim Z(T/W)&=m-c-\kappa+1.
\end{aligned}
\]

Indeed `T` has `m+g` edges and `c+g` vertices, while `T/W` has `m` edges and
`c+kappa` vertices.  Deletion/contraction gives the exact sequence

\[
0\longrightarrow Z(W)\longrightarrow Z(T)
 \longrightarrow Z(T/W)\longrightarrow0,
\]

so the labeled lifetime rows have codimension at most `kappa` in `Z(T)`.
They need not contain any prescribed wake-cycle lift.  Applying the physical
coordinate pushforward can lower their rank further.

This is the complete boundary consequence of ordinary circuit-nullity.  It
does not bound `c`, `m-c`, or the resulting rank in terms of `g`.

## 3. Smallest four-port failure of full boundary spanning

Use cyclic temporal edges of alternating axes (even outgoing edges H, odd
outgoing edges V) and the word

```
A U1 U2 U3 A U4
```

Declare the first `A` to be R, the second `A` to be L, and all `Uj` to be
unmatched R events.  Thus `g=4`, the two occurrences of `A` have the same
arrival axis, and every local parity requirement used by the abstract
construction is satisfied.

This word is even locally square-lattice realizable.  Starting at `A=(0,0)`
heading north, the turns `R R R R L R` visit

```
A=(0,0), U1=(1,0), U2=(1,-1), U3=(0,-1), A=(0,0), U4=(-1,0)
```

and finish at `(-1,1)` heading north.  This observation does not assert that
periodically repeating the segment produces a valid Langton translator; its
translation-voltage identifications are additional constraints.

H/V smoothing gives four open components:

* `H1 : U4--U1` (through `A`) and `H2 : U2--U3`;
* `V1 : U1--U2` and `V2 : U3--U4` (through `A`).

The boundary touch edges are

\[
A:H1\!-\!V2,\quad U1:H1\!-\!V1,\quad U2:H2\!-\!V1,\quad
U3:H2\!-\!V2,\quad U4:H1\!-\!V2.
\]

Hence `T` is connected with five edges and four vertices, so
`dim Z(T)=2`.  The only R-to-L lifetime interval has vector
`A+U1+U2+U3`, of rank one.  The independent wake cycle
`U1+U2+U3+U4` is missing.  This is minimal
among four-port systems with a paired lifetime: `g=4` forces four singleton
events, and one pair forces two more occurrences.

After contracting the wake 4-cycle, `A` becomes a loop and the projected row
`A` spans `Z(T/W)`, exactly as the corrected theorem predicts.

## 4. Unbounded family at fixed `g=4`

For every `k>=1`, take the cyclic word

```
A1 B1 A1 B1  A2 B2 A2 B2  ...  Ak Bk Ak Bk  U1 U2 U3 U4
```

For each paired label declare its first occurrence R and second occurrence L;
all four `Uj` are unmatched R.  Alternating temporal axes again give the
required two H and two V half-edges at every paired vertex.

Smoothing produces two open H paths, two open V paths, and `k` closed V
circuits.  For each `i`, the lifetime edges `Ai` and `Bi` are parallel edges
between the long open H component and the `i`th closed V circuit.  The four
wake edges form one 4-cycle on the open components.  Therefore

\[
m=2k,\qquad c=k,\qquad \kappa=1,
\]

and

\[
\dim Z(T)=k+1,\qquad \dim Z(T/W)=k.
\]

The directed R-to-L lifetime rows for `Ai` and `Bi` are both `Ai+Bi`.  Their
span has rank `k`; it is exactly the contracted cycle space and misses the
one wake-cycle direction in the full boundary graph.  Both the contracted
rank and the number of closed smoothed circuits are unbounded although
`g=4` is fixed.

This family is an exact counterexample to any claim derived only from the
double-occurrence/degree-2-port axioms that four wake ports bound the touch
rank.  It is not a counterexample to Langton's highway conjecture: excluding
the family would require genuinely Langton-specific information such as
unit-square-lattice realizability, direction/translation voltages, or signed
mod-four coordinate constraints.  General circuit-nullity supplies none of
those restrictions.
