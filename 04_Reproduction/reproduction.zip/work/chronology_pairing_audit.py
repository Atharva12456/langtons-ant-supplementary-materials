#!/usr/bin/env python3
"""Targeted audit of the Dyck/P3 chronology-pairing identities.

This checks only the standard period-104 trace and the six fixed g=4
near-models from ``g4_case_audit.py``.  It is deliberately not a search.
"""

from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs"))
import langton_research as lr  # noqa: E402


G4_WORDS = {
    "g4_(0,2)": "LRRLRRRR",
    "g4_(2,0)": "RLRRLRRR",
    "g4_(1,-1)": "LLLRLRRRRLRRRR",
    "g4_(1,1)": "LLRRRRLLRLRRRR",
    "g4_(2,-2)": "LLLRLRRRRLLLLRLRRRRLRRRR",
    "g4_(2,2)": "LLLRRRRLRLRLRLLRRRRLLRRR",
}


def rotate_to_minimum(word: str) -> tuple[str, int]:
    signs = [1 if symbol == "R" else -1 for symbol in word]
    height = [0]
    for sign in signs:
        height.append(height[-1] + sign)
    cut = min(range(len(word)), key=lambda index: height[index])
    return word[cut:] + word[:cut], cut


def trace_geometry(word: str) -> dict[str, object]:
    signs = [1 if symbol == "R" else -1 for symbol in word]
    height = [0]
    for sign in signs:
        height.append(height[-1] + sign)

    position = (0, 0)
    heading = 0
    positions: list[tuple[int, int]] = []
    headings: list[int] = []
    for sign in signs:
        positions.append(position)
        headings.append(heading)
        heading = (heading + sign) & 3
        position = lr.add(position, lr.DIRS[heading])
    assert heading == 0
    drift = position
    assert drift != (0, 0)

    period = len(word)
    groups: dict[
        tuple[int, int], list[tuple[int, int, int, int, int]]
    ] = defaultdict(list)
    for phase, (point, sign, preheading) in enumerate(
        zip(positions, signs, headings)
    ):
        representative, level = lr.quotient_representative_level(point, drift)
        lifted_time = phase - period * level
        groups[representative].append(
            (lifted_time, phase, level, sign, preheading)
        )
    for entries in groups.values():
        entries.sort()

    return {
        "signs": signs,
        "height": height,
        "positions": positions,
        "headings": headings,
        "drift": drift,
        "groups": groups,
    }


def dyck_matching(signs: list[int]) -> tuple[dict[int, int], list[int]]:
    stack: list[int] = []
    matching: dict[int, int] = {}
    for phase, sign in enumerate(signs):
        if sign == 1:
            stack.append(phase)
        else:
            assert stack
            matching[stack.pop()] = phase
    return matching, stack


def physical_or_surrogate_matching(
    groups: dict[
        tuple[int, int], list[tuple[int, int, int, int, int]]
    ],
    *,
    require_p3: bool,
) -> tuple[
    dict[int, tuple[int, int, int, int]],
    list[int],
    dict[tuple[int, int], str],
]:
    """Return L phase -> (R phase, tau_R, tau_L, epsilon).

    When ``require_p3`` is false, R and L entries are merely zipped within
    each translation class.  That surrogate is intentionally nonphysical;
    it tests whether the exchange congruences can detect bad chronology.
    """

    inverse: dict[int, tuple[int, int, int, int]] = {}
    unmatched: list[int] = []
    bad: dict[tuple[int, int], str] = {}
    for representative, entries in groups.items():
        stable_word = "".join("R" if entry[3] == 1 else "L" for entry in entries)
        alternating = entries[0][3] == 1 and all(
            left[3] != right[3] for left, right in zip(entries, entries[1:])
        )
        if not alternating:
            bad[representative] = stable_word

        if require_p3:
            assert alternating
            pairs = [(entries[index], entries[index + 1]) for index in range(0, len(entries) - 1, 2)]
            leftovers = entries[-1:] if len(entries) & 1 else []
        else:
            rights = [entry for entry in entries if entry[3] == 1]
            lefts = [entry for entry in entries if entry[3] == -1]
            assert len(rights) - len(lefts) in (0, 1)
            pairs = list(zip(rights, lefts))
            leftovers = rights[len(lefts) :]

        for right, left in pairs:
            tau_r, phase_r, _, sign_r, heading_r = right
            tau_l, phase_l, _, sign_l, heading_l = left
            assert sign_r == 1 and sign_l == -1
            if require_p3:
                assert tau_r < tau_l
            difference = (heading_l - heading_r) & 3
            assert difference in (0, 2)
            epsilon = difference // 2
            inverse[phase_l] = (phase_r, tau_r, tau_l, epsilon)
        unmatched.extend(entry[1] for entry in leftovers)
    return inverse, unmatched, bad


def exchange_audit(word: str, *, require_p3: bool) -> dict[str, object]:
    rotated, cut = rotate_to_minimum(word)
    geometry = trace_geometry(rotated)
    signs = geometry["signs"]
    height = geometry["height"]
    headings = geometry["headings"]
    assert isinstance(signs, list)
    assert isinstance(height, list)
    assert isinstance(headings, list)
    assert all(value >= 0 for value in height)

    dyck, dyck_unmatched = dyck_matching(signs)
    inverse, p_unmatched, bad = physical_or_surrogate_matching(
        geometry["groups"], require_p3=require_p3
    )
    growth = sum(signs)
    assert [height[phase] for phase in dyck_unmatched] == list(range(growth))
    assert len(dyck) == len(inverse)
    assert len(dyck_unmatched) == len(p_unmatched) == growth

    opposite = 0
    local_failures: list[dict[str, int]] = []
    sigma: dict[int, int] = {}
    for right, left in dyck.items():
        partner, _, _, epsilon = inverse[left]
        sigma[right] = partner
        opposite += epsilon
        residual = (height[partner] - height[right] - (1 - 2 * epsilon)) & 3
        if residual:
            local_failures.append(
                {
                    "dyck_R": right,
                    "dyck_L": left,
                    "P_R": partner,
                    "residual_mod4": residual,
                }
            )
    assert not local_failures

    m = len(dyck)
    lhs = (m - 2 * opposite) & 3
    rhs = (growth * (growth - 1) // 2 - sum(height[u] for u in p_unmatched)) & 3
    assert lhs == rhs

    # Each directed sigma component is a path or cycle.  Check its own
    # telescoping identity, not only the global finite-set identity.
    domain = set(sigma)
    image = set(sigma.values())
    starts = sorted(domain - image)
    visited: set[int] = set()
    component_checks: list[dict[str, object]] = []
    for start in starts:
        current = start
        increment = 0
        length = 0
        while current in sigma:
            assert current not in visited
            visited.add(current)
            nxt = sigma[current]
            increment += (height[nxt] - height[current])
            length += 1
            current = nxt
        component_checks.append(
            {
                "kind": "path",
                "start": start,
                "end": current,
                "steps": length,
                "telescopes": increment == height[current] - height[start],
            }
        )
    for start in sorted(domain - visited):
        current = start
        increment = 0
        length = 0
        while current not in visited:
            visited.add(current)
            nxt = sigma[current]
            increment += height[nxt] - height[current]
            length += 1
            current = nxt
        assert current == start
        component_checks.append(
            {
                "kind": "cycle",
                "start": start,
                "steps": length,
                "sum_mod4": increment & 3,
            }
        )
    assert visited == domain
    assert all(
        item.get("telescopes", True) and item.get("sum_mod4", 0) == 0
        for item in component_checks
    )

    odd_wake = sum(
        (geometry["positions"][phase][0] + geometry["positions"][phase][1]) & 1
        for phase in p_unmatched
    )
    assert (len(rotated) // 2 - odd_wake) % 2 == 0

    return {
        "rotation_to_global_minimum": cut,
        "period": len(rotated),
        "growth": growth,
        "drift": geometry["drift"],
        "p3_valid": not bad,
        "bad_stabilized_classes": [
            {"representative": representative, "word": stable_word}
            for representative, stable_word in sorted(bad.items())
        ],
        "matching_used": "physical_P3" if require_p3 else "nonchronological_surrogate",
        "dyck_pairs": m,
        "opposite_arrival_pairs": opposite,
        "wake_phases": sorted(p_unmatched),
        "global_identity_mod4": [lhs, rhs],
        "component_count": len(component_checks),
        "pairing_parity_identity": True,
    }


def standard_discrepancy_audit(word: str) -> dict[str, object]:
    rotated, cut = rotate_to_minimum(word)
    assert cut == 0
    geometry = trace_geometry(rotated)
    inverse, _, bad = physical_or_surrogate_matching(
        geometry["groups"], require_p3=True
    )
    assert not bad
    period = len(rotated)
    positions = geometry["positions"]
    drift = geometry["drift"]

    def lifted_position(time: int) -> tuple[int, int]:
        block, phase = divmod(time, period)
        return lr.add(positions[phase], lr.mul(block, drift))

    all_sizes: Counter[int] = Counter()
    parallel_sizes: Counter[int] = Counter()
    opposite_sizes: Counter[int] = Counter()
    equality_examples: list[dict[str, object]] = []
    for phase_l, (phase_r, tau_r, tau_l, epsilon) in inverse.items():
        base = lifted_position(tau_r)
        assert base == lifted_position(tau_l)
        odd_visits: set[tuple[int, int]] = set()
        # Difference between the states immediately after R and immediately
        # after L: toggle times tau_r+1,...,tau_l are included.
        for time in range(tau_r + 1, tau_l + 1):
            odd_visits.symmetric_difference_update((lifted_position(time),))
        assert base in odd_visits
        row_degrees = Counter(y for x, y in odd_visits)
        column_degrees = Counter(x for x, y in odd_visits)
        assert all(degree % 2 == 0 for degree in row_degrees.values())
        assert all(degree % 2 == 0 for degree in column_degrees.values())
        assert len(odd_visits) >= 4
        all_sizes[len(odd_visits)] += 1
        (opposite_sizes if epsilon else parallel_sizes)[len(odd_visits)] += 1
        if len(odd_visits) == 4:
            xs = {x for x, _ in odd_visits}
            ys = {y for _, y in odd_visits}
            assert len(xs) == len(ys) == 2
            assert odd_visits == {(x, y) for x in xs for y in ys}
            equality_examples.append(
                {
                    "R_phase": phase_r,
                    "L_phase": phase_l,
                    "arrival_type": "opposite" if epsilon else "parallel",
                    "base": base,
                    "four_total_cells": sorted(odd_visits),
                }
            )
    assert sum(all_sizes.values()) == 46
    assert sum(opposite_sizes.values()) == 22
    assert sum(parallel_sizes.values()) == 24
    assert sum(count for size, count in all_sizes.items() if size == 4) == 26
    assert sum(count for size, count in opposite_sizes.items() if size == 4) == 11
    return {
        "all_pair_discrepancy_size_distribution": dict(sorted(all_sizes.items())),
        "parallel_pair_discrepancy_size_distribution": dict(
            sorted(parallel_sizes.items())
        ),
        "opposite_pair_discrepancy_size_distribution": dict(
            sorted(opposite_sizes.items())
        ),
        "size_four_examples": equality_examples,
        "minimum_total_cells": min(all_sizes),
        "minimum_other_cells": min(all_sizes) - 1,
    }


def standard_oriented_chord_audit(word: str) -> dict[str, object]:
    """Check the finite period-type form of the oriented chord identity."""

    rotated, cut = rotate_to_minimum(word)
    assert cut == 0
    geometry = trace_geometry(rotated)
    period = len(rotated)
    signs = geometry["signs"]
    assert isinstance(signs, list)

    # (tau_R, tau_L, eta), with eta=+1 for parallel and -1 for opposite.
    pairs: list[tuple[int, int, int]] = []
    unmatched: list[int] = []
    for entries in geometry["groups"].values():
        stable = list(entries)
        assert stable[0][3] == 1
        assert all(a[3] != b[3] for a, b in zip(stable, stable[1:]))
        for index in range(0, len(stable) - 1, 2):
            right, left = stable[index], stable[index + 1]
            eta = 1 if right[4] == left[4] else -1
            pairs.append((right[0], left[0], eta))
        if len(stable) & 1:
            unmatched.append(stable[-1][0])

    def open_copy_count(tau: int, lower: int, upper: int) -> int:
        # Exact count of n with lower < tau+n*period < upper.
        first = (lower - tau) // period - 1
        last = (upper - tau) // period + 1
        return sum(
            1
            for level in range(first, last + 1)
            if lower < tau + level * period < upper
        )

    pair_count = len(pairs)
    k_matrix = [[0] * pair_count for _ in range(pair_count)]
    h_matrix = [[0] * len(unmatched) for _ in range(pair_count)]
    rotations: list[int] = []
    for row, (tau_r, tau_l, eta) in enumerate(pairs):
        for column, (other_r, other_l, _) in enumerate(pairs):
            k_matrix[row][column] = open_copy_count(
                other_r, tau_r, tau_l
            ) - open_copy_count(other_l, tau_r, tau_l)
        for column, tau_u in enumerate(unmatched):
            h_matrix[row][column] = open_copy_count(tau_u, tau_r, tau_l)

        interior_turn_sum = sum(signs[time % period] for time in range(tau_r + 1, tau_l))
        assert (eta + interior_turn_sum) % 4 == 0
        rotation = (eta + interior_turn_sum) // 4
        rotations.append(rotation)
        assert eta + sum(k_matrix[row]) + sum(h_matrix[row]) == 4 * rotation

    assert all(k_matrix[index][index] == 0 for index in range(pair_count))
    assert all(
        k_matrix[row][column] == -k_matrix[column][row]
        for row in range(pair_count)
        for column in range(pair_count)
    )
    eta_sum = sum(eta for _, _, eta in pairs)
    h_sum = sum(sum(row) for row in h_matrix)
    assert eta_sum + h_sum == 4 * sum(rotations)
    return {
        "pair_types": pair_count,
        "unmatched_types": len(unmatched),
        "aggregate_K_is_skew_symmetric": True,
        "eta_sum": eta_sum,
        "unmatched_containment_sum": h_sum,
        "rotation_sum": sum(rotations),
        "exact_summed_identity": [eta_sum + h_sum, 4 * sum(rotations)],
        "rotation_distribution": dict(sorted(Counter(rotations).items())),
    }


def binary_rank(rows: list[int], columns: int) -> int:
    basis: dict[int, int] = {}
    mask = (1 << columns) - 1
    for row in rows:
        value = row & mask
        while value:
            pivot = value.bit_length() - 1
            if pivot in basis:
                value ^= basis[pivot]
            else:
                basis[pivot] = value
                break
    return len(basis)


def standard_boundary_touchgraph_audit(word: str) -> dict[str, object]:
    """Build the finite phase-cylinder H/V smoothing and check its ranks."""

    rotated, cut = rotate_to_minimum(word)
    assert cut == 0
    geometry = trace_geometry(rotated)
    period = len(rotated)
    positions = geometry["positions"]
    headings = geometry["headings"]
    signs = geometry["signs"]
    assert isinstance(positions, list)
    assert isinstance(headings, list)
    assert isinstance(signs, list)

    outgoing_headings = [
        (heading + sign) & 3 for heading, sign in zip(headings, signs)
    ]
    pairs: list[tuple[int, int, int, int]] = []
    unmatched: list[tuple[int, int]] = []
    for entries in geometry["groups"].values():
        stable = list(entries)
        for index in range(0, len(stable) - 1, 2):
            right, left = stable[index], stable[index + 1]
            pairs.append((right[0], left[0], right[1], left[1]))
        if len(stable) & 1:
            unmatched.append((stable[-1][0], stable[-1][1]))

    parent = list(range(period))

    def find(edge: int) -> int:
        while parent[edge] != edge:
            parent[edge] = parent[parent[edge]]
            edge = parent[edge]
        return edge

    def union(left: int, right: int) -> None:
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    for _, _, phase_r, phase_l in pairs:
        half_edges: list[tuple[int, int]] = []
        for phase in (phase_r, phase_l):
            half_edges.append(((phase - 1) % period, headings[phase] & 1))
            half_edges.append((phase, outgoing_headings[phase] & 1))
        assert Counter(orientation for _, orientation in half_edges) == Counter(
            {0: 2, 1: 2}
        )
        for orientation in (0, 1):
            same_type = [
                edge for edge, edge_type in half_edges if edge_type == orientation
            ]
            union(same_type[0], same_type[1])

    components: dict[int, list[int]] = defaultdict(list)
    for edge in range(period):
        components[find(edge)].append(edge)
    port_count: Counter[int] = Counter()
    wake_incidence: list[tuple[int, int]] = []
    for _, phase in unmatched:
        incoming = find((phase - 1) % period)
        outgoing = find(phase)
        assert incoming != outgoing
        port_count[incoming] += 1
        port_count[outgoing] += 1
        wake_incidence.append((incoming, outgoing))
    assert all(port_count[component] in (0, 2) for component in components)

    closed = [component for component in components if port_count[component] == 0]
    open_components = [
        component for component in components if port_count[component] == 2
    ]
    assert len(open_components) == len(unmatched)

    wake_parent = {component: component for component in open_components}

    def wake_find(component: int) -> int:
        while wake_parent[component] != component:
            wake_parent[component] = wake_parent[wake_parent[component]]
            component = wake_parent[component]
        return component

    def wake_union(left: int, right: int) -> None:
        left, right = wake_find(left), wake_find(right)
        if left != right:
            wake_parent[right] = left

    for left, right in wake_incidence:
        wake_union(left, right)
    wake_cycle_count = len({wake_find(component) for component in open_components})

    def open_copy_count(tau: int, lower: int, upper: int) -> int:
        first = (lower - tau) // period - 1
        last = (upper - tau) // period + 1
        return sum(
            1
            for level in range(first, last + 1)
            if lower < tau + level * period < upper
        )

    pair_count = len(pairs)
    rows: list[int] = []
    for row, (tau_r, tau_l, _, _) in enumerate(pairs):
        vector = 1 << row
        for column, (other_r, other_l, _, _) in enumerate(pairs):
            if (
                open_copy_count(other_r, tau_r, tau_l)
                + open_copy_count(other_l, tau_r, tau_l)
            ) & 1:
                vector ^= 1 << column
        for column, (tau_u, _) in enumerate(unmatched):
            if open_copy_count(tau_u, tau_r, tau_l) & 1:
                vector ^= 1 << (pair_count + column)
        rows.append(vector)

    projected_rank = binary_rank(rows, pair_count)
    full_rank = binary_rank(rows, pair_count + len(unmatched))
    contracted_cycle_rank = (
        pair_count - len(closed) - wake_cycle_count + 1
    )
    boundary_cycle_rank = pair_count - len(closed) + 1
    assert projected_rank == contracted_cycle_rank
    assert full_rank <= boundary_cycle_rank
    return {
        "paired_vertices": pair_count,
        "wake_ports": len(unmatched),
        "closed_HV_circuits": len(closed),
        "open_HV_trails": len(open_components),
        "wake_subgraph_cycles": wake_cycle_count,
        "contracted_touch_cycle_rank": contracted_cycle_rank,
        "projected_lifetime_row_rank": projected_rank,
        "boundary_touch_cycle_rank": boundary_cycle_rank,
        "full_lifetime_row_rank": full_rank,
        "missing_boundary_dimensions": boundary_cycle_rank - full_rank,
    }


if __name__ == "__main__":
    standard = (ROOT / "work" / "standard_cyclic_min_trace.txt").read_text().strip()
    report = {
        "standard_exchange": exchange_audit(standard, require_p3=True),
        "standard_all_lifetime_discrepancy": standard_discrepancy_audit(standard),
        "standard_oriented_chord": standard_oriented_chord_audit(standard),
        "standard_boundary_touchgraph": standard_boundary_touchgraph_audit(
            standard
        ),
        "g4_surrogate_hostile_tests": {
            name: exchange_audit(word, require_p3=False)
            for name, word in G4_WORDS.items()
        },
    }
    print(json.dumps(report, indent=2))
