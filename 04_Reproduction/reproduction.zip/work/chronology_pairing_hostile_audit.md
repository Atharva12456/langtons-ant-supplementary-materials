# Hostile audit of the chronology-pairing and interlacement route

**Date:** 14 July 2026  
**Scope:** exact periodic translators only.  This note does not claim a
classification or a proof of the universal highway conjecture.

## 1. Audit verdict

1. The Dyck matching and the physical P3 matching are legitimate finite
   matchings on phase vertices.  The period/level voltage is harmless in the
   mod-four exchange calculation because the growth is divisible by four.
2. The pairing-parity identity and the oriented exchange identities are
   correct.  They are useful bookkeeping, but by themselves they are not a
   new obstruction: the same component identities hold for any arbitrary
   within-class R--L matching, even one that ignores stabilized chronology.
3. The same-pose discrepancy theorem is correct.  The first draft of its
   lifetime corollary incorrectly said "four other cells."  The paired cell
   itself belongs to the discrepancy, so the correct conclusion is at least
   four cells total and at least three other cells.  A stronger theorem below
   proves this for **every** physical P lifetime, not only opposite-arrival
   lifetimes.
4. There is a rigorous voltage interlacement formula, including a signed
   skew-reciprocity and an exact rotation identity.  A direct Cohn--Lempel
   rank/nullity conclusion is not currently justified; the precise failure
   of the classical hypotheses is recorded in Section 6.

## 2. Actual-cell meaning of a phase-level P edge

Index a state immediately before turn `t` by

\[
(B_t,p_t,q_t),
\]

and put `s_t=+1` for R and `s_t=-1` for L.  Thus turn `t` toggles
`p_t`, changes the heading by `s_t`, and moves to `p_{t+1}`.  For a
periodic trace of length `N`, drift `d`, and restored heading, extend the
phase data by

\[
p_{i+kN}=p_i+kd,\qquad q_{i+kN}=q_i,\qquad s_{i+kN}=s_i.
\tag{2.1}
\]

Fix one translation class and write a phase position as

\[
p_i=b+a_i d.
\]

Define its lifted time

\[
\tau_i=i-Na_i.
\tag{2.2}
\]

The occurrence of phase `i` at the actual cell `b+nd` is in period
`n-a_i`, hence occurs at the actual time

\[
i+N(n-a_i)=nN+\tau_i.
\tag{2.3}
\]

Consequently the stabilized order "decreasing level, then increasing phase"
is exactly increasing lifted time `tau`.  P3 gives a word

\[
R,L,R,L,\ldots
\]

in that order.  A consecutive P pair with lifted times
`r_e<l_e` therefore gives a genuine consecutive R--L lifetime of the actual
cell `b+nd` at times

\[
r_e+nN<l_e+nN
\tag{2.4}
\]

whenever those periods lie in the repeating regime; in particular this holds
for every sufficiently large `n`.  Allowing all integer `n` below is a formal
periodic lift.  Any finite collection of its intervals becomes an actual
forward-orbit collection after adding one sufficiently large common period
shift.  This proves that P is a true phase matching, not merely a matching
after projection to the translation quotient.

For the exchange congruences, let `h_i` be the normalized cumulative turn
height in one period.  At the occurrence (2.3), the extended height differs
from `h_i` by `(n-a_i)g`.  Since restored heading gives

\[
g\equiv0\pmod4,
\]

the level voltage disappears modulo four.  Similarly `N` is even, so it
does not alter phase parity.  These are the exact reasons that phase vertices
suffice in the mod-two and mod-four exchange proofs.

## 3. Exchange identities: correct, but not an independent obstruction

Rotate the word to a global minimum of its cumulative turn walk.  Stack
matching gives the Dyck matching D and leaves R phases at pre-turn heights
`0,1,...,g-1`.  P3 gives the physical matching P and leaves one wake R in
each odd class.  D edges reverse phase parity; P edges preserve it because
the drift has even checkerboard parity.  The alternating union of D and P
therefore proves

\[
\frac N2\equiv O\pmod2,
\tag{3.1}
\]

where `O` is the number of odd-checker wake bases.

For a D pair `r -> l`, let `r'` be the R phase physically P-paired with
`l`.  Put `epsilon=0` if the P endpoints have the same arrival heading and
`epsilon=1` if their headings are opposite.  Dyck matching gives
`h_l=h_r+1`, while the P endpoint headings give

\[
h_{r'}-h_r\equiv1-2\epsilon\pmod4.
\tag{3.2}
\]

Summation over the partial bijection gives the audited identity

\[
m-2E\equiv \frac{g(g-1)}2-\sum_{u\in U_P}h_u\pmod4,
\tag{3.3}
\]

and summation on an individual exchange component gives the corresponding
cycle or path equation.

The limitation is exact.  Suppose a word has class excess zero or one, but
its stabilized words are not alternating.  Pair the R and L phases in each
class by any bijection and leave the excess R unmatched.  Equation (3.2)
still holds: it uses only the Dyck relation and the fact that two phases in
one translation class have arrival headings equal or opposite.  Every
component and global telescoping formula therefore still holds.  The P3
information lost by (3.2) is precisely

\[
\tau_R<\tau_L\quad\text{and no same-cell occurrence lies between them.}
\tag{3.4}
\]

The six fixed `g=4` near-models confirm this limitation without a search.
Using one deterministic, deliberately nonchronological within-class
matching gives:

| drift | surrogate E | two sides of (3.3) mod 4 |
|---|---:|---:|
| `(0,2)` | 1 | `0=0` |
| `(2,0)` | 1 | `0=0` |
| `(1,-1)` | 2 | `1=1` |
| `(1,1)` | 3 | `3=3` |
| `(2,-2)` | 4 | `2=2` |
| `(2,2)` | 6 | `2=2` |

All six fail (3.4), hence fail P3, but all local, component, and global
exchange congruences pass.  The exchange graph is therefore a useful
normal form, not yet a new exclusion theorem.  On the standard 104 trace,
the exact physical calculation gives `g=12`, `m=46`, `E=22`, wake-height
sum `124`, and both sides of (3.3) equal `2 mod 4`.

## 4. All-lifetimes Eulerian discrepancy theorem

### Theorem 4.1 (consecutive-lifetime Eulerian discrepancy)

Let `r<l` be one actual P-paired lifetime supplied by (2.4).  Thus

\[
p_r=p_l=z,\qquad s_r=+1,\qquad s_l=-1,
\]

and `z` is not visited at any time strictly between `r` and `l`.  Define the
odd-visit set

\[
S=\left\{x:\#\{t\in[r,l):p_t=x\}\text{ is odd}\right\}.
\tag{4.1}
\]

Then:

1. the two natural color discrepancies have the same support,

   \[
   S=B_r\mathbin\triangle B_l
    =B_{r+1}\mathbin\triangle B_{l+1};
   \tag{4.2}
   \]

2. `z` belongs to `S` and every exact row and exact column contains an even
   number of cells of `S`;
3. in the bipartite incidence graph whose vertices are exact rows and exact
   columns and whose cell `(x,y)` is the edge `C_x R_y`, every vertex has
   even degree, and the edge belonging to `z` lies on a cycle;
4. consequently `S` contains at least four cells, including at least three
   distinct cells other than `z`; if it contains exactly four, they are the
   corners of a nondegenerate axis-aligned rectangle.

**Proof.**  The first symmetric difference in (4.2) is produced by the
toggles at times `r,...,l-1`.  The second is produced by the toggles at
times `r+1,...,l`.  These multisets differ only by replacing the occurrence
`p_r=z` by the identical occurrence `p_l=z`, proving (4.2).
Consecutiveness says that `z` occurs exactly once in either multiset, so
`z in S`.

The moves at times `r,...,l-1` form a closed lattice walk.  Successive moves
alternate horizontal and vertical orientation.  Closure forces equally many
east/west and north/south moves; hence both the horizontal and vertical move
counts are even.  The alternating sequence is therefore cyclically
alternating.  Pair every horizontal move with the following vertical move.
The starting cells of
the two moves lie in the same exact row, so every row contains an even total
number of visits, counted with multiplicity.  Pairing every vertical move
with the following horizontal move proves the analogous column statement.
Passing to odd multiplicities gives item 2.

The row--column incidence graph of `S` is therefore finite and Eulerian.
Every edge of a finite even-degree graph lies on a cycle.  A simple bipartite
cycle has length at least four, proving item 4.  With exactly four edges the
cycle is a 4-cycle, which is exactly an axis-aligned rectangle.  QED.

This proof is kinematic and applies to parallel and opposite arrivals alike;
it does not need the no-corners theorem or a same-pose comparison.

### Theorem 4.2 (signed aligned-pose refinement)

Let

\[
\epsilon_e=\begin{cases}
0,&q_l=q_r,\\
1,&q_l=q_r+2,
\end{cases}
\qquad \eta_e=1-2\epsilon_e.
\tag{4.3}
\]

If `epsilon_e=0`, compare the pre-turn states at `r,l`; they have the same
directed pose and `z` changes white to black, with endpoint sign `+1`.
If `epsilon_e=1`, compare the post-move states at `r+1,l+1`; R sends heading
`q_r` to `q_r+1`, while L sends `q_r+2` to the same heading and neighboring
cell.  These post-move poses agree, and `z` changes black to white, with
endpoint sign `-1`.  In either convention define

\[
\Delta_e(x)=\mathbf1_{B_t}(x)-\mathbf1_{B_s}(x).
\]

Its support is the same set `S` in (4.2), and

\[
\Delta_e(z)=\eta_e.
\tag{4.4}
\]

The exact checker-signed mod-four charges now give, for every exact column
`x=c` and exact row `y=c`,

\[
\sum_{(x,y)\in S:x=c}\Delta_e(x,y)(-1)^{x+y}\equiv0\pmod4,
\tag{4.5}
\]

\[
\sum_{(x,y)\in S:y=c}\Delta_e(x,y)(-1)^{x+y}\equiv0\pmod4.
\tag{4.6}
\]

If equality `|S|=4` holds, write its corners relative to the paired corner
as

\[
z,\quad z+(a,0),\quad z+(0,b),\quad z+(a,b),\qquad ab\ne0.
\]

The four endpoint signs are forced to be

\[
\boxed{
\eta_e,\quad(-1)^{a+1}\eta_e,\quad
(-1)^{b+1}\eta_e,\quad(-1)^{a+b}\eta_e.}
\tag{4.7}
\]

Indeed, each two-cell row and column in (4.5)--(4.6) has two unit terms;
their signed-checker values must be opposite.  Propagation from `z` gives
(4.7).

Every other cell of `S` is supplied by an odd number of endpoints of other
physical lifetimes crossing one of the two temporal cuts, or by an unmatched
wake R event inside the interval.  Theorem 4.1 therefore forces at least
three distinct such other cells/events for every P lifetime.

The bound is sharp in the standard trace.  Among its 46 physical P pair
types, 26 have `|S|=4`: 15 parallel-arrival and 11 opposite-arrival pairs.
For example, the opposite pair at phases 44 and 48 has

\[
S=\{(0,0),(0,1),(1,0),(1,1)\}.
\]

## 5. Voltage-aware interlacement formula

The finite phase labels alone are insufficient when a lifetime spans more
than one period.  Retain the integral voltage explicitly.

Let `E` be the finite set of physical P pair types and `U` the `g` unmatched
wake types.  For `e in E`, choose its level-zero copy with actual cell `c_e`
and lifted interval `(r_e,l_e)`.  Copy `n` of type `f` has endpoints

\[
r_f+nN,\qquad l_f+nN,
\]

and cell `c_f+nd`.  Define over `F_2`

\[
A_{ef,n}=1
\]

exactly when **one** endpoint of copy `f,n` lies strictly inside
`(r_e,l_e)`, and put it zero otherwise.  For an unmatched type `u`, put

\[
U_{eu,n}=1\quad\Longleftrightarrow\quad r_e<u+nN<l_e.
\]

Only finitely many coefficients in each row are nonzero.  The odd-visit
vector of Theorem 4.1 is exactly

\[
\boxed{
v_e=\delta_{c_e}
+\sum_{f,n}A_{ef,n}\delta_{c_f+nd}
+\sum_{u,n}U_{eu,n}\delta_{c_u+nd}.}
\tag{5.1}
\]

Let

\[
\partial\delta_{(x,y)}=C_x+R_y
\]

be the row--column incidence boundary.  Theorem 4.1 is equivalently the
finite-support voltage equation

\[
\boxed{\partial v_e=0\quad\text{for every }e.}
\tag{5.2}
\]

If

\[
A_{ef}(T)=\sum_n A_{ef,n}T^n,
\]

then endpoint alternation gives the reciprocity

\[
A_{ef}(T)=A_{fe}(T^{-1}).
\tag{5.3}
\]

The diagonal Laurent polynomial need not vanish: a long lifetime can
interlace shifted copies of its own type, producing paired terms
`T^n+T^{-n}`.  This is one reason not to replace the voltage matrix silently
by an ordinary finite chord matrix.

There is also an integral oriented form.  Put

\[
K_{ef,n}=
\begin{cases}
+1,&r_f+nN\in(r_e,l_e),\ l_f+nN\notin(r_e,l_e),\\
-1,&l_f+nN\in(r_e,l_e),\ r_f+nN\notin(r_e,l_e),\\
0,&\text{otherwise}.
\end{cases}
\tag{5.4}
\]

Then the aligned signed endpoint difference in Theorem 4.2 is exactly

\[
\boxed{
\Delta_e=\eta_e\delta_{c_e}
+\sum_{f,n}K_{ef,n}\delta_{c_f+nd}
+\sum_{u,n}U_{eu,n}\delta_{c_u+nd}.}
\tag{5.5}
\]

Interlaced intervals occur in opposite orientations when their roles are
reversed, so

\[
\boxed{K_{ef,n}=-K_{fe,-n}.}
\tag{5.6}
\]

Pairing (5.5) with any admissible mod-four black-cell weight gives zero,
because its two endpoint states have the same directed pose.  Exact-column
and exact-row checker weights recover (4.5)--(4.6).

For the constant weight, there is an exact integer lift.  Close the lattice
walk from `r_e` to `l_e` at its base cell.  The missing closure corner is R
for parallel arrivals and L for opposite arrivals, hence has sign `eta_e`.
If `omega_e` is the integer rotation number of this closed walk, then

\[
\boxed{
\eta_e+\sum_{f,n}K_{ef,n}+\sum_{u,n}U_{eu,n}=4\omega_e.}
\tag{5.7}
\]

After summing the voltage coefficients over `n`, (5.6) makes the finite
aggregate K matrix skew-symmetric.  Summing (5.7) over pair types therefore
gives

\[
\boxed{
m-2E+H_{\rm tot}=4\sum_e\omega_e,}
\tag{5.8}
\]

where `H_tot` is the total number of unmatched-wake copies strictly
contained in the chosen pair intervals.  This is a proved, genuinely
voltage-aware chord/rotation identity.  It is not yet a contradiction.

On the standard 104 trace, the targeted audit finds 46 pair types, 12
unmatched types, `m-2E=2`, `H_tot=190`, and rotation sum 48, so (5.8) reads

\[
192=192.
\]

## 6. Exact touch-graph reduction and the remaining boundary kernel

The finite phase cylinder gives a valid partial touch-graph construction.
Identify the two phase occurrences of every physical P pair.  Paired
lifetimes become 4-valent vertices of the temporal phase circuit, while the
`g` unmatched wake events remain degree-2 H/V switches.  At every paired
vertex, H/H and V/V smoothing is the `psi` transition relative to the
temporal Euler circuit: the two incoming half-edges have the same H/V type,
and the two outgoing half-edges have the other type.  Consequently the
closed double-occurrence modified matrix is exactly `I+A`.

Cut the degree-2 wake switches.  The smoothing gives `g/2` open H paths,
`g/2` open V paths, and an unbounded possible collection of `c` closed H/V
circuits.  Form `T_boundary` with these components as vertices, physical
lifetimes as ordinary edges, and unmatched wake events as distinguished wake
edges.  The wake subgraph `W` is 2-regular on the `g` open components, hence
is a union of `kappa` even cycles.

Suppressing the degree-2 wake switches in the temporal graph gives an
ordinary connected 4-regular graph with an Euler circuit.  Its H/V circuit
partition has touch graph

\[
T_0=T_{\rm boundary}/W.
\tag{6.1}
\]

Traldi's fundamental-circuit theorem now applies without conjecture.  After
the wake coordinates of (5.1) are deleted, the physical lifetime rows span
the entire cycle space of `T_0`.  Extra full period laps caused by level
voltage meet every paired vertex twice and therefore vanish on these matched
coordinates.  With `m` paired lifetimes,

\[
\dim Z(T_0)=m-c-\kappa+1.
\tag{6.2}
\]

The full boundary graph has

\[
\dim Z(T_{\rm boundary})=m-c+1,
\]

and the kernel of contraction to `T_0` is `Z(W)`, of dimension `kappa`.
Thus the lifetime rows span the full boundary cycle space only up to at most
`kappa` wake-cycle directions.  This is the precise remaining rank problem.

For `g=4`, there are two open paths of each orientation.  The wake subgraph
is either one 4-cycle (`kappa=1`) or two doubled H--V edges (`kappa=2`).  Both
are allowable; arbitrarily many closed H/V circuits may still occur.  The
coordinate-residue wake skeleton does not determine the smoothed-trail
vertex partition, so no `g=4` contradiction follows.

The standard trace is a sharp targeted check: `m=46`, `g=12`, `c=5`, and
`kappa=1`.  Traldi predicts contracted rank 41, and the projected lifetime
matrix has rank 41.  The full boundary cycle space has dimension 42, while
the full lifetime matrix still has rank 41.  Its missing dimension is the
wake cycle.  Therefore the stronger claim that physical lifetime rows always
span the uncontracted boundary touch graph is false even for the standard
highway.

The unresolved lemma is to control the `Z(W)` lift and the unbounded closed
H/V circuits using voltage, square-lattice labels, or signed mod-four data.
General circuit-nullity alone cannot do this.

## 7. Reproducibility

`work/chronology_pairing_audit.py` performs only the narrow tests cited in
this note: the standard period-104 trace and the six fixed `g=4` near-models.
It checks the exchange identities, the all-lifetimes Eulerian discrepancy,
the sharp four-cell cases, skewness of the aggregate oriented matrix, and
the exact rotation sum.  Its deterministic output is
`work/chronology_pairing_audit.json`.
