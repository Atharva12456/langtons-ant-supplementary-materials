"""Independent fixed-trace seed audit; no project-code imports.

Read the authoritative 104-word and seed, reconstruct exact translation
classes, compare direct first-visit seeds to the alternating level-gap
formula, and audit every cyclic phase in its normalized origin/N pose.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


SOURCE = Path(__file__).resolve().with_name("sts_sample_report.tex")
RECORD = SOURCE.parents[2] / "langtons-ant-highway/results/standard_highway.json"
OUTPUT = Path(__file__).with_suffix(".json")
UNITS = ((0, 1), (1, 0), (0, -1), (-1, 0))


def rotate(point, clockwise_quarters):
    x, y = point
    for _ in range(clockwise_quarters % 4):
        x, y = y, -x
    return (x, y)


def multiple(delta, drift):
    axis = 0 if drift[0] else 1
    if delta[axis] % drift[axis]:
        return None
    level = delta[axis] // drift[axis]
    return level if tuple(level * x for x in drift) == delta else None


def walk(word):
    positions, headings = [], []
    position, heading = (0, 0), 0
    for letter in word:
        positions.append(position)
        headings.append(heading)
        heading = (heading + (1 if letter == "R" else -1)) % 4
        step = UNITS[heading]
        position = tuple(a + b for a, b in zip(position, step))
    assert heading == 0 and position != (0, 0)
    return positions, headings, position


def canonical(word):
    positions, headings, drift = walk(word)
    length = len(word)
    classes = []
    for phase, point in enumerate(positions):
        for record in classes:
            delta = tuple(a - b for a, b in zip(point, record["representative"]))
            level = multiple(delta, drift)
            if level is not None:
                record["events"].append((level, phase, word[phase]))
                break
        else:
            classes.append({"representative": point, "events": [(0, phase, word[phase])]})
    seed = set()
    records = []
    for record in classes:
        events = sorted(record["events"], key=lambda event: (-event[0], event[1]))
        assert events == sorted(events, key=lambda event: event[1] - length * event[0])
        stable = "".join(event[2] for event in events)
        assert stable == "RL" * (len(stable) // 2) + ("R" if len(stable) % 2 else "")
        lower, upper = min(event[0] for event in events), max(event[0] for event in events)
        direct_levels = []
        for level in range(lower, upper):
            boundary = [event for event in events if event[0] <= level]
            actual = sorted(boundary, key=lambda event: event[1] + length * (level - event[0]))
            assert actual == boundary
            boundary_word = "".join(event[2] for event in boundary)
            assert all(a != b for a, b in zip(boundary_word, boundary_word[1:]))
            if boundary_word.startswith("L"):
                direct_levels.append(level)
        formula_levels = [level for j in range(0, len(events) - 1, 2)
                          for level in range(events[j + 1][0], events[j][0])]
        gap_count = sum(events[j][0] - events[j + 1][0] for j in range(0, len(events) - 1, 2))
        assert sorted(direct_levels) == sorted(formula_levels)
        assert len(direct_levels) == gap_count
        representative = record["representative"]
        cells = [tuple(b + level * d for b, d in zip(representative, drift)) for level in direct_levels]
        assert seed.isdisjoint(cells)
        seed.update(cells)
        records.append({"representative": representative, "stable_word": stable,
                        "ordered_levels": [event[0] for event in events],
                        "ordered_phases": [event[1] for event in events],
                        "seed_count_gap_formula": gap_count, "seed_cells": sorted(cells),
                        "minimum_level": lower, "maximum_level": upper})
    return seed, records, positions, headings, drift


def in_visited(point, classes, drift):
    for record in classes:
        delta = tuple(a - b for a, b in zip(point, record["representative"]))
        level = multiple(delta, drift)
        if level is not None:
            return level >= record["minimum_level"]
    return False


def main():
    source_text = SOURCE.read_text(encoding="utf-8-sig")
    witness = source_text.split("\\section{A realised highway attaining width ten}", 1)[1]
    displayed_word = witness.split("\\begin{minipage}", 1)[1].split("\\end{minipage}", 1)[0]
    word = "".join(re.findall(r"^[RL]+", displayed_word, flags=re.MULTILINE))
    displayed_seed = witness.split("The seed supplied by", 1)[1].split("\\[", 1)[1].split("\\]", 1)[0]
    listed_seed = {tuple(map(int, point)) for point in re.findall(r"\((-?\d+),(-?\d+)\)", displayed_seed)}
    archived = json.loads(RECORD.read_text(encoding="utf-8-sig"))
    assert word == archived["normalisation_A"]["turn_word"]
    seed, classes, positions, headings, drift = canonical(word)
    assert seed == listed_seed == {tuple(point) for point in archived["normalisation_A"]["seed_cells_11"]}
    assert (len(word), drift, len(seed)) == (104, (2, -2), 11)
    assert len(classes) == 22 and sum(len(record["stable_word"]) % 2 for record in classes) == 12
    phase_records = []
    forward_black = set(seed)
    for shift in range(len(word)):
        shifted = word[shift:] + word[:shift]
        phase_seed, phase_classes, phase_positions, _, phase_drift = canonical(shifted)
        assert phase_drift == rotate(drift, -headings[shift])
        normalized_black = {rotate(tuple(a - b for a, b in zip(point, positions[shift])), -headings[shift])
                            for point in forward_black}
        assert {point for point in normalized_black if in_visited(point, phase_classes, phase_drift)} == phase_seed
        extras = normalized_black - phase_seed
        assert all(not in_visited(point, phase_classes, phase_drift) for point in extras)
        for relative_phase, normalized_position in enumerate(phase_positions):
            total_phase = shift + relative_phase
            original_position = positions[total_phase % len(word)]
            translated = tuple(a + (total_phase // len(word)) * d - b
                               for a, d, b in zip(original_position, drift, positions[shift]))
            assert normalized_position == rotate(translated, -headings[shift])
        phase_records.append({"shift": shift, "first_turn": shifted[0], "original_pose": positions[shift],
                              "original_heading": headings[shift], "normalized_drift": phase_drift,
                              "canonical_seed_count": len(phase_seed), "canonical_seed": sorted(phase_seed),
                              "forward_state_black_count": len(normalized_black),
                              "forward_state_unvisited_extra_count": len(extras)})
        point = positions[shift]
        assert (point not in forward_black) == (word[shift] == "R")
        forward_black.symmetric_difference_update({point})
    shifted_b = phase_records[100]
    assert tuple(shifted_b["normalized_drift"]) == tuple(archived["normalisation_B"]["drift"])
    assert {tuple(point) for point in shifted_b["canonical_seed"]} == {tuple(point) for point in archived["normalisation_B"]["seed_cells_13"]}
    counts = Counter(record["canonical_seed_count"] for record in phase_records)
    minimum, maximum = min(counts), max(counts)
    result = {"status": "PASS", "scope": "Immediate w^omega, fixed word phase, origin and heading; all phases separately normalized by translation and rotation only.",
              "implementation": "Independent literal walk and pairwise exact drift multiples; direct boundary words compared to gap formula; no project-code imports.",
              "source_path": str(SOURCE), "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              "record_path": str(RECORD), "record_sha256": hashlib.sha256(RECORD.read_bytes()).hexdigest(),
              "word_sha256": hashlib.sha256(word.encode("ascii")).hexdigest(),
              "word_length": len(word), "normalisation_A_drift": drift, "normalisation_A_seed": sorted(seed),
              "normalisation_A_class_records": classes,
              "all_phase_count_distribution": {str(k): v for k, v in sorted(counts.items())},
              "all_phase_minimum_seed_count": minimum, "all_phase_maximum_seed_count": maximum,
              "all_phase_minimum_shifts": [record["shift"] for record in phase_records if record["canonical_seed_count"] == minimum],
              "all_phase_maximum_shifts": [record["shift"] for record in phase_records if record["canonical_seed_count"] == maximum],
              "all_phase_forward_state_intersection_checks": True, "normalisation_B_match_at_shift_100": True,
              "phase_records": phase_records}
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({key: result[key] for key in ("status", "all_phase_count_distribution", "all_phase_minimum_seed_count", "all_phase_maximum_seed_count", "all_phase_minimum_shifts", "all_phase_maximum_shifts", "normalisation_B_match_at_shift_100")}, indent=2))


if __name__ == "__main__":
    main()
