"""Independent standard-word check of the periodic lifetime occupancy formula.

No project-code imports. Lifetime sets are compared with first-remaining-event
seeds at every cyclic phase and selected negative/positive absolute cuts.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import re

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sts_sample_report.tex"
UNITS = ((0, 1), (1, 0), (0, -1), (-1, 0))


def add(p, d, k):
    return (p[0] + k*d[0], p[1] + k*d[1])


def multiple(delta, d):
    axis = 0 if d[0] else 1
    if delta[axis] % d[axis]:
        return None
    k = delta[axis] // d[axis]
    return k if delta == (k*d[0], k*d[1]) else None


def group(points, word, d):
    classes = []
    for i, p in enumerate(points):
        for base, entries in classes:
            k = multiple((p[0]-base[0], p[1]-base[1]), d)
            if k is not None:
                entries.append((i, k, word[i]))
                break
        else:
            classes.append((p, [(i, 0, word[i])]))
    return classes


def boundary_seed(points, word, d):
    """Literal first future event at each boundary physical cell."""
    seed = set()
    for base, entries in group(points, word, d):
        lo = min(k for _, k, _ in entries)
        hi = max(k for _, k, _ in entries)
        for n in range(lo, hi+1):
            events = sorted((i+len(word)*(n-k), w)
                            for i, k, w in entries if k <= n)
            assert events and all(a[1] != b[1] for a, b in zip(events, events[1:]))
            if events[0][1] == "L":
                assert n < hi
                seed.add(add(base, d, n))
    return seed


def ceildiv(a, b):
    return -((-a)//b)


def main():
    raw = SOURCE.read_bytes()
    text = raw.decode("utf-8-sig")
    witness = text.split("\\section{A realised highway attaining width ten}", 1)[1]
    display = witness.split("\\begin{minipage}", 1)[1].split("\\end{minipage}", 1)[0]
    word = "".join(re.findall(r"^[RL]+", display, flags=re.MULTILINE))
    N = len(word)
    assert N == 104
    points, p, q = [], (0, 0), 0
    for w in word:
        points.append(p)
        q = (q + (1 if w == "R" else -1)) % 4
        p = add(p, UNITS[q], 1)
    d = p
    assert q == 0 and d == (2, -2)
    pairs = []
    terminal_phases = []
    for base, entries in group(points, word, d):
        events = sorted((i-N*k, w, i, k) for i, k, w in entries)
        stable = "".join(e[1] for e in events)
        assert stable == "RL"*(len(stable)//2) + ("R" if len(stable)%2 else "")
        if len(events) % 2:
            terminal_phases.append(events[-1][2])
        for j in range(0, len(events)-1, 2):
            r, l = events[j][0], events[j+1][0]
            assert l > r and (l-r)%4 == 0
            pairs.append((base, r, l))
    m = len(pairs)
    g = word.count("R")-word.count("L")
    assert 2*m+g == N
    counts = []
    cuts = list(range(N+1)) + [-2*N, -N-1, -N, -1, 2*N, 2*N+17]
    for s in cuts:
        occupied = []
        count_formula = 0
        for base, r, l in pairs:
            low = ceildiv(s-l, N)
            high = ceildiv(s-r, N)-1
            occupied.extend(add(base, d, n) for n in range(low, high+1))
            count_formula += ceildiv(s-r, N)-ceildiv(s-l, N)
        assert len(set(occupied)) == len(occupied) == count_formula
        suffix_points = [add(points[(s+i)%N], d, (s+i)//N) for i in range(N)]
        suffix_word = "".join(word[(s+i)%N] for i in range(N))
        direct = boundary_seed(suffix_points, suffix_word, d)
        assert set(occupied) == direct
        if 0 <= s < N:
            counts.append(len(direct))
    h = math.gcd(N,4)
    buckets = [sum(1 if word[i] == "R" else -1 for i in range(j,N,h)) for j in range(h)]
    terminal_buckets = [sum(i % h == j for i in terminal_phases) for j in range(h)]
    assert buckets == terminal_buckets and min(buckets) >= 0
    residence_buckets = [sum(counts[j::h]) for j in range(h)]
    assert len(set(residence_buckets)) == 1
    lengths = [l-r for _, r, l in pairs]
    L = sum(lengths)
    Q = sum(ell//N for ell in lengths)
    M = sum(ell%N != 0 for ell in lengths)
    assert sum(counts) == L == 1676
    assert Fraction(L,N) == Fraction(419,26)
    assert Q <= min(counts) <= max(counts) <= Q+M
    assert max(counts)-min(counts) <= M <= m
    phase_bound = m*((N-1)//sum(map(abs,d)))
    assert max(counts) <= phase_bound
    result = {
        "status": "PASS", "source_sha256": hashlib.sha256(raw).hexdigest(),
        "N": N, "g": g, "m": m, "drift": d,
        "exact_set_cut_checks": len(cuts), "all_occupancy_unions_disjoint": True,
        "all_lifetime_lengths_positive_multiples_of_four": True,
        "lifetime_length_distribution": dict(sorted(Counter(lengths).items())),
        "h": h, "turn_buckets": buckets, "terminal_R_buckets": terminal_buckets,
        "residence_buckets": residence_buckets,
        "residence_sum": L, "mean": str(Fraction(L,N)),
        "Q": Q, "M": M, "trace_specific_occupancy_bounds": [Q,Q+M],
        "phase_count_range": [min(counts),max(counts)],
        "geometric_phase_count_upper_bound": phase_bound,
        "phase_counts": counts,
        "pairs": [{"cell": base, "r": r, "l": l, "length": l-r} for base,r,l in pairs],
    }
    (HERE/"seed_lifetime_audit_2026-10-12.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ("phase_counts","pairs")}, indent=2))


if __name__ == "__main__":
    main()
