"""Independent bit-cut enumeration of all ordered count compositions.

This does not import the project's dynamic-programming enumerator.
Each of the H-1 separator bits uniquely defines one ordered composition
of H. Contributions are accumulated unit by unit using NumPy batches.
"""
from pathlib import Path
import json
import numpy as np

cos = np.array([1,0,-1,0],dtype=np.int32)
sin = np.array([0,1,0,-1],dtype=np.int32)
targets = {'E':(2,-2,-2,0),'W':(-2,2,2,0),
           'S':(2,2,0,-2),'N':(-2,-2,0,2)}
results=[]
for half_period in (20,24):
    total=1<<(half_period-1)
    counts=dict.fromkeys(targets,0)
    for begin in range(0,total,131072):
        masks=np.arange(begin,min(begin+131072,total),dtype=np.uint32)
        index=np.zeros(len(masks),dtype=np.int32)
        p=np.zeros(len(masks),dtype=np.int32)
        q=np.zeros(len(masks),dtype=np.int32)
        r=np.zeros(len(masks),dtype=np.int32)
        t=np.zeros(len(masks),dtype=np.int32)
        for unit in range(half_period):
            c=cos[index&3]; s=sin[index&3]
            p+=c; q+=s; r+=index*c; t+=index*s
            if unit<half_period-1:
                index+=((masks>>unit)&1).astype(np.int32)
        orientations=((p,q,r,t),
                      (-q,p,-t-q,r+p),
                      (-p,-q,-r-2*p,-t-2*q),
                      (q,-p,t+3*q,-r-3*p))
        for pp,qq,rr,tt in orientations:
            for name,(pt,qt,rt,ttarget) in targets.items():
                candidate=(pp==pt)&(qq==qt)
                nr=rt-rr[candidate]; nt=ttarget-tt[candidate]
                sr=nr//(4*pt); st=nt//(4*qt)
                matched=(nr%(4*pt)==0)&(nt%(4*qt)==0)&(sr==st)&(sr>=0)
                counts[name]+=int(np.count_nonzero(matched))
    result={'period':2*half_period,
            'compositions_per_residue':total,
            'composition_residue_cases':4*total,
            'by_direction':counts,
            'total':sum(counts.values())}
    expected=({'E':48,'W':104,'S':138,'N':72} if half_period==20
              else {'E':859,'W':1375,'S':1526,'N':947})
    assert counts==expected, (result,expected)
    results.append(result)
Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results,indent=2))
