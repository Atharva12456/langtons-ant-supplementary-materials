"""Independent finite checks of the sample's added invariant statements."""
from itertools import product
from pathlib import Path
import json

OUT = Path(__file__).with_suffix('.json')

def weight(c, x, y, mod):
    a,b,c2,d,e,f = c
    return (a*x*x+b*x*y+c2*y*y+d*x+e*y+f) % mod

def admissible(c, mod):
    # Weights are periodic in each integer coordinate modulo mod.
    # 4w is periodic modulo mod with period two for mod four/eight.
    for x,y in product(range(2), repeat=2):
        if 4*weight(c,x,y,mod) % mod:
            return False
    for x,y in product(range(mod), repeat=2):
        if sum(weight(c,x+i,y+j,mod) for i,j in product(range(2),repeat=2)) % mod:
            return False
    return True

def mod4_formula(c):
    a,b,c2,d,e,f = c
    return b%2 == 0 and (2*a+b+2*c2+2*d+2*e)%4 == 0

valid4 = set()
for c in product(range(4), repeat=6):
    actual = admissible(c,4)
    assert actual == mod4_formula(c), c
    if actual:
        valid4.add(tuple(weight(c,x,y,4) for x,y in product(range(4),repeat=2)))

valid8_count = 0
for c in product(range(8), repeat=6):
    actual = admissible(c,8)
    predicted = all(v%2 == 0 for v in c) and mod4_formula(tuple(v//2 for v in c))
    assert actual == predicted, c
    valid8_count += actual

# The old subgroup consists of admissible affine charges and doubled
# one-coordinate charges. x(x-1), y(y-1) supply the latter degree-two part.
grid = tuple(product(range(4),repeat=2))
old = set()
for alpha,beta,gamma,a,c2 in product(range(4),range(4),range(4),range(2),range(2)):
    if (alpha-beta)%2:
        continue
    old.add(tuple((alpha*x+beta*y+gamma+a*x*(x-1)+c2*y*(y-1))%4 for x,y in grid))
q = tuple((x*x+2*x*y)%4 for x,y in grid)
coset = {tuple((u+v)%4 for u,v in zip(w,q)) for w in old}
assert old.isdisjoint(coset) and old|coset == valid4
assert tuple(2*v%4 for v in q) in old

directions = ((0,1),(1,0),(0,-1),(-1,0))
affine_potential = (
    lambda x,y:2*x+3*y+3,
    lambda x,y:x+2*y+2,
    lambda x,y:y+3,
    lambda x,y:3*x+2,
)
quadratic_potential = (
    lambda x,y:2*x*y+3*x,
    lambda x,y:3*x*x+x,
    lambda x,y:2*x*x+2*x*y+3*x,
    lambda x,y:x*x+x,
)
potential_cases = 0
for w,potential in [(lambda x,y:x+y,affine_potential),
                    (lambda x,y:x*x+2*x*y,quadratic_potential)]:
    for x,y,h,turn in product(range(4),range(4),range(4),(-1,1)):
        heading = (h+turn)%4
        dx,dy = directions[heading]
        assert (turn*w(x,y)+potential[heading](x+dx,y+dy)-potential[h](x,y))%4 == 0
        potential_cases += 1

# Polynomial identities valid for every h: relative-axis statistics are
# P=Q=2, R=2a-2h+4=0 and T=2a-2h+2=-2 for a=h-2.
u = ((1,0),(0,-1),(-1,0),(0,1))
for h in range(3,1001):
    a=h-2
    m=(h,h+2,h-2,h)
    drift=[0,0]
    moment=[0,0]
    for i,amount in enumerate(m):
        k=a+i
        for z in (0,1):
            drift[z] += amount*(u[i%4][z]+u[(i+1)%4][z])
            moment[z] += amount*(k*u[i%4][z]+(k+1)*u[(i+1)%4][z])
    assert sum(m)==4*h and drift==[0,-4] and moment==[0,0]

def subsequence(s, t):
    i=0
    for c in t:
        if i<len(s) and c==s[i]:
            i+=1
    return i==len(s)

completion_cases=0
for n in range(9):
    for letters in product('RL',repeat=n):
        s=''.join(letters)
        for require_l in (False, True):
            need_r=(bool(s) and s[0]=='L')+sum(x==y=='L' for x,y in zip(s,s[1:]))
            need_l=sum(x==y=='R' for x,y in zip(s,s[1:]))+(require_l and bool(s) and s[-1]=='R')
            attainable=[]
            for size in range(2*n+3):
                t=('RL'*(size//2+1))[:size]
                if require_l and size%2:
                    continue
                if subsequence(s,t):
                    attainable.append((t.count('R')-s.count('R'),t.count('L')-s.count('L')))
            assert (need_r,need_l) in attainable, (s,require_l)
            assert min(r for r,l in attainable)==need_r
            assert min(l for r,l in attainable)==need_l
            completion_cases+=1

# Independent simulation, using no project implementation, of first-L
# thirteen-cell C/A/S phase and exact boundaries through twenty periods.
C={(-2,1),(0,0)}
A={(-6,0),(-5,0),(-5,1),(-4,0),(-4,2),(-3,-1),(-3,2),(-2,-1),(-1,1),(0,1),(0,2)}
S={(-8,1),(-7,0),(-7,1),(-6,1),(-4,3),(-3,0),(-2,0),(-2,2),(-1,2),(-1,3),(-1,4),(0,3)}
B=C|A
x=y=h=0
words=[]
for n in range(21):
    widget={(xx-2*n,yy+2*n) for xx,yy in A}
    wake={(xx-2*j,yy+2*j) for xx,yy in S for j in range(n)}
    assert C.isdisjoint(widget) and C.isdisjoint(wake) and widget.isdisjoint(wake)
    assert B==C|widget|wake and len(B)==13+12*n
    assert (x,y,h)==(-2*n,2*n,0)
    if n==20:
        break
    word=[]
    for step in range(104):
        turn=-1 if (x,y) in B else 1
        word.append('L' if turn==-1 else 'R')
        B.symmetric_difference_update({(x,y)})
        h=(h+turn)%4
        dx,dy=directions[h]
        x+=dx; y+=dy
    words.append(''.join(word))
assert words[0][0]=='L' and all(w==words[0] for w in words)

result={
    'quadratic_mod4_coefficient_tuples_checked':4**6,
    'quadratic_mod8_coefficient_tuples_checked':8**6,
    'distinct_admissible_mod4_weight_functions':len(valid4),
    'old_charge_subgroup_size':len(old),
    'quadratic_quotient_size':len(valid4)//len(old),
    'admissible_mod8_coefficient_tuples':valid8_count,
    'potential_step_cases':potential_cases,
    'count_family_h_values_checked':[3,1000],
    'alternating_completion_cases':completion_cases,
    'first_L_C_A_S_period_boundaries_checked':21,
    'first_L_seed_count':13,
    'first_L_drift':[-2,2],
    'first_L_growth':12,
    'all_assertions_passed':True,
}
OUT.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
