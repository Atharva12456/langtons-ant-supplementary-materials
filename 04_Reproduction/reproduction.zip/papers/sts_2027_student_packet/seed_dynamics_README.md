# Reproducing the canonical seed checks

These files check the displayed 104-step word, its cyclic phases, and the canonical seed/wake identities in the sample report. They do not rerun the long period searches or certify every proof in the project.

Run from this packet with Python 3:

```powershell
python seed_phase_audit_2026-10-12.py
python canonical_wake_audit_2026-10-12.py
python seed_lifetime_audit_2026-10-12.py
python checker_mixing_audit_2026-10-12.py
```

The scripts use only Python's standard library. They locate the source beside themselves and the supplied standard-highway record at ../../langtons-ant-highway/results/standard_highway.json. The second script also reads the first audit's JSON and standard_strands_2026-07-14.json in this packet. Run them in the order shown.

The first audit independently constructs exact drift classes and initial colours from physical visit chronology for all 104 cyclic phases. The second uses a Bezout class key and compares sorted chronology with direct boundary words. It checks exact future-return flags, seed updates, both standard seed normalizations, the canonical gateway, its integer endpoint identity, and compatibility with the alternative fixed-cap decomposition. The third audit independently reconstructs paired lifetime roots and compares their occupied sets with first-future-event seeds at 111 cuts, including every cyclic phase and cuts outside the first period. It checks positive four-divisible lifetimes, the residence identity, and the phase-bucket cancellation for the standard 104-step witness. The general gcd(N,4) condition, including N congruent to 2 modulo 4, is proved in the report; this witness does not test that latter case. Finite simulations support data checks; all-period identities are proved in the report.

Each JSON result identifies the exact source and input word. seed_dynamics_file_identities_2026-10-12.json pins the delivered files, separately from the earlier search and strip-certificate manifest. Rerunning after editing the source changes the recorded source identity, so retain a versioned copy if comparing revisions.

The canonical gateway applies to the least seed for a specified repeating trace from time zero. Extra black cells outside the future path remain stationary debris. The eleven-cell benchmark is limited to immediate repetition of the displayed word's cyclic phases; it is not a minimum for eventual highway entry or for all highways. No literature-priority claim or competition-eligibility certification is made.

The fourth audit checks the cardinality-free pure-checker two-lane algebra used in Section 6.2. It computes directed-edge source and target keys from lattice coordinates, tests local correction cases, exhausts bounded finite binary flows for both checker parities, and checks larger deterministic random flows and lane-count arithmetic. The report's analytic finite-support argument supplies the conclusion for every growth at drift (2,-2) and its quarter-turn rotations. The audit is not an ant-word search, an unbounded theorem oracle, a result for mixed-checker wakes or scaled drifts, or a rerun of an archived period search.
