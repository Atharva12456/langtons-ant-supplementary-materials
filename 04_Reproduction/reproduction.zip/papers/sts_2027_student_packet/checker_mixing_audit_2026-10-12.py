"""Independent bounded regressions of cardinality-free pure checker flow.
Physical directed-edge keys are computed from lattice coordinates; no project imports.
The analytic finite-support proof, not this enumeration, supplies all-growth scope.
"""
from collections import defaultdict,Counter
from itertools import product
from math import comb
from pathlib import Path
import hashlib,json,random
HERE=Path(__file__).resolve().parent
SOURCE=HERE/"sts_sample_report.tex"
DIRECTIONS={'E':(1,0),'W':(-1,0),'N':(0,1),'S':(0,-1)}
def keys(edge):
 t,r,kind=edge;x=r;y=t-r;dx,dy=DIRECTIONS[kind]
 assert (t%2==0 and dx) or (t%2==1 and dy)
 positive=int(dx+dy>0)
 return (t,r,positive),(x+dx+y+dy,(x+dx)%2,positive)

def make_flow(which,bits):
 edges=set()
 for r,lane in enumerate(bits):
  for k,bit in enumerate(lane):
   if not bit:continue
   j=2*k+1
   if which=='C':
    edges.update(((j,r,'N'),(j+2,r,'S'),(j+1,1-r,'W'),(j+1,1-r,'E')))
   else:edges.update(((j,r,'N'),(j,r,'S'),(j-1,r,'E'),(j+1,r,'W')))
 return edges

def check(which,bits):
 edges=make_flow(which,bits); incoming=defaultdict(list);outgoing=defaultdict(list)
 for edge in edges:
  a,b=keys(edge);outgoing[a[:2]].append(a[2]);incoming[b[:2]].append(b[2])
 corr=0;wakes=Counter()
 for v in outgoing.keys()|incoming.keys():
  assert len(outgoing[v])%2==len(incoming[v])%2
  D=len(outgoing[v])%2;Q=v[0]%2==0;p=(sum(incoming[v])+sum(outgoing[v]))%2
  if D:
   assert Q==(which=='Q');wakes[v[1]]+=1
  corr += p*(D+1) if Q else D*(p+1)
 assert corr%2==0
 ordered=sorted(edges,key=lambda e:keys(e)[0]);targets=[keys(e)[1] for e in ordered]
 E=sum(targets[i]>targets[j] for i in range(len(targets)) for j in range(i+1,len(targets)))%2
 boundaries=[];runs=[]
 for lane in bits:
  b=(0,)+tuple(lane)+(0,)
  boundaries.append(sum(b[i]!=b[i+1] for i in range(len(b)-1)))
  runs.append(sum(b[i]==0 and b[i+1]==1 for i in range(len(b)-1)))
 assert boundaries==[wakes[0],wakes[1]]==[2*r for r in runs]
 assert E==(sum(comb(o,2) for o in boundaries)%2)==sum(runs)%2
 return tuple(boundaries)

def main():
 local_checks=0
 for Q,m,p,D in product((False,True),range(0,81),range(2),range(2)):
  if ((m-2*p) if Q else (2*p-m))%4!=D:continue
  raw=p*(m-1)+(0 if Q else comb(m,2))
  reduced=p*(D+1) if Q else D*(p+1)
  assert raw%2==reduced%2;local_checks+=1
 enum_checks=0;count_spectra=set();pure_cases=0
 L=7
 for flat in product(range(2),repeat=2*L):
  bits=(flat[:L],flat[L:])
  for which in ('Q','C'):
   boundary=check(which,bits);count_spectra.add(boundary);enum_checks+=1
   if all(o%4==2 for o in boundary):
    assert sum(comb(o,2) for o in boundary)%2==0;pure_cases+=1
 rng=random.Random(121026);random_checks=0;max_boundary=0
 for _ in range(200):
  bits=tuple(tuple(rng.randrange(2) for _ in range(96)) for r in range(2))
  for which in ('Q','C'):
   boundary=check(which,bits);max_boundary=max(max_boundary,sum(boundary));random_checks+=1
 residue_checks=0
 for o0,o1 in product(range(2,203,4),repeat=2):
  assert comb(o0,2)%2==comb(o1,2)%2==1
  assert (o0+o1)%4==0 and sum(comb(o,2) for o in (o0,o1))%2==0
  residue_checks+=1
 heading_checks=0
 for M in range(2,202,2):
  for g in range(4,2*M+1,4):
   assert (M-g//2)%2==0;heading_checks+=1
 result={'status':'PASS','scope':'bounded independent regressions, not proof oracle',
 'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'local_multiplicity_corrections':local_checks,
 'exhaustive_two_lane_masks':enum_checks,'chain_length_per_lane':L,'pure_residue_masks':pure_cases,
 'boundary_count_spectra':sorted(count_spectra),'large_random_chain_checks':random_checks,
 'random_chain_length_per_lane':96,'max_random_wake_cardinality':max_boundary,
 'arbitrary_large_lane_count_arithmetic_checks':residue_checks,'heading_and_L_count_parity_checks':heading_checks,
 'all_checks_passed':True}
 (HERE/'checker_mixing_audit_2026-10-12.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:v for k,v in result.items() if k!='boundary_count_spectra'},indent=2))
if __name__=='__main__':main()
