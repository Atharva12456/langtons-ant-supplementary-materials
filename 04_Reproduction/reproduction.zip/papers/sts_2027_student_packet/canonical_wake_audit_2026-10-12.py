"""Independent finite verification of canonical phase dynamics.

No project-code imports. The literal paper word is walked afresh. A sorted
Bézout-key implementation is checked against separately grouped and literally
ordered boundary words at every phase; future-visit flags use exact physical
return times, without a simulation horizon. Gateway identities are also checked
by direct ant simulation on canonical seeds in both archived normalizations.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import re

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sts_sample_report.tex"
ARCHIVE = SOURCE.parents[2] / "langtons-ant-highway/results/standard_highway.json"
PRIOR = HERE / "seed_phase_audit_2026-10-12.json"
STRANDS = HERE / "standard_strands_2026-07-14.json"
UNITS = ((0, 1), (1, 0), (0, -1), (-1, 0))


def plus(point, drift, k=1):
    return tuple(p + k * d for p, d in zip(point, drift))


def multiple(delta, drift):
    axis = 0 if drift[0] else 1
    if delta[axis] % drift[axis]:
        return None
    k = delta[axis] // drift[axis]
    return k if delta == tuple(k * d for d in drift) else None


def bezout(a, b):
    if not b:
        return (abs(a), 1 if a > 0 else -1, 0)
    h, r, s = bezout(b, a % b)
    return (h, s, r - (a // b) * s)


def walk(word):
    positions = []
    headings = []
    p, q = (0, 0), 0
    for turn in word:
        positions.append(p)
        headings.append(q)
        q = (q + (1 if turn == "R" else -1)) % 4
        p = plus(p, UNITS[q])
    assert q == 0 and p != (0, 0)
    return positions, headings, p


def fast_phase_data(word, positions, drift):
    h = math.gcd(*map(abs, drift))
    ap, bp = (d // h for d in drift)
    _, r, s = bezout(ap, bp)
    assert r * ap + s * bp == 1
    classes = {}
    for i, (x, y) in enumerate(positions):
        coord = r * x + s * y
        residue = coord % h
        key = (bp * x - ap * y, residue)
        level = (coord - residue) // h
        classes.setdefault(key, []).append((level, i, word[i]))
    eta = [0] * len(word)
    mu0 = 0
    wake = set()
    lifetime_sum = 0
    class_records = []
    for key, raw in sorted(classes.items()):
        events = sorted(raw, key=lambda e: (-e[0], e[1]))
        stable = "".join(e[2] for e in events)
        assert stable == "RL" * (len(stable) // 2) + ("R" if len(stable) % 2 else "")
        mu0 += sum(events[j][0] - events[j + 1][0] for j in range(0, len(events) - 1, 2))
        lifetime_sum += sum((events[j + 1][1] - len(word) * events[j + 1][0])
                            - (events[j][1] - len(word) * events[j][0])
                            for j in range(0, len(events) - 1, 2))
        if len(events) % 2:
            phase = events[-1][1]
            eta[phase] = 1
            wake.add(positions[phase])
        class_records.append({"key": key, "events": events, "stable": stable})
    counts = [mu0]
    for i, turn in enumerate(word):
        counts.append(counts[-1] + (1 if turn == "R" else -1) - eta[i])
    assert counts[-1] == mu0
    return counts, eta, wake, lifetime_sum, class_records


def literal_boundary_seed(word, positions, drift):
    """Group by pairwise drift multiples; order explicit physical visit times."""
    classes = []
    for i, point in enumerate(positions):
        for base, events in classes:
            level = multiple(tuple(p - b for p, b in zip(point, base)), drift)
            if level is not None:
                events.append((level, i, word[i]))
                break
        else:
            classes.append((point, [(0, i, word[i])]))
    seed = set()
    for base, events in classes:
        lower = min(e[0] for e in events)
        upper = max(e[0] for e in events)
        for n in range(lower, upper + 1):
            visits = sorted((i + len(word) * (n - a), turn)
                            for a, i, turn in events if a <= n)
            assert all(u[1] != v[1] for u, v in zip(visits, visits[1:]))
            if n == upper:
                assert visits[0][1] == "R"
            elif visits[0][1] == "L":
                seed.add(plus(base, drift, n))
    return seed


def future_visit_flag(i, positions, drift, length):
    point = positions[i]
    later = []
    for j, other in enumerate(positions):
        k = multiple(tuple(p - o for p, o in zip(point, other)), drift)
        if k is not None and k >= 0 and j + length * k > i:
            later.append(j + length * k)
    return bool(later)


def future_contains(point, positions, drift):
    for other in positions:
        k = multiple(tuple(p - o for p, o in zip(point, other)), drift)
        if k is not None and k >= 0:
            return True
    return False


def audit_gateway(word, periods=12):
    positions, _, drift = walk(word)
    seed = literal_boundary_seed(word, positions, drift)
    counts, eta, wake, _, _ = fast_phase_data(word, positions, drift)
    assert len(seed) == counts[0]
    black = set(seed)
    p, q = (0, 0), 0
    signed = Counter()
    for n in range(periods + 1):
        translated_seed = {plus(c, drift, n) for c in seed}
        pieces = [translated_seed] + [{plus(c, drift, k) for c in wake} for k in range(n)]
        union = set()
        for piece in pieces:
            assert union.isdisjoint(piece)
            union.update(piece)
        assert black == union
        assert len(black) == len(seed) + n * len(wake)
        if n == periods:
            break
        for i, expected in enumerate(word):
            turn = "L" if p in black else "R"
            assert turn == expected
            sign = 1 if turn == "R" else -1
            if n == 0:
                signed[p] += sign
            black.symmetric_difference_update({p})
            q = (q + sign) % 4
            p = plus(p, UNITS[q])
    translated = {plus(c, drift) for c in seed}
    all_cells = set(signed) | seed | translated | wake
    assert all(signed[c] == (c in wake) + (c in translated) - (c in seed)
               for c in all_cells)
    return {"seed_count": len(seed), "drift": drift, "canonical_seed": sorted(seed),
            "terminal_odd_phases": [i for i, e in enumerate(eta) if e],
            "terminal_representatives_W": sorted(wake), "simulated_periods": periods,
            "all_gateway_sets_disjoint": True, "binary_endpoint_identity": True}


def main():
    raw = SOURCE.read_bytes()
    text = raw.decode("utf-8-sig")
    witness = text.split("\\section{A realised highway attaining width ten}", 1)[1]
    display = witness.split("\\begin{minipage}", 1)[1].split("\\end{minipage}", 1)[0]
    word = "".join(re.findall(r"^[RL]+", display, flags=re.MULTILINE))
    assert len(word) == 104
    archived = json.loads(ARCHIVE.read_text(encoding="utf-8-sig"))
    assert word == archived["normalisation_A"]["turn_word"]
    positions, headings, drift = walk(word)
    counts, eta, wake, lifetime_sum, records = fast_phase_data(word, positions, drift)
    assert drift == (2, -2)
    growth = word.count("R") - word.count("L")
    assert sum(eta) == growth == 12
    assert len(records) == 22
    seed0 = literal_boundary_seed(word, positions, drift)
    assert len(seed0) == counts[0] == 11
    actual_black = set(seed0)
    canonical_sets = []
    for shift in range(105):
        suffix_positions = [plus(positions[(shift + j) % 104], drift, (shift + j) // 104)
                            for j in range(104)]
        phase_word = word[shift % 104:] + word[:shift % 104]
        seed = literal_boundary_seed(phase_word, suffix_positions, drift)
        assert len(seed) == counts[shift]
        assert actual_black & {c for c in actual_black if future_contains(c, suffix_positions, drift)} == seed
        canonical_sets.append(seed)
        if shift < 104:
            literal_eta = int(word[shift] == "R" and not future_visit_flag(shift, positions, drift, 104))
            assert literal_eta == eta[shift]
            assert (positions[shift] not in actual_black) == (word[shift] == "R")
            actual_black.symmetric_difference_update({positions[shift]})
    for shift in range(104):
        updated = canonical_sets[shift] ^ {positions[shift]}
        discarded = updated - canonical_sets[shift + 1]
        assert discarded == ({positions[shift]} if eta[shift] else set())
        assert canonical_sets[shift + 1] <= updated
    assert canonical_sets[104] == {plus(c, drift) for c in canonical_sets[0]}
    assert actual_black == canonical_sets[104] | wake
    assert canonical_sets[104].isdisjoint(wake)
    assert lifetime_sum == sum(counts[:-1])
    prior = json.loads(PRIOR.read_text(encoding="utf-8-sig"))
    assert counts[:-1] == [r["canonical_seed_count"] for r in prior["phase_records"]]
    gateway_a = audit_gateway(word)
    assert set(map(tuple, gateway_a["canonical_seed"])) == set(map(tuple, archived["normalisation_A"]["seed_cells_11"]))
    shifted_b = word[100:] + word[:100]
    gateway_b = audit_gateway(shifted_b)
    assert set(map(tuple, gateway_b["canonical_seed"])) == set(map(tuple, archived["normalisation_B"]["seed_cells_13"]))
    assert gateway_b["drift"] == tuple(archived["normalisation_B"]["drift"])
    old_strands = json.loads(STRANDS.read_text(encoding="utf-8-sig"))
    caps = {tuple(r["point"]) for r in old_strands["canonical_stationary_correction"]}
    assert all(r["coefficient"] == 1 for r in old_strands["canonical_stationary_correction"])
    b_seed = set(map(tuple, gateway_b["canonical_seed"]))
    b_wake = set(map(tuple, gateway_b["terminal_representatives_W"]))
    b_drift = gateway_b["drift"]
    assert caps <= b_seed & b_wake
    moving = b_seed - caps
    shifted_caps = {plus(c, b_drift) for c in caps}
    assert (b_wake - caps).isdisjoint(shifted_caps)
    old_bases = (b_wake - caps) | shifted_caps
    assert moving == set(map(tuple, old_strands["canonical_moving_widget"]))
    assert old_bases == set(map(tuple, old_strands["canonical_strand_bases"]))
    for n in range(13):
        general = {plus(c, b_drift, n) for c in b_seed} | {plus(c, b_drift, k) for c in b_wake for k in range(n)}
        cap_form = caps | {plus(c, b_drift, n) for c in moving} | {plus(c, b_drift, k) for c in old_bases for k in range(n)}
        assert general == cap_form
    distribution = Counter(counts[:-1])
    result = {"status": "PASS", "scope": "Immediate repetition of this word, all cyclic phases; no global seed minimum or transient bound.",
              "source_sha256": hashlib.sha256(raw).hexdigest(), "word": word,
              "word_sha256": hashlib.sha256(word.encode()).hexdigest(), "N": 104, "g": growth,
              "all_phase_cardinalities_including_N": counts, "eta": eta,
              "terminal_odd_phases": [i for i, e in enumerate(eta) if e],
              "distribution": dict(sorted(distribution.items())),
              "minimum": min(counts), "maximum": max(counts),
              "minimum_phases": [i for i, c in enumerate(counts[:-1]) if c == min(counts)],
              "maximum_phases": [i for i, c in enumerate(counts[:-1]) if c == max(counts)],
              "black_residence_lifetime_sum": lifetime_sum,
              "mean_canonical_seed_count": str(Fraction(lifetime_sum, 104)),
              "all_exact_seed_update_checks": True,
              "all_exact_physical_future_visit_checks": True,
              "all_literal_boundary_seed_checks": True,
              "all_prior_audit_count_comparisons": True,
              "old_cap_decomposition_equivalent": True,
              "old_cap_cells": sorted(caps),
              "old_strand_bases_replaced_by_predecessors": sorted(shifted_caps),
              "normalisation_A_gateway": gateway_a,
              "normalisation_B_gateway": gateway_b}
    (HERE / "canonical_wake_audit_2026-10-12.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("status", "N", "g", "terminal_odd_phases", "distribution", "minimum", "maximum", "minimum_phases", "maximum_phases", "black_residence_lifetime_sum", "mean_canonical_seed_count")}, indent=2))


if __name__ == "__main__":
    main()
