#!/usr/bin/env python3
"""Exact edge-multiplicity spectrum for clean Langton-ant translators.

The calculation uses only integer arithmetic.  It aggregates ordered
compositions by four residue-class statistics, rather than iterating over
candidate starting heights up to an arbitrary cutoff.

Direction convention (matching the research journal):

    u_0 = (1, 0), u_1 = (0, -1), u_2 = (-1, 0), u_3 = (0, 1).

If M_r = sum_{k == r (mod 4)} m_k and
K_r = sum_{k == r (mod 4)} k m_k, define

    P = M_0 - M_2,  Q = M_1 - M_3,
    R = K_0 - K_2,  S = K_1 - K_3.

Then the displacement and centered-moment sum are

    d = (P - Q, -P - Q),
    Z = (R - S - Q, -R - S - P).

The targets below are therefore exactly the cases Z = 0 and d one of the
four axis displacements of magnitude four.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Final


TARGETS: Final[dict[str, dict[str, object]]] = {
    "E": {"drift": (4, 0), "stats": (2, -2, -2, 0)},
    "W": {"drift": (-4, 0), "stats": (-2, 2, 2, 0)},
    "S": {"drift": (0, -4), "stats": (2, 2, 0, -2)},
    "N": {"drift": (0, 4), "stats": (-2, -2, 0, 2)},
}

# Regression values from the first direct ordered-composition traversal.
EXPECTED_TOTALS: Final[dict[int, dict[str, int]]] = {
    20: {"E": 48, "W": 104, "S": 138, "N": 72},
    24: {"E": 859, "W": 1375, "S": 1526, "N": 947},
}


def _add_counter(counter: Counter[int], key: int, amount: int) -> None:
    counter[key] += amount


def _classify_endpoint(
    *,
    start_residue: int,
    length: int,
    multiplicity: int,
    p: int,
    q: int,
    r: int,
    s: int,
    accumulators: dict[str, dict[str, object]],
) -> None:
    """Classify one aggregated terminal composition state.

    The statistics r,s here are computed with support starting at
    ``start_residue``.  Every actual nonnegative start in that residue class
    is uniquely ``a = start_residue + 4*shift``.  Such a shift sends
    ``(R,S)`` to ``(R + 4*shift*P, S + 4*shift*Q)``.
    """

    matched = 0
    for direction, target in TARGETS.items():
        target_p, target_q, target_r, target_s = target["stats"]  # type: ignore[misc]
        if (p, q) != (target_p, target_q):
            continue

        numerator_r = target_r - r
        numerator_s = target_s - s
        denominator_r = 4 * p
        denominator_s = 4 * q
        if numerator_r % denominator_r or numerator_s % denominator_s:
            continue
        shift_r = numerator_r // denominator_r
        shift_s = numerator_s // denominator_s
        if shift_r != shift_s or shift_r < 0:
            continue

        start = start_residue + 4 * shift_r
        acc = accumulators[direction]
        acc["count"] = int(acc["count"]) + multiplicity
        _add_counter(acc["by_start"], start, multiplicity)  # type: ignore[arg-type]
        _add_counter(acc["by_length"], length, multiplicity)  # type: ignore[arg-type]
        _add_counter(acc["by_max_black_count"], start + length, multiplicity)  # type: ignore[arg-type]
        matched += 1

    # The four targets have distinct (P,Q), so no composition/residue case
    # can be classified in two directions.
    assert matched <= 1


def enumerate_half_period(half_period: int) -> dict[str, object]:
    """Enumerate every positive contiguous m-pattern with sum half_period."""

    if half_period <= 0:
        raise ValueError("half_period must be positive")

    accumulators: dict[str, dict[str, object]] = {
        direction: {
            "count": 0,
            "by_start": Counter(),
            "by_length": Counter(),
            "by_max_black_count": Counter(),
        }
        for direction in TARGETS
    }

    expected_compositions = 1 << (half_period - 1)
    checked_by_residue: dict[int, int] = {}

    for start_residue in range(4):
        # State is (used_sum, P, Q, R, S).  The value is the number of
        # ordered positive prefixes producing that exact state.
        current: dict[tuple[int, int, int, int, int], int] = {
            (0, 0, 0, 0, 0): 1
        }
        completed_compositions = 0

        for index in range(half_period):
            k = start_residue + index
            residue = k & 3
            epsilon_p = 1 if residue == 0 else -1 if residue == 2 else 0
            epsilon_q = 1 if residue == 1 else -1 if residue == 3 else 0
            next_states: defaultdict[tuple[int, int, int, int, int], int] = (
                defaultdict(int)
            )

            for (used, p, q, r, s), prefix_count in current.items():
                for m in range(1, half_period - used + 1):
                    new_used = used + m
                    new_p = p + epsilon_p * m
                    new_q = q + epsilon_q * m
                    new_r = r + k * epsilon_p * m
                    new_s = s + k * epsilon_q * m
                    if new_used == half_period:
                        completed_compositions += prefix_count
                        _classify_endpoint(
                            start_residue=start_residue,
                            length=index + 1,
                            multiplicity=prefix_count,
                            p=new_p,
                            q=new_q,
                            r=new_r,
                            s=new_s,
                            accumulators=accumulators,
                        )
                    else:
                        next_states[(new_used, new_p, new_q, new_r, new_s)] += (
                            prefix_count
                        )
            current = next_states

        # There are exactly 2^(H-1) ordered compositions of H.  This
        # assertion proves that the DP neither loses nor duplicates one for
        # each of the four possible support-start residues.
        assert completed_compositions == expected_compositions, (
            start_residue,
            completed_compositions,
            expected_compositions,
        )
        assert not current
        checked_by_residue[start_residue] = completed_compositions

    directions: dict[str, object] = {}
    for direction, acc in accumulators.items():
        count = int(acc["count"])
        by_start: Counter[int] = acc["by_start"]  # type: ignore[assignment]
        by_length: Counter[int] = acc["by_length"]  # type: ignore[assignment]
        by_max: Counter[int] = acc["by_max_black_count"]  # type: ignore[assignment]
        assert sum(by_start.values()) == count
        assert sum(by_length.values()) == count
        assert sum(by_max.values()) == count
        directions[direction] = {
            "drift": list(TARGETS[direction]["drift"]),
            "count": count,
            "by_start": dict(sorted(by_start.items())),
            "by_length": dict(sorted(by_length.items())),
            "by_max_black_count": dict(sorted(by_max.items())),
            "largest_support_minimum": max(by_start, default=None),
            "largest_support_maximum": max(by_max, default=None),
        }

    if half_period in EXPECTED_TOTALS:
        observed = {
            direction: int(directions[direction]["count"])  # type: ignore[index]
            for direction in TARGETS
        }
        assert observed == EXPECTED_TOTALS[half_period], (observed, EXPECTED_TOTALS)

    return {
        "half_period": half_period,
        "period": 2 * half_period,
        "ordered_compositions_per_start_residue": expected_compositions,
        "ordered_compositions_checked_by_start_residue": checked_by_residue,
        "composition_residue_cases_checked": 4 * expected_compositions,
        "surviving_patterns": sum(
            int(directions[direction]["count"])  # type: ignore[index]
            for direction in TARGETS
        ),
        "largest_support_minimum": max(
            int(directions[direction]["largest_support_minimum"])  # type: ignore[index]
            for direction in TARGETS
        ),
        "largest_support_maximum": max(
            int(directions[direction]["largest_support_maximum"])  # type: ignore[index]
            for direction in TARGETS
        ),
        "directions": directions,
    }


def family_check(half_period: int) -> dict[str, object] | None:
    """Check the four-edge closed-form survivor when H is a multiple of 4."""

    if half_period % 4:
        return None
    h = half_period // 4
    start = h - 2
    pattern = (h, h + 2, h - 2, h)
    if start < 0 or min(pattern) <= 0:
        return None

    directions = ((1, 0), (0, -1), (-1, 0), (0, 1))
    drift_x = drift_y = moment_x = moment_y = 0
    for index, m in enumerate(pattern):
        k = start + index
        ux, uy = directions[k & 3]
        vx, vy = directions[(k + 1) & 3]
        drift_x += m * (ux + vx)
        drift_y += m * (uy + vy)
        moment_x += m * (k * ux + (k + 1) * vx)
        moment_y += m * (k * uy + (k + 1) * vy)

    assert sum(pattern) == half_period
    assert (moment_x, moment_y) == (0, 0)
    assert (drift_x, drift_y) in {
        (4, 0),
        (-4, 0),
        (0, 4),
        (0, -4),
    }
    return {
        "h": h,
        "support_start": start,
        "multiplicities": list(pattern),
        "drift": [drift_x, drift_y],
        "moment": [moment_x, moment_y],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--half-periods",
        type=int,
        nargs="+",
        default=[20, 24],
        help="values H=N/2 to enumerate (default: 20 24)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("work/moment_spectrum_results.json"),
        help="JSON destination",
    )
    args = parser.parse_args()

    results = {
        str(half_period): enumerate_half_period(half_period)
        for half_period in args.half_periods
    }
    payload = {
        "exact_integer_enumeration": True,
        "direction_convention": {
            "u0": [1, 0],
            "u1": [0, -1],
            "u2": [-1, 0],
            "u3": [0, 1],
        },
        "target_statistics_P_Q_R_S": {
            direction: list(target["stats"]) for direction, target in TARGETS.items()
        },
        "results": results,
        "four_edge_family": {
            "formula": {
                "half_period": "H=4h",
                "support_start": "a=h-2",
                "multiplicities": ["h", "h+2", "h-2", "h"],
                "valid_for": "h>=3",
            },
            "instances": {
                str(half_period): family_check(half_period)
                for half_period in args.half_periods
            },
        },
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(args.output), "results": results}, sort_keys=True))


if __name__ == "__main__":
    main()
