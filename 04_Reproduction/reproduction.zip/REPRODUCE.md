# Reproducing the supplementary checks

Extract reproduction.zip, raw_search_records.zip and research_notes_sources.zip
into the same empty directory. The notes archive is in 03_Research_notes; the
other archives are in 04_Reproduction and 05_Raw_records.
Keep the paths inside the ZIPs: the seed programs locate their input record by
its position relative to papers/sts_2027_student_packet/sts_sample_report.tex.
The current report source is included there. The longer reference source is
provided separately in the supplementary folder; full_proof_core.tex is an
additional, narrower reference inside this archive.

## Current report checks

Use Python 3.10 or later. The following four checks need only its standard library.
From papers/sts_2027_student_packet, run in this order:

    python seed_phase_audit_2026-10-12.py
    python canonical_wake_audit_2026-10-12.py
    python seed_lifetime_audit_2026-10-12.py
    python checker_mixing_audit_2026-10-12.py

The delivered JSON outputs were regenerated against the included report source.
All four passed; every substantive result agrees with the earlier dated output.
They check the standard witness, bounded regressions and algebra described in the
report. They do not rerun the archived long-period searches or prove every
statement in the manuscripts. source_path and record_path in the first JSON
record the directory used for this check; its content hashes identify the inputs.

PACKAGE_MANIFEST.json identifies the members in this delivery. The unchanged
evidence_manifest_2026-10-07.json is an earlier search/certificate checkpoint;
its hashes can differ from later edited prose. The earlier seed identity record
is kept in historical/ and does not identify the current source or PDF. The
seed_dynamics_README.md describes the mathematical scope of the four programs;
use PACKAGE_MANIFEST.json for this delivery's identities.

## Other checks

The separate research_notes_sources.zip contains all 150 research notes and
the local files reached through their Markdown links. Its NOTES_MANIFEST.json
identifies those sources. The eight combined reading files organize the same
notes by topic. Some historical notes also mention programs and run directories
as plain text; this link closure does not supply every such later execution
dependency. No reproduction of all exploratory branches is asserted here.
The current report does not claim to close any growth-eight drift orbit.

The exact Python enumerators generally use the standard library. The optional
qa/sample_count_spectrum_audit.py requires NumPy. Scripts whose names contain
smt, width4_prefix_flow.py, and local_pair_invariant_audit.py require z3-solver.
The lower-cap, quiet-cap, offset-six and positive-skew enumeration checks also
require z3-solver. Install optional dependencies with:

    python -m pip install numpy z3-solver

These optional packages are unnecessary for the four current-report checks.
Most scripts under langtons-ant-highway/code/python run directly with Python.
Read that script's arguments and the corresponding certificate before starting
a potentially long enumeration. The period-search engines require a JDK;
the archived runs record OpenJDK 25.0.1 and exact commands in their manifests.
No long-period engine was rerun while assembling this delivery.

From langtons-ant-highway/lean, run build.ps1 with the pinned Lean 4.32.0
toolchain available on PATH (or set LANGTON_LEAN_LAKE). Dockerfile provides the
alternative documented in lean/README.md. The build configuration and complete
Lean import closure are included; toolchains and compiled caches are omitted.
Read FORMALIZATION_BOUNDARY.md for the hypotheses the Lean files leave open.
No new Lean build is asserted for this package assembly.

The raw-record ZIP preserves the original shard filenames and layout. Follow
langtons-ant-highway/records/README.md to extract and audit the existing
langton_search_records.tar.gz; that dated archive has its own manifest and
engine snapshot. Growth-eight summaries name their variant-specific audit and
hybrid endpoint dependencies. Do not treat an intermediate run_manifest status
as the final completion certificate.

From the extracted root, this reproduces the lifetime/touch-graph diagnostics:

    python work/chronology_pairing_audit.py

It uses work/standard_cyclic_min_trace.txt and outputs/langton_research.py,
both included. Its saved JSON is retained as a dated comparison.

The missing-cap and lower-cap hand-certificate programs named in the ledger
are included with their local imports. Run them from langtons-ant-highway.
verify_missing_cap_lemma_m.py now raises an error if it finds a counterexample;
its documented finite count ranges remain unchanged. StableWordFrontier.java
requires a seed file supplied with --seed; the input rows are displayed in the
corresponding lower-cap note. No new Java frontier run is claimed.
