# Upper F123 quiet-three/four, wake-five: terminal hand reduction

For literal positive drift `(1,3)`, the upper F123 cap with quiet offsets
3,4,6,7 and wake 5 is impossible for either wake bit at 8. The initial
reduction to six prefixes is a complete, independently audited finite
necessary-domain calculation. The final elimination of those prefixes
below is a hand argument: it enumerates no row-eight words and uses no
clock or period bound. This replaces the previous enumeration of the 51
terminal candidates. It does **not** yet make the initial six-prefix
reduction a hand proof. The whole orbit remains **OPEN**.

## Conventions and the six necessary prefixes

Apply the orientation-preserving half-turn at the upper extremum.
R/L are preserved. The cap words are `0:NR`, `1:WR WL`,
`2:NR SL NR`. The upper clock is `1+N*dx`, with integer `N>=1`
unbounded and strict stable order. No growth, P22, period residue or
gap-four assumption enters the local reduction.

At row 8 write `D_i` for its i-th west departure, and `S_j` for its
j-th south arrival. Every port there is NR,NL,SR,SL. Hence a west
departure is NL or SR, and a south arrival is SL or SR. At a zero-copy
physical first return `D_i -> S_j`, those two events are consecutive.
Alternation therefore gives:

* `D_i=NL` implies `S_j=SR`, which is also `D_(i+1)`.
* `D_i=SR` implies `S_j=SL`.

Every L event at row 8 is either NL, adding one west departure, or SL,
adding one south arrival. Thus two SR events cannot be consecutive in
**both** ordinal lists: alternation puts an L between them, and that L
adds an intervening member of one list. We use this elementary fact
twice below.

The six prefixes, named A through F in saved order, have the following
words. Spaces separate events; row positions used below are one-based.
All share the cap above.

```text
A
3 WR WL ER WL WR WL
4 NR SL NR NL SR SL NR SL
5 WR WL WR EL ER WL WR WL ER
6 NR SL NR NL SR NL NR SL SR SL NR NL
7 WR WL WR EL ER WL ER WL WR EL WR EL ER WL

B
3 WR WL ER WL WR WL
4 SR SL NR NL NR SL NR SL
5 WR WL ER WL WR EL WR WL ER
6 SR SL NR NL NR SL NR NL SR SL NR NL
7 WR WL WR EL ER WL WR EL ER WL WR EL ER WL

C: same rows3..6 as B
7 WR WL WR EL WR WL ER EL ER WL WR EL ER WL

D: same rows3..5 as B
6 SR SL NR SL NR NL NR NL SR SL NR NL
7 WR WL WR WL WR EL ER EL ER WL WR EL ER WL

E: same rows3..5 as B
6 SR SL SR NL SR SL NR NL
7 ER WL ER EL ER WL WR EL ER WL

F
3 WR WL WR WL ER WL
4 NR SL SR SL NR NL NR SL
5 WR WL WR EL ER WL WR WL ER
6 NR SL NR NL SR SL SR SL NR NL NR NL
7 WR WL WR EL ER WL WR WL WR EL ER EL ER WL
```

Each has six west arrivals at row 5 and seven south departures at row 7.
Thus row 8 has exactly six west departures and seven south arrivals.
Flow would give its vectors, for either `omega8` bit, as

```text
SR=s, SL=7-s, NL=6-s, NR=omega8+13-3s,  0<=s<=4.
```

The hand proof needs neither these vectors nor an enumeration of their
alternating words; the two ordinal totals and the return table suffice.

## The physical return table

Matching departure and arrival ordinals through rows 0..7 gives:

| Prefix | First adjacency | Second adjacency | Third adjacency |
|---|---|---|---|
| A | D1 -> S2 | D3 -> S4 | D5 -> S6 |
| B | D1 -> S2 | D4 -> S4 | D5 -> S6 |
| C,D,E | D1 -> S3 | D4 -> S4 | D5 -> S6 |
| F | D1 -> S2 | D3 -> S5 | D5 -> S6 |

The direction words for the second and third columns are respectively
`WNES`, `WNENWSES` for A and F; `WNWSENENWSES`, `WNENWSES`
for B,C,D,E. First-column words are `WNES` for B,C,D,E,
`WNENWNENWNESWSESWSES` for A, and `WNENWNENWSESWSES` for F.
All have zero displacement and no intermediate return to the starting
physical cell. The fresh standard-library checker displays every edge
and verifies all 18 walks, including the intermediate copy coordinates.
It does not treat a return to another copy as adjacency.

Here are the additional conditional wrong physical first returns.
`t[k]` means the k-th event in row t. The condition says which south
arrival at 8 is SR and its west-departure ordinal.

| Prefix | Condition | Forced path | Required next event at start |
|---|---|---|---|
| A | S1=SR=D1 | 7[2] -> S1 -> 5[1] -> 4[1] -> 7[4], SWNE | 7[3] |
| A | S4=SR=D4 | 5[3] -> 4[3] -> 7[7] -> S4 -> 5[6], NESW | 5[4] |
| B | S1=SR=D1 | 7[2] -> S1 -> 5[1] -> 4[3] -> 7[5], SWNE | 7[3] |
| B | S3=SR=D4 | 7[6] -> S3 -> 5[5] -> 4[4] -> 1[2] -> 2[2] -> 5[6] -> 4[5] -> 7[8], SWNWSENE | 7[7] |
| F | S1=SR=D1 | 7[2] -> S1 -> 5[1] -> 4[1] -> 7[4], SWNE | 7[3] |
| F | S5=SR=D4 | 5[3] -> 4[5] -> 7[11] -> S5 -> 5[6], NESW | 5[4] |
| F | S4=SR=D3 | 7[8] -> S4 -> 5[3] -> 4[5] -> 7[11], SWNE | 7[9] |

Each listed endpoint is the first physical return, but skips the next
stable event. The checker verifies these seven paths independently of
the earlier frontier and certificate engines.

## Six short eliminations

**C,D,E.** Before D1 every south arrival is SL. If D1 is SR, its
adjacency to S3 makes D1=S2; if D1 is NL, the following S3 is SR=D2.
Thus every SR before S4 has west ordinal at most two. D4 must precede
S4 and cannot be SR, so D4 is NL. Its next event is S4=SR=D5.
But D5 must immediately precede S6. This skips S5, a contradiction.

**A.** If S1 were SR it would be D1, giving the first wrong SWNE
return in the table. Hence S1 is SL. The adjacency D1 -> S2 forces
D1=NL and S2=SR=D2. If D3 is NL, its successor S4 is SR=D4,
giving the wrong NESW return. Hence D3 is SR. Since it precedes S4,
it must be S3. Now S2=SR=D2 and S3=SR=D3 are consecutive in both
ordinal lists, which the intervening L event makes impossible.

**B.** The first SWNE return again forces S1=SL, followed by
D1=NL and S2=SR=D2. If D4 is NL, its successor is S4=SR=D5,
whose next event would have to be S6, skipping S5. Thus D4 is SR.
It precedes S4 and cannot be S1 or S2, so D4=S3. The displayed
eight-step SWNWSENE path now skips the next row-seven event.

**F.** The first SWNE return forces S1=SL, D1=NL, and S2=SR=D2.
If D3 is NL, its successor is S5=SR=D4, giving the wrong NESW
return. Therefore D3 is SR. It precedes S5, so it is S3 or S4.
It cannot be S3, because then S2=SR=D2 and S3=SR=D3 would be
consecutive in both ordinal lists. It must be S4=SR=D3, giving the
last wrong SWNE return in the table.

These eliminations mention no final NR event and no wake parity at 8.
They therefore exclude both `omega8=0` and `omega8=1`.

## Audit of the original proof and all-width endpoint derivation

The local computation in
`research-notes/positive_skew_upper_fat_quiet34_wake5_exclusion_2026-10-01.md`
is sound. A fresh implementation imports no previous proof engine,
regenerates all 351 nonnegative count vectors and the 533,498 raw-word
counts, independently regenerates every emitted candidate, and
replays all 158 finite physical and 34 unbounded integer-clock
rejections. Its terminal counts are 24 and 27, with physical words
NESW (20), SWNE (24), and SWNWSENE (7). All stages are complete.
The clock equations use **+N**, strict order, and only `N>=1`.

There are two inaccurate explanatory sentences in the endpoint prose.
For `W=6m+2`, the fixed fibre-one wakes number two and have opposite
signs; they do not number at least three. For `W=6m+4`, the fibre-zero
pair is already completed by the lower wakes 0 and 6. Neither error
changes the displayed family or its consequence. The following proof
supplies the correct sign argument.

At growth eight, lower thin 110 contributes `{0,4,5,6}`, and the upper
cap in question contributes `{W-5,W-2,W}`. The prior complete width-16
exclusion gives `W>=18`, making the two seven-offset bands disjoint.
There is one residual wake. Lower quiet seven puts it above 7; no
quietness of upper six or seven is assumed in the arithmetic argument.

Use fibre `j=-t mod3`, sign `(-1)^t`, and `n=ceil(t/3)`.
Each fibre's signed sum is 2 modulo 4. With eight distinct wakes, this
forces fibre sizes 4,2,2: the four-wake fibre has a 3+1 sign split;
each two-wake fibre is uniform in sign. Consequently:

* If `W=6m`, the seven fixed wakes give at least three wakes in both
  fibre zero and fibre two. Both would need size at least four, leaving
  no room for the required two wakes of fibre one.
* If `W=6m+2`, fibre zero already contains `{0,6,W-5,W-2}`. Fibre one
  has `{5,W}` with opposite signs, signed sum zero. It needs at least
  two extra wakes to reach sum 2 modulo 4, but only one residual exists.
* Therefore `W=6m+4`. Fibre zero is `{0,6}` with two positives, and
  fibre two is `{4,W}` with two positives. Fibre one contains
  `{5,W-5,W-2}` with signs `-,-,+`; the residual must also be negative
  in fibre one. Write it `6p+5`.

The lower band gives `p>=1`. Since the residual is at most W, initially
`p<=m-1`; but `p=m-1` would duplicate the fixed wake `W-5`. Therefore
`p<=m-2`, without assuming quiet upper six or seven. The fixed signed moment
is `2m+5`; the residual contributes `-(2p+2)`, so the full moment is
`2(m-p)+3`. Moment one modulo four gives `m-p` odd. Since the initial
upper bound gives `m-p>=2`, odd parity gives `m-p>=3` and
`p<=m-3`.

For rank, the seven fixed wakes give 11 increasing-fibre pairs: five
from fibre zero to one, three from zero to two, and three from one to
two. The residual has `n=2p+2`, between 4 and `2m-2`; it adds two
pairs from fibre zero and one pair to fibre two. The total rank is 14,
which is even. Hence the complete arithmetic family is exactly

```text
W=6m+4,
O={0,4,5,6,6p+5,W-5,W-2,W},
m>=4, 1<=p<=m-3, m-p odd.
```

The remaining upper distance is
`W-(6p+5)=6(m-p)-1=12r+5`, where `r>=1`.
It is therefore 17,29,41,... . The closest lower fixed wake has upper
distance `W-6>=22`; all upper offsets 6 through 16 are quiet. In
particular the local theorem applies and excludes every member of
this arithmetic family. The minimum arithmetic example has `W=28`
and wakes `{0,4,5,6,11,23,26,28}`; it is an arithmetic candidate,
not a trajectory.

The independent original-coordinate regression through even widths
18..150 allows the residual at every unused offset 8..W, including
upper six and seven. It finds exactly the same 121 endpoint sets and recomputes all
signed sums, moments, and ranks directly. The sign/rank/moment proof
above supplies the unbounded scope; the regression is not an all-width
enumeration.

## Reproduction and scope

From the project root:

```text
python -B work_positive_skew_upperfat_wake5_hand_20261002/verify_hand_reduction.py
python -B work_positive_skew_upperfat_wake5_hand_20261002/audit_saved_prefixes.py
```

The first command is standard-library only and checks all 18 adjacency
walks, seven conditional bad first returns, and 121 endpoint sets.
The second additionally uses Z3 to recheck the 34 rejected clocks and
reads the saved prefix evidence; all outputs stay in this new folder.
No resource cap is used for candidate generation. Its eight-step
terminal witness check verifies an explicit return for every one of
the 51 emitted terminal words; it does not prune words that lack such
a witness. The terminal hand argument independently eliminates those
words without enumeration.

Only the stated local cap and its lower-thin-110 growth-eight endpoint
family are closed. Other upper caps, other lower bands, and the whole
literal positive-skew orbit remain **OPEN**.
