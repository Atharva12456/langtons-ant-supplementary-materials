# Independent source and checkpoint review of the finite W22 join

`source_geometry_audit.json` is PASS for every one of the 1,518 complete
parent domains. The checker imports no frontier, production constraint
constructor, join implementation, or clock engine. It regenerates all
617,021 necessary row-nine words and all 135,293 entered row-ten words
without memoization. It also reconstructs every one of the 234,821 cached
constraint signatures from actual compass traces, including signatures
whose word domains are nonempty.

The physical representative of row `t` is `(0,-t)`. The checker starts
each proposed new-row departure there, follows each compass step in literal
coordinates, and matches old arrivals by their heading ordinal. It stops
at the first return to the new row or at an unknown edge. A return to
`(0,-t)` forces the immediately next stable new-row event; its incoming
heading and ordinal supply the cached adjacency pair. No period, phase,
growth, or numerical search bound enters this implication.

For the Boolean word domain, remaining port counts determine the prefix
length, next R/L turn, and all used incoming and outgoing ordinals. Together
with the required next incoming heading/ordinal, they determine every
possible continuation. This is the complete memoization state. A required
zero-copy target already used by the prefix is impossible, including a
target equal to the current event. The separate reverse-order complete
word audit in `constraint_domain_audit.json` verifies every cached Boolean
result. `external_audit_link.json` checks that its digest is exactly the
final 234,821-signature cache used here.

The row-nine source protocol is also complete. The first 231 parents reuse
only previously complete checkpoints. Their saved survivors preserve the
actual row-eight word and upper index, and their saved count domain equals
the exact full-strip matrix. Their survivors and 100,364 clock rejects form
a disjoint partition of the independently regenerated source word domain.
Later parents regenerate the entire source domain. Empty parents are
complete zero-word domains; an omitted zero Counter key supplies no bound
or exclusion on its own. All 1,518 current checkpoints are complete and
consecutive, and the input list equals the independently checked complete
row-eight survivor list.

For fixed period `N`, this checker derives every equality directly from
the compass edge: `tau(target)-tau(source)=1-N*dx`. It discovers actual
connected components by its own BFS; no producer labels or potentials are
read. Each component is connected by construction, so disconnected free
roots are never merged. It then applies all stable gaps of four and tests
the resulting component difference constraints. The final source audit
checks 231 imported UNSAT examples, 1,003 new UNSAT examples, 740 SAT
examples, and the unique row-ten UNSAT example. The separate complete
`lookahead_geometry_clock_audit.json` supplies fresh proofs for all 113,976
clock rejections, including 199 original-variable Z3 cross-checks.

The final partition is 498,641 empty row-ten continuations, 13,611 new
row-nine clock rejects, 135,292 empty row-eleven continuations, and one
row-ten clock reject, in addition to the imported row-nine clocks. No
continuation reaches a complete row-eleven word. Periods 210, 226, and 242
come from the complete count matrices, with no period or raw-word ceiling.
This closes the W22 lower-thin011 / upper-F123 wake-six member only; it
does not exclude arbitrary widths or the whole growth-eight orbit.

The first audit invocation stopped after parent 1,050 because the auditor
indexed an omitted zero Counter field. Its independently regenerated
empty domain already matched the producer. The corrected full invocation
passed all parents. The progress artifact is explicitly incomplete and
superseded by the final report. No canonical notes, ledgers, or prior
upper47 audit files were modified.
