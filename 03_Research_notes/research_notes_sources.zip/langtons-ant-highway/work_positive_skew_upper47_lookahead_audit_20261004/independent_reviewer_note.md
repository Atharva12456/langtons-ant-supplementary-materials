# Independent upper47 empty14 lookahead review, 2026-10-04

The reviewed zero-copy lookahead is a sound necessary-domain test: a
row 13 candidate is rejected as `REJECT_EMPTY14` only after **every exact
quiet14 count vector** has a completely exhausted empty word domain.
The finite calibration and frozen prefix checks below passed. This is
an engine/prefix review, not an exclusion of the unbounded family. The
whole orbit and the full lowerthin110 / upperF122 family with wakes at
offsets 4 and 7 remain **OPEN**.

This review wrote only to its new audit directory. It did not edit producer
programs, old audited sources, papers, or the finished W22 review.
Producer cache appends during the audit were permitted; the complete
cache-line prefix read by the auditor was hashed and checked unchanged
at the end. Complete parent files zero through 17 were fixed inputs.

## Exact family and period floor

The endpoint family is `W=6m+4`, residual `t=6r+5`, with
`1<=r<=m-3` and `m-r` odd. Thus `m>=4`, `W>=28`, and
`W-t=6(m-r)-1=17 mod12`, at least 17. Upper inward offsets 8 through 16
are quiet. At minimum width, the upper band through 16 is at global
levels 12 through 28 and is disjoint from the lower band 0 through 7.
The fixed lowerthin110 template has 34 events. These facts justify the
necessary upper-clock domain `N>=max(62,assignedUpper+34)`, `N=2 mod4`,
with upper `+N` edge gauge and stable gaps at least four. There is no
period ceiling. The same disjoint lower band remains valid through 16.

The source is the complete 2,076-word upper12 frontier. The auditor checked
the producer's exact source/result and source-audit hashes, and all
**112** individual source hashes in the saved independent upper12 audit.
That earlier audit's full regeneration was not repeated.

## Recurrence, geometry, and word-state completeness

At quiet14, let `b` be the known S-arrival count from row 13 and `c`
the known W-departure count into row 11. With `s=SR`, the only possible
port multiplicities are

`SR=s`, `SL=b-s`, `NL=c-s`, `NR=b+c-3s`,

for every integer `0<=s<=min(b,c)` for which all four are nonnegative.
This solves the known interfaces and `R=L`; it is an exact finite domain
from flow, with no port-count cutoff. Zero-valued port entries are omitted
canonically. The corresponding odd-row recurrence was checked for all
reviewed source parents as well.

The independent auditor computes rotation from the compass cycle
`E,S,W,N` and traces literal `(x,y)` starting at `(0,-14)`. Each old edge
is matched by its independently counted heading ordinal. It stops at the
first quotient row 14 entry or an unknown interface. Only a return to
the starting physical point imposes the immediately next stable event;
a translated row 14 entry imposes no zero-copy adjacency. Unknown paths
cannot supply an empty-domain certificate. Stopping at a repeated old
quotient event may omit an additional necessary condition, but does not
introduce a false physical next-event constraint.

For the quiet14 count vectors, the known W departure multiplicity is
`NL+SR=c` independently of `s`; E departures go into unknown row 17.
Thus the literal zero-copy pairs are constant across one row 13 candidate's
quiet14 count vectors. The audit still compares each vector and each
referenced cache entry separately.

For a fixed initial count vector, the remaining counts determine prefix
length, the next R/L turn, and every consumed incoming/outgoing ordinal.
Together with the next required heading/arrival ordinal, they determine
all possible continuations. The producer memo key is complete for this
zero-copy predicate. Its early check that a forced next target has already
been consumed rejects an impossible next event, including a self-target.
An unfinished final next-event requirement rejects the word. A true
answer carries a literal complete witness; an empty answer exhausts the
finite state graph.

The independently written Boolean oracle instead traverses a breadth
layer of **consumed-count states**, retaining the required next ordinal
but omitting the producer's early already-consumed-target prune. It uses
no producer or older auditor imports. Self-target and unfinished-final-
requirement fixtures both reject; an unconstrained one-event word and an
empty quiet word both remain possible.

## Fresh frozen-prefix and independent calibration results

`python -B work_positive_skew_upper47_lookahead_audit_20261004/audit_lookahead.py`
exited zero in **29.808 seconds**. Its report is `independent_audit.json`.

For the fixed **18 complete producer parents** zero through 17, the auditor
checked consecutive candidate indices, candidate uniqueness, exact
source parent prefixes, exact row 13 count vectors/raw word totals,
all imported complete-checkpoint and literal-rejection source bindings,
every row 14 count vector, every used physical pair signature, every saved
positive word witness, and the all-vectors disposition. It checked:

| Frozen-prefix check | Count |
| --- | ---: |
| Literal row13 candidate records | 9,698 |
| Exact quiet14 count-vector queries | 111,451 |
| Zero-copy return paths | 49,451 |
| Translated return paths correctly omitted | 7,183 |
| Positive witness queries directly checked | 25,178 |

For the first **two complete source parents**, the auditor went further.
It independently regenerated their entire plain zero-copy row 13 domains,
compared exact sets with saved survivors and literal prior rejections,
replayed every physical rejection in actual coordinates, and tested every
old clock rejection with original-variable Z3 and unbounded N:

| Independent initial-parent calibration | Count |
| --- | ---: |
| Complete plain row13 source words | 2,998 |
| Prior physical first-return rejections replayed | 2,758 |
| Prior clock rejections proved UNSAT | 176 |
| Row13 survivors calibrated | 64 |
| Every exact quiet14 vector calibrated | 687 |
| Empty quiet14 vector answers | 611 |
| Nonempty quiet14 vector answers | 76 |
| Row13 candidates rejected by all-vector emptiness | 48 |
| Row13 candidates retained as necessary | 16 |

The 687 queries contain 269 distinct cached Boolean signatures; all 269
were freshly checked by the independent breadth state traversal. This
reproduced the producer's earlier calibration without importing that
oracle. Every one of the 16 retained initial row 13 candidates also has a
fresh original-variable SAT model. All literal edge equalities, stable
gaps, the period floor, and period residue were evaluated against each
model directly. Models are saved in `row13_SAT_models.json`.

The calibration records and independent word witnesses are saved in
`independent_calibration_records.json`. The report binds the exact files
used by SHA-256 and records the append-only producer cache prefix of
26,912 complete records read for this run. **It does not certify all
26,912 Boolean answers.** Beyond parents 0 and 1, this review checks the
saved complete candidate prefix, lookahead geometry, count domains,
positive witnesses, and disposition semantics; it does not independently
regenerate every later guarded row 13 source word or prove every later
clock rejection. Full 2,076-parent coverage is not asserted.

## Caps, checkpoint reuse, and provenance

`cap_probes.py` called the actual pure producer functions, without invoking
the runner or touching its logs/cache. The zero-DP state cap, zero-DP
expired deadline, generator expired deadline, generation node cap, and
clock iteration cap each raised an incomplete/unknown exception and
returned no empty answer. Mixed or unfinished domain lists produce
`INCOMPLETE`; one complete positive domain retains a candidate; only all
complete negative domains produce `REJECT_EMPTY14`. The targeted results
are saved in `cap_probes.json`.

The runner writes a complete candidate only after all quiet14 vectors
have answers. A cap during a vector leaves that candidate unfinished,
and the parent receives an explicitly incomplete file. A complete parent
is written only after its source generator is exhausted. Restart skips
already completed candidates only when deterministic indices agree.
The active input metadata binds the source and engine dependencies.
Completed parent outputs and incomplete histories remain distinct.

Imported parents use only previously complete row 13 checkpoints and
retain their exact literal survivor words. The carried unguarded domains
are supersets of guarded domains, which is safe for necessity; prior
physical/clock rejections remain separately bound. The independent
initial two-parent set reconstruction confirms those particular reused
domains directly, rather than relying on counts alone.

One initial provenance omission was found: the first input bound engine
dependencies but omitted `lookahead_run.py` itself. The implementer
preserved `lookahead_run_pass1_snapshot.py` and
`input_before_runner_binding.json`, recorded `runner_binding_migration.json`,
and bound the active runner before subsequent resumes. I verified all
three digests, exact old/new metadata correspondence, and the source
diff: the only changed runner logic is the added self-hash metadata
field. This concern is resolved for the reviewed active version.

## Scope of a positive word answer and future stronger predicates

A positive row 14 domain is only a literal alternating-word witness under
the witnessed zero-copy constraints. It does not establish physical
first-return feasibility, clock feasibility at row 14, or an ant orbit.
The producer has asserted no complete row 14 physical/clock continuation;
the fresh SAT models here are for partial upper rows 0 through 13.
Testing one canonical positive row 14 witness cannot prove that its
entire count-vector domain is empty.

Adding verified one-new-visit old-cell physical return pairs or signed
translated-excursion order can strengthen the necessary domain. Such a
version must use a separate cache context containing **all** added
predicate signatures. Zero-only cached answers cannot be substituted.
The remaining-count/next-need memo key stays complete only when every
new predicate is determined by the currently derived port ordinals and
current port; a predicate depending on hidden prefix order or earlier
port pairings needs additional state or a separate completeness proof.
Every new empty answer still requires complete exhaustion for every
exact quiet14 count vector, and every cap remains unknown.

No speed benchmark or partial parent prefix closes the family.
