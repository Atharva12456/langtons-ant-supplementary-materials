# One-new-event physical guard, independent audit 2026-10-03

The guard is a necessary physical exclusion under the existing stable
words and directed ordinal edges. It requires no new period or row-phase
assumption. Independent reconstruction and complete row 12 regression
pass. The guard removes all 12,377 physical rejects in that domain,
while preserving all 24,507 source-clock words and all 2,076 survivors.
This does not assert that the guard detects every physical obstruction
at other depths or that any surviving word has a trajectory.

## Conditional witness proof

Fix the assigned old rows, the new-row count vector, and an old stable
event `s=(old_level,i)`. Begin at its physical cell `(0,-old_level)`.
Trace old directed ordinal edges until either:

* the first physical return to this starting cell occurs;
* the first new-row arrival is reached;
* an unknown exit or repeated old quotient event prevents a finite
  found-entry trace.

Only the second case supplies this guard. Record its incoming heading
`h`, incoming ordinal `a`, and its literal physical position. For a
possible new-row port `p` with heading `h`, fix its outgoing ordinal
`b`. The outgoing compass heading and ordinal determine a unique
matched old arrival. Follow old ordinal edges from that arrival until
the first physical return to the starting cell, or until the assigned
old trace ends. If the first return is to old stable event `r` with
`r!=(old_level,i+1)`, then the combination

```
(incoming heading h, incoming ordinal a, port p, outgoing ordinal b)
```

is impossible in the new row.

Indeed, any full candidate containing this combination has the same
old prefix, the specified new arrival/port/departure, and the same old
suffix. This is a complete physical trace touching exactly one new-row
event. Its return to the old starting physical cell occurs before any
other return there, so it must be the immediately next stable visit.
A nonconsecutive old target contradicts that requirement. The argument
uses physical coordinates throughout; a repeated quotient event at a
nonzero copy is never treated as a physical return.

If the trace needs another new-row event, it adds no exclusion from
this one-event guard. Repeated quotient events with no finite recorded
witness are also left untested. Stopping those searches can miss an
obstruction but cannot create a false forbidden combination.

## Generator state

Immediately before appending port `p`, its incoming ordinal is the
number of earlier arrivals of `p`'s heading, and its outgoing ordinal
is the number of earlier departures in `out(p)`. The guard therefore
tests the forbidden tuple using both counters **before** the append.
All these counters are functions of initial minus remaining port
counts. The forbidden table is fixed for the old parent and new count
vector. Consequently the added test introduces no history beyond the
generator's existing `(remaining counts,next-required)` state.

This statement is about the conditional guard. It does not license
memoizing full clock feasibility or arbitrary physical-return tests
using only those counters. Root's optional prefix-clock callback was
not invoked in this production-path comparison; the comparison used
its default `None` and also tested the physical-pair option.

## Independent complete row-12 checks

`audit_physical_pairs.py` imports only the independent compass,
ordinal, and word helpers in this audit folder. It constructs every
conditional forbidden pair afresh and verifies each root witness
step by step, including the incoming/outgoing ordinal splice, every
physical coordinate, exactly one new-row event, the first-return
property, and the nonconsecutive returned old event.

The root modules were executed only by a separate comparison runner.
Their guard maps and emitted words were treated as untrusted input by
the independent checker. All 55 parents and 262 count-vector tables
match exactly, including 3,876 conditional pair witnesses. Both the
root default signed generator and its physical-guard version agree
with independent nonmemoized generators and direct full-word filters.
Every actually removed full word also realizes its conditional
physical witness at the word's concrete new stable event.

| Complete row12 domain | Emitted candidates | Physical rejects remaining | Clock rejects remaining | SAT survivors |
|---|---:|---:|---:|---:|
| Original necessary words | 38,960 | 12,377 | 24,507 | 2,076 |
| Physical-pair guard only | 26,583 | 0 | 24,507 | 2,076 |
| Signed excursion order only | 27,096 | 8,626 | 16,394 | 2,076 |
| Both guards | 18,470 | 0 | 16,394 | 2,076 |

The physical guard removes all saved physical rejects and no saved
physical-safe word, including every word rejected later only by the
shared clock. Combined with signed order, it removes 20,490 of 38,960
candidates (52.5924%). These are measurements on this complete row 12
domain, not an estimated rate at later depths. Full physical and
clock checks remain necessary for future complete extensions.

No resource cap was hit. The comparison runner's explicit cap was
3,000,000 recursive nodes per parent across its two calls; total
comparison nodes across all 55 parents were 269,279. A capped output
would be labeled INCOMPLETE and could not produce a PASS audit.

The final hash check confirmed that the current source modules are
exactly the versions whose default and physical-guard outputs passed:

```
ordered_words.py
63338f8e3b0550bd8363c02e54395ac6c594fc1433ade6c0fb0e4f8c35f807d8

physical_pairs.py
52c78551797633cafe8d2c360f05c697f32d7d077a8a02b36517573c6cdace61
```

Artifacts are `physical_pair_audit.json`,
`independent_physical_pair_witnesses.jsonl`,
`root_physical_pair_domains.json`, `audit_physical_pairs.py`, and
`compare_root_physical_pairs.py`. Root source, canonical notes,
ledgers, and papers were not edited by this audit. The literal
positive-skew growth-eight orbit problem remains **OPEN**.
