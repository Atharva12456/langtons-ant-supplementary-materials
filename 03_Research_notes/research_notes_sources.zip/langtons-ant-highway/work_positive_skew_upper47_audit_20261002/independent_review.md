# Independent upper F122 wake4/7 audit, 2026-10-02

The complete weak stages 3 through 11, the 97-state shared-period survey,
and the complete shared-period stage 12 were checked independently of
`frontier`, `fast_clock`, and root's `shared_clock`. The literal
positive-skew `(1,3)`, growth-eight orbit problem remains **OPEN**.
These are complete necessary local domains, not trajectories.

## Scope and source boundaries

The upper cap has wakes at inward offsets 0,4,7 and quiet offsets 1,2,3,
5,6. For lowerthin110, the independent endpoint derivation in
`../work_positive_skew_high_thin_endpoints_20261002/high_thin_endpoint_families.md`
forces quiet offsets 8 through 16, width
`W=6m+4 >=28`, and residual distance `17+12h`.

The original source is
`../work_positive_skew_upperthin_high110_20261002/wake47`.
Its complete stages 3 through 11 were audited. Its stage 12 is incomplete
and was excluded from seeds and completeness claims. The separate
complete stage 12 source is
`../work_positive_skew_upper47_shared_20261002/level12/parent_000.json`
through `parent_054.json`, together with each parent's rejection file.
The retained `parent_030_INCOMPLETE.json` history was ignored; the
complete `parent_030.json` was checked. No stage 13 output was used.

## Exact complete-domain accounting

For stages 3 through 11, the clock domain is integer `N>=1`, no upper
bound, upper east shift `1+N`, and strict stable order (gap 1). No growth,
P22, congruence, or assigned-event period floor is imposed in this weak
domain.

| Stage | Parents | Complete count vectors | Raw alternating words | Emitted necessary words | Physical rejects | Clock rejects | Survivors |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 3 | 1 | 1 | 2 | 2 | 0 | 0 | 2 |
| 4 | 2 | 6 | 46 | 5 | 0 | 1 | 4 |
| 5 | 4 | 10 | 97 | 14 | 4 | 0 | 10 |
| 6 | 10 | 28 | 847 | 79 | 20 | 8 | 51 |
| 7 | 51 | 183 | 73,727 | 122 | 65 | 8 | 49 |
| 8 | 49 | 238 | 555,943 | 165 | 106 | 33 | 26 |
| 9 | 26 | 111 | 277,382 | 224 | 23 | 173 | 28 |
| 10 | 28 | 110 | 705,974 | 1,051 | 296 | 639 | 116 |
| 11 | 116 | 607 | 16,995,791 | 3,978 | 3,804 | 77 | 97 |
| Cumulative | — | 1,294 | 18,609,809 | 5,640 | 4,318 | 939 | 383 |

The cumulative survivor total counts surviving prefixes at each stage;
the final complete domain has 97 states. All 383 cumulative survivors
were independently checked for physical first-return safety and given
affine integer clock witnesses. Their fixed witness periods were also
checked with the original event variables in Z3.

The complete shared-period stage 12 starts from the verified 55-state
subset of stage 11. Its independently reconstructed totals are:

| Parents | Count vectors | Raw alternating words | Emitted necessary words | Physical rejects | Shared-clock rejects | Survivors |
|---:|---:|---:|---:|---:|---:|---:|
| 55 | 262 | 46,445,636 | 38,960 | 12,377 | 24,507 | 2,076 |

Every complete parent vector list, raw-word total, emitted-word set,
rejection count, and survivor set agrees with the source. All emitted
words are accounted for exactly once as a physical rejection, a clock
rejection, or a survivor. Parent domains are reconstructed from the
count equations; they are not accepted merely because a saved source
declares a stage complete.

## Independent word and physical checks

The seed is the upper half-turn gauge

```
0 NR
1 WR WL
2 NR SL
```

Compass turns are defined directly by right/left rotations; geometric
steps use `(E,N,W,S)=((1,0),(0,1),(-1,0),(0,-1))`. An edge changes the
transverse level by `3dx-dy`. Directed ordinal edges match departures
in their stable order to arrivals of the same compass heading at the
destination row.

For a new odd row, let `a` count east departures from row `t-3` and `d`
count north arrivals in row `t-1`. Every nonnegative count vector is

```
ER=a-e, EL=e, WR=d-e, WL=a+d-3e-wake,
0 <= e <= min(a,d).
```

For a new even row, let `b` count south departures from row `t-1` and
`c` count west arrivals in row `t-3`. Every nonnegative vector is

```
NR=wake+b+c-3s, NL=c-s, SR=s, SL=b-s,
0 <= s <= min(b,c).
```

The raw alternating word count is `R! L! / product(port_count!)`.
The new-row wake bit is `R-L`. The independent generator then walks
each possible new-row departure through old rows. A first return to
the new row at zero physical displacement forces the immediately next
stable arrival, including its incoming ordinal. First returns at
nonzero displacement add no adjacency condition. Recursive word
enumeration obeys these necessary conditions and uses **no memoization
or dead-state cache**.

All saved physical rejection certificates were replayed by fresh
compass/ordinal edges. Every path event, physical coordinate, copy,
step count, direction, first-return assertion, and nonconsecutive
returned stable event was checked. All certificates in these complete
domains have finite, complete traces. Survivors were independently
checked from every starting event, including possible later physical
returns arising from a repeated quotient cycle with nonzero copy
displacement.

## Independent unbounded clock proofs

For every assigned directed edge `q -> r`, the upper clock equation is

```
T(r) = T(q) + 1 + N*dx.
```

The independent constructor contracts the bidirectional equality
graph. Inside a component, each event has potential `a+bN`. Equality
cycles either impose a consistent integral fixed period or prove an
inconsistency. A stable gap constraint between events becomes a
difference-graph arc between components with weight

```
gap + a(q)-a(r) + (b(q)-b(r))*N.
```

At a proposed period, a positive directed cycle proves infeasibility.
For cycle weight `c+dN`, a negative slope requires a higher lower bound
on `N`; a nonnegative slope rejects every period above the current
necessary bound. For the shared domain, each new bound is rounded up
to `N=2 mod4`. A fixed period is checked against the full domain. If
there is no positive cycle, longest-path component values give literal
integer event times, which are verified against every original edge
and stable gap. No period upper bound is introduced. An iteration cap
would raise an explicit `INCOMPLETE` error and produce no PASS result;
no cap was reached.

All 939 weak clock rejections have independent affine proofs: 917 end
with a positive cycle excluding every remaining period, and 22 have a
positive cycle at a forced period. All 222 distinct weak rejection
coefficient signatures were cross-checked with original-variable Z3.

For the growth-eight lower110 coupling, the required shared domain is

```
N >= max(62, assigned_upper_events+34),
N = 2 mod4,
upper east shift 1+N,
stable gap4.
```

The saved forced lower110 prefix was directly recounted as row lengths
`1,2,2,4,3,3,9,10`, giving 34 events. Its prior domain derivation was not
repeated in this audit. At `W>=28`, upper rows through 11 lie in
`[W-11,W]`, and through 12 in `[W-12,W]`; both are disjoint from lower
rows 0 through 7. Thus adding the 34 lower events to the assigned upper
events is a necessary period floor throughout this arithmetic family.

The independent affine and original-variable Z3 screen of all 97
complete stage-11 states reproduces exactly 42 UNSAT and 55 SAT indices. Every
supplied SAT model period was checked directly in Z3, rather than
requiring it to equal the independent constructor's witness.

At complete stage 12, all 24,507 shared-clock rejections have independent
affine proofs. Every one of the 2,076 survivors has literal integer
clock times checked on all original constraints and an additional
original-variable Z3 check at its witness period. The 275 distinct
UNSAT coefficient-signature/initial-floor representatives were also
checked in original-variable Z3. These checks retain an unbounded
integer period; they do not turn endpoint arithmetic or local clocks
into a trajectory construction.

## Artifacts and reruns

* `audit_upper47.py`: complete audit of weak stages 3..11 and 97-state shared survey.
* `independent_audit.json`: PASS report, exact counts, indices, and source hashes.
* `complete3_11_domains.json`: independently reconstructed count-vector domains.
* `weak_clock_certificates.jsonl`, `shared_period_certificates.jsonl`: affine proofs and event-time witnesses.
* `verified_shared55_seed.json`: the verified necessary complete stage-11 subset.
* `lower110_event_recount.json`: direct event recount of the previously complete forced lower prefix.
* `audit_shared12.py`: independent complete 55-parent row 12 audit.
* `shared12_independent_audit.json`: PASS report for the complete stage-12 audit, including source hashes.
* `shared12_complete_domains.json`, `shared12_clock_certificates.jsonl`: count domains and individual affine clock certificates.
* `verified_shared12_seed.json`: all 2,076 verified necessary stage-12 survivors.

Both auditors import no root enumeration or clock engine. The stage 12
auditor imports only the independent helpers written in this folder.
Run either script with Python from the project root. Canonical notes,
ledgers, papers, and all source folders remain unchanged by this audit.
