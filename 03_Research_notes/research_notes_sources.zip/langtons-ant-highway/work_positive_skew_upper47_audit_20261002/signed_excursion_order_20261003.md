# Signed old-row excursion order, independent audit 2026-10-03

The pruning lemma is valid under its stated period floor. It introduces
no extra row-phase assumption. The complete upper47 row 12 regression
retains all 2,076 verified survivors while removing 11,864 of 38,960
previously emitted candidates (30.4517%). The orbit problem remains open.

Let a new-row departure at stable index `i` follow assigned old ordinal
events and first enter the new row at arrival index `q`. Write `L>0`
for the number of steps and `k` for its cumulative copy voltage. A
found-return traversal visits each old quotient event at most once:
if it repeated an old event before entry, its deterministic successor
cycle could never first enter the new row later. Thus

```
L <= old assigned event total + 1.
```

For the shared upper47 domain,
`N >= full new upper event total +34`, so `L<N`, including an empty
new row. With upper clock sign `+1`, summing edge equations gives

```
T(q)-T(i) = L+Nk.
```

Strict stable order therefore forces `q>i` when `k>0`, and `q<i`
when `k<0`. At `k=0`, this is a first return to the same physical
cell, so its arrival must be the immediately next stable visit,
`q=i+1`. Unknown exits and old cycles with no found entry imply no
condition from this lemma. For a lower clock with sign `-1`, replace
`k` by `-k` in the two nonzero cases; the zero case is unchanged.

Suppose the target heading is `h`, its incoming ordinal is `j`, and
the prefix has seen `a` arrivals of heading `h` before appending the
current port `p`. A positive copy must target an arrival absent after
the append, hence

```
j >= a + [p has incoming heading h].
```

A negative copy must target an arrival already present before the
append, hence `j<a`. The before/after distinction excludes a target
equal to the current arrival. The proof uses the fixed representatives'
existing clock equation and strict row order; it does not need a
global choice of the row's first-visit phase or a new within-period
time window.

All incoming and outgoing ordinal counters are sums of
`initial_port_count-remaining_port_count`. The current position and
turn parity are also determined by the remaining counts. Thus the
nonzero-order predicate introduces no extra history into the word
generator. Its cache state remains `(remaining counts,next-required)`,
where `next-required` records the existing zero-copy adjacency rule.
This statement concerns this local necessary-word pruner, not a cache
for full clock feasibility or full physical-return checks.

`audit_ordered_excursions.py` independently reconstructs old excursions
with compass coordinates, uses a nonmemoized signed generator, and
also filters the old emitted words by literal target indices. All
262 count-vector domains across the 55 complete row 12 parents agree
between these two independent forms and root's isolated generator.
Root's generator was executed only in a separate comparison runner;
the independent checker imports no root generator or frontier engine.
No resource cap was hit. A capped comparison would be recorded as
explicitly INCOMPLETE and would not receive a PASS result.

Across every new row 3 through 12 of all 2,076 survivors, the checker
verified 30,619 found excursions against literal integer clock
witnesses: 24,437 zero-copy and 6,182 negative-copy, with maximum 44
steps. Negative voltages were `-1` in 6,177 cases and `-2` in 5 cases.
There are no positive-copy found excursions in these survivors;
the positive rule still follows from the hand proof above. The
separate signed phase fixtures compare the root predicate with
literal full-word positions for 55,200 cases across both clock signs
and both incoming axes, including positive-voltage cases and 10,272
self-target cases.

The row 12 pruning accounting is exact:

| Classification in the old complete domain | Retained | Removed |
|---|---:|---:|
| Physical rejection | 8,626 | 3,751 |
| Shared-clock rejection | 16,394 | 8,113 |
| SAT survivor | 2,076 | 0 |
| Total | 27,096 | 11,864 |

The 8,113 removed source-clock words were already independently proved
UNSAT in the complete row-12 audit. All 3,751 removed source-physical words
were additionally proved clock-UNSAT with the independent affine
constructor; 72 coefficient-signature/floor representatives were
cross-checked with original-variable Z3. Consequently every removed
word has a verified necessary obstruction, and the physical rejection
ordering in the source does not hide a lost clock-SAT survivor.

Artifacts: `ordered_excursion_audit.json`,
`ordered12_removed_physical_clock_proofs.jsonl`,
`root_ordered12_domains.json`, and `signed_phase_fixture_audit.json`.
This regression measures pruning in the complete row 12 domain; it is
not a claimed pruning fraction at other depths or a broad closure.
