# Generic upper fat cap with wake six: bounded necessary-word probe

Work date: 2026-10-02. This directory is isolated research output. The whole
literal `(1,3)` orbit problem remains **OPEN**.

The [finite width-22 join](../work_positive_skew_thin011_W22_join_20261002/finite_W22_exclusion.md) later excludes the width-22 lower011/F123 wake-six member. It does not close the generic upper cap studied here or the larger-width endpoint family.

## Exact domain

Use upper inward offset `u`, the half-turn gauge with `t=3x-y` and
representative `(0,-u)`. In this gauge the seed is

```
0: NR
1: WR WL
2: NR SL NR
```

Offsets 3,4,5 are quiet, offset 6 is wake, and offsets 7 through 13 are
quiet. Each row starts with R and alternates R/L; quiet rows have equal
turn counts and wake rows have one additional R. The upper lifted clock
uses E shift `1+N`, W shift `1-N`, and vertical shift 1, with integer
`N >= 1` and strict stable row order. There is no period upper bound,
period congruence, event-count lower bound on N, P22 condition, growth
budget, or width bound in this local probe.

The parent supplied the endpoint consequence for the lower011/F123
growth-eight family: `W=6m+4`, residual `6r+2`, `1<=r<=m-2`, `m+r` even;
the residual upper distance is `14 mod 12` and at least 14. This makes
upper offsets 7 through 13 quiet. That arithmetic was checked separately
by the endpoint agent; it is not a new endpoint classification here.

## Exact finite recurrence and necessary pruning

For odd `u`, let A be the east-departure count at `u-3` and D the north-
arrival count at `u-1`. For each nonnegative feasible `e`, the only count
vector is

```
ER=A-e, EL=e, WR=D-e, WL=A+D-3e-wake(u).
```

For even `u`, let B be the south-departure count at `u-1` and C the west-
arrival count at `u-3`. For each nonnegative feasible `s`, the only count
vector is

```
NR=B+C-3s+wake(u), NL=C-s, SR=s, SL=B-s.
```

Every alternating word in these finite count vectors is represented.
The generator follows a departure through already assigned rows to its
first new-row entry. It requires that entry to be the next event only
when its copy displacement is zero. A nonzero-copy entry makes no next-
event restriction. Full physical-return failures are rejected only with
a finite geometric certificate whose endpoint is the starting physical
cell and whose event is not the immediate next stable event. The strict
upper clock is checked with exact affine integer constraints, unbounded
above in N.

## Completed stages and the preserved resource limits

| Offset | Parents | Complete survivors | Emitted necessary words | Physical rejects | Clock rejects |
| --- | ---: | ---: | ---: | ---: | ---: |
| 3 | 1 | 4 | 4 | 0 | 0 |
| 4 | 4 | 9 | 10 | 0 | 1 |
| 5 | 9 | 29 | 35 | 4 | 2 |
| 6 | 29 | 160 | 445 | 225 | 60 |
| 7 | 160 | 164 | 1,283 | 1,103 | 16 |
| 8 | 164 | 111 | 4,375 | 3,782 | 482 |
| 9 | 111 | 190 | 22,938 | 3,572 | 19,176 |
| 10 | 190 | 415 | 51,783 | 38,176 | 13,192 |

Quiet10 represents 1,581 exact count vectors and 94,808,169,890 theoretical
raw alternating words. Necessary zero-copy adjacency emits only 51,783.
Those raw words were not enumerated individually.

The initial quiet10 pass hit its 60-second limit after 139 complete
parents. `stage_10.json` and `result.json` retain that **INCOMPLETE** result
unchanged. At the parent's request, `resume10.py` completed parents 139..189
in a separate 45.04-second pass. Parent 139 was restarted in full; duplicate
emitted rejection records were removed by exact `(parent,row-word)` key.
The final full count domain and deduplicated records are in
`complete10_domains.json`, `complete10_rejections.jsonl`, and
`complete10_result.json`.

Quiet11 hit the 60-second limit after only 19 of 415 parents, with 3,414
partial survivors. It examined 190 count vectors, emitted 21,527 words,
and rejected 17,117 physically plus 996 by clocks. Its 364,245 recursion
nodes remained below the two-million-node cap. `stage_11.json` and
`continuation_result.json` explicitly mark this stage **INCOMPLETE**.
Offsets12/13 were not attempted. No resource limit is an UNSAT result.

## Useful restriction and remaining gap

Every one of the 415 completed quiet10 survivors has the same initial
row 3/4 pair:

```
3: WR WL WR WL ER WL
4: NR SL SR SL NR NL NR SL
```

Thus quiet3..5, wake6, quiet7..10 excludes every other early upperF123
row 3/4 family in this generic weak clock domain. This is a finite necessary-
word implication; no hand proof of the row 3/4 rigidity is supplied.

All 415 also share row 5:

```
5: WR WL WR EL ER WL WR WL ER WL
```

Their entire row 6 word is one of two possibilities:

```
6A: NR SL NR NL SR SL SR SL SR NL NR                 (413 survivors)
6B: NR SL NR NL SR SL SR SL NR NL NR SL NR NL NR     (2 survivors)
```

Only three prefixes through offset7 remain. With 6A, offset7 is either

```
7A: WR WL WR EL ER WL ER WL ER EL ER WL WR WL        (324 survivors)
7B: WR WL WR EL ER WL ER WL ER WL ER WL WR EL        (89 survivors)
```

With 6B, offset7 is

```
7C: WR WL WR EL ER WL WR WL WR EL WR WL ER WL ER WL WR EL (2 survivors)
```

The generic cap is **not excluded**. A full quiet11 extension is missing,
and even the inspected portion of quiet11 is nonempty. A productive next
restriction must use additional ordinal/clock structure or a smaller
relevant family; extending this broad domain mechanically would exceed
the requested bounded probe.

## Independent checks

`independent_audit.py` regenerated each completed count domain and every
emitted necessary word using prior independently written geometric
helpers, then replayed all finite physical-return certificates. It
checked every rejected clock using a separate affine-potential
constructor, and checked surviving clocks for feasibility. It imported
neither `frontier` nor `fast_clock`. All complete stages 3..10 passed;
668 distinct clock coefficient signatures also passed Z3 cross-checks.
The report is `independent_audit_3_10.json`, with individual affine proofs
in `audit_{offset}_clock_proofs.jsonl`.

At terminal quiet10 alone the audit regenerated all 1,581 count vectors
and all 51,783 emitted words, replayed all 38,176 physical certificates,
proved all 13,192 clock rejections, and found feasible weak clocks for all
415 survivors. Of its clock failures, 12,464 have a positive cycle for
every permitted N and 728 have a positive cycle at an equality-forced
period. Survivor N witnesses lie between 35 and 55; these are sample
witnesses, not a period bound.

The independent audit took 191.902 seconds over all eight completed
stages. This was certificate verification, separate from the bounded
probe passes. The quiet11 partial domain was not audited as complete.

## Necessary period floors do not exclude the survivors

`period_floor_audit.py` independently retested all 415 complete quiet10
survivors with only the additional necessary bound
`N >= assigned upper events`, and separately
`N >= assigned upper events + 38` for the lower011 contribution.
Both domains retain all 415 words. The upper clock still has strict gap 1
and no residue condition, gap 4 condition, or upper bound on N.

The assigned upper event count ranges 103..131, and each word is feasible
at its own floor. Adding 38 likewise gives witnesses 141..169. The earlier
35..55 witnesses therefore give no upper bound on N. The separate fresh
inspection of all directed ordinal graphs found no closed quotient
successor cycle in any of these 415 words, so a proper closed-component
length/voltage obstruction is also unavailable here. The exact per-word
results are in `period_floor_records.json`; the summary is
`period_floor_audit.json`. These outcomes agree with the parent's
independent direct Z3 survey over all 415 words and both floors.
