"""Replay supplied strong-clock witnesses and their canonical phase rounding.

No search/frontier/clock implementation is imported. This checks a
redundancy lemma, not a new highway exclusion.
"""
from collections import defaultdict
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'work_positive_skew_upper47_shared_20261002'
AUDIT = ROOT / 'work_positive_skew_upper47_audit_20261002'
VECTOR = {'N': (0, 1), 'E': (1, 0), 'S': (0, -1), 'W': (-1, 0)}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as file:
        for block in iter(lambda: file.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def outgoing(port):
    x, y = VECTOR[port[0]]
    v = (y, -x) if port[1] == 'R' else (-y, x)
    return next(d for d in VECTOR if VECTOR[d] == v)


def edges(rows):
    ins, outs = defaultdict(list), defaultdict(list)
    for t, word in sorted(rows.items()):
        for j, port in enumerate(word):
            ins[t, port[0]].append((t, j))
            outs[t, outgoing(port)].append((t, j))
    result = []
    for (t, d), nodes in outs.items():
        dx, dy = VECTOR[d]
        u = t + 3 * dx - dy
        if u not in rows:
            continue
        assert len(nodes) == len(ins[u, d])
        result.extend((q, r, dx) for q, r in zip(nodes, ins[u, d]))
    return result


def main():
    prior = json.loads((AUDIT / 'shared12_independent_audit.json').read_text())
    assert prior['pass'] and prior['totals']['survivors'] == 2076
    parents = [json.loads((SOURCE / 'level12' / f'parent_{i:03}.json').read_text())
               for i in range(55)]
    seen = set()
    counts = defaultdict(int)
    certificate_file = AUDIT / 'shared12_clock_certificates.jsonl'
    with certificate_file.open() as file:
        for line in file:
            record = json.loads(line)
            if not record['sat']:
                continue
            i, j = record['parent_index'], record['survivor_index']
            assert (i, j) not in seen
            seen.add((i, j))
            rows = {int(t): tuple(w) for t, w in parents[i]['survivors'][j].items()}
            tau = {tuple(map(int, q.split(','))): value
                   for q, value in record['proof']['event_times'].items()}
            nodes = {(t, k) for t, w in rows.items() for k in range(len(w))}
            assert set(tau) == nodes
            period = record['proof']['period_witness']
            assert period % 4 == 2 and period >= max(62, len(nodes) + 34)
            phase = {q: 0 if q[0] % 2 == 0 else 3 for q in nodes}
            rounded = {q: 4 * ((value - phase[q]) // 4) + phase[q]
                       for q, value in tau.items()}
            changed = sum(tau[q] != rounded[q] for q in nodes)
            counts['witnesses_requiring_rounding'] += int(changed > 0)
            counts['event_values_changed'] += changed
            for t, word in rows.items():
                assert all((p[0] in 'NS') == (t % 2 == 0) for p in word)
                for k in range(len(word) - 1):
                    assert tau[t, k + 1] - tau[t, k] >= 4
                    assert rounded[t, k + 1] - rounded[t, k] >= 4
                    counts['stable_gaps_checked'] += 1
            for q, r, dx in edges(rows):
                increment = 1 + period * dx
                assert (increment - phase[r] + phase[q]) % 4 == 0
                assert tau[r] - tau[q] == increment
                assert rounded[r] - rounded[q] == increment
                counts['edge_equalities_checked'] += 1
            assert all(rounded[q] % 4 == phase[q] for q in nodes)
            counts['witnesses'] += 1
            counts['event_values'] += len(nodes)
    expected = {(i, j) for i, p in enumerate(parents)
                for j in range(len(p['survivors']))}
    assert seen == expected and len(seen) == 2076
    sources = [certificate_file, AUDIT / 'shared12_independent_audit.json']
    sources += [SOURCE / 'level12' / f'parent_{i:03}.json' for i in range(55)]
    report = {'pass': True, 'counts': dict(counts),
              'global_phase': 'tau=0 mod4 at even rows; tau=3 mod4 at odd rows',
              'clock_gauge_checked': 'upper +N; N2mod4; same-row stable gap4',
              'scope': 'Canonical phase rounding of every complete shared12 SAT witness',
              'new_exclusions': 0, 'whole_orbit_status': 'OPEN',
              'no_production_imports': True,
              'sources_sha256': {p.relative_to(ROOT).as_posix(): sha(p) for p in sources},
              'checker_sha256': sha(Path(__file__))}
    (HERE / 'phase_rounding_audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'sources_sha256'}))


if __name__ == '__main__':
    main()
