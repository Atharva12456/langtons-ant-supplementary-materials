# No upper (1,2,2) fat cap at drift (1,-3)

**Status, 21 September 2026.** The upper `(1,2,2)` fat-cap profile is excluded at every period. In particular, family A in the September 13 wake-family table is excluded. Family B, and the other cap profiles in the `(1,-3)` orbit, remain unresolved here. The whole drift orbit is not closed.

This is a hand proof using the previously established two-sided five-level normal form, same-cell first returns, and one upper-orientation time inequality. It does not require the long September 14–15 continuation analysis of forms P, Q, R, or U, and uses no period cutoff or upper bound on a black lifetime. A small accompanying script checks the explicit walks and the integer coefficients in the inequality; it is not an end-to-end formalization.

## Coordinates and prior input

At the upper cap rotate both spatial axes by 180 degrees and measure inward offset

`t = 3x' + y'`,

with the upper endpoint at zero. The drift in these coordinates is **`(-1,3)`**. Let `tau(v)` be the stable visit time at representative `(0,t)`. Matching directional departures and arrivals in their stable order gives

`tau(target) = tau(source) + 1 + N*dx`,

where `dx=1,-1,0,0` for local `E,W,N,S`. The sign is important: an east step contributes **`+N`** at the upper cap. At the lower cap it would contribute `-N`.

A port `NR`, for example, means arrival heading north followed by a right turn. Every stable word starts with a right turn and alternates right and left. Consecutive visits to one physical cell have a positive time gap divisible by four, so the gap is at least four. A specified zero-displacement walk with no intermediate visit to its starting cell must join consecutive stable visits there.

The two-sided `(1,2,2)` normal form is proved in [the September 12 cap note](https://drive.google.com/file/d/1JLYIDq4Narav-ArKnc60B_fb9o3TTojQ/view?usp=drivesdk). With `b=omega_4` and `c=omega_5`, it gives

| Offset | Complete stable word |
|---|---|
| 0 | `WR` |
| 1 | `NR,SL` |
| 2 | `WR,WL` |
| 3 | `SR,SL1,NR,SL2` |
| 4 | `WR1,WL1,ER,WL2,WR2,EL,[WR3]^b` |
| 5, A | `SR,SL1,NR1,NL,NR2,(SL,NR)^b,[SL]^(1-c)` |
| 5, B | `NR1,SL1,SR,NL,NR2,(SL,NR)^b,[SL]^(1-c)` |

The indicators `b,c` can each be zero or one. The proof below covers all four choices. No wake indicator at offset six or beyond is assumed.

Write `E1,E2,E3` for the east arrivals on six. Their sources on three are respectively `SL1,NR,SL2`. Write `W1,W2,W3,...` for west departures on seven. Their targets on four are respectively `WR1,WL1,WL2,WR2,[WR3]^b`. These are ordinal matches, not assumptions about an inward continuation.

## Word B is impossible at either cap

The immediate stable successor of `5:SR` in B is `5:NL`.

If `E2=ER`, the path

`5:SR -> 2:WR -> 3:NR -> 6:E2=ER -> 5:south arrival`

is a four-step same-cell first return, with directions `WNES`. Its endpoint arrives from the south, whereas the required next visit is `NL`. Thus `E2=EL`.

Let `D` be the south departure on six feeding `5:SR`. The path

`D -> 5:SR -> 2:WR -> 3:NR -> 6:E2=EL`

is a square first return on six. Therefore `D` is a right-turn south departure, hence `ER`, immediately before `E2`. Since `E2` is the second east arrival, `D=E1=ER`.

Next, `W2` must be `SR`. If it were `NL`, let `U` be its north-departure predecessor on six. The path

`6:U -> 7:W2=NL -> 4:WL1 -> 3:SR -> 0:WR -> 1:NR -> 4:ER -> 3:SL1 -> 6:E1=ER`

is an eight-step same-cell first return. Its source must turn left, so the north departure `U` would be `EL` before the first east arrival `E1`, a contradiction.

With `W2=SR`, the following twelve-step path is a same-cell first return on seven:

`7:W2 -> 4:WL1 -> 3:SR -> 0:WR -> 1:NR -> 4:ER -> 3:SL1 -> 6:E1=ER -> 5:SR -> 2:WR -> 3:NR -> 6:E2=EL -> 7:north arrival`.

Its target is `NL`, immediately after `W2`, and hence is the next west departure `W3`. It feeds `4:WL2`. Consequently

`6:E2=EL -> 7:W3=NL -> 4:WL2 -> 3:SL2 -> 6:E3`

is a square first return, forcing `E3=ER` immediately after `E2`.

We now have the forced eight-step path

`5:SR -> 2:WR -> 3:NR -> 6:E2=EL -> 7:W3=NL -> 4:WL2 -> 3:SL2 -> 6:E3=ER -> 5:south arrival`.

Its directions are `WNENWSES`. The visited offsets are

`5,2,3,6,7,4,3,6,5`.

It has zero displacement and no intermediate visit to offset five, so it returns to the starting physical cell before any other visit there. Its endpoint again arrives from the south, contradicting the required immediate successor `5:NL`.

This excludes word B. Every walk used here has zero displacement, so the argument applies at both cap orientations. In particular, it excludes the Q continuation without analyzing any of its offset-eight suffixes. In Q with `c=0`, the eight-step path explicitly jumps from the third to the sixth event on five, skipping `NL,NR2`.

## Word A is impossible at the upper cap

In A the first two south arrivals on five are `SR,SL1`; both precede `NR1`. Let `D1,D2` be their south-departure predecessors on six.

The square

`6:D1 -> 5:SR -> 2:WR -> 3:NR -> 6:E2`

makes `D1,E2` consecutive stable visits on six. Since `D2` is the next south departure after `D1`, it is `E2` itself or a later stable event. Hence

`tau(D2) >= tau(E2)`.

Put `A=tau(4:WR1)`. The two stable gaps from `WR1` through `WL1` to `ER`, the south step to `3:SL1`, and the gap from `3:SL1` to `3:NR` give

`tau(3:NR) >= A+13`.

At the upper cap the east step from `3:NR` to `6:E2` gives

`tau(E2) = tau(3:NR)+1+N >= A+14+N`.

Therefore

`tau(5:SL1) = tau(D2)+1 >= A+15+N`.

But `4:WR1` supplies `5:NR1` by a north step, so `tau(5:NR1)=A+1`. The stable order `SL1,NR1` on five requires

`A+1 >= tau(5:SL1)+4 >= A+19+N`,

or **`0 >= N+18`**, impossible for positive `N`.

This last contradiction is specific to the upper cap. With the lower-cap voltage sign the same calculation gives only `N>=18`, which is compatible. No orientation symmetry is being used to claim a lower-cap exclusion.

Both possible offset-five words are now excluded at the upper cap. This proves the theorem.

## Consequences for the current ledger

The [September 13 wake-family note](https://drive.google.com/file/d/1G9yoPb_w1HaVMIbFgXGzWTRCnBWgBsOl/view?usp=drivesdk), together with the subsequent lower-band exclusions, leaves families A and B for every lower `(1,2,2)` cap. Family A has an upper `(1,2,2)` cap and is therefore excluded by this theorem.

The sole remaining recorded family with a lower `(1,2,2)` cap is B:

`W=6m+4`,

`O={0,5,6,8,6p+2,6r+4,W-2,W}`,

`2<=p<r<=m-1`, with `p+r` odd.

Its upper cap is `(1,2,3)`, and its minimum allowed width is 28. Family B is not excluded in this note. Cases with other lower-cap profiles remain separate. The complete `(1,-3)` orbit, the other growth-eight drift orbits, and the claim `g>=12` are not proved here.

## Verification and provenance

`verify_upper_fat122_exclusion.py` independently reconstructs the displayed closed walks from incoming headings and right/left turns. It checks their lengths, zero displacement, absence of an earlier return, heading compatibility, and invariance of those checks under a half-turn. It also sums the upper time inequalities with exact integers and obtains `(constant, coefficient of N)=(18,1)`.

The proof was found while continuing the September 15 Q work from Google Drive. Exploratory port enumeration suggested the obstruction, but neither its counts nor a numerical linear-programming result is used as a premise. The dependency boundary is the cited two-sided normal form plus the stable-order/edge-matching rules. The checker verifies the displayed finite certificates; it does not formally prove that normal form or the global wake-family classification.
