# Upper fat `(1,2,3)` band `210` requires a wake at offset five or six

23 September 2026

At drift `(1,-3)`, take an upper `(1,2,3)` cap in inward coordinates, with
headings rotated by 180 degrees. Its retained initial long band `210` has
non-wake inward offsets three and four. If offsets five and six are also
non-wake, the band is impossible at every period and width at least eight.
No parity assumption is made at offsets seven or eight.

The fixed rows through offset four are recorded in
`odd_skew_upper_fat123_210_quiet_5_7_2026-09-23.md`. Starting with them,
enumerate every flow- and excess-compatible count row and every right-first
alternating word satisfying the finite, witnessed same-cell return adjacency.
Reject remaining words only for a witnessed wrong first return or an
infeasible exact integer clock:

```text
tau(target) = tau(source) + 1 + N*voltage,
N >= max(6, number of represented events),
consecutive visits to one physical cell differ by at least four steps.
```

The enumeration has no upper bound on `N`, width, row length, or black
lifetime. It does not infer a bad return by extrapolating a quotient cycle.

| Offset | Wake | Count rows | Adjacency words | Wrong finite returns | Survivors |
|---:|---:|---:|---:|---:|---:|
| 5 | 0 | 3 | 9 | 0 | 9 |
| 6 | 0 | 34 | 46 | 5 | 36 |
| 7 | 1 | 175 | 107 | **107** | **0** |
| 7 | 0 | 175 | 216 | 178 | 23 |
| 8 after quiet 7 | 0 | 130 | **0** | 0 | **0** |
| 8 after quiet 7 | 1 | 134 | **0** | 0 | **0** |

The wake-seven branch dies immediately: all 107 candidate words have a
witnessed first return to the wrong stable event. The quiet-seven branch
has no adjacency-compatible offset-eight word of either parity. Every
candidate of width at least eight contains that offset or its empty word.
`code/python/verify_upper_fat123_210_near_wake.py` reproduces the table and
writes `results/upper_fat123_210_near_wake_checks_2026-09-23.json`.

Consequently, whenever an upper `(1,2,3)` cap has offset five non-wake, its
`210` band needs offset six wake. The lower-missing M-I family has both five
and six non-wake at the upper cap, so `210` is excluded there. In the remaining
lower fat `(1,2,3)` band with `omega_3=omega_4=1` and `jkl=110`, the current
P22/rank/moment wake classification leaves a possible upper `210` band only
in its width-`0 mod 6` edge family with upper offset six wake. These are
initial-band restrictions; neither cap pair nor the full orbit is closed.
