# Exact visit orders below an alternating half rail

The partial-rail family in `growth8_m4_partial_rail_obstruction_2026-09-04.md`
passes the residue and rank tests. Exact visit order removes some of the
count patterns that those tests allow. This note derives its upper-cap
normal form through three inward levels, using closed same-cell returns.
It does not exclude the family.

Subsequent status: [the alternating-half-rail argument](m4_alternating_half_rail_exclusion_2026-09-06.md)
excludes this explicit family. The normal forms and lower period bound derived
here remain necessary conditions; the final gap statement records the earlier
checkpoint. The whole growth-eight drift orbit remains open.

## Hypotheses and physical cells

Normalize the drift to `(4,-4)`. Write `t=x+y`, with horizontal arrivals
on odd levels and vertical arrivals on even levels. Let the actual upper
rail be `t=W+1`, where `W` is even. Only its odd `x mod 4` lanes are
visited, each at a singleton ER event. Its even lanes are unvisited.

Assume the classes on the next three inward levels are non-wake. These
are exactly the upper-cap hypotheses in the displayed partial-rail family
when `W>=12`. Write the physical cells as

```text
T_x = (x,W+1-x),      U_x = (x,W-x),
V_x = (x,W-1-x),      P_x = (x,W-2-x).
```

All arguments use sufficiently far future copies, where P3 gives the actual
first-white, alternating visit order. The index `x` is an integer, not merely
a residue: `T_(x+4)=T_x+d`, and likewise on the other levels. This keeps
every return at the same physical cell even across a quotient seam.

Port labels give the incoming heading followed by the turn. Count vectors
on horizontal-arrival cells have order `(ER,EL,WR,WL)`; on vertical-arrival
cells they have order `(NR,NL,SR,SL)`.

## The first inward level

At an even-indexed `U_x`, no arrival comes from above, and exactly one east
departure feeds `T_(x+1)`. Zero excess therefore gives `NR=NL=1` and no
other ports. At an odd-indexed `U_x`, the singleton `T_x` supplies one south
arrival, while east departures would reach an unvisited rail cell and are
forbidden. Zero excess gives `SR=NL=1`. Thus the complete stable words are

```text
U_x, x even: NR,NL
U_x, x odd:  SR,NL.
```

In particular, all four classes at this level have exactly two visits.

## A four-step return fixes the even lanes of the next level

For even `x`, `V_x` has two west arrivals, from the two departures of
`U_(x+1)`, and two north departures, feeding `U_x`. If `c=WR`, then

```text
EL=WL=2-c,       ER=4-3c.
```

Nonnegativity leaves the count rows `(4,2,0,2)` and `(1,1,1,1)`. For odd
`x`, both totals are one, giving `EL=WL=1-c`, `ER=2-3c`; only the row
`(2,1,0,1)` remains.

Let `x` be even and let `A_x` be the first NR time at `U_x`. Its physical
predecessor is a north departure from `V_x` at time `A_x-1`. The following
path is forced:

```text
V_x -> U_x:NR -> T_(x+1):ER -> U_(x+1):SR -> V_x.
```

Its directions are `N,E,S,W`. It returns to `V_x` at time `A_x+3`, without
an intermediate visit to that cell. This endpoint is the first west arrival
there: the two west arrivals come from the same physical `U_(x+1)`, whose
order is SR,NL, and the displayed departure is its SR.

The starting north departure cannot be WR, since that would itself be an
earlier west arrival at `V_x`. It is EL. Consecutive same-cell visits have
opposite turns, so the endpoint is WR. This eliminates the eight-visit count
row. In the remaining four-visit row, EL,WR are consecutive; stable
alternation fixes the complete word:

```text
V_x, x even: ER,EL,WR,WL.
```

The WR at `A_x+3` immediately reaches `U_x` at `A_x+4`, its last NL visit.
Consequently the two visits to each even `U_x` are exactly four steps apart.

The odd lanes still have precisely two alternatives:

```text
A: ER,EL,ER,WL
B: ER,WL,ER,EL.
```

Both are retained below.

## An eight-step return fixes the odd lanes one level farther in

For odd `x`, `P_x` has three south arrivals from `V_x` and two east
departures feeding `V_(x+1)`. With `a=SL`, zero excess gives

```text
(NR,NL,SR,SL) = (2-a,5-3a,3-a,a).
```

The possible count rows are `(2,5,3,0)` with ten visits and `(1,2,2,1)`
with six visits.

Put `A=A_(x+1)`. The last east departure `J` from `P_x` feeds the second
and last east arrival, EL, at `V_(x+1)`. It occurs at `A-2`. The cap words
just proved force this return:

| time | physical cell and port |
|---|---|
| `A-2` | `P_x:J` |
| `A-1` | `V_(x+1):EL` |
| `A` | `U_(x+1):NR` |
| `A+1` | `T_(x+2):ER` |
| `A+2` | `U_(x+2):SR` |
| `A+3` | `V_(x+1):WR` |
| `A+4` | `U_(x+1):NL` |
| `A+5` | `V_x:WL` |
| `A+6` | south arrival at `P_x` |

Its directions are `E,N,E,S,W,N,W,S`, with zero displacement. No intermediate
event lies on the `P` level. Its endpoints are therefore consecutive visits
to the same physical `P_x`, and their turns are opposite.

The ten-visit count row has no SL: both an east departure and a south arrival
would turn R, which is impossible here. In the six-visit row, if `J` were NR,
the earlier east departure would already have used the unique SL. The return
would require that same SL after `J`, another impossibility. Hence

```text
first east departure = NR,
last east departure J = SL,
return endpoint = SR,
```

with SL,SR consecutive in the stable word.

The six visits alternate R,L. If SL is in the second position, the earlier
NR must be first, giving `NR,SL,SR,NL,SR,NL`. If SL is in the fourth
position, the earlier NR can be first or third, giving the other two words
in the table below. A final-position SL cannot have its consecutive return.

| odd-lane word at `V_x` | complete possibilities at `P_x` |
|---|---|
| A: `ER,EL,ER,WL` | `NR,NL,SR,SL,SR,NL` or `SR,NL,NR,SL,SR,NL` |
| B: `ER,WL,ER,EL` | `NR,SL,SR,NL,SR,NL` |

To distinguish the rows, the return is fed by `V_x:WL`. In A this is its
last south departure, so the endpoint must be the last south arrival at
`P_x`. In B it is the middle south departure, selecting the middle-arrival
alternative. Directed-edge matching preserves the actual visit order.

## A four-step return fixes the even lanes of `P`

For even `x`, there are two south arrivals at `P_x` and three east
departures feeding `V_(x+1)`. Writing `a=SL` gives

```text
(NR,NL,SR,SL)=(3-a,5-3a,2-a,a),
```

so the count rows before using chronology are `(3,5,2,0)` and
`(2,2,1,1)`.

Let `J` be the east departure from `P_x` that feeds the unique `EL` event
at `V_(x+1)`. The cap words force the closed return

```text
P_x:J -> V_(x+1):EL -> U_(x+1):NL -> V_x:WL -> P_x.
```

Its directions are `E,N,W,S`. No intermediate event is on the `P` level,
so its endpoints are consecutive visits to the same physical `P_x` and
have opposite turns. The return endpoint is the second and last south
arrival at `P_x`, because `V_x:WL` is the second south departure from the
even-lane word `ER,EL,WR,WL`.

The ten-visit row has no `SL`. Its departure `J` would therefore be `NR`,
but the opposite-turn return on an incoming south port would have to be
`SL`, a contradiction. Thus every even `P` lane has the six-visit count
row

```text
(NR,NL,SR,SL)=(2,2,1,1).
```

Directed-edge order determines the position of `J`. If `V_(x+1)` has
type A, its east-arrival subsequence is `ER,EL,ER`, so `J` is the second
east departure from `P_x`. If it has type B, that subsequence is
`ER,ER,EL`, so `J` is the third. Inserting the consecutive opposite-turn
endpoint into the six-place alternating word leaves exactly

| odd-lane word at `V_(x+1)` | complete possibilities at even `P_x` |
|---|---|
| A: `ER,EL,ER,WL` | `SR,NL,NR,NL,NR,SL`; `NR,NL,SR,NL,NR,SL`; or `NR,SL,SR,NL,NR,NL` |
| B: `ER,WL,ER,EL` | `NR,NL,NR,SL,SR,NL` |

Together with the preceding table, every class on the fourth level from
the upper rail now has exactly six visits and an explicit finite list of
stable port words.

## Period cost in the explicit partial-rail family

For the family with `W=8j+4>=12`, the top four levels now have at least

```text
2 + 8 + 16 + 24 = 50
```

period visits: two at the rail, two in each `U` class, four in each `V`
class, and at least six in each `P` class.

The full lower rail contributes four visits. Each class at level two has
one north arrival and one west departure. Zero excess forces its count row
`(NR,NL,SR,SL)=(1,0,1,2)`, so that level contributes sixteen visits.
Every level-three class consequently has three east arrivals and three
south departures. If its wake bit is `D`, its horizontal count row is

```text
(ER,EL,WR,WL)=(a,3-a,6+D-3a,3-a).
```

For the two wake classes `D=1`, the least possible multiplicity is five;
for the two non-wake classes it is four. The bottom three levels therefore
contribute at least `4+16+18=38` visits.

There are `W-6` remaining levels, from four through `W-3`. The unique
parity flow and local multiplicity residues in the partial-rail note force
at least eight visits on each. At every even level all four multiplicities
are `2 mod 4`. At each odd level the two odd lanes have odd north and south
edge counts, so they are visited; their multiplicities are `0 mod 4`, hence
at least four apiece. No occupancy of the other two lanes is assumed.

Summing these disjoint sets of levels gives

```text
N >= 50+38+8(W-6) = 8W+40.
```

In particular this family requires `N>=136`. This is a hand-derived
exclusion of its smaller periods, not an exclusion at arbitrary period.

## Remaining gap

The odd `V` alternatives and the displayed finite word lists at `P` survive
the argument. The layers below `P` have not been forced into a contradiction.
Thus the partial-rail family remains unresolved after these chronological
restrictions. No simulation or mathematical enumeration was used to derive
them.
