# Width-22 exclusion for lower thin011 / upper F123 wake six

For literal drift `(1,3)` and growth eight, no highway in the lower-thin011 /
upper-F123 wake-six cap family has width 22. The whole orbit remains **OPEN**.

The wake set is `{0,4,6,7,8,16,20,22}`. Lower rows zero through seven are
fixed by thin rigidity. The complete upper domain through inward offset
ten has 415 necessary words. The half-turn sends offset `u` to global row
`22-u`, exchanges headings E/W and N/S, and preserves turns and order.
Thus only rows eight through eleven remain to be joined.

Exact directed interface balance gives 921 full count matrices, of which
221 have literal displacement `(1,3)`. Their complete event totals force
periods 210, 226, or 242. These values are consequences of full counts;
there is no arbitrary period or visit-count ceiling. The independently
checked complete row-eight join leaves 1,518 necessary parents.

The complete row-nine domain represents 74,525,472 raw alternating words
and emits 617,021 words under necessary physical next-visit constraints:

| Disposition | Count |
|---|---:|
| Reused clock rejection, freshly proved independently | 100,364 |
| Empty necessary row-ten word domain | 498,641 |
| New exact-period clock rejection | 13,611 |
| Reaches row-ten word enumeration | 4,405 |
| Total | 617,021 |

The row-ten domains represent 3,583,487,277 raw words and emit 135,293
necessary words. Of these, 135,292 have an empty necessary row-eleven
domain. The final one violates its exact-period clock constraints. No
candidate reaches a row-eleven word or a full-tour acceptance test.

Independent checks regenerate all emitted row-nine and reached row-ten
word sets, replay every referenced zero-copy compass return, verify all
234,821 finite word-existence signatures, and independently prove all
113,976 imported or new clock rejections. Another independently written
source audit reconstructs all 234,821 signature geometries and checks the
231-parent reuse partition. Empty parents are complete zero-word domains;
an omitted zero Counter field is normalized to zero, never used as a cap.
All resource-limited earlier searches are explicitly incomplete and
provide no exhaustion claim.

The sole terminal clock rejection also has a six-edge hand contradiction
valid for every period. Put `A=(10,12), B=(10,13), C=(12,8), D=(12,9)`
using zero-based event indices. Literal ordinal paths `A --E--> (13,7)
--N--> D` and `C --W--> (9,11) --S--> B` imply, in the lower gauge,

```text
tauD-tauA = 2-N,
tauB-tauC = 2+N,
(tauB-tauA)+(tauD-tauC) = 4.
```

Both differences in the last line are adjacent stable gaps, each at least
four. Their sum must instead be at least eight. These are clock equations
between translated copies; no physical next-return assumption is made.
A second independently checked hand contradiction uses zero-copy paths
of lengths four, three, and seventeen and needs only strict integer order.

The [complete proof chain](../work_positive_skew_thin011_W22_join_20261002/finite_W22_exclusion.md)
and [bound certificate manifest](../work_positive_skew_thin011_W22_join_20261002/final_certificate_audit.json)
give every source, disposition, and checker. The separate
[source review](../work_positive_skew_W22_zero_dp_audit_20261003/independent_source_review.md)
checks the geometric and reuse dependencies. A fresh root check on
4 October verified the byte hashes of all 38 bound primary artifacts and
all secondary source bindings before recording this exclusion.

The [unbounded endpoint classification](../work_positive_skew_high_thin_endpoints_20261002/high_thin_endpoint_families.md)
gives `W=6m+4`, residual `6r+2`, `1<=r<=m-2`, and even `m+r`.
Its unique width-22 member has `m=3,r=1`. After this exclusion, the
minimum remaining possible width is 28 (`m=4,r=2`). Larger widths, other
cap pairs, and the full growth-eight orbit remain open. No count of
arithmetic templates is a percentage of proof completion.
