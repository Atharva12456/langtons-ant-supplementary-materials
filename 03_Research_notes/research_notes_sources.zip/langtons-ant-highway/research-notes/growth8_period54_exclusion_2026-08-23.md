# Growth eight does not occur at period 54

The fixed-growth search has now been completed at period 54.  This is the third
targeted run after the general residue-free exclusion through period 48.

## Result

There is no finite-support periodic highway with ant period `N=54` and growth
`g=8`.

The search used

```text
--period 54 --target-growth 8 --prefix-length 12 --deficit-depths 0
```

A normalized positive-growth word starts with `R`, so there are 2,048 possible
length-12 prefixes.  Sixty-four half-open intervals of 32 ranks cover them
exactly once.  Every shard completed without a node cap, and the optional
deficit rule was disabled.  The aggregate counts are

```text
prefix ranks                   2,048
search nodes          99,180,610,230
endpoint prunes       16,912,730,914
growth prunes         18,882,824,613
residue checks         2,123,298,784
residue prunes         2,018,813,540
P3 checks                104,485,244
accepted words                     0
```

The residue test is a proved pruning lemma.  Every leaf that passes it is sent
to the exact periodic-realisability test.

## Audit trail

The raw records are archived in `records/g8_p54_shards`.  The aggregate checker
reconstructs every prefix from its rank, checks the normalization directly,
verifies exact rank coverage and every per-rank counter sum, rejects capped or
deficit-pruned shards, compares the two copies of the hit lists, and records a
SHA-256 digest for each shard.  Rebuilding the aggregate from the archive gives

```text
results/growth8_period54_exclusion.json
e906fbf3f7cd06d3a4a21977e679514ad611b052edce475744f1776fd2279fb8
```

The relevant source digests are

```text
code/java/PositiveGrowthResidueSearch.java
315c18bd3f7749750fc8c618d5b3f464756d2ddd64bda5dd9be4cbb1f33e9c23

code/python/aggregate_target_growth_shards.py
c4db9da60a9b19e634a51d552420528e1cf43868d4754bf3d633cf951f920925
```

The fixed-growth branch was previously compared with the original all-growth
mode at every even period through 18.  Those runs partition the original leaf,
residue, P3, and hit records exactly.  That regression checks the new search
restriction; it does not replace the proof of the residue theorem or the P3
criterion.

The aggregate can be rebuilt with

```text
python code/python/aggregate_target_growth_shards.py records/g8_p54_shards \
  --output results/growth8_period54_exclusion.json
```

Together with the general period-at-most-48 result and the targeted period-50
and period-52 runs, this excludes growth eight through period 54. Period 56 was
the first possibility left by those runs; later computations extend the exclusion
through period 60. The result is finite: all ten drift orbits retain open cases.
See [the period-60 record](growth8_period60_exclusion_2026-08-25.md).
