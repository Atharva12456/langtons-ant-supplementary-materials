# Upper fat `(1,2,3)` band `210` needs a wake at offset five, six, or seven

23 September 2026

At drift `(1,-3)`, orient the upper cap inward and rotate headings by 180
degrees. Suppose its `(1,2,3)` cap has the retained long initial band
`(j,k,l)=(2,1,0)`, so inward offsets three and four are non-wake. If offsets
five, six, and seven are also non-wake, then the band is impossible at every
period, regardless of the parity of offset eight. This strengthens the earlier
lemma, which assumed offset eight non-wake.

The fixed initial rows are

```text
0: WR
1: NR SL
2: WR WL WR
3: NR SL SR SL NR SL
4: WR WL WR WL ER WL WR EL
```

From these rows, enumerate every later count row from flow and excess balance,
and every right-first alternating stable word satisfying witnessed, finite
same-cell return adjacency. Reject a word only when a witnessed first return
lands on the wrong stable event or its exact integer lifted clock is infeasible:

```text
tau(target) = tau(source) + 1 + N*voltage,
N >= max(6, number of represented events),
same-cell consecutive stable visits differ by at least four steps.
```

The bound by represented events is necessary because they occupy distinct
phases of the period. No upper bound on period, width, row length, or lifetime
is used. The checker uses no quotient-cycle extrapolation to reject a word.

| Inward offset | Wake | Count rows | Adjacency words | Surviving prefixes |
|---:|---:|---:|---:|---:|
| 5 | 0 | 3 | 9 | 9 |
| 6 | 0 | 34 | 46 | 36 |
| 7 | 0 | 175 | 216 | 23 |
| 8 | 0 | 130 | **0** | **0** |
| 8 | 1 | 134 | **0** | **0** |

At offset eight, neither parity supplies even one adjacency-compatible word
from the 23 prefixes. Every trace of width at least eight contains that row or
its empty word, so the contradiction holds at every period. Run
`python code/python/verify_upper_fat123_210_quiet_5_7.py` from the repository
root; it writes
`results/upper_fat123_210_quiet_5_7_checks_2026-09-23.json`.

For a lower missing cap paired with an upper `(1,2,3)` cap, the surviving wake
family M-I has upper inward offsets five, six, and seven non-wake. Its upper
initial band therefore cannot be `210`. The short band and long bands `111`
and `120` remain open. This does not exclude M-I or the full `(1,-3)` orbit.
