# Family B lower row twelve with one `ER`

26 September 2026. This is an all-period necessary-prefix restriction for
Family B at drift `(1,-3)`. It does not exclude Family B or assert that any
retained prefix extends to a complete highway.

Family B has `W=6m+4` and wakes
`{0,5,6,8,6p+2,6r+4,W-2,W}` with `2<=p<r<=m-1` and `p+r` odd.
Consequently rows nine through thirteen are non-wake. The established lower
normal form gives the two row-eight words A and B and the unique row-nine
word `(NR,SL)^4`. Exact lifted clocks retain 8 row-ten words after A and 17
after B.

Suppose lower row twelve has **exactly one `ER`**. Then its port counts
`(ER,EL,WR,WL)` must be `(1,7,9,3)`. The row-ten word is one of only four:

| Row eight | Row-ten index | Row-ten word | Remaining row-eleven/twelve prefixes |
|---|---:|---|---:|
| A | 3 | `WR EL WR WL WR WL WR WL WR EL WR WL` | 6 |
| A | 4 | `WR EL WR WL WR WL WR WL WR WL WR EL` | 7 |
| A | 7 | `WR EL WR WL WR WL ER WL` | 6 |
| B | 7 | `WR WL WR EL WR WL WR WL WR WL WR EL` | 2 |

The verifier `code/python/verify_family_b_row12_er1_all.py` regenerates the 25 row-ten
words from the checked normal form, then enumerates all 110 directional count
rows on row eleven. Ordinal matching and one-excursion same-cell returns
reduce the row-eleven words to 1,150; 112 have an explicit finite wrong first
return, and 473 of the rest fail the exact lifted integer clock. Thus 565
row-eleven prefixes remain. At row twelve, the `ER=1` count vector is unique
above each prefix. One-excursion adjacency leaves 532 words; explicit finite
wrong returns reject 272, and exact clocks reject 239 of the rest. Exactly 21
necessary prefixes remain, distributed as in the table.

Each clock uses an unbounded integer period `N`, the edge equation
`tau(v)-tau(u)=1-N*voltage`, and stable-row time gaps at least four. No period
or width cutoff, wake property beyond row twelve, or quotient-cycle return
extrapolation is used. The finite return checks reject only when an explicit
walk reaches the same physical cell at the wrong next stable event. The
verifier depends on the established lower-cap normal form and on the
`p2_research.py` ordinal successor and adjacency routines. It regenerates its
row-ten and row-eleven prerequisites without loading scratch data.

The 21 retained prefixes are enumerated in
`results/family_b_row12_er1_all_2026-09-26.json`. They pass these necessary checks; their
existence rules out a claim that `ER>=2` follows from the present prefix
argument.
