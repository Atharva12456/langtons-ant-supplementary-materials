# Growth eight at diagonal drift four: neither extremal rail can be full

Date: 2026-09-06.

**Result:** in the remaining pure horizontal-wake branch of the growth-eight drift orbit `(-4,4)` / `(4,-4)`, neither extremal rail can occupy all four quotient lanes. Thus any remaining candidate must have **both rails partially occupied**.

This is an all-period reduction, not closure of the orbit. The proof combines exact finite local certificate proofs with a symbolic rank-sign calculation. It has not been formalized in Lean or externally reviewed. It uses the project's established P3, extremal singleton, coordinate-fibre, period, and rank-factorization results.

## 1. Existing reductions and notation

Write `t=x+y`, `r=x mod 4`, and put horizontal-arrival classes on odd levels. The existing growth-eight reductions give:

- exactly eight wake classes, all horizontal in the remaining pure branch;
- exactly two wakes in every x-residue and every y-residue;
- period `N=0 mod 8`;
- each occupied class on an actual extremal rail is a singleton right-turn event;
- rail separation `W>=10`.

Upper-rail events are `ER`, lower-rail events are `WR`. We do not assume that all lanes on either rail are occupied. A wake class has odd stable multiplicity; a non-wake class has even multiplicity. P3 makes each stable word start with R and alternate turns at a physical cell sufficiently far in the future.

Assume for contradiction that the lower rail is full. Translate it to `t=1` and put the upper rail at `t=H`. Let `S` be the set of occupied upper lanes. The lower rail already supplies one wake in every x- and y-residue, so the other four wakes supply each residue exactly once.

The upper rail is nonempty. Up to a cyclic lane shift its mask is one of

| Occupancy | Lane set |
|---|---|
| One lane | `{0}` |
| Two adjacent lanes | `{0,1}` |
| Two alternating lanes | `{1,3}` |
| Three lanes | `{0,1,2}` |
| Four lanes | `{0,1,2,3}` |

These are all nonempty four-lane masks up to translation.

## 2. Three exact local obstructions

Denote the four inward levels by `U=H-1`, `V=H-2`, `P=H-3`, and `Z=H-4`. In the pure branch `U` and `P` have no wake. The local statements below do not require any lower-rail hypothesis.

**L1 — one occupied upper lane.** If the upper rail is occupied only in lane 0, there must be a wake in lane 0 at `V`. This holds whatever the wake bits in the other three lanes at `V`.

**L2 — two adjacent occupied upper lanes.** If the upper rail occupies lanes 0 and 1, the entire `V` level cannot be non-wake. No restriction on wake at `Z` is needed.

**L3 — two alternating occupied upper lanes.** If the upper rail occupies lanes 1 and 3, `V` must contain a wake in lane 1 or 3. Wakes confined to lanes 0 and 2 do not suffice. No restriction on wake at `Z` is needed.

The separate note `m4_alternating_half_rail_exclusion_2026-09-06.md` gives a hand proof of the weaker form of L3 with no wakes anywhere at `V`; it already excludes the September 4 displayed family. The following complete finite certificate audits establish L1, L2, and the stronger L3.

### Why the local enumeration is exhaustive

Start with just the singleton upper-rail words. At each successive level, counts entering from and exiting into the preceding level are fixed. All directed-edge occurrences are matched in their actual chronological order at physical neighboring cells.

For a horizontal-arrival cell, let `A` be its number of north departures, `B` its number of west arrivals, and `D` its wake bit. With `c=WR`, all possible count rows are exactly

\[
(ER,EL,WR,WL)=(A+B+D-3c,A-c,c,B-c),
\]

where all four entries are nonnegative. For a vertical-arrival cell, let `A` be its number of east departures, `B` its number of south arrivals, and `D` its wake bit. With `d=SL`, all possible rows are exactly

\[
(NR,NL,SR,SL)=(A-d,A+B-D-3d,B-d,d).
\]

For each row, enumerate every first-R alternating word with those port counts. Nonnegativity bounds `c` or `d`, hence the domain is finite without a visit-count or period cutoff.

A rejection certificate is a forced sequence of actual unit steps that first returns to the same physical cell but skips one or more required stable visits, returns to an earlier visit, or returns to the starting visit. Each is impossible. The validator independently reconstructs the physical coordinates, verifies the outgoing direction and the ordinal matching on every directed edge, checks that no intermediate point is the starting cell, and checks the inconsistent endpoint rank.

For these three lemmas the audit uses **only physical-return certificates**. It uses no numerical period, no time-cycle rejection, no wake-degree pruning, and no inherited interior word table. A separate nonnegative count-box enumeration and recursive word generator check equality with every domain used by the search.

### Completed enumeration sizes

L1 exhausts all eight wake masks at `V` omitting lane 0. Each gives one `U` assignment, one surviving `V` assignment, and **zero `P` assignments**.

L2 starts from its rail and obtains 2 assignments at `U`, 7 at `V`, and 4 at `P`. At lane 2 of `Z`, all 1,992 words across both wake bits and all four caps are impossible. Enumerating the other `Z` lanes is unnecessary.

L3 exhausts the four `V` wake masks supported on the even lanes:

| Wake lanes at V | U assignments | V assignments | P assignments | Z lane 0 words, D=0 | Z lane 0 words, D=1 | Survivors |
|---|---:|---:|---:|---:|---:|---:|
| none | 1 | 4 | 16 | 3,616 | 4,352 | 0 |
| `{0}` | 1 | 4 | 16 | 7,584 | 9,088 | 0 |
| `{2}` | 1 | 4 | 16 | 7,584 | 9,088 | 0 |
| `{0,2}` | 1 | 4 | 16 | 18,176 | 21,792 | 0 |

The 16 `P` assignments in this physical-only audit include one assignment discarded by the older lifted-time audit, explaining the different count of 15 in the companion hand-proof audit. The 16-assignment audit excludes it directly at `Z` as well.

The known 104-step highway and its twofold and threefold repeats remain valid positive controls in lane quotients 2, 4, and 6.

## 3. Eliminate upper occupancies one and two

With a full lower rail, an upper-occupied lane already has its two allowed wakes. L1 would require a third wake in that lane when the upper occupancy is one; contradiction.

L3 likewise requires a third wake in one of the occupied upper lanes when the occupancy is an alternating pair; contradiction.

For an adjacent pair `S={0,1}`, a wake on `V=H-2` cannot use lane 0 or 1 by the x-residue budget. It also cannot use lane 2 or 3: the y-residues there are respectively `H` and `H-1` modulo four, already occupied by the two upper wakes and by the full lower rail. Thus every `V` lane must be non-wake, contradicting L2.

Equivalently, the x/y budget allows `V` wakes only outside `S union (S+2)`. For an adjacent pair this union is all four lanes.

## 4. Eliminate upper occupancy three by rank sign

Normalize the upper occupied lanes to `{0,1,2}`. The eighth wake must lie in lane 3, at some odd interior level `J`. Since the lower rail contributes every y-residue once and the upper rail contributes y-residues `H,H-1,H-2`, the remaining wake must have y-residue `H-3`. Therefore

\[
J\equiv H\pmod4,\qquad 1<J<H.
\]

Put `k=(H-J)/2`. Then `k` is positive and even.

### Parity flow

Use the project's pure-horizontal parity recurrence. At odd level `j`, north-edge parity is `b_j` and south-edge parity is `b_(j-2)`. At even level `t`, east and west edge parities agree and are `a_t`. With the zero boundary below the strip,

\[
b_{j,r}=b_{j-2,r}+D_{j,r},\qquad
a_{j+1,r+1}=a_{j-1,r-1}+D_{j,r}
\quad\text{over }\mathbb F_2.
\]

Write `f=(1,1,1,1)` and let `m_i` be `f` with lane i removed. The unique finite flow is:

- `b_j=f` for odd `1<=j<J`, and `b_j=m_3` for odd `J<=j<H`;
- `a_t=f` for even `2<=t<J`;
- `a_(J+1+2i)=m_0` for even i and `m_2` for odd i, for `0<=i<k`;
- all other entries vanish.

This follows by substituting the lower full wake, the lane-3 wake at `J`, and the upper three wakes into the recurrence. The evenness of k makes the flow vanish above H.

### Local correction

The rank correction is

\[
\Lambda=\sum_Q p_v(D_v+1)+\sum_C D_v(p_v+1)\pmod2,
\]

where `p_Q(t,r)=b_(t-1,r)+a_(t,r)` and `p_C(j,r)=a_(j-1,r-1)+b_(j,r)`.

Below J, every Q correction is zero. On each of the k intermediate even levels, `m_3` differs from `m_0` or `m_2` in exactly two places, so the sum of Q corrections is even. Every wake C class has `p=1`: this is immediate at the lower rail and the lone wake; at the upper rail the last a-mask is `m_2`, and its predecessor-lane values are one in lanes 0, 1, and 2. Therefore `Lambda=0`.

### Edge inversion sign

Use source and target block order `(level,lane,negative-before-positive)`, as in the September 4 parity note. Its paired adjacent-level terms cancel. The horizontal-source contribution is

\[
E_C=\sum_j\left[\binom{|b_j|}{2}+|b_j|+
\sum_{r<s}b_{j,r}b_{j-2,s}\right]\pmod2.
\]

The self terms for f and `m_3` are respectively 10 and 6, both even. The transition `m_3` against f contributes 6. Each of the `k-1` subsequent `m_3`/`m_3` terms contributes 3. Hence `E_C=k-1=1 mod 2`.

For vertical sources, the self term of a mask a is

\[
G(a)=\binom{|a|}{2}+a_0(|a|-a_0)+a_3(|a|-a_3),
\]

and a successive-level term is

\[
B(a,b)=\sum_{r,s}a_rb_s\,\mathbf1_{(r+1\bmod4)\ge(s-1\bmod4)}.
\]

Here `G(f)=12`, `G(m_0)=5`, and `G(m_2)=7`. The k intermediate self terms sum to zero modulo two because k is even. The transition counts are

| Transition | B |
|---|---:|
| f to f | 10 |
| f to m_0 | 9 |
| m_0 to m_2 | 6 |
| m_2 to m_0 | 6 |

Thus `E_Q=1`, so `E=E_C+E_Q=0`. Together with `Lambda=0`, this gives `E+Lambda=0` for every permitted J and H.

### Contradiction

The project's rank factorization requires `K=1+E+Lambda mod 2`, hence K odd. But stable alternation and growth eight give

\[
K\equiv\#L=(N-8)/2\equiv0\pmod2
\]

because `N=0 mod 8`. Contradiction. No height bound or finite placement search is used in this calculation.

## 5. Finish the full-rail exclusion

If the upper rail is also full, all eight wakes lie on the two rails. The existing full/full rank proof gives `E=Lambda=0` and the same contradiction. It also follows from the preceding block formulas with every nonzero a- and b-mask equal to f: all self, transition, and local sums are even.

Every possible upper occupancy has now been excluded when the lower rail is full. A half-turn preserves Langton's rule and exchanges the two extremal rails. The local proofs use only physical returns, and the rank proof uses only parity flow and the same period congruence; both apply with either sign of the diagonal drift. Hence a full upper rail is excluded as well.

## 6. Exact remaining boundary

The entire orbit is still open. What is now necessary in its pure branch is

\[
1\le |S_{\rm lower}|\le3,\qquad1\le |S_{\rm upper}|\le3.
\]

The new local conditions still apply to those partial rails. In particular, a singleton rail requires a same-lane wake two levels inward, and an alternating half rail requires such a wake in at least one occupied lane. Both rails can now consume the eight-wake budget through nearby interior wakes; proving that all remaining arrangements are impossible requires another argument.

No percentage or claim of being a fixed number of lemmas from closure is justified. The remaining periods and transverse separations are unbounded.

A concrete algebraically surviving placement is

\[
D=\{(1,0),(1,1),(1,2),(7,3),(9,3),(11,0),(11,1),(11,2)\}.
\]

Both rails occupy three lanes. Every x/y residue has degree two; the pure-wake additive parameters are `a=b=1`, `Z=9`, satisfying `Z=a+b-1 mod 4`; and direct parity-block evaluation gives `E=1`, `Lambda=0`, the permitted rank sign. This is **only relaxed wake data**: no chronological P3 word, finite seed, or actual highway has been constructed. It demonstrates why the algebraic tests do not by themselves finish the reduced problem.

**Update, September 7:** The displayed placement is now excluded by a complete two-ended local-word enumeration and independently checked middle-interface contradictions. This is an all-period exclusion of that specific placement, under the project's established reductions. See `m4_partial_rail_progress_2026-09-07.md` and `m4_two_ended_audit_2026-09-06.json`. The new continuation also forces at least six wakes onto the four boundary levels and classifies the remaining boundary-only patterns. The whole orbit remains open.

## 7. Reproduction and research record

Run:

```bash
python verify_m4_full_rail_exclusion.py --output m4_full_rail_audit_2026-09-06.json
```

This recomputes the single-, adjacent-, and alternating-rail certificates, checks every local domain independently, checks the rank transition table, corroborates the rank calculation by direct edge-block sorting on finite examples, and includes rank-passing controls from the old relaxed family. The finite rank examples corroborate the symbolic proof; they are not substituted for it.

The three-lane local cap survey did retain partial-word assignments. They are not highways. The all-period rank contradiction above excludes their required global wake completion when the lower rail is full. This distinction prevented treating a surviving local relaxation as evidence against the new global reduction.

Sources:

- [September 4 cap-order note](m4_partial_rail_cap_order_2026-09-04.md).
- [September 4 partial-rail parity formulas and relaxed family](growth8_m4_partial_rail_obstruction_2026-09-04.md).
- [Mixed-wake exclusion and coordinate-fibre reduction](growth8_m4_mixed_rank_exclusion_2026-09-04.md).
- [Conditional full/full rank exclusion](growth8_extremal_m4_exclusion_2026-08-22.md).
- [Rail-occupancy scope audit](rail_occupancy_scope_audit_2026-09-03.md).
