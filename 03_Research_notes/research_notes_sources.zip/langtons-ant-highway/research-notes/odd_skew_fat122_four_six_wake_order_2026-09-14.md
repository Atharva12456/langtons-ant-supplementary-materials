# A forced tail when four and six are wake and five is not

Consider a lower `(1,2,2)` cap in the `(1,-3)` orbit with

```text
(omega_4,omega_5,omega_6)=(1,0,1).
```

Both remaining north right turns on level seven must follow its
last west departure. The alternative with one on either side is
excluded below. In the surviving order, write `f=omega_7` and
`g=omega_8`. Level seven is

```text
SR,SL,SR,NL,SR,SL,SR,SL,NR,SL,NR,[SL]^(1-f).
```

If `E1,...,E6` denote the east arrivals on level eight, its tail
from `E3` is necessarily

```text
E3=ER,E4=EL,X1=WR,J=WL,E5=ER,E6=EL,X2=WR,K=WL,
    (WR,WL)^(1-f),[WR]^g.                              (1)
```

Moreover, `f=1` forces `g=1`. These are all-period lower-cap
restrictions, not an exclusion of the surviving tail. The proof
uses prescribed first returns and lifted-time order, without a
finite search or assumptions on later wakes.

## Fixed rows and clocks

The preceding lower-band and level-seven notes give

```text
4: WR,WL,ER,WL,WR,EL,WR
5: SR,SL,NR,NL,NR,SL,NR,SL
6: ER,EL,ER,WL1,WR1,WL2,WR2.
```

The west departures `W1,...,W5` on level seven have turns
`SR,SR,NL,SR,SR`. The two remaining candidate words are

```text
P: SR,SL,SR,NL,SR,SL,NR,SL,SR,SL,NR,[SL]^(1-f);
Q: SR,SL,SR,NL,SR,SL,SR,SL,NR,SL,NR,[SL]^(1-f).
```

There are six east arrivals `Ei` on level eight, supplied in
order by the east departures `SL1,NR1,NR2,SL2,NR3,SL3` on
level five. In particular, `E3=ER` is already forced and is
the fifth south departure on level eight. Level eight has
`9-f` south departures in total.

Let `D1,...,D4` be the west departures on level nine, feeding
`6:WL1,WR1,WL2,WR2`. Write `Fi` for the east arrivals on
level ten. There are `7-f` of them. The three-step paths from
`D2,D4` through a level-six `WR` and a level-seven `NR` end at

```text
             from D2     from D4
P:              F3          F6
Q:              F4          F6.
```

The following comparisons will also be used:

```text
tau(E4) = tau(6:WL1)+2-N
tau(E6) = tau(6:WL2)+2-N
tau(F6) = tau(6:WR2)+2-N > tau(E6).                   (2)
```

For P, `tau(F3)=tau(6:WR1)+2-N > tau(E4)`; for Q the
same inequality holds with `F4` in place of `F3`.

A south departure `I` on level eight which feeds an `SL` on
level seven supplies the corresponding `F` at time
`tau(F)=tau(I)+2-N`. Throughout, `N>=6`. Thus a six-step
path with displacement `(1,-3)` cannot run from one stable
event to a later event of the same class.

Every same-cell return used below is a first return: its listed
path has no earlier visit to its starting cell. Its endpoints
must therefore be consecutive stable events with opposite turns.

## An obstruction at the last two west departures on nine

Suppose `D3=SR` and `E6=EL`. The square through
`6:WL2,5:SL3,E6` forces the consecutive target `D4=NL`.
Then `F6` cannot be `ER`: the square

```text
D4=NL -> 6:WR2 -> 7:last NR -> F6=ER -> south arrival on 9
```

would end at a fifth west departure `SR`. Hence `F6=EL`.

The south predecessor `Y` of `D3` on level ten has the
eight-step first return

```text
10:Y -> 9:D3=SR -> 6:WL2 -> 5:SL3 -> 8:E6=EL
     -> 9:D4=NL -> 6:WR2 -> 7:last NR -> 10:F6=EL.
```

It follows that `Y=F5=ER`, immediately preceding `F6`.
In particular, a square which identifies `Y` with `F3` or
`F4` gives a skipped-visit contradiction.

## Excluding P when E5 turns left

If `E5=EL`, the square through `W5` forces the consecutive
pair `E4=ER,E5=EL`. There is an eight-step return

```text
D1 -> 6:WL1 -> 5:SL2 -> E4=ER -> 7:W5=SR
   -> 4:last WR -> 5:last NR -> E5=EL -> north arrival on 9.
```

Its source cannot be `NL`. In that case its incoming north
predecessor `X` on level eight would be the north departure
immediately preceding `E5`, and the square
`X -> D1 -> 6:WL1 -> 5:SL2 -> E4=ER` would force
`X=EL=E3`, contrary to `E3=ER`. Thus `D1=SR`, followed
immediately by `D2=NL`.

If `F3=EL`, the south predecessor of `D1` on level ten follows
this eight-step return and then the path from `D2` to `F3`.
The resulting twelve-step first return forces that predecessor
to be `F2=ER`. But `F2` is supplied by the `SL` after `W4`,
so this forces the six-step translated path

```text
8:E3=ER -> 7:SL2 -> 10:F2=ER -> 9:D1=SR
        -> 6:WL1 -> 5:SL2 -> 8:E4=ER.
```

This contradicts `E3<E4`. Therefore `F3=ER`, whose square
from `D2=NL` forces `D3=SR`.

If `E6=EL`, the preceding obstruction would identify the
south predecessor of `D3` both as `F3` and as `F5`. Hence
`E6=ER`. The south ordinal of `E4` is seven, so `E6` feeds
one of the two possible later `SL` ports on level seven.
They supply `F5` and, when present, `F7`. Thus

```text
10:F3=ER -> 9:D3=SR -> 6:WL2 -> 5:SL3 -> 8:E6=ER
         -> 7:SL -> 10:F5 or F7
```

is another six-step translated path to a later east arrival.
This excludes `E5=EL` in P.

## Excluding P when E5 turns right

If `E5=ER`, its square from `W5=SR` ends at the following
`SL`. Consequently `E5` is the eighth south departure.
Since `E3=ER` is the fifth, `E4` must be `EL`: taking `E4=ER`
would require a `WL` between each successive pair of east
right turns and put `E5` at south ordinal at least nine.
Likewise `E6=ER` would require a further intervening `WL`
and put `E6` at ordinal at least ten. Hence `E6=EL`.

If `E3,E4` were not consecutive stable events, a `WL` between
them would be the sixth south departure `I`. It feeds the
`SL` before `W5`, hence supplies `F4`. By (2),

```text
tau(F4)=tau(I)+2-N < tau(E4) < tau(F3),
```

contradicting `F3<F4`. Therefore `E3=ER,E4=EL` are
consecutive.

The square from `D1` through `6:WL1,5:SL2,E4=EL` now
forces `D1=SR,D2=NL`. Indeed, an `NL` source would require
an incoming `WR` immediately before `E4`, where the stable
predecessor is `E3=ER`.

Taking `F3=ER` would force `D3=SR`, contradicting the
obstruction with `E6=EL`. Taking `F3=EL` instead gives an
eight-step first return from the south predecessor of `D1`
to `F3`. This forces `F2=ER` and the same forbidden
six-step translated path from `E3` to `E4`. P is excluded.

## The last east arrival in Q

In Q, `W5` is the sixth south arrival on level seven. Taking
`E5=EL` would force `E4=ER` as the sixth south departure
on level eight. This is impossible after `E3=ER` at ordinal
five: an intervening `WL` is required. Thus `E5=ER`, at
south ordinal seven.

Alternation now forces

```text
E3=ER,E4=EL,X1=WR,J=WL,E5=ER,                         (3)
```

where `J` is the sixth south departure and feeds `W5`.
In particular, `D1=SR,D2=NL` as in the preceding section.

If `E6=ER`, it must be the ninth south departure, forcing
`f=0`. It then supplies the last east arrival `F7` through
the last `SL` on level seven. But (2) would give

```text
tau(F7)=tau(E6)+2-N < tau(E6) < tau(F6),
```

contrary to `F6<F7`. Hence `E6=EL`. More generally, when
`f=0`, the ninth south departure must occur after `E6`, by
the same comparison.

Taking `F4=ER` would force `D3=SR`, with south predecessor
`F4`, contrary to the last-two-departures obstruction. Thus
`F4=EL`. The eight-step return from the south predecessor
of `D1` forces the consecutive pair

```text
F3=ER,F4=EL.                                        (4)
```

Here `F3` is supplied by `E5` through the `SL` after `W5`.

## The eighth south departure cannot precede E6

Let `K` be the eighth south departure on level eight. It is
`WL` and supplies `F5`. Suppose `K<E6`. Since the ninth
south departure, if present, is after `E6`, the tail through
`E6` must be

```text
E3=ER,E4=EL,X1=WR,J=WL,E5=ER,K=WL,X2=WR,E6=EL.
```

If `D3=SR`, its south predecessor is `F5=ER` by the
obstruction. This gives a six-step translated path from
`K` through `7:SL,10:F5,9:D3,6:WL2,5:SL3` to `E6`,
contradicting `K<E6`. Hence `D3=NL`.

The north arrival from `E4` is `D2=NL`; the one from `X1`
is `NR`; the one from `X2` is `D3=NL`, immediately
followed by `NR` from `E6`. There is no south arrival
between these events. Any such arrival would require an
additional `SR` before `D3`, whereas the intervening west
departures are already `D2,D3`. The fourth west departure
occurs later. Thus every south arrival after `D1` is later
than the north arrival from `E6`.

Since `tau(F5)=tau(K)+2-N<tau(E6)`, it follows that
`F5=EL`. The same comparison excludes all south departures
between `F4` and `F5` on level ten, forcing the consecutive
block

```text
F4=EL,WR,F5=EL.                                     (5)
```

The west arrivals `J,K` are adjacent in west-arrival order
on level eight. Let their matching west departures on
level eleven be `P1,P2`. They have first returns

```text
P1 -> 8:J -> 7:W5 -> 4:last WR -> 5:last NR -> 8:E5
   -> 7:SL3 -> 10:F3 -> 9:D1 -> 6:WL1 -> 5:SL2 -> 8:E4
   -> 9:D2 -> 6:WR1 -> 7:NR2 -> 10:F4 -> north arrival Na;

P2 -> 8:K -> 7:SL4 -> 10:F5 -> north arrival Nb.
```

These have lengths sixteen and four. Block (5) gives
`b=a+2`. If `P1=SR`, its consecutive target `Na=NL`
would be `P2`, whose return would then have to end at
`N(a+1)`. Therefore `P1=NL=N(a-1)`.

Its incoming north predecessor `X` on level ten precedes
`F3`, by (4). The initial part of its long return gives

```text
10:X -> 11:P1 -> 8:J -> 7:W5 -> 4:last WR
     -> 5:last NR -> 8:E5 -> 7:SL3 -> 10:F3=ER.
```

This eight-step first return forces `X=F2=EL`. But then

```text
8:E3=ER -> 7:SL2 -> 10:F2=EL -> 11:P1=NL -> 8:J=WL
```

is a square return skipping `E4,X1` in the stable word.
This contradiction proves `E6<K` and establishes (1).

## A wake at seven forces a wake at eight

In the surviving tail, `E5=ER,E6=EL` are consecutive.
The square from `D3` through `6:WL2,5:SL3,E6` therefore
cannot have an `NL` source: its incoming predecessor on
level eight would have to be `WR` immediately before
`E6`. Thus `D3=SR,D4=NL`, and the obstruction forces
the consecutive pair `F5=ER,F6=EL`.

On level eleven, let `P_J,P_X,P_K` feed the successive
west arrivals `J,X2,K` on level eight. The sixteen-step
return from `P_J` to the north arrival supplied by `F4`
is unchanged. Taking `P_J=NL` again forces the square
from `E3` to `J` which skips `E4,X1`. Hence `P_J=SR`,
and its consecutive target is `P_X=NL`, supplied by
`10:F4=EL`.

There is also a twelve-step first return

```text
P_K -> 8:K -> 7:SL4 -> 10:F5=ER -> 9:D3=SR -> 6:WL2
    -> 5:SL3 -> 8:E6=EL -> 9:D4=NL -> 6:WR2
    -> 7:NR3 -> 10:F6=EL -> north arrival on 11.
```

If `P_K=NL`, its incoming predecessor `X` on level ten
is the north departure immediately preceding `F6`.
The square `X -> P_K -> 8:K -> 7:SL4 -> F5=ER`
would force `X=F4=EL`. But this departure already feeds
the distinct west departure `P_X`. Thus `P_K=SR`.
Its consecutive target is a further west departure `NL`.
There must consequently be a west arrival after `K` on
level eight. In (1), when `f=1`, the only possible such
arrival is the final `[WR]^g`. Hence `g=1`.

The surviving tail (1), with `f=0` or `(f,g)=(1,1)`, is
subsequently excluded in
`odd_skew_fat122_four_six_band_exclusion_2026-09-14.md`.
These lower-orientation clock comparisons have not been
transferred to an upper cap.
