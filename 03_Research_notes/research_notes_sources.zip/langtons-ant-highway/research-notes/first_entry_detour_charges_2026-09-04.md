# First-entry detour charges and a stronger period bound

The first-entry cycle gives an exact integer decomposition of growth. It also
gives the uniform bound

```text
N >= 6 max(|a|,|b|) + 2(|a|+|b|)
```

for nonzero drift `(a,b)`. Both statements follow from visit order and planar
geometry. They use no enumeration. Neither closes a growth-eight drift orbit.

The sign of an individual detour charge remains the obstruction. Simple
detours have charge one, but a legal eight-step detour with charge zero is
given below. Its compatibility with an entire periodic trace is not asserted.

## Exact charge accounting

Use the forward first-entry cycle from
`cylinder_exit_cycles_2026-09-03.md`. Its length is `k`, its voltage is one,
and its geometric turn sum is zero. The actual period consists of the
selected edges and closed waits at their sources. Exactly the `k/2`
geometric L corners have positive waits; R corners have zero waits.

At a positive wait, let `T` be the sum of the actual turns during the wait,
excluding the departure along the selected edge. Let `s` be that departure's
turn, with R equal to `+1` and L to `-1`. Define

```text
q = (T+s+1)/4.
```

This is an integer. If the final incoming heading equals the first incoming
heading, feeding the geometric L edge requires `s=-1`, and `T=0 mod 4`.
If the heading is reversed, feeding that same edge requires `s=+1`, and
`T=2 mod 4`. The fixed incoming axis leaves no other case.

Every zero-wait R corner contributes one actual R. Adding the turns in the
period therefore gives

```text
g = sum_positive_waits T + k/2 + sum_positive_waits s
  = 4 sum_positive_waits q.
```

At growth eight, the `k/2` integer charges sum to two. The formula by itself
does not say that the charges are positive, or even nonnegative.

## A four-step wait cannot follow a geometric R corner

A four-step closed quarter-turn walk is a unit square. Its root is visited
once before the return. Since this is a first-entry wait, that first visit
is white/R, and the return finds the root black. The feeding turn is thus L.
The selected geometric turn is also L, so the return heading equals the
initial heading. The square's closing corner at the root is consequently R:
the square is clockwise, and all four turns during the wait are R.

Let `u` be the physical predecessor of the root's first visit. The square
visits `u` at its third step, then returns to the root. There is no intervening
visit to `u` after its selected departure immediately before the wait.
Because the square turns R at `u`, that preceding departure must have turned L.

If `u` were a geometric R corner of the first-entry cycle, its selected
departure would instead be its first, right-turn departure. Hence a
four-step wait is impossible at the L corner of every cyclic R-to-L
transition.

Let `rho` count these transitions. The `k/2` positive waits cost at least
four steps each, and these `rho` waits cost at least eight. Thus

```text
N >= 3k + 4 rho.                                      (1)
```

There is at least one transition, so equality in the earlier bound `N>=3k`
is impossible at every nonzero drift, independently of growth.

## Drift forces enough turn changes

Write `e_i` for the selected unit step leaving cycle vertex `i`, with indices
modulo `k`, and `c_i` for the geometric turn from `e_(i-1)` to `e_i`.
Two successive quarter turns give

```text
e_(i+1) = -c_i c_(i+1) e_(i-1).
```

If the turns agree, `e_(i-1)+e_(i+1)=0`; if they differ, the sum is
`2 e_(i-1)`. Summing around the cycle yields the vector identity

```text
(a,b) = sum_(c_i != c_(i+1)) e_(i-1).
```

There are `2 rho` changes, since R-to-L and L-to-R changes alternate in a
cyclic word. Taking the lattice one-norm gives

```text
|a|+|b| <= 2 rho.
```

Combine this with (1) and `k>=2 max(|a|,|b|)`:

```text
N >= 6 max(|a|,|b|) + 2(|a|+|b|).                     (2)
```

For diagonal drift `(m,-m)`, (2) is `N>=10m`. At growth eight, combining
it with the existing period congruences gives `N>=20` at `(2,0)` and
`N>=40` at either `(2,4)` or `(2,-4)`. These are consequences of this
argument alone, not claims that those periods are feasible or that other
proved restrictions stop there. There is still no upper bound on `N`.

## Eight-step positive waits have charge zero

First suppose an eight-step positive wait revisits its root before the final
return. The intermediate return must occur at step four, since closed
quarter-turn walks have length divisible by four.

If the first square is clockwise, the root returns with its initial heading
and is black. Its L departure at step four already takes the selected edge.
That reaches the selected target too early, contrary to the definition of
the wait.

For the other orientation, rotate coordinates so the initial heading is N.
The first square has directions `E,N,W,S` and turns `R,L,L,L`. At step four
the black root has heading S, so its L turn again sends it E. The next cell
was flipped from black to white during the first square, forcing R and then
S. A four-step return now has to finish W,N. At step eight the root is white
and the heading is N, so its next R again takes E, not the selected W edge.
This also cannot be the required wait. Hence the root has no intermediate
visit in an eight-step positive wait.

The return therefore finds the root black. The feeding turn is L, the
return heading equals the initial heading, and `T=0 mod 4`.

There is no simple eight-edge unit lattice polygon that turns at every
vertex. Its four horizontal and four vertical edges put its bounding box
inside a two-by-two square. A simple polygon's enclosed unit faces must be
edge-connected. A single face has perimeter four, and two adjacent faces
have perimeter six. Perimeter eight therefore leaves an L-shaped set of
three unit faces or the full two-by-two square. Both have consecutive
collinear boundary edges.

Thus some other physical cell repeats. Its two visits are four steps apart,
and splitting the cyclic closed walk there gives two unit squares. Write
their clockwise orientation signs as `epsilon_1,epsilon_2`, each equal to
`+1` or `-1`. The six corners away from the splitting cell contribute
`3(epsilon_1+epsilon_2)`. The two actual turns at the splitting cell alternate
and sum to zero. At the original root the polygon's closing corner equals
its actual initial turn, since the return heading is unchanged. Consequently

```text
T = 3(epsilon_1+epsilon_2) in {-6,0,6}.
```

Only zero is divisible by four. Therefore `T=0`, `s=-1`, and `q=0` for
every eight-step positive first-entry wait.

### Strictness at diagonal drift

If `d=(m,-m)` and equality held in `N>=10m`, the inequalities above would
force `k=2m`, `rho=m`, and length eight at every positive wait. Their charges
would all be zero, giving `g=0`. At growth eight equality is impossible.
Since `N=2m mod 4`, the resulting bound is

```text
N >= 10m+4.
```

For `m=1,2,3` this gives respectively `N>=14,24,34`. For `m=4`, the
growth-eight congruence `N=0 mod 8` raises the bound further to `N>=48`.
These remain lower bounds on period, not all-period exclusions.

## Two preceding R corners rule out an eight-step wait

The eight-step classification also constrains the preceding selected cycle
vertices. At every geometric `R,R,L` pattern, the wait at the L corner has
length at least twelve. The four-step case was excluded above; the following
argument excludes eight using the actual predecessor visits.

An eight-step positive wait consists of two oppositely oriented unit squares,
as in the charge-zero proof. If the squares coincided, their join would
reverse direction. If they met only at diagonally opposite corners, the join
would be straight. Both are forbidden in a quarter-turn walk. They therefore
share an edge. Both endpoints of that edge repeat, so the first-entry root,
which has no intermediate visit, is a nonshared corner. Its closing turn is
R, placing it on the clockwise square.

There are two such corners. Up to rotation and translation, with root
`v=(0,0)` and initial incoming heading E, they give the two direction words

```text
A: S,W,N,W,S,E,N,E
B: S,W,S,E,N,W,N,E.
```

The selected edge after either wait goes north. Set the first visit to `v`
at time zero. Its physical cycle predecessor is `u=(-1,0)`, whose selected
departure reaches `v` at time zero and hence occurs at time `-1`.

In case B, the wait visits `u` at time seven with an R turn. There is no
intervening visit to `u` after time `-1`, so that selected departure must
have turned L. In particular, `u` cannot be a geometric R corner: such a
corner has zero wait and its selected departure is its first, right turn.

In case A, the visits to `u` at times three and seven turn L and R. Suppose
`u` is a geometric R corner. Its event at time `-1` is then its first visit,
with incoming heading N and outgoing heading E. Thus its physical cycle
predecessor is `z=(-1,-1)`, whose selected north departure occurs at time
`-2`. Case A reaches `z` at time two with incoming heading W and turn R.
The intervening events, at times `-1,0,1`, occur at `u`, `v`, and `(0,-1)`,
none of which is `z`. Same-cell alternation therefore makes the selected
departure from `z` at time `-2` an L turn. Consequently `z` cannot be a
geometric R corner either.

An eight-step wait following an R corner thus forces the corner before that
R to be L. This rules out the pattern `R,R,L`. The argument is on one
physical lift of the cycle; it also applies when these three vertices
straddle the chosen period boundary.

### A nonzero-growth cycle needs a wait of length at least twelve

Suppose all positive waits of a selected first-entry cycle have length four
or eight. If any cyclic R run had length at least two, its last two corners
and the following L would form `R,R,L`, contradicting the preceding result.
Hence every R run is a singleton.

The geometric turn sum is zero, so the cycle has equal numbers of R and L
corners. Its cyclic R and L runs also have equal counts. It follows that
every L run is a singleton as well: the turn word alternates R,L. Each
positive wait now follows an R corner, so none can have length four. All
have length eight and charge zero, giving `g=0` by the exact charge identity.

Therefore every trace with nonzero growth has a positive wait of length at
least twelve on every selected first-entry cycle. In particular, this holds
for every growth-eight drift orbit. It is a restriction from coupled visit
history, not a sign bound on longer waits or an exclusion of any orbit.

## Simple positive waits have charge one

Suppose a positive wait is a simple closed physical lattice polygon: no
physical cell repeats before the final return to its root. The root again
finds black at the return, so `s=-1`, the return heading equals the first
heading, and the polygon's closing corner is R.

The infinite forward lift of the selected first-entry cycle starts at this
root, takes the feeding edge, and tends to infinity. Every other vertex on
that forward ray has a strictly later first-visit time than the end of the
wait. Consequently the ray cannot meet any vertex visited during the wait.
Unit lattice edges cannot cross without sharing a vertex, so it cannot
cross the wait polygon either.

If the polygon were counterclockwise, its R corner at the root would be
reflex. The feeding edge, opposite to the wait's first outgoing edge, would
enter its bounded interior. The forward ray would then have to cross the
polygon to reach infinity. This is impossible. The polygon is clockwise,
so its turn sum is `T=4`, and

```text
q=(4-1+1)/4=1.
```

If every positive wait of the chosen cycle is simple, it follows that
`g=2k`. At growth eight this forces `k=4`. Four alternating-axis steps with
nonzero displacement allow only the quarter-turn orbits of `(2,0)` and
`(2,-2)`. Thus the other eight growth-eight drift orbits necessarily require
a nonsimple positive wait on every first-entry cycle. This is a restriction
on their detours, not an exclusion of those orbits.

## Why root colour and an unvisited future ray do not prove positivity

Start at `v=(1,0)` with incoming heading E. Initially make exactly
`(0,0),(-1,0),(-1,-1)` black among the cells used below. The following
eight-step return is legal:

| time | cell | incoming | turn | outgoing |
|---|---|---|---|---|
| 0 | `(1,0)` | E | R | S |
| 1 | `(1,-1)` | S | R | W |
| 2 | `(0,-1)` | W | R | N |
| 3 | `(0,0)` | N | L | W |
| 4 | `(-1,0)` | W | L | S |
| 5 | `(-1,-1)` | S | L | E |
| 6 | `(0,-1)` | E | L | N |
| 7 | `(0,0)` | N | R | E |
| 8 | `(1,0)` | E | L | N |

The last row is the feeding departure, excluded from the wait's turn sum.
The two repeated interior cells alternate: `(0,-1)` has R,L and `(0,0)`
has L,R. The root is first-white and appears only at times zero and eight.
There are four R and four L turns during the wait, so `T=0` and `q=0`.

The feeding north edge reaches the unvisited cell `(1,1)`. A northeast
unit staircase from there avoids the whole detour, which lies in `y<=0`.
The immediate predecessor can even be a first NR visit to `(0,0)` at
time `-1`; it supplies the required black colour there, with visible
same-cell order R,L,R.

This is a re-rooted domino-transfer example of the type discussed in
`axis_two_exit_cycles_2026-09-03.md`. It does not supply the earlier histories
of the other black cells or a periodic P3 extension. It establishes the
narrow obstruction: first-white root, the right feeding edge, ordinary
alternation, and an unvisited ray to infinity do not force `q>=1`.

A growth-eight closure by this decomposition must use the coupled periodic
histories of the detours. Neither replacing every charge by one nor counting
all temporarily black cells as permanent wake is valid.
