# The remaining single-ER continuation at the upper cap of family A

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Use inward offsets and rotated heading labels at an upper cap.
Suppose a `(1,2,2)` cap has a wake at offset four, non-wakes at
offsets five, seven, and eight, and exactly one `ER` port at
offset six. Then offset six is wake, and offsets five through
seven have the necessary words

```text
5: NR,SL,SR,NL,NR,SL,NR,SL
6: WR,WL,WR,EL,WR,WL,ER,WL,WR,EL,WR
7: SR,SL,NR,NL,NR,SL,NR,NL,NR,NL,SR,SL.
```

In particular, for family A, the single-`ER` branch requires
`h=1`, equivalently `p=m-1`. This last continuation is not
excluded here. Nor are the upper two-`ER` branches.

The proof uses only first same-cell returns and stable order.
It has no longitudinal voltage inequality, so it applies with
the same inward words at either cap.

## A left-return obstruction for word B

The two-sided normal form with a wake at four is

```text
4: WR,WL,ER,WL,WR,EL,WR
5 B: NR,SL,SR,NL,NR,SL,NR,[SL]^(1-c).
```

Let `W1,...,W5` be the west departures on offset seven,
feeding `4:WR1,WL1,WL2,WR2,WR3`. Let `Ei` be the east
arrivals on offset eight, supplied by the east departures
of word B on offset five. In particular, `E2` is supplied
by `5:SL1`, and `E3,E4,E5` by `5:NR2,SL2,NR3`.

Suppose the last east arrival on offset six is `L=EL`.
The square from `W3` through `4:WL2,3:last SL,L` ends
at a north arrival on offset seven. If `W3=SR`, its
consecutive target must be `W4=NL`.

The seven-step path

```text
W4 -> 4:WR2 -> 5:NL -> 2:WL -> 1:SL
   -> 4:EL -> 5:NR2 -> E3
```

cannot end at `E3=ER`. Its south step would return from
`W4=NL` to `W5=SR`, after which the square through
`4:WR3,5:NR3` to `E5` would skip `E4` in east-arrival
order. Thus `E3=EL`.

The south predecessor of `W3` on offset eight follows
the square to `W4` and then this seven-step path. The
twelve-step first return to `E3=EL` forces that predecessor
to be `E2=ER`. It follows that

```text
5:SL1 -> 8:E2=ER -> 7:W3=SR -> 4:WL2 -> 3:last SL
      -> 6:L=EL -> 7:W4=NL -> 4:WR2 -> 5:NL
```

is an eight-step first return. Its direction word is
`E S W S E N W N`. Both endpoints turn left, a
contradiction.

Consequently `W3=NL`. Its square return now forces its
incoming predecessor on offset six to be `WR`, immediately
preceding `L=EL`. This conclusion applies to any word B
with the stated last east arrival, not just the single-`ER`
count row.

The single-`ER` reduction in
`odd_skew_fat122_four_wake_single_er_2026-09-13.md` leaves
words T and U when `c=0`, and V when `c=1`. In T and V,
the last `EL` is immediately preceded by `ER`, not `WR`.
They are therefore excluded at either cap. Only U remains
when `c=0`:

```text
6: WR1,WL1,WR2,EL1,WR3,WL2,ER,WL3,WR4,EL2,[WR5]^e.
```

Here `e=omega_6`. In particular, there is no single-`ER`
continuation at either cap when `c=1`.

## The prefix on offset seven for U

Write `Ni` for the north arrivals on offset seven. The
earlier return reduction gives `W2=NL=N2`, with consecutive
target `N3=NR`. The preceding section gives `W3=NL=N5`,
with consecutive target `N6=NR`.

The path from `W1` through `4:WR1,5:NR1` reaches the
first east arrival `E1` on offset eight. The square from
its south predecessor forces `E1=ER`: an `EL` endpoint
would require an earlier east arrival as its source. Its
south step then forces `W1=SR` to be immediately followed
by `SL`.

The first north arrival `N1` cannot precede this pair.
If it did, there would be no right turn available between
the `SL` after `W1` and `W2=NL=N2`. Hence alternation
and the north order fix the prefix through `N6`:

```text
7: SR,SL,NR,NL,NR,SL,NR,NL,NR,... .                  (1)
```

Its first nine events contain `W1,W2,W3` and the first
six north arrivals. If `e=1`, the only remaining north
arrival is `N7`, supplied by `6:WR5`.

## The two remaining west departures

If `W4=SR`, then `E3=ER`. Indeed, taking `E3=EL` in
the seven-step path from `W4` would force its south
predecessor to be `E2=ER`. But then

```text
5:SL1 -> 8:E2=ER -> 7:W4=SR -> 4:WR2 -> 5:NL
```

would be a square with two left-turn endpoints. Thus
`W4=SR` is followed immediately by `SL`.

In this case `W5` cannot be `NL`: it would have to be
`N7`, but no right turn is available between the `SL`
after `W4` and that `NL`. Therefore `W5=SR` as well.

Assume this case until the final section. If `e=0`,
append `SL,SR,SL,SR,SL` to (1). If `e=1`, append one
of the following tails, according to the position of `N7`:

```text
before W4:       SL,NR,SL,SR,SL,SR,SL;
between W4,W5:   SL,SR,SL,NR,SL,SR,SL;
after W5:        SL,SR,SL,SR,SL,NR,SL.
```

All words end with `SL`, since offset seven is non-wake.
The resulting south ordinals are

| Case | Ordinal of E3=ER | Ordinal of W5 | Total south arrivals on seven |
|---|---:|---:|---:|
| `e=0` | 6 | 7 | 8 |
| `N7` before `W4` | 7 | 8 | 9 |
| `N7` between `W4,W5` | 6 | 8 | 9 |
| `N7` after `W5` | 6 | 7 | 9 |

An `E5=EL` would force `E4=ER` at the south ordinal
feeding `W5`. In the first, second, and fourth rows this
is immediately after the ordinal of `E3=ER`, which is
impossible for successive east right turns. Hence `E5=ER`
in those rows. In the first two rows it is the last south
departure, and in the fourth it is the eighth.

In all four rows, `E6=EL`. In the first two there is no
south departure left for another `ER`. In the fourth,
two consecutive east right turns `E5,E6` would require
an intervening `WL`, exceeding the nine south departures.
In the third row, either `E5=ER` is already the ninth
south departure, or `E5=EL` follows `E4=ER` at ordinal
eight. In the latter case `E6=ER` would be both the last
east arrival and the last south departure, forcing offset
eight to be wake, contrary to the hypothesis.

## The sixth west departure on offset nine must be NL

Label the west departures on offset nine by `Di`. They
feed the offset-six west arrivals in the order

```text
WR1,WL1,WR2,WR3,WL2,WL3,WR4,[WR5]^e.
```

Suppose `D6=SR`. Its square through `6:WL3,5:SL3,E6=EL`
forces the consecutive target `D7=NL`. The latter has
the seven-step path

```text
D7 -> 6:WR4 -> 7:W3=NL -> 4:WL2 -> 3:last SL
   -> 6:EL2 -> 7:N6=NR -> 10:F6.
```

If `F6=EL`, the south predecessor of `D6` on offset ten
has a twelve-step first return to `F6`, forcing it to
be `F5=ER`. But `F5` is supplied by `7:N4=NR`, from
`6:WR3`. The resulting square

```text
6:WR3 -> 7:N4=NR -> 10:F5=ER -> 9:D6=SR -> 6:WL3
```

skips `WL2,ER` in the offset-six word. Thus `F6=ER`.
Its south step returns from `D7=NL` to another west
departure `D8=SR`. This already excludes `e=0`.

For `e=1`, `D8` feeds `6:WR5`, then `7:N7=NR`, then
an east arrival `Fq` on offset ten. In the three displayed
tails, `q` is respectively eight, nine, or ten. The square

```text
10:F6=ER -> 9:D8=SR -> 6:WR5 -> 7:N7=NR -> 10:Fq
```

would force `Fq=EL` immediately after `F6`, skipping
at least `F7`. This is impossible. Therefore `D6=NL`.
Its incoming predecessor on offset eight must be `WR`,
immediately preceding `E6=EL`.

In the `e=0` and `N7`-before-`W4` rows, `E5=ER` is
the last south departure, so `E5,E6` are consecutive.
The same holds in the middle row if `E5=ER`. Their
right-turn predecessor is not `WR`, excluding these cases.

## The middle row with E5=EL

Here `E4=ER,E5=EL` are consecutive. The fifth west
departure on offset nine has the twelve-step first return

```text
D5 -> 6:WL2 -> 5:SR -> 2:WR -> 3:NR -> 6:ER
   -> 5:SL2 -> 8:E4=ER -> 7:W5=SR -> 4:WR3
   -> 5:NR3 -> 8:E5=EL -> north arrival on 9.
```

If `D5=NL`, its north predecessor on offset eight lies
before `E4`. The initial eight-step return to `E4=ER`
would force that predecessor to be `E3=EL`, contrary
to `E3=ER`. Hence `D5=SR`, with consecutive target
`D6=NL` supplied by `8:E5=EL`.

But the square from `E5` through `D6,6:WL3,5:SL3`
ends at `E6=EL`. Both endpoints turn left. This excludes
the middle row.

## The row with N7 after W5

Here `E3=ER` is the sixth south departure and `E5=ER`
the eighth. Their intervening east arrival is `E4=EL`;
the square through `W5` forces its south predecessor
`J=WL` immediately before `E5`. Hence the tail begins

```text
E3=ER,E4=EL,WR,J=WL,E5=ER.
```

Now `D5` has the eight-step first return through
`6:WL2,5:SR,2:WR,3:NR,6:ER,5:SL2,E4=EL` to a
north arrival on offset nine. An `NL` source would
force an incoming `WR` immediately before `E4`, where
the stable predecessor is instead `E3=ER`. Thus
`D5=SR`, with consecutive target `D6=NL` supplied by
`E4=EL`. Its square through `6:WL3,5:SL3` to `E6=EL`
again has two left-turn endpoints. This excludes the last
row with `W4=SR`.

## The one remaining order

Therefore `W4=NL`. The only north arrival available to
it is `N7`, so `e=1`. There are no north arrivals left
for `W5`, which must be `SR`. Alternation, the prefix
(1), and the non-wake condition at offset seven give

```text
7: SR,SL,NR,NL,NR,SL,NR,NL,NR,NL,SR,SL.
```

Its `W4=NL` also forces `E3=EL` by the skipped-east-
arrival square used at the start of the note. In family A
the wake at upper offset six is equivalent to `h=1`, so
this single-`ER` branch has `p=m-1`. The remaining order
is subsequently excluded in
`odd_skew_upper_a_single_er_exclusion_2026-09-14.md`.
The two-`ER` branch is separate and remains open.
