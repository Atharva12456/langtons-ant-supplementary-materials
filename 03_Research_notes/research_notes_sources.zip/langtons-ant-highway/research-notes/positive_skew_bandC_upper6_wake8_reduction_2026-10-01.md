# Band C: quiet upper four and wake upper six require wake upper eight

This note concerns literal drift `(1,3)` at growth eight, with
`t=3x-y`, lower extremum zero and even width W. The whole orbit remains
**open**. The arithmetic proof, independent necessary-word generation,
physical-certificate replay and complete integer-clock audit have passed.

## Endpoint classification under quiet upper four

Lower fat band C fixes wakes `0,2,3,4`. Its fibre-zero sign counts are
either `(3 positive,1 negative)` or `(1 positive,3 negative)`;
fibres one and two each have two positive wakes. Here
`j=-t mod3`, `n=ceil(t/3)`, and the checker sign is `(-1)^t`.
These counts follow from growth-eight P22 and the lower opposite-sign
pair `0,3`. They forbid negative wakes outside fibre zero.

Consider an upper `(1,2,2)` cap with quiet inward offset four and wake
inward offset six. The cap itself has only its extremal wake W through
offset two. Established width exclusion gives `W>=18`.

The two positive wakes `W-6,W` belong to the same fibre. If that were
fibre one or two, they and the existing lower wake `2` or `4` would
give three positive wakes in a fibre that has exactly two. Thus
`W=6m`. Fibre zero is now filled by `0,3,W-6,W`, with positive majority.
The two remaining wakes must be positive, one in each other fibre:

```text
O={0,2,3,4,6p+2,6q+4,W-6,W},   W=6m.
```

The residuals lie above level four. Quiet upper two gives
`1<=q<=m-2`; quiet upper four gives `1<=p<=m-2`. Both residuals
therefore precede `W-6`.

The ordered fixed fibre word is `0,1,0,2,0,0`, with four
increasing-fibre pairs. The fibre-one residual adds two interactions
with fixed wakes, the fibre-two residual adds three, and their mutual
pair contributes one exactly when `p<=q`. The required even rank
therefore forces `p<=q`.

The signed longitudinal moment is

```text
M=4m+2(p+q)+3 = 3+2(p+q) (mod4).
```

Requiring M=1 gives odd `p+q`, hence p and q differ. The exact
arithmetic family is consequently

```text
1<=p<q<=m-2,   p+q odd.
```

Conversely every such pair satisfies P22, moment and rank. This is
sufficiency for those arithmetic conditions only.

The residual upper distances are `6(m-p)-2>=16` and
`6(m-q)-4>=8`. The four lower fixed distances are at least twenty,
since the bounds require `m>=4`. Besides fixed wake six, the only
possible upper wake through offset fifteen is eight, occurring exactly
when `q=m-2`. In particular offsets `3,4,5,7,9,10,11,12,13,14,15`
are quiet.

The independent original-coordinate checker
`work_positive_skew_upper6_quiet8_20261001/verify_bandC_upper6_endpoints.py`
exhausts both residual positions at every even width 18 through 150.
Its 1,078 accepted endpoint sets match the formula exactly: 132 have
wake eight and 946 have quiet eight. The hand derivation above gives
the all-width scope. **Quiet upper four is essential**: a different
rank interaction occurs when a residual lies at `W-4`, after `W-6`.

## Local upper-cap obstruction

In the upper half-turn gauge, an upper `(1,2,2)` cap starts

```text
0: NR;   1: WR,WL;   2: NR,SL.
```

The tested local schedule has quiet offsets three, four and five,
wake six, and quiet offsets seven through twelve. The exact necessary
domain is empty. This local statement uses no growth assumption:
the integer period N is unbounded above, only `N>=1` and strict stable
order are imposed, and directed edge times satisfy
`tau_target=tau_source+1+N*dx`. The positive sign follows from the
upper half-turn. R/L labels are preserved by that rotation.

For odd new level t, let A count east departures from `t-3` and D
count north arrivals in `t-1`. All possible count vectors are

```text
ER=A-e, EL=e, WR=D-e, WL=A+D-3e-omega_t.
```

For even t, let B count south departures from `t-1` and C count
west arrivals in `t-3`. All vectors are

```text
SR=s, SL=B-s, NL=C-s, NR=omega_t+B+C-3s.
```

Nonnegativity bounds e or s, so each new vector domain is finite
without a visit-count cutoff. Every R-first alternating word is
included unless an excursion through already assigned rows makes a
zero-copy physical return whose prescribed arrival cannot be the next
stable event. This is a necessary adjacency condition. Excursions with
nonzero copy displacement do not impose it. The remaining words are
checked for witnessed wrong physical first returns and for exact
unbounded integer clocks.

| Offset | Complete input prefixes | Count vectors | Raw alternating words | Necessary prefixes left |
|---|---:|---:|---:|---:|
| 3 | 1 | 1 | 2 | 2 |
| 4 | 2 | 4 | 38 | 3 |
| 5 | 3 | 6 | 57 | 5 |
| 6 | 5 | 15 | 280 | 12 |
| 7 | 12 | 46 | 9,054 | 14 |
| 8 | 14 | 54 | 10,852 | 12 |
| 9 | 12 | 56 | 58,240 | 8 |
| 10 | 8 | 46 | 2,938,682 | 10 |
| 11 | 10 | 64 | 5,126,888 | 43 |
| 12 | 43 | 345 | 1,961,761,244 | 0 |

At twelve the necessary adjacency generator emits 27,934 words.
Every one is rejected: 17,107 have a wrong physical first return and
10,827 have an inconsistent weak integer clock. The stage finishes
with 237,147 recursion nodes and no resource cap reached.

Root independently recomputed every count-vector domain and raw-word
total, reconciled every emitted candidate, and geometrically replayed
all 18,561 saved physical first-return rejections over all stages.
The root checker imports no frontier engine. A second independently
written geometric generator regenerated every emitted candidate at
all ten stages, including all 27,934 terminal words, with no frontier
imports or memoization. It also rederived the 106 earlier clock
rejections with Z3. The separate terminal affine-potential audit proved
all 10,827 clock rejections: 10,440 by incompatible positive-cycle
inequalities and 387 by a positive cycle at an equality-forced period.
Z3 checks of all ninety distinct coefficient signatures passed. All
clocks use `+N`, strict order and unbounded integer `N>=1` only.

Reproduction files are in
`work_positive_skew_upper6_quiet8_20261001`: `probe.py` produces the
complete domains through eleven, `extend12.py` completes twelve,
and `replay_physical_and_domains.py` performs the independent domain
and geometry audit. The initial 30-second probe of row twelve is explicitly
incomplete and is superseded by `complete12_result.json`; an incomplete
stage is never used to infer exclusion.

## All-width consequence

If band C and this upper cap had quiet eight as well as quiet four
and wake six, the endpoint classification would force exactly the
excluded local schedule. Thus quiet four and wake six require wake
eight. The residual parameter then satisfies `q=m-2`, leaving

```text
W=6m,   m>=4,
O={0,2,3,4,6p+2,W-8,W-6,W},
1<=p<=m-3,   m+p odd.
```

The last residual's upper distance is `6(m-p)-2=12r+4`, `r>=1`:
sixteen, twenty-eight, forty, and so on. This family still has
unbounded arithmetic realizations; it has not been proved to admit
or forbid a physical highway. All other remaining cap pairs and the
seven remaining lower-thin templates must also be addressed to close
the whole orbit.
