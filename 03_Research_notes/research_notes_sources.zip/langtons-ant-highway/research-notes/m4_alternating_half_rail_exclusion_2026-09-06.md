# An alternating upper half rail forces a nearby wake

Date: 2026-09-06. New research result derived from the project's September 4 cap-order note.

**Status:** a hand proof, with independently checked finite certificates as corroboration. This excludes the displayed September 4 partial-rail family at every period and every allowed width. It does **not** close the entire growth-eight drift orbit of `(-4,4)` (equivalently, after a half-turn, `(4,-4)`). This result has not been formalized in Lean or externally reviewed.

## 1. Statement and scope

Use drift `d=(4,-4)`, transverse coordinate `t=x+y`, and horizontal arrivals on odd levels. Suppose the actual upper rail is `t=H`, its odd `x mod 4` classes are singleton `ER` events, and its even classes are absent. Then the next three inward levels cannot all be non-wake.

Here a wake class has an odd-length stable visit word; a non-wake class has an even-length word, possibly empty. P3 supplies first-white, alternating stable words at sufficiently far future physical copies.

In the **pure horizontal-wake branch**, the first and third inward levels are vertical-arrival levels and already have no wake. The theorem therefore says:

\[
\boxed{\text{An alternating upper half rail requires a wake on }t=H-2.}
\]

No condition on the fourth inward level, no lower-rail occupancy, and no bound on the period or rail separation is used.

In particular, the September 4 family has wakes at `t=1` in all four lanes, at `t=3` in lanes 0 and 2, and at `t=W+1` in lanes 1 and 3, with `W=8j+4>=12`. Its top three inward levels are non-wake. **Every member of that family is excluded.** The earlier family-specific bound `N>=8W+40` is superseded by this exclusion.

## 2. Physical cells and the existing cap normal form

For integer `x`, define

\[
T_x=(x,H-x),\quad U_x=(x,H-1-x),\quad
V_x=(x,H-2-x),\quad P_x=(x,H-3-x),\quad Z_x=(x,H-4-x).
\]

These are physical cells, not just quotient classes. For example, `Z_(x+4)=Z_x+d`. All closed paths below return to exactly the same integer coordinates; crossing a quotient seam cannot change their conclusions.

Port labels give incoming heading and turn. Their outgoing directions are

| Port | NR | NL | ER | EL | SR | SL | WR | WL |
|---|---|---|---|---|---|---|---|---|
| Outgoing | E | W | S | N | W | E | N | S |

The September 4 cap-order proof, under precisely these upper-rail and three non-wake hypotheses, gives the following complete stable words:

| Cell | Word |
|---|---|
| `U_x`, even x | `NR NL` |
| `U_x`, odd x | `SR NL` |
| `V_x`, even x | `ER EL WR WL` |
| `V_x`, odd x, type A | `ER EL ER WL` |
| `V_x`, odd x, type B | `ER WL ER EL` |

If `V_(x+1)` is A, an even `P_x` has one of

- E1: `SR NL NR NL NR SL`;
- E2: `NR NL SR NL NR SL`;
- E3: `NR SL SR NL NR NL`.

If `V_(x+1)` is B, its even predecessor instead has

- EB: `NR NL NR SL SR NL`.

At odd `P_x`, type A at `V_x` gives

- O1: `NR NL SR SL SR NL`;
- O2: `SR NL NR SL SR NL`.

Type B gives `NR SL SR NL SR NL`.

The source derives these lists using directed-edge counts and closed four- and eight-step returns, without assuming that every rail lane is occupied. The accompanying verifier also reconstructs the admissible cap words directly from the singleton upper rail, so its enumeration does not merely assume these interior tables.

## 3. Eliminate B and E3

Fix even `x`. In either EB or E3, the first south arrival at `P_x` is `SL`, and that event feeds the unique `EL` arrival at `V_(x+1)`. Consequently the following physical four-step return is forced:

\[
V_x:\mathrm{ER}\to P_x:\mathrm{SL}\to
V_{x+1}:\mathrm{EL}\to U_{x+1}:\mathrm{NL}\to V_x:\mathrm{WL}.
\]

There is no intermediate visit to `V_x`. But its complete word is `ER EL WR WL`, requiring two visits between those endpoints. This is impossible.

Thus every odd `V` has type A, every even `P` has type E1 or E2, and every odd `P` has type O1 or O2. The rest of the proof handles all four local E/O combinations. It does not need any additional global time-cycle pruning.

## 4. Two forced returns at the fourth inward level

Fix even `x`. At the physical cell `Z_x`, let `n_1,...,n_4` denote its north-departure events in chronological order, and let `w_1,...,w_4` denote its west-arrival events in chronological order. There are exactly four of each: the former feed the four north arrivals at `P_x`, and the latter come from the four west departures at `P_(x+1)`.

An event can belong to both lists: precisely a `WR` event. A north departure is `EL` or `WR`; a west arrival is `WR` or `WL`. Successive visits at this physical cell alternate turns, regardless of whether the class is a wake.

### The short return

The first `NR` at `P_x` is fed by `n_k`, where `k=2` in E1 and `k=1` in E2. It forces

\[
Z_x:n_k\to P_x:\text{first NR}\to V_{x+1}:\text{first ER}
\to P_{x+1}:\text{first SR}\to Z_x:w_l.
\]

Here `l=2` in O1 and `l=1` in O2. This is a four-step first return, so `n_k` and `w_l` are consecutive visits with opposite turns.

### The long return

The last north departure `n_4` feeds the second `NR` at `P_x`. All remaining steps in the following table are forced by the cap words and ordered matching on each physical directed edge:

| Step | Cell and event |
|---:|---|
| 0 | `Z_x:n_4` |
| 1 | `P_x:second NR` |
| 2 | `V_(x+1):EL` |
| 3 | `U_(x+1):NL` |
| 4 | `V_x:WL` |
| 5 | `P_x:SL` |
| 6 | `V_(x+1):second ER` |
| 7 | `P_(x+1):SL` |
| 8 | `V_(x+2):EL` |
| 9 | `U_(x+2):NR` |
| 10 | `T_(x+3):ER` |
| 11 | `U_(x+3):SR` |
| 12 | `V_(x+2):WR` |
| 13 | `U_(x+2):NL` |
| 14 | `V_(x+1):WL` |
| 15 | `P_(x+1):last SR` |
| 16 | `Z_x:w_3` |

No intermediate cell is `Z_x`; the two endpoints are consecutive visits. If `n_4` were `EL`, its opposite-turn return would be `WR`, creating a fifth north departure. Therefore

\[
n_4=\mathrm{WR},\qquad w_3=\mathrm{WL},\qquad
n_4\text{ is either }w_1\text{ or }w_2.
\]

## 5. Exhaust the four E/O combinations

**O1, either E1 or E2 (`l=2`).** If `n_k` is `WR`, its consecutive return `w_2` is `WL`. Since `k<=2`, `n_4` must be later than `w_2`. If `n_k` is `EL`, its consecutive return is `w_2=WR=n_(k+1)`; again `k+1<=3`, so `n_4` is later than `w_2`. Both contradict `n_4` being `w_1` or `w_2`.

**E1 with O2 (`k=2,l=1`).** The starting `n_2` cannot be `WR`, because that would itself be a west arrival before `w_1`. Hence `n_2=EL` and its consecutive return is `w_1=WR=n_3`. Thus `n_4=WR` must be `w_2`. Between the right-turn events `n_3` and `n_4`, alternation requires a left turn. An `EL` would be another north departure between consecutive `n_3,n_4`; a `WL` would be another west arrival between consecutive `w_1,w_2`. Neither is possible.

**E2 with O2 (`k=1,l=1`).** The same first-arrival reasoning gives `n_1=EL`, `w_1=WR=n_2`, and then `n_4=WR=w_2`. In O2, `w_2` comes from the `NL` event in the second position at `P_(x+1)`. The following eight-step first return is consequently forced:

\[
P_{x+1}:\mathrm{NL}\to Z_x:\mathrm{WR}\to P_x:\text{second NR}
\to V_{x+1}:\mathrm{EL}\to U_{x+1}:\mathrm{NL}\to V_x:\mathrm{WL}
\to P_x:\mathrm{SL}\to V_{x+1}:\text{second ER}\to P_{x+1}:\mathrm{SL}.
\]

There is no intermediate visit to `P_(x+1)`. Its O2 word `SR NL NR SL SR NL` requires an `NR` visit between those `NL` and `SL` endpoints. Contradiction.

All cases are impossible, proving the theorem.

## 6. Independent computational corroboration

Run from the accompanying code directory:

```bash
python verify_m4_cap_frontier.py --output m4_cap_audit_2026-09-06.json
```

The completed audit reports:

- 49 cap assignments from the September 4 tables; 15 survive the local and lifted-time checks through `P`.
- Reconstruction from the singleton rail gives respectively 1, 4, and 15 surviving assignments after the `U`, `V`, and `P` levels, exactly matching the surviving table assignments.
- At one even `Z` lane, every possible alternating count word is enumerated: 3,390 extensions for wake bit 0 and 4,080 for wake bit 1 across the 15 caps. All 7,470 extensions have contradictions.
- In total 7,807 rejection certificates are checked: 7,805 impossible physical returns and two positive time cycles of weight `24+N`.
- Positive controls pass for the known 104-step highway and its twofold and threefold repetitions, using quotient lane counts 2, 4, 6 and periods 104, 208, 312.

The extension count domains are finite by exact nonnegative port equations, not by an arbitrary visit-multiplicity cutoff. For a horizontal cell with north-departure total `A`, west-arrival total `B`, and wake bit `D`, writing `c=WR` gives

\[
(ER,EL,WR,WL)=(A+B+D-3c,A-c,c,B-c).
\]

The verifier independently enumerates all nonnegative count boxes and alternating words, and checks equality with the engine's domain. Here `A=B=4`.

The engine may use a large numerical period to *discover* a time cycle, but it accepts an all-period rejection only after checking the cycle's exact integer coefficient and positivity for every integer `N>=1`. Physical-return certificates use no period parameter at all. The independent checker reconstructs physical coordinates and edge ordinals using its own explicit routing table. None of these checks establishes that a surviving partial word is a realizable highway.

## 7. Subsequent strengthening and what is still open

The full pure eight-wake branch remains open. Subsequent work in `m4_full_rail_exclusion_2026-09-06.md` strengthens this local result: a wake on `H-2` is required in one of the upper rail's occupied lanes. It also handles the other upper-rail masks when the lower rail is full, proving that neither extremal rail can be full. Both-partial-rail configurations remain. No percentage of completion is justified: the remaining cases are unbounded in period and separation.

The next useful target is to combine the forced nearby wake with the exact two-wakes-per-x/y-residue budget and the additive height congruence. Any further cap enumeration should track which wake configurations it actually exhausts and distinguish partial-word survivors from genuine periodic candidates.

## Source notes

- [September 4 cap-order note](m4_partial_rail_cap_order_2026-09-04.md): source normal form and earlier period bound.
- [September 4 partial-rail family](growth8_m4_partial_rail_obstruction_2026-09-04.md): the family now excluded.
- [September 3 occupancy-scope audit](rail_occupancy_scope_audit_2026-09-03.md): why partial rails must be retained in the full orbital problem.
- [September 4 pure-wake additive normal form](growth8_m4_pure_additive_normal_form_2026-09-04.md): residual global additive condition.
