# A lower fat `(1,2,3)` prefix exclusion for drift `(1,-3)`

22 September 2026

The lower fat cap with `omega_3=1`, `omega_4=0`, and
`(j,k,l)=(1,1,0)` cannot occur at any period. This is an exact finite
prefix exclusion through level ten. It does not close the other lower fat
bands or the full `(1,-3)` drift orbit.

The first five stable rows are fixed by the lower fat cap normal form:

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: SR,SL,NR,SL,NR
4: WR,WL,ER,WL,WR,EL.
```

P22 permits four wakes in one residue modulo three and two in each other
residue. The two-wake fibres have equal checker signs; the four-wake fibre
has three signs of one kind and one of the other. Wakes at levels zero and
three have opposite signs, so residue zero is the four-wake fibre. The wake
at level two is even, hence the second wake in residue two must also be
even; in particular `omega_5=0`. The exact prefix check below shows that
every surviving level-six row has `omega_6=1`. Then wakes at zero, three,
six and nine would have signs `+,-,+,-`, contrary to P22, so
`omega_9=0`. The fourth wake in residue zero must be even and can occur
no earlier than level twelve. Thus every candidate has `W>=12`, and the
level-ten extension used below is present at every possible width.

At each level the checker enumerates every nonnegative count row allowed
by the flow and wake equations and every alternating stable word with
those counts. It matches edges by ordinal, rejects words whose first
return to a physical cell skips or reverses stable order, and solves the
exact lifted clock equations

```text
tau(target)-tau(source) = 1-N*voltage,
N>=6,  tau(t,i+1)-tau(t,i)>=4.
```

Only the necessary lower bound `N>=6` is imposed. No period, width,
row-size, visit-count, or black-lifetime upper bound is used. All allowed
wake choices at levels six, seven, eight and ten are explored, with the
P22 restrictions applied at each step.

| Level | Count rows | Raw stable words | Rejected by first return | Rejected by clock | Survivors |
|---:|---:|---:|---:|---:|---:|
| 5 | 3 | 46 | 40 | 2 | 4 |
| 6 | 32 | 4,168 | 4,140 | 23 | 5 |
| 7 | 37 | 6,679 | 6,673 | 2 | 4 |
| 8 | 34 | 15,668 | 15,650 | 4 | 14 |
| 9 | 54 | 8,748 | 8,742 | 0 | 6 |
| 10 | 52 | 17,680 | 17,008 | 672 | 0 |

The level-ten row exhausts every continuation of the six level-nine
prefixes, and none satisfies both necessary tests. This proves the
stated branch impossible for every period.

Run `python code/python/verify_lower_fat123_a1_b0_110_exclusion.py` from the repository
root to reproduce the table; the checker writes `results/lower_fat123_a1_b0_110_checks_2026-09-22.json`.
It independently implements the count equations, stable-word generation,
ordinal matching, physical-return test, P22 prefix rule and lifted clock
solver, without calling the existing `p2_research` enumerator. The
separate adjacency-based `work_next_lower/probe_lower.py` yields the same
survivor counts. This is a computer-checked local exclusion, not a Lean
formalization or a complete ant trace classification.
