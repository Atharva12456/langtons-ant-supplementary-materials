# Axis growth-eight residue structure

There are two axis drift orbits at growth eight, represented by `(2,0)` and
`(4,0)`.  The signed residue theorem, including its exact-row clause for a zero
drift coordinate, determines their coarse wake structure.

## Drift `(2,0)`

A translation class is labelled by `(x mod 2,y)`, so a fixed row contains at
most two odd classes.  The exact-row signed sum is `0 (mod 4)`.  A row containing
one odd class has signed sum `1` or `-1` and is impossible.  A row containing two
must contain both `x` residues; their checker signs are opposite.

There are eight odd classes, hence exactly four wake-bearing rows. Every such
row is checker-balanced and both `x` residues contain four classes.  P22 says that the
signed sum in either residue is `2 (mod 4)`, so the parities of the four rows split
three to one.  In particular, exactly four odd classes have even checker parity.

The kinematic congruence

```text
N/2 + a + b + A = 0  (mod 4)
```

now gives `N=4 (mod 8)`.  The two-column lifted-rank identity supplies an
independent check: P3 makes `K=#L=(N-8)/2` even, while the kinematic side is
`K=1+N/4`, again forcing `N/4` odd.

## Drift `(4,0)`

P22 is saturated: each of the four `x` residues contains exactly two odd classes,
and the two in one residue have the same checker sign.  A fixed row contains at
most one class from each residue.  Its exact signed sum is zero modulo four, so a
nonempty row has either two classes of opposite checker sign or all four residues.
In the four-class case the two even and two odd `x` residues make the row
checker-balanced automatically.  Thus every occupied row is balanced and again
`A=4` globally.

With `(a,b)=(4,0)`, the same kinematic congruence gives

```text
N = 0  (mod 8).
```

The coordinate-fibre visit law adds unsigned information to both rows. At
`(2,0)`, each `x mod 2` residue and each of the four wake-bearing exact rows has
visit count two modulo four. At `(4,0)`, every `x mod 4` residue has visit count
zero modulo four, while the visit count of an exact row is congruent to the
number of odd classes on that row. These conditions are compatible with the
classifications above.

At `(2,0)` there is also an exact chronological reduction in
`axis_two_exit_cycles_2026-09-03.md`.  Every last-exit cycle has four vertices
on two adjacent rows and winds once forward; every first-departure cycle has
the same size and winds once backward.  One period decomposes into a last-exit
cycle and four actual closed return excursions.  The note also proves exact
lifetime identities at the trace extremes and restricts which extremes a
last-exit cycle can touch.

The first visits give a further all-period reduction.  There is necessarily
a row whose first vertical-arrival port is `SR` and whose first horizontal-
arrival port is `ER`.  Two coupled closed returns at this row have positive
lengths summing to `N`.  Their signed changes sum to the period's change,
with a correction of zero or two at one root class.  The same note proves
a six-physical-cell bound for heading-reversing returns with unchanged root
colour, but exhibits the inherited-colour cancellation that prevents counting
these cells directly as wake.

Quarter turns cover the other axis directions.  Neither orbit is excluded.
The two-class-per-row argument and the two-column rank identity cannot simply
be reused for `(4,0)`, whose quotient has four residue columns.
