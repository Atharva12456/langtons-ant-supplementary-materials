# Open lower fat `(1,2,3)` band: `a=b=1`, `(j,k,l)=(1,1,0)`

For drift `(1,-3)`, the first five stable rows are

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: SR,SL,NR,SL,NR
4: WR,WL,ER,WL,WR,EL,WR.
```

`code/python/probe_lower_fat123_a1_b1_110.py` exhausts the necessary prefix conditions through level nine. It
derives every port count row from incoming/outgoing flow and the binary wake,
enumerates every right/left alternating stable word satisfying forced
zero-copy return adjacency, checks explicitly witnessed physical first
returns, then solves the exact lifted clock constraints. The clock imposes
`N >= max(6, number of represented quotient events)` and successive
same-cell gaps of at least four. No upper bound on the period, width, row
length or black lifetime is imposed.

P22 forces wake indicators `omega5=omega7=0` and rules out simultaneous
`omega6=omega9=1`. The code explores both values of `omega6` and `omega8`,
and both permitted values of `omega9`. The fourth wake in the residue-zero
fibre cannot occur before level twelve, so every complete candidate has a
level-nine row.

| Level | Count rows | Boundary-adjacent words | Wrong return | Clock rejection | Survivors |
|---:|---:|---:|---:|---:|---:|
| 5 | 3 | 10 | 0 | 2 | 8 |
| 6 | 60 | 113 | 41 | 47 | 25 |
| 7 | 107 | 276 | 212 | 37 | 27 |
| 8 | 286 | 596 | 306 | 140 | 150 |
| 9 | 1,012 | 740 | 596 | 40 | 104 |

The 104 survivors have wake triples `(omega6,omega8,omega9)` distributed as
`(1,0,0):40`, `(1,1,0):48`, `(0,1,0):6`, `(0,0,0):4`, `(0,1,1):4`, and
`(0,0,1):2`. They are necessary-condition prefixes, not realised ant traces.
This branch **remains open**. An attempted level-ten expansion was stopped
without a complete result and supplies no exclusion claim.

Run `python code/python/probe_lower_fat123_a1_b1_110.py` from the repository root. It writes
`results/lower_fat123_a1_b1_110_prefix_2026-09-22.json`. The calculation is a
computer-checked local reduction, not a Lean formalization.
