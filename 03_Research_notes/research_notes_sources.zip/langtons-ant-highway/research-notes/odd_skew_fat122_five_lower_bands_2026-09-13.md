# Five possible lower `(1,2,2)` bands through level six

For drift `(1,-3)`, every lower cap of profile `(1,2,2)` has one of
the five stable bands described below. No restriction on the period,
growth, upper cap, or later wake positions is used.

Put `b=omega_4`, `c=omega_5`, and `e=omega_6`. The common rows are

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,[WR]^b
5: SR,SL,NR,NL,NR,(SL,NR)^b,[SL]^(1-c).
```

The level-six word is fixed by the wake indicators:

| `(b,c)` | Allowed `e` | Level six |
|---|---|---|
| `(0,1)` | `1` | `ER,EL,ER` |
| `(1,0)` | `0` or `1` | `ER,EL,ER,WL,WR,WL,[WR]^e` |
| `(1,1)` | `0` or `1` | `ER,EL,ER,WL,[WR]^e` |

The count of five includes the separate choices of `e` in the last
two rows. These bands are necessary conditions, not realizations.
The first row is the previously studied lower `0,5,6,8` branch.
The later note `odd_skew_fat122_adjacent_wakes_force_six_2026-09-13.md`
excludes `(b,c,e)=(1,1,0)`, and
`odd_skew_fat122_four_only_forces_six_2026-09-13.md` excludes
`(1,0,0)`. The later notes
`odd_skew_fat122_four_six_band_exclusion_2026-09-14.md` and
`odd_skew_fat122_adjacent_wake_band_exclusion_2026-09-14.md`
exclude `(1,0,1)` and `(1,1,1)` respectively. Only the first
band remains for this lower cap profile; the entire drift
orbit is still open.

## The last east arrival cannot be a late south departure

Use `t=3x+y` and stable lifted times with

```text
tau(target)=tau(source)+1-N*lambda,
lambda(E)=1,       lambda(W)=-1,       lambda(N)=lambda(S)=0.
```

The count and last-east theorems in
`odd_skew_fat122_four_wake_single_er_2026-09-13.md` give

```text
(ER,EL,WR,WL)=(2,1,b-c+e,1+b-c)
```

on level six, and its last east arrival is `ER`. Denote that event
by `R`. The lower early-wake theorem rules out `b=c=0`.

For `b=0`, the same earlier results already force `c=e=1`, with
level-six word `ER,EL,ER` and the stated level-five word. Hence
assume `b=1` for the rest of the argument.

The two level-five possibilities before this reduction are

```text
A: SR,SL,NR,NL,NR,SL,NR,[SL]^(1-c),
B: NR,SL,SR,NL,NR,SL,NR,[SL]^(1-c).
```

Let `W1,...,W5` be the west departures on level seven, feeding the
level-four west arrivals `WR,WL,WL,WR,WR`. The forced path

```text
W3 -> 4:second WL -> 3:last SL -> 6:R
```

has length three and zero longitudinal voltage. Thus

```text
tau(R)=tau(W3)+3.                                      (1)
```

Label the east arrivals on level eight by `Ei`. For either level-five
word, `E3,E4` are supplied by its second `NR` and second `SL`.
The seven-step path

```text
W4 -> 4:second WR -> 5:NL -> 2:WL -> 1:SL
   -> 4:EL -> 5:second NR -> E3
```

has zero longitudinal voltage. Since `W4` follows `W3`, it gives

```text
tau(E3)=tau(W4)+7 > tau(W3)+7.                          (2)
```

If `R` were the third south departure on level six, it would feed
`5:SL2` in either word. Consequently

```text
tau(E4)=tau(R)+2-N=tau(W3)+5-N.
```

This contradicts (2) and `E3<E4` in stable order. Therefore `R`
cannot be the third south departure.

A fourth south departure exists only when `c=0`. It feeds `5:SL3`,
which supplies `E6`. The preceding east arrival `E5` is supplied by
the last `NR` on level five. Its three-step path from `W5` gives

```text
tau(E5)=tau(W5)+3 > tau(W3)+3.
```

If `R` were that fourth south departure, (1) would instead give

```text
tau(E6)=tau(W3)+5-N < tau(W3)+3,
```

using `N>=6`. This contradicts `E5<E6`.

There is an earlier `ER` on level six, so `R` is not the first
south departure either. It must be the second.

## The level-five order and the initial double square

In word B the second south arrival is `SR`. If the second south
departure `R` fed it, the four-step return

```text
6:R -> 5:SR -> 2:WR -> 3:NR -> second east arrival on 6
```

would end before its source, which is the third east arrival.
Thus word B is impossible: the level-five word is A.

The second south departure `R` now feeds `5:SL1`. The earlier `ER`
is necessarily the first south departure, feeding `5:SR`. Its
four-step return ends at the second east arrival, which must be
`EL`. The first `ER` and this `EL` are consecutive stable events.

No event can precede the first `ER`. It is both the first east
arrival and the first south departure, so any preceding event would
be `WR`; R-first alternation would then require a left turn before
this `ER`, but neither `EL` nor `WL` is available there. Nor can a
`WR` occur between the consecutive `ER,EL` pair and `R`: another
left turn would be needed, and a `WL` would create a south departure
before the second one `R`.

Hence the level-six word starts exactly

```text
ER,EL,ER.
```

All remaining ports are west arrivals. Alternation and the count row
now force the tails in the statement. This proves the five-band
classification.

The two gaps in this initial triple both equal four. The first is
the square through `5:SR,2:WR,3:NR`. For the second, the twelve-step
return from `7:W2` through the lower cap ends at its first north
arrival, fed by `6:EL`. Its source must be `SR`, and its consecutive
target is `NL=W3`. Therefore

```text
6:EL -> 7:W3=NL -> 4:second WL -> 3:last SL -> 6:last ER
```

is another four-step first same-cell return. If the first `ER` has
time `T`, the triple occurs at times `T,T+4,T+8`.

## One further forced return when level four is wake

For `b=1`, the fourth west departure `W4` on level seven is `SR`.
To prove this, suppose it were `NL`. The first north arrival on
level seven is already `W3=NL`, supplied by `6:EL`. Thus `W4`
would have to be supplied by a `WR` event `X` on level six.

Every such `X` follows the first `WL`, denoted `J`, in the tails
just proved. The path from `W4` to `E3` then gives

```text
tau(E3)=tau(X)+8.
```

But `J`, the third south departure on level six, feeds `5:SL2`,
so `tau(E4)=tau(J)+2-N<tau(X)`. This contradicts `E3<E4`.
If no `WR` exists in the level-six tail, `W4=NL` is already
impossible by the north-arrival count. Hence `W4=SR` in every case.

Its seven-step path to `E3` forces `E3=ER`. Otherwise, the south
predecessor of `W4` would have an eight-step first return to
`E3=EL`, with source `E2=ER`. The path from `W1=SR` through
`4:first WR,5:first NR` to `E2` would then complete a four-step
same-cell return to `W4=SR`, with two right-turn endpoints.

The south step from `E3=ER` returns to the immediate stable
successor of `W4`, which is therefore `SL`. Thus `W4=SR` is
immediately followed by `SL`, independently of the later wakes.

All inequalities containing `-N` in this note are lower-cap
inequalities. Their signs reverse in upper inward coordinates.
The five-band classification and the last paragraph's forced
departure are not asserted for upper caps.
