# One Family B lower row-ten word has no continuation

23 September 2026. This is an all-period exclusion of **one word**, not of
Family B or the `(1,-3)` drift orbit.

Take lower row eight B from the proved two-word normal form and the forced
non-wake row nine:

```text
8:  WR EL WR WL ER WL WR WL ER
9:  NR SL NR SL NR SL NR SL
10: ER EL WR WL WR WL WR WL
```

The row-ten word is one of the seventeen integer-clock-feasible B words in
`family_b_lower_level10_restriction_2026-09-22.md`. Family B has no wake at
row eleven. Directional balance and R-first alternation allow four possible
row-eleven count rows:

| NR | NL | SR | SL |
|---:|---:|---:|---:|
| 4 | 0 | 6 | 10 |
| 3 | 1 | 5 | 7 |
| 2 | 2 | 4 | 4 |
| 1 | 3 | 3 | 1 |

Write `W6` for the sixth row-eleven west departure in stable order and `N1`
for its first north arrival. Ordinal successor matching fixes the following
path, independently of the still unknown row-eleven word:

```text
11:W6 -> 8:WL8 -> 7:SR5 -> 4:WR5 -> 5:NL4 -> 2:WL2
      -> 1:SL2 -> 4:EL6 -> 5:NR5 -> 8:ER9 -> 7:SL6
      -> 10:EL2 -> 11:N1.
```

Here `WL8` means the eighth event in row eight, not the eighth WL port.
The path has twelve steps and net horizontal voltage zero. It does not visit
row eleven earlier, so `N1` is the first same-physical-cell return after
`W6`. The two visits must therefore be consecutive in stable row-eleven
order.

In the first count row, all six west departures before `N1` have to be
`SR`. Thus `W6` is a right turn, while `N1` is `NR`, also a right turn.
They cannot be consecutive in an alternating word. In each of the other
three count rows, at most five `SR` ports are available; the sixth west
departure requires an `NL` port, which is itself a north arrival. Thus `N1`
is no later than `W6`, again contradicting the forced first return.

The standalone `code/python/verify_family_b_row11_return.py` checks the fixed path,
its zero voltage, all four count rows, and all 899 R-first alternating
count-compatible words against physical first returns; none survives. The
generic adjacency checker in `work_family_b_next/lower11_physical.py` independently finds zero.
The other
24 previously retained row-ten words have row-eleven continuations. Exact
lifted clocks leave 189 such prefixes after row-eight A and 376 after
row-eight B; all 565 remain feasible with `N>=1,000,000` and neither
period residue `N=2,6 (mod 8)` removes any. Those computations show why this
local argument does not presently extend to a Family B exclusion.
