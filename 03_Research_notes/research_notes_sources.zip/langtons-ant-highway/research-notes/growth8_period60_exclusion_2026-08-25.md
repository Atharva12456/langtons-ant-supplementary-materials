# Growth eight does not occur at period 60

## Result

There is no finite-support periodic highway with ant period `N=60` and growth
`g=8`.

The search covered all 2,048 normalized length-12 prefix ranks exactly once.
It combined four disjoint sets of completed shards:

```text
original engine       57 eight-rank shards      456 ranks
endpoint reuse 0     116 one-rank shards        116 ranks
endpoint reuse 1     109 one-rank shards        109 ranks
endpoint engine    1,367 one-rank shards      1,367 ranks
total              1,649 shards               2,048 ranks
```

No shard used a node cap. The aggregate counters are

```text
search nodes              594,889,763,705
endpoint prunes           107,827,678,241
growth prunes              96,145,468,458
deficit checks              4,203,887,773
deficit prunes              4,203,344,162
deficit endpoints tested   12,834,070,625
residue checks             18,848,141,274
residue prunes             16,975,250,784
P3 checks                   1,872,890,490
accepted words                          0
aggregate core time           345,889.321 s
```

The endpoint engine uses the eight period-60 endpoints allowed by heading
reset, growth eight, P16, and parity. Its suffix table records exact simultaneous
reachability in heading, displacement, and growth. An independent brute-force
enumeration checked that table for every suffix of length at most ten. The
endpoint-specific deficit test retains a prefix whenever at least one exact
suffix can reach an allowed endpoint without violating cyclic-minimum
normalization. Leaves passing the residue condition are sent to the same exact
P3 test used by the original engine.

## Certificate audit

The raw archive is `records/g8_p60_hybrid_shards`. Its four subdirectories
contain 1,649 shard files and four manifests. The hybrid auditor checked the
engine-specific deficit settings and endpoint declaration, reconstructed every
prefix, verified exact rank coverage and all per-rank counter sums, rejected
incomplete or capped shards, and compared every hit list. A second audit from
the archive matched every shard digest stored in the certificate.

```text
results/growth8_period60_exclusion.json
bbf3c624f679d654c6994e80d0fe46c34f7a142bd99b7779c54c401e30aa606c
```

The principal source digests are

```text
code/java/PositiveGrowthResidueSearch.java
315c18bd3f7749750fc8c618d5b3f464756d2ddd64bda5dd9be4cbb1f33e9c23

tmp/PositiveGrowthP60EndpointSearch.java
ea006745d901c8a67a0156d4d28021a379456f18323b0b08455519bfcc717444

tmp/run_p60_endpoint_hybrid.py
a218c294e8e954a014f0c3c27941f51f946e285328ca6a4812dd8284982a7cae

tmp/audit_hybrid_target_growth_shards.py
08e794e6d9547e0cbfcaecb1cbe302de58cc7486c9669f53cc485d84bad027b7
```

This completes the finite exclusion through period 60. Period 62 is the first
period not covered by the exact word searches. The all-period classification is
unchanged: all ten drift orbits remain open. At `(4,-4)`, only the full-rail and
mixed-checker subfamilies are excluded analytically; the pure partial-rail branch
remains.
