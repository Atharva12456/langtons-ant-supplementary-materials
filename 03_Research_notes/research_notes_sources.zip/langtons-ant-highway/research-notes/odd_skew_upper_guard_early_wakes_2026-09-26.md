# Three upper-guard wake prefixes are impossible at every period

For growth eight and drift `(1,-3)`, orient the upper guard inward. Its fixed
rows are `0:WR`, `1:NR`, `2:WR`, and inward offsets `0,1,2` are wakes. Three
additional wake prefixes are impossible:

1. Offset `3` is wake and offset `4` is quiet.
2. Offsets `3,4` are quiet, offset `5` is wake, and offsets `6,7` are quiet.
3. Offsets `3,4,5` are quiet, and offsets `6,7` are wakes.

The proof is a finite prefix exhaustion, with no assumption about any later
offset or the period. At each row, directional flow and the binary wake excess
give every possible port-count vector. The checker enumerates **all**
right/left alternating multiset words directly, without an adjacency filter
or a solver. It removes a word when an explicit finite successor path
returns to the same cell and horizontal copy before the next listed stable
visit. Such a return must be the next visit in the stable event order, so a
different return index is impossible. Every path stays inside the built rows;
no repeated quotient vertex is treated as a physical return. Pattern 3 also
removes one row-five word by the explicit upper-clock identity below.

| Prefix | Inward row | Count vectors | Raw words | Wrong first returns | Survivors |
|---|---:|---:|---:|---:|---:|
| wake 3, quiet 4 | 3 | 1 | 2 | 0 | 2 |
| | 4 | 4 | 8 | 8 | 0 |
| quiet 3,4; wake 5; quiet 6,7 | 3 | 1 | 2 | 0 | 2 |
| | 4 | 4 | 12 | 11 | 1 |
| | 5 | 1 | 2 | 0 | 2 |
| | 6 | 4 | 38 | 34 | 4 |
| | 7 | 12 | 376 | 376 | 0 |
| quiet 3,4,5; wake 6,7 | 3 | 1 | 2 | 0 | 2 |
| | 4 | 4 | 12 | 11 | 1 |
| | 5 | 1 | 2 | 0 | 1 after one clock rejection |
| | 6 | 3 | 56 | 50 | 6 |
| | 7 | 16 | 992 | 992 | 0 |

For pattern 3, the one row-five word `SR SL NR SL` has the verified upper
clock identity

```text
[tau(3,3)-tau(3,1)] + [tau(5,3)-tau(5,1)]
    + [tau(4,2)-tau(4,1)] = 2-N.
```

All positions here are one-based. Strict integer row order makes the left
side at least `2+2+1=5`, so it would require `N<=-3`. The checker verifies
the three path links that yield this identity; the same hand certificate was
proved in `odd_skew_upper_guard_hand_certificate_2026-09-24.md` independently
of later wake values. No bound on positive `N` is needed.

Run `python code/python/verify_upper_guard_early_wakes_20260926.py` from the
repository root. This standard-library checker independently implements the
flow equations, raw word generation, ordinal successors, and finite return
test. It asserts the counts above and writes
`results/upper_guard_early_wakes_2026-09-26.json`, including a complete
sample return path for each terminal row. The only clock check is the
displayed hand identity for pattern 3.

## Consequence for lower fat `(0,0,111)` and upper guard

The earlier P22/rank/moment classification leaves nine all-width static
families after the upper near-wake lemma. Two entire families now disappear.
For `W=6m+2`, they have the free wakes shown below in addition to
`{0,2,W-2,W-1,W}`. Their index restrictions are `1<=c<a<=m-1` and `a-c` odd.

| Former family | Free wakes | Forced upper prefix |
|---|---|---|
| `r2_fibre0_odd_top` | `6c+1, 6a, W-5` | quiet 3,4; wake 5; quiet 6,7 |
| `r2_fibre2_odd_top` | `6c+1, 6a+2, W-3` | wake 3; quiet 4 |

In the first row, `6a<=W-8` and `6c+1<=W-13`, so no other wake occupies
inward offsets `3,4,6,7`. In the second, `6a+2<=W-6` and
`6c+1<=W-13`, so offset `4` is quiet. This is an all-width deduction from
the two local prefix exclusions, not a finite-width extrapolation.

Pattern 3 also removes an all-width *subfamily* of
`r4_odd_pair_singleton_near`. In that family `W=6m+4` and the free wakes
are `{6b+3,6c+3,W-6}`, with `b<c<=m-1` and `b+c` odd. When `c=m-1`, the
second wake is `W-7`, whereas `6b+3<=W-13`. Hence inward offsets `3,4,5`
are quiet and `6,7` are wakes. Cases with `c<m-1` are not removed by this
pattern.

Thus seven of the nine classified parameter families remain. At `W=20`, the
only two static placements were members of the eliminated families:
`{0,2,7,12,15,18,19,20}` and `{0,2,7,14,17,18,19,20}`. This cap pair now
requires **`W>=22`**. At `W=22`, the static classification initially left
two placements: `{0,2,10,12,18,20,21,22}` and
`{0,2,9,15,16,20,21,22}`. The latter has upper inward wakes
`0,1,2,6,7,13,20,22`, so pattern 3 excludes it. Only
`{0,2,10,12,18,20,21,22}` remains at width 22. The seven-family all-width
statement still counts portions of families at larger widths that the third
local pattern can remove; this note does not claim a complete
reclassification of those portions. The cap pair and the full drift orbit
remain open.
