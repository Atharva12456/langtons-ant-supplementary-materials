# Exact excursions and the odd-skew domino transfer

This note gives an exact algebraic description of a quarter-turn lattice
excursion and applies same-cell return arguments at odd-skew caps.  The
`(1,3)` profile `(1,2,2)` admits a local domino transfer and remains open.  For
the lower `(1,1,0)` cap at drift `(1,-3)`, the return arguments and P22 prove
that level six or level seven is wake at growth eight, in addition to the
known wake levels `0,1,4`.  This excludes the lower-missing/upper-guard cap
pair, but not the drift orbit.

## An exact flow description of an excursion

Write the four directions in clockwise order as

```text
E, S, W, N.
```

A direction word of length `s` is a sequence

```text
q_0,q_1,...,q_(s-1)
```

in which every transition is a right or left quarter-turn.  For each direction
`q`, let `r_q` count transitions from `q` to its right successor and let `l_q`
count transitions from `q` to its left successor.  Put `a=q_0` and
`b=q_(s-1)`.

The following conditions characterize the possible direction words exactly.

1. All eight transition counts are nonnegative integers, and their sum is
   `s-1`.
2. The prescribed turn balance is

   ```text
   sum_q (r_q-l_q).
   ```

3. In the directed graph on the four directions, the transition counts have
   degree imbalance `+1` at `a`, degree imbalance `-1` at `b`, and zero
   imbalance elsewhere.  When `a=b`, every degree is balanced.
4. Every used direction lies in the same component of the underlying
   undirected support as `a`.
5. If

   ```text
   n_q = out(q) + [q=b],
   ```

   then the displacement is `sum_q n_q v_q`, where `v_q` is the unit vector in
   direction `q`.

Necessity follows by counting the transitions of a direction word.  For
sufficiency, regard the transition counts as a directed multigraph.  If
`a!=b`, add one artificial edge from `b` to `a`.  The resulting multigraph is
balanced and its used vertices are weakly connected.  A balanced weakly
connected directed multigraph is strongly connected on its used edges: in the
condensation graph, a source component has no incoming edge, and degree balance
then gives it no outgoing edge.  Weak connectivity leaves only one component.
The directed Euler theorem supplies a circuit.  Removing the artificial edge
gives a trail from `a` to `b`.  If `a=b`, the same argument applies without the
extra edge.  Reading the vertices of the trail gives the required direction
word, and condition 5 gives its displacement.

This theorem works at arbitrary excursion length.  It does not assert that the
excursion stays inside a transverse strip, and it does not impose alternation
between separate visits to the same physical cell.  An infeasible flow is a
valid local obstruction; a feasible flow is not a highway certificate.

## Consecutive visits of either colour

The completed-lifetime argument in the detailed reference's "Collision chains"
section treats an `R` visit followed by the next `L` visit to the same physical
cell. Its unsigned incidence conclusion also holds in the other direction.

Let `r<l` be any two consecutive visits to a cell `z`.  The turns at the two
visits are opposite.  The cell `z` occurs once in the departure interval
`[r,l)`.  The two endpoint ant states are at the same cell and have the same
horizontal-or-vertical heading type. The two-endpoint collision-chain parity
theorem therefore gives

```text
partial(B_r symmetric_difference B_l)=0.
```

The symmetric difference contains `z`, so its row-column incidence component
through `z` contains a cycle.  It has at least four cells.  This applies to a
black `R`-to-`L` lifetime and to a white `L`-to-`R` lifetime.  The extension is
only the unsigned completed-lifetime conclusion; signed endpoint conventions must still be chosen
according to the aligned directed poses.

## The `(1,2,2)` cap chronology

Take drift `d=(1,3)` and transverse coordinate

```text
t=3x-y.
```

At the lower cap, name the level-zero singleton `A`, the level-one pair `B`,
and the level-two pair `C`.  In lifted physical time, normalize

```text
B_R=-1,  A=0,  B_L=u,  C_L=u+1.
```

If `C_R=v`, stable order gives exactly two possibilities.  Either `v<-1`, in
which case the `C` lifetime contains the `B` lifetime, or
`-1<v<u`, in which case the two lifetimes interlace.  There is no integer time
strictly between `B_L=u` and `C_L=u+1`.

The forced path leaving `B_R` is

```text
B_R -> A_R -> P_R -> Q,
```

where `P` is the unique level-three `ER` event and `Q` is the level-four corner
cell.  The predecessor of `B_L` is the same physical cell `Q`.

If the displayed visit to `Q` is `R`, the path returns immediately to `B_L`.
The earlier visit to `Q` is then `L`, and the central chronology is

```text
Q_L -> B_R -> A_R -> P_R -> Q_R -> B_L -> C_L.
```

With

```text
A=(0,0), B=(0,-1), C=(0,-2),
P=(1,0), Q=(1,-1), D=(1,-2),
```

their transverse levels are `0,1,2,3,4,5`, respectively.  The immediate-return
branch puts `C_R` before `B_R`, so the `C` lifetime contains both visits to `B`
and both visits to `Q`.  Those cells cancel from its odd-visit discrepancy.  In
the sharp completion the remaining signed rectangle is

```text
-C -D +A +P.
```

Every exact row and column has signed sum zero.

## Why the local bridge does not iterate

The level-four `Q` bridge is enclosed by consecutive visits to `D` at level
five.  It is tempting to declare this a strictly inward successor and repeat
the argument.  The following compatible completion disproves that step:

```text
D_L -> Q_L -> B_R -> A_R -> P_R -> Q_R -> B_L -> C_L -> D_R.
```

Between the two directed poses at `D`, the turn word is

```text
LLRRRRLL.
```

Starting at `D` with eastward arrival, the successive moves are

```text
N,W,N,E,S,W,S,E.
```

The displacement and turn balance are zero, and the eastward arrival at `D` is
restored.  The repeated cells `B,Q` cancel.  The four odd cells are exactly
`C,D,A,P`, with signs `-,-,+,+`.

Geometrically, the block is the clockwise all-`R` square on `B,A,P,Q` together
with the adjacent counterclockwise all-`L` square on `C,D,Q,B`.  Its scalar
rotation is zero: it transfers one unit-square winding from the outer face to
the next face instead of forcing a new wake.

Adding white lifetimes does not strengthen this sharp local system.  The black
`B_R`-to-`B_L` lifetime and the white `Q_L`-to-`Q_R` lifetime both have odd
support `{A,B,P,Q}`.  When `C_R` goes directly to the displayed `D_L`, the black
`C_R`-to-`C_L` lifetime and the white `D_L`-to-`D_R` lifetime both have support
`{A,C,D,P}`.  Thus the two new white rows duplicate the two black rows over
`F_2`; they do not recover a missing rank direction at the cap.

This duplication is not an accident of the six named cells.  In a stable odd
class

```text
R_1,L_1,R_2,L_2,...,R_k,L_k,R_(k+1),
```

the black intervals are `(R_i,L_i)` and the white intervals are
`(L_i,R_(i+1))`.  Their endpoint pairs form one open path, not a cycle.  Over
`F_2`, the sum of all its interval boundaries is

```text
R_1 + R_(k+1).
```

For an even class the corresponding boundary is `R_1+L_k`.  White pairing
therefore transports the unmatched defect to the first or terminal event; it
does not fill the black wake cycle.  A white version of the touch-graph theorem
is valid only after building a new touch graph with these seed and terminal
switches.  Its boundary size is not controlled by growth.

There is also a small graph-theoretic obstruction to a universal two-colour
lifting claim.  Take boundary vertices `H_1,H_2,V_1,V_2`, wake edges

```text
u_1=H_1V_1, u_2=H_2V_1, u_3=H_2V_2, u_4=H_1V_2,
```

and one ordinary edge `a=H_1V_2`.  The black row
`a+u_1+u_2+u_3` is a cycle, while the wake cycle
`u_1+u_2+u_3+u_4` is independent.  The alternating class system

```text
A_R,U1_R,U2_R,U3_R,A_L,U4_R
```

has no white interval at all, so adding every white row leaves the missing wake
direction unchanged.  This example concerns the algebra of the touch graph; it
is not asserted to be a Langton trace.

The same paired `C` structure occurs at the start of profile `(1,2,3)`.  Its
extra level-two `R` supplies another endpoint, but it does not invalidate this
zero-voltage block.

The block cannot be forbidden as a turn subword.  In the normalized standard
period-104 highway recorded in `results/standard_highway.json`, the cyclic word
contains `LLRRRRLL` at zero-based phases `7,13,82,102`.  Any exclusion must use
the growth-eight wake budget and the cap placement, not the eight letters alone.

The present local tools therefore do not close profiles `(1,2,2)` or `(1,2,3)`.
A valid next lemma has to retain where the two opposite
unit-square windings lie.  Equivalently, it must prove that a chain of these
domino transfers cannot be spliced into the single voltage-one Euler tour
without ending at further wake classes or violating a stable class order.  No
such global splice lemma has been proved here.

## A last-exit voltage lemma

There is a chronological constraint which is absent from the row spaces above.
Let a periodic trace have period `N` and primitive drift `d`.  Choose one cell
`c_v` in each visited translation class `v`.  If a phase occurrence in that
class is at `c_v+a_i d`, give it lifted time

```text
tau_i = i-N a_i.
```

The copy at the physical cell `c_v+n d` then occurs at actual time
`nN+tau_i`.  Let `tau_v` be the largest lifted time among the occurrences of
class `v`, and let the outgoing step from this last occurrence enter class
`f(v)`.  Define the integer edge voltage `lambda_v` by

```text
c_v + outgoing_step = c_(f(v)) + lambda_v d.
```

The arrival occurs one step after the last visit to the source.  It is one of
the visits to the target, whose last visit can only be later.  Therefore

```text
tau_(f(v)) + N lambda_v >= tau_v + 1.                 (3)
```

Every vertex has one selected outgoing edge, so each component of the finite
quotient contains a directed cycle.  Summing (3) around a cycle `C` gives

```text
N sum_(v in C) lambda_v >= |C|.
```

In particular, every last-exit cycle has strictly positive integral voltage.
Equivalently, the periodic lift of the selected last exits has no directed
cycle in the plane; every quotient cycle advances in the drift direction.

The cylinder argument in `cylinder_exit_cycles_2026-09-03.md` strengthens this
to voltage exactly one.  It also recovers one complete period as the selected
cycle edges interspersed with actual zero-displacement return excursions.
Every such excursion has length divisible by four and strictly less than the
period.  This keeps the omitted visit order available for a global argument.

The first entries give the reverse statement.  Let `epsilon_v` be the smallest
lifted visit time, and write the physical predecessor of `c_v+n d` as
`c_(p(v))+(n+mu_v)d`.  Its first visit is no later than this predecessor event,
so

```text
epsilon_(p(v)) + N mu_v <= epsilon_v - 1.
```

Every cycle of the reverse predecessor map has strictly negative total
`mu`-voltage.  These two inequalities use chronological extremality, rather
than only alternation or aggregate port flow.

For `d=(1,3)` and transverse level `t=3x-y`, take `c_t=(0,-t)`.  East and west
edges have voltages `1,-1`; north and south edges have voltage zero.  Thus every
last-exit cycle has more east than west edges.  The forced lower-cap final exits
in both profiles under study are

```text
0 -> 3,          1 -> 2 -> 5.
```

The arrows `0->3` and `2->5` have voltage one; `1->2` has voltage zero.  The
next exit from level three is not fixed.  In the odd level-three branch of the
sharp `(1,2,2)` completion, the stable port order is `ER,WL,WR`, so the final
`WR` event exits north and `f(3)=2`.  The even branch ends in `WL` and has
`f(3)=4`.  The aggregate port table for profile `(1,2,3)` also permits both
inward endings; no global realisability claim is intended here.  This
distinction is easy to miss because the predecessor of `C_R` lies at the
translated cell `P-d`: its physical time in the displayed block is earlier,
but its lifted time in the class represented by `P` is one period later.

The displayed arrows are a genuine new restriction on a global splice.
Positivity alone does not show where their orbits merge or which quotient
cycles they enter, so it is not an exclusion of either cap profile.

## Why the fifth and sixth missing-cap levels are not local consequences

For `d=(1,-3)`, use `t=3x+y` and consider the lower `(1,1,0)` cap.  The
proved port rows through level four are

```text
0: WR
1: NR
2: empty
3: SR,SL
4: WR,WL,ER
```

The stable words on levels three and four are `RL` and `RLR`.  On level five,
write the ports as `(NR,NL,SR,SL)`.  The level-four `WR` supplies one north
arrival, while the empty level two forbids west departures.  Hence

```text
NR=1,       NL=SR=0,       SL in {0,1}.
```

Thus level five can be either the wake row `NR` or the even row `NR,SL`.
In the even case, level six has one east arrival from the level-three `SL`
and one south departure to the level-five `SL`.  The even port row

```text
(ER,EL,WR,WL)=(0,1,2,1)
```

has stable order `WR,EL,WR,WL` and satisfies every aggregate equation.

The even/even branch also survives the cap chronology.  The following data
give one exact lifted ordering for the named classes.  Take bookkeeping period
`N=202`, representatives `c_t=(0,t)`, and write an occurrence as `(phase,x)`,
meaning the physical cell `c_t+x(1,-3)`.  Its lifted time is `phase-202x`.

```text
t=0: WR (22,-1)
t=1: NR (23,-1)
t=3: SR (21,0), SL (25,0)
t=4: WR (102,1), WL (20,0), ER (24,0)
t=5: NR (103,1), SL (61,0)
t=6: WR (180,2), EL (26,1), WR (142,1), WL (60,0)
```

Sorting by lifted time gives `R`, `R`, `RL`, `RLR`, `RL`, and `RLRL` on
the six occupied levels.  The phases `20` through `26` form the forced block

```text
(0,4) WL -> (0,3) SR -> (-1,3) WR -> (-1,4) NR
         -> (0,4) ER -> (0,3) SL -> (1,3) EL.
```

There are also the required immediate edges from the level-six `WL` at phase
`60` to the level-five `SL` at phase `61`, and from the level-four `WR` at
phase `102` to the level-five `NR` at phase `103`.  At a fixed physical copy,
the visits occur in the following orders:

```text
t=3:  21 R, 25 L
t=4: -100 R, 20 L, 24 R
t=5:  -99 R, 61 L
t=6: -224 R, -176 L, -60 R, 60 L.
```

The named cells therefore obey ordinary alternation as well as stable P3
order.  Here are literal direction words for the five open gaps; the last gap
ends at the translate of phase `20` in the next period.

```text
26 ->  60: NENENENENENENENENWNWSWSWSWSWSWSWSW
61 -> 102: ENENENENENENENENESESESWSWSWSWSWSWSWSWSWSW
103 -> 142: ENENENENENENENENENENWSWSWSWSWSWSWSWSWSW
142 -> 180: NENENENENENENENESESESWSWSWSWSWSWSWSWSW
180 -> 222: NENENENENENENENENENENWSWSWSWSWSWSWSWSWSWSW
```

Successive letters are perpendicular, so each word is a quarter-turn walk.
Every proper intermediate position has level at least seven.  No further cap
event is forced.  These fillers need not obey P3 on their own translation
classes, so this construction is not a periodic highway.  Its point is
narrower.  Even when exact motion and same-cell chronology are added to local
port flow, neither level five nor level six is forced to be wake.  Ruling out
this branch requires the stable first-turn condition in the inward excursions,
or an equivalent global splice or lifetime invariant.

## Orientation of first-departure cycles

There is a useful global restriction on those inward excursions.  Let
`epsilon_v` be the first lifted visit time of a class `v`, and let `g(v)` be
the class reached by the edge leaving that visit.  If the edge voltage is
`lambda_v`, its arrival has lifted time

```text
epsilon_v+1-N lambda_v.
```

The first visit to the target is no later, so

```text
epsilon_(g(v))+N lambda_v <= epsilon_v+1.             (4)
```

For a `g`-cycle of length `k`, summing (4) gives `N Lambda<=k`.  A positive
integer voltage is therefore possible only when `k=N`; in that exceptional
case the cycle contains every period event.  Every proper first-departure
cycle has nonpositive voltage.

Suppose a zero-voltage cycle lifts to a simple lattice Jordan curve.  It
cannot be clockwise.  At a selected first visit, write `e` for the outgoing
unit edge.  P3 makes the turn `R`, so the predecessor cell is the unit right
normal from the current cell.  On a clockwise grid polygon this cell lies in
the closed interior.  The statement remains true at a reflex corner: the
short right-normal segment starts on the interior side and cannot cross a
grid edge transversely.

Now take a sufficiently far future translate of the lifted curve.  The ant
starts outside this bounded region, and the selected visits are the genuine
first visits to its boundary cells.  Choose the earliest of them.  If its
predecessor is another boundary cell, that cell was visited earlier.  If the
predecessor is strictly inside, the ant must already have crossed the Jordan
curve.  Either alternative contradicts the choice of the earliest boundary
visit.  Thus every simple zero-voltage first-departure cycle is
counterclockwise.  A doubled two-edge cycle is not a Jordan curve and is not
covered by this argument.

For the odd-skew drifts this gives a four-level test.  With `d=(1,3)` and
`t=3x-y`, let `a` be even.  The first-port pattern

```text
a:NR,       a+1:WR,       a+3:ER,       a+4:SR
```

would give the clockwise square with directions `E,S,W,N` and edge voltages
`1,0,-1,0`.  It is impossible.  For `d=(1,-3)`, `t=3x+y`, and odd `a`, the
corresponding forbidden pattern is

```text
a-1:WR,     a:NR,         a+2:SR,       a+3:ER.
```

At the lower `(1,1,0)` cap this second test applies to levels `0,1,3,4`.
The first ports on the first three of those levels are `WR,NR,SR`, so level
four cannot begin with `ER`.  Its proved order `WR,WL,ER` has the required
orientation.

## Order-preserving returns at the missing cap

The local countermodel through level six does not settle its inward extension.
Exact edge matching supplies a stronger restriction one level later.  Assume
that levels five through seven are all even.  Level five is `NR,SL`.  On level
six, write `(a,b,c,d)=(ER,EL,WR,WL)`.  Its equations are

```text
a+b=1,       a+d=1,       a+c=b+d.
```

Nonnegativity forces `(a,b,c,d)=(0,1,2,1)`.  There are two possible stable
orders, and both must be retained at this stage:

```text
A: WR,EL,WR,WL
B: WR,WL,WR,EL.
```

For a zero-excess level-seven row, the three northbound departures from level
six and the two west arrivals on level four give

```text
NR+NL=3,       NL+SR=2,       NR+SR=NL+SL.
```

Thus its count row is either `(2,1,1,2)` or `(3,0,2,5)`, in the order
`(NR,NL,SR,SL)`.

Let `W0<W1` be its two westbound departures in stable order.  They feed the
level-four ports `WR,WL` in that order.  Indeed, along any fixed directed edge
block, target lifted time is source lifted time plus the constant
`1-N lambda`, so matching preserves order.  The later departure has the forced
successor path

```text
W1 -> 4:WL -> 3:SR -> 0:WR -> 1:NR
   -> 4:ER -> 3:SL -> 6:EL -> Q,
```

where `Q` is a north arrival on level seven.  Its direction word is
`WSWNESEN`.  The eight steps have zero displacement, and no intermediate event
lies on level seven.  Thus `W1` and `Q` are consecutive visits to the same
physical cell.  Their turns must be opposite, and they must be adjacent in the
stable level-seven word.

In the larger count row `(3,0,2,5)`, both west departures are `SR` and every
north arrival is `NR`.  The two endpoints would both turn right.  This row is
therefore impossible.  In the smaller row, if `W1` were `SR`, its opposite-turn
target would have to be the unique `NL`.  But that `NL` is the earlier west
departure `W0`, contrary to the forward chronology of the return.  Consequently

```text
W0=SR,       W1=NL,       Q=NR,
```

and `NL,Q` are consecutive stable events.

In order A, `6:EL` is the middle northbound departure, so `Q` is the middle
north arrival on level seven.  In order B it is the last northbound departure,
so `Q` is the last north arrival.  Placing the unique `SR` before `NL` in the
alternating six-event word leaves exactly

```text
level 6 A:  level 7 SR,NL,NR,SL,NR,SL
level 6 B:  level 7 SR,SL,NR,NL,NR,SL
         or level 7 NR,SL,SR,NL,NR,SL.
```

Two of these possibilities are impossible even if level eight is allowed to
be wake.  In each, let `r` be the unique `7:SR` event.  It is the earlier
westbound departure, so the three-step path

```text
r -> 4:WR -> 5:NR -> U
```

ends at the first east arrival `U` on level eight.  Its net edge voltage is
zero, giving `tau(U)=tau(r)+3`.  Let `V` be the southbound departure from level
eight that feeds `r`.  Then
`tau(V)=tau(r)-1`.  Since `V` precedes the first east arrival, it cannot be
`ER`; it must be `WL`.

The path `V->r->4:WR->5:NR->U` is a four-step return to the same physical
level-eight cell, with no intermediate level-eight event.  Opposite turns
therefore force `U=ER`.  Its southward step then completes a four-step return
from `r` to the same level-seven cell, now with a south arrival.  These are
consecutive visits there, so the `SR` must be immediately followed by `SL` in
the stable word.  Only the middle row of the displayed list has that property.
We have therefore forced

```text
level 6: WR,WL,WR,EL
level 7: SR,SL,NR,NL,NR,SL.
```

If level eight is also even, its count equations leave only

```text
(ER,EL,WR,WL)=(0,2,5,3) or (1,1,2,2).
```

The first row has no `ER`, so it is impossible.  In the second, the first east
arrival is `ER`, and the four-step return makes `WL,ER` consecutive stable
events.  This `WL` is also the first southbound departure, because `r` is now
the first south arrival on level seven.  The alternating word then has only
two possibilities:

```text
WR,WL,ER,EL,WR,WL
WR,WL,ER,WL,WR,EL.
```

The second order contradicts a lifted-time inequality.  Put
`a=tau(6:WL)` and `b=tau(second 6:WR)`, so `a<b`.  The northbound step from
the latter feeds `7:NL`, and the eight-step return gives
`tau(last 7:NR)=b+9`.  If `h=tau(last 7:SL)`, then `h>b+9`.  On level eight,
the second east arrival is its sole `EL`; it is fed by
`6:WL->5:SL->8:EL`, giving

```text
tau(8:EL)=a+2-N.
```

The last `8:WL` feeds the last `7:SL`, so its time is `h-1>b+8`.  Since the
period is positive, the `EL` is earlier than this `WL`, excluding the second
order.

Thus there is a unique stable band through level eight when levels five
through eight are all even:

```text
level 5: NR,SL
level 6: WR,WL,WR,EL
level 7: SR,SL,NR,NL,NR,SL
level 8: WR,WL,ER,EL,WR,WL.
```

The next level cannot also be even.

## A fourth lower-cap wake by level nine

At a lower `(1,1,0)` cap with drift `(1,-3)`, at least one of levels five
through nine is a wake level.  Together with `0,1,4`, this gives at least four
wake classes in the first ten transverse levels.  The proof is independent of
the period and uses no hypothesis on level ten.

Suppose, to the contrary, that levels five through nine are all even.  The
preceding argument fixes the stable rows through level eight.  The level-nine
port equations are

```text
NR+NL=3,       NL+SR=3,       NR+SR=NL+SL.
```

Their nonnegative solutions are

```text
(NR,NL,SR,SL)=(3,0,3,6), (2,1,2,3), or (1,2,1,0).
```

Let `W1,W2,W3` be the westbound departures on level nine in stable order, and
let `N1,N2,N3` be its ordered north arrivals.  The second west departure feeds
`6:WL`; the middle north departure on level eight is `EL`.  Hence edge matching
forces

```text
W2 -> 6:WL -> 5:SL -> 8:EL -> N2.
```

This is a four-step same-cell return with direction word `WSEN` and no
intermediate level-nine event.  The count row `(3,0,3,6)` makes both endpoints
right turns and is impossible.

For `(1,2,1,0)`, the only possible stable order is `SR,NL,NR,NL`: the other
alternating order makes the return run backward in stable time.  Here
`W2=N1=NL`.  This forces another return,

```text
8:first WR -> 9:NL -> 6:WL -> 5:SL -> 8:EL,
```

whose four steps have zero displacement and no intermediate level-eight
event.  But the fixed stable row on level eight has `WL,ER` between this first
`WR` and its `EL`.  That is impossible.

In the remaining count row `(2,1,2,3)`, if `W2=NL`, the first four-step return
makes it the first north arrival.  The same level-eight contradiction applies.
Thus `W2=SR` and `N2=NL=W3`.  These are adjacent stable events.  Placing the
other ports in the alternating word leaves only

```text
NR,SL,SR,SL,SR,NL,NR,SL
SR,SL,NR,SL,SR,NL,NR,SL.
```

Write the two `SR` events as `SR1,SR2`.  Their west-departure order is
`SR1,SR2,NL`.  Let `E1,E2,E3,E4` be the east arrivals on level ten; the ordered
east departures on level seven that feed them are `SL1,NR1,NR2,SL2`.

The third arrival `E3` must be `EL`.  If it were `ER`, the path

```text
9:NL -> 6:WR2 -> 7:NL -> 4:WL -> 3:SR -> 0:WR
     -> 1:NR -> 4:ER -> 3:SL -> 6:EL -> 7:NR2 -> E3 -> 9
```

would be a twelve-step return to the same level-nine cell, with direction
word `WNWSWNESENES` and no intermediate level-nine event.  Its target is a
south arrival, whereas the next stable event after `9:NL` is `NR`.  Therefore
`E3=EL`.

Now let `J` be the level-ten southbound departure feeding `9:SR2`.  Its
successors are forced all the way to `E3`:

```text
J -> 9:SR2 -> 6:WL -> 5:SL -> 8:EL -> 9:NL
  -> 6:WR2 -> 7:NL -> 4:WL -> 3:SR -> 0:WR
  -> 1:NR -> 4:ER -> 3:SL -> 6:EL -> 7:NR2 -> E3.
```

The direction word `SWSENWNWSWNESENE` has zero displacement, and none of its
intermediate events lies on level ten.  Its endpoints must be consecutive
same-cell visits with opposite turns.  Since `E3` is `EL`, this forces
`J=ER`.  It is an east arrival earlier than `E3`, so it is either `E1` or
`E2`.  It cannot be `E1`, since then the stable visit `E2` would intervene.
Thus `J=E2`.

But this gives the four-step return

```text
9:SR1 -> 6:WR1 -> 7:NR1 -> J -> 9:SR2.
```

Its direction word is `WNES`, and it has no intermediate level-nine event.
Both endpoints turn right, contradicting ordinary same-cell alternation.
This eliminates the last even level-nine possibility and proves the wake
claim.

The conclusion is a disjunction, not five separate forced offsets:
`omega_5+omega_6+omega_7+omega_8+omega_9>=1`.  In particular, it does not prove
the previously conjectured individual wake offsets five and six, nor does it
close growth eight.

At growth eight, P22 strengthens the disjunction to

```text
omega_5+omega_6+omega_7+omega_8 >= 1.
```

To see this, partition the wake classes by level modulo three, which is the
same as the `y mod 3` partition up to a common residue shift.  Each fibre has
signed sum `2 mod 4`, so it contains an even number of classes, at least two.
The known wake levels one and four share a fibre and have opposite checker
signs.  They cancel, so that fibre needs at least two further classes.  The
total of eight therefore forces fibre cardinalities `2,4,2`, with the middle
fibre containing levels one and four.

The fibre containing level zero has only one other wake class.  Its checker
sign must agree with that of level zero, so its level is an even multiple of
three.  Level nine cannot be wake.  Combining this with the preceding theorem
proves the four-level disjunction.  Thus a growth-eight lower missing cap
contributes at least four wake classes among levels zero through eight.

## Allowing a wake on level eight

The level-nine contradiction can be strengthened.  If levels five through
seven are even, level nine must be wake regardless of level eight's parity.
Only the wake-level-eight branch remains to check.

The argument through level seven did not assume level eight was even, so its
stable rows remain

```text
6: WR,WL,WR,EL
7: SR,SL,NR,NL,NR,SL.
```

For wake level eight, the equations `ER+EL=2`, `ER+WL=3`, and excess one give
the count rows

```text
(ER,EL,WR,WL)=(0,2,6,3), (1,1,3,2), or (2,0,0,1).
```

The four-step return already proved that the first south departure is `WL`,
immediately followed by the first east arrival `ER`.  The first count row has
no `ER`.  The last has stable word `ER,WL,ER`, whose first south departure is
`ER`.  Thus only the middle count row remains.  Its stable order must be

```text
WR,WL,ER,EL,WR,WL,WR
or WR,WL,ER,WL,WR,EL,WR.
```

The earlier inequality `tau(8:EL)<tau(last 8:WL)` still holds: the extra final
`WR` changes neither of the two paths used to derive it.  Therefore level
eight has the first displayed order.

Suppose level nine is even.  It now has four north arrivals and three west
departures.  Its possible count rows are

```text
(NR,NL,SR,SL)=(4,0,3,7), (3,1,2,4), or (2,2,1,1).
```

Let `W2` again be the second west departure, and let `N2` be the second of the
four north arrivals.  The same four-step return is

```text
W2 -> 6:WL -> 5:SL -> 8:EL -> N2.
```

The first count row makes both endpoints right turns.  In either remaining
row, if `W2=NL`, its opposite-turn target is `NR`, so this `NL` is the first
north arrival.  Then the four-step return from the first `8:WR` to `8:EL`
skips the fixed intervening `WL,ER` visits.  Thus `W2` must be `SR`.

For the middle count row, the target is its unique `NL`, which is also the
last west departure.  The possible stable words are

```text
NR,SL,SR,SL,SR,NL,NR,SL,NR,SL
SR,SL,NR,SL,SR,NL,NR,SL,NR,SL.
```

These differ from the preceding even-level-eight branch only by a final
`NR,SL` pair.  The twelve-step return still forces the third east arrival on
level ten to be `EL`, since `9:NL` is immediately followed by `NR`.  The
sixteen-step return then identifies its predecessor as the second east
arrival.  The resulting four-step `SR1`-to-`SR2` return has two right-turn
endpoints.  All events in those paths are unchanged by the extra pair.

In the last count row, the two west departures other than `SR` are both
`NL`.  Since `W2=SR` and its target `N2` comes later, that target must be
`W3=NL`; the other `NL` is `W1=N1`.  No right turn can precede this first
`NL`: the only `SR` comes later, while either `NR` would already be a north
arrival before `N1`.  This contradicts the R-first stable order.

All even level-nine rows are impossible.  We have proved

```text
omega_5+omega_6+omega_7+omega_9 >= 1.
```

At growth eight, the P22 argument above gives `omega_9=0`, so at least one of
levels five through seven is wake.

## Level six or level seven must be wake

There is a short complementary argument when level five is wake.  Its entire
row is then `NR`.  If level six is even, its east-arrival count is one and
its south-departure count is zero.  Its unique stable row is `WR,EL`.

If level seven were also even, its equations would be

```text
NR+NL=2,       NL+SR=2,       NR+SR=NL+SL,
```

leaving count rows `(2,0,2,4)` and `(1,1,1,1)`.  The eight-step return from
the later west departure on level seven still goes through
`4:WL,3:SR,0:WR,1:NR,4:ER,3:SL,6:EL` and returns to the last north arrival.
The larger row has two right-turn endpoints and is impossible.  In the
smaller row the later west departure cannot be `SR`, because its target
would be the earlier `NL`.  Hence the consecutive endpoint pair is `NL,NR`,
forcing the complete stable row

```text
SR,NL,NR,SL.
```

The earlier west departure `SR` feeds `4:WR->5:NR` and then the first east
arrival on level eight.  The same four-step square used above forces this
`SR` to be immediately followed by `SL`, contradicting the displayed `NL`.
Thus level five cannot be wake while both levels six and seven are even.

Combining this with the preceding disjunction proves the growth-eight bound

```text
omega_6+omega_7 >= 1.
```

This uses exact P3 at the lower missing cap, together with P22 at growth eight.
No period bound or inward cap assumption is needed.  The
consequence for a guard at the opposite cap is proved in
`odd_skew_missing_guard_exclusion_2026-09-03.md`.

## Last-exit cycles need not be unique

The standard period-104 trace already has two last-exit cycles.  In its
`d=(2,-2)` normalization, use quotient coordinates

```text
(t,r)=(x+y,x mod 2),       ell=(x-r)/2.
```

The latest lifted occurrences listed below give the two cycles

```text
(-1,1) -> (-2,1) -> (-1,0) -> (-2,0) -> (-1,1),
(-3,0) -> (-4,0) -> (-3,1) -> (-4,1) -> (-3,0).
```

Their phase indices are respectively `(97,98,99,16)` and `(19,20,21,26)` in
normalization A of `results/standard_highway.json`.  In each cycle exactly one
selected edge raises `ell`; the other three preserve it.  Both cycles therefore
have voltage one, exactly as the lemma requires.  This finite check is a direct
counterexample to uniqueness even under exact P3 alternation.  Any useful cap
argument must control how the two forced cap chains attach to positive-voltage
cycles; it cannot assume that the last-exit forest has only one such cycle.
