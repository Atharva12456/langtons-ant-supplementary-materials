# The two lower fat `(1,2,3)` bands with `omega_3=0` and `(j,k,l)=(2,0,1)` are impossible

22 September 2026

In the lower-cap coordinates for drift `(1,-3)`, the forced rows through
level four are

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: NR,SL,SR,SL,NR,SL
4: WR,WL,WR,WL,ER,EL,WR,WL,[WR]^b
```

where `b=omega_4` is either zero or one. Both bands fail at level six,
regardless of the wake choices at levels five and six. Growth eight has eight
distinct wake levels in `0,...,W`, so its transverse width satisfies `W>=7`.
Levels five and six therefore exist in any full candidate.

The standalone checker `code/python/verify_lower_fat123_a0_j2_exclusion.py` independently derives row counts and generates **all** alternating words at each new level. It matches
successors by incoming and outgoing ordinals, and rejects only witnessed finite first returns to
the wrong stable event of a physical cell. It stops when a quotient node repeats rather than extrapolating the cycle. It applies no period cutoff, width cutoff, P22 pruning,
or clock solver. The necessary physical-return filter gives these counts:

| `b` | Level-five raw words | Level-five survivors | Level-six raw words | Level-six first-return survivors |
|---:|---:|---:|---:|---:|
| 0 | 172 | 8 | 23,629 | 49 |
| 1 | 313 | 8 | 47,767 | 98 |

Every one of the 147 level-six first-return survivors has the forced path

```text
1:NR -> 4:ER -> 3:second SL -> 6:ER -> 5:SR -> 2:WL -> 1:SL.
```

The ordinal positions of the level-six `ER` and level-five `SR` vary with the
stable words. The checker follows six successor edges from `1:NR` and asserts
their level sequence, ports, endpoint, and total longitudinal voltage in
every surviving case. The direction word is `E,S,E,S,W,S`, with net
displacement `(1,-3)` and voltage `+1`. Thus exact lifted chronology gives

```text
tau(1:SL)-tau(1:NR) = 6-N.
```

The two level-one events are successive stable visits to one representative
cell, so their time gap is at least four. Alternating step axes and drift
`(1,-3)` imply `N>=6`; hence `6-N<=0`, a contradiction. The two initial bands
are excluded at every period. This is a finite computer-checked stable-word
certificate, not a full closure of the drift orbit.

`work_remaining_a0/verify_a0_j2_brute.py` gives a separate raw-word/SMT check with an earlier
clock filter; it reaches the same empty level-six frontier. The exact path
checker and `results/lower_fat123_a0_j2_checks_2026-09-22.json` are the primary certificate.
