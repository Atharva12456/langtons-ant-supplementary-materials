# Family B requires an east-right event on lower row twelve

24 September 2026. This is an all-period necessary prefix restriction at
drift `(1,-3)`. Family B and the full drift orbit remain open.

Family B has width `W=6m+4` and wakes

```text
{0,5,6,8,6p+2,6r+4,W-2,W},
2<=p<r<=m-1,  p+r odd.
```

The first later wake is at least level fourteen, so lower rows nine through
twelve are non-wake. The established lower-cap return analysis gives two row
eight words, a unique row nine, and 25 row-ten words after exact lifted-clock
filtering: eight after row-eight A and seventeen after B. One of the latter
has no row-eleven continuation by the separate fixed-return argument, leaving
24 viable row-ten words.

**Claim.** Every Family B tour has at least one `ER` event on lower row twelve.

For each of the 25 row-ten candidates, the verifier derives every non-wake
row-eleven count row and enumerates R-first alternating words satisfying
one-excursion, zero-voltage first-return adjacency. There are 339,024 raw
alternating row-eleven words, 1,150 after that adjacency condition, and 1,038
after the full physical first-return check. Exact integer clocks, checked
separately in the preceding row-eleven analysis, leave 565 of those 1,038;
the present exclusion does not need that row-eleven clock filter.

If row twelve contains no `ER`, directional flow and non-wake balance force
one of only three count vectors, shown as `(ER,EL,WR,WL)`:

```text
(0,8,12,4), (0,8,16,8), (0,8,20,12).
```

Assume `ER=0`. Then every south departure from row twelve is `WL`.
For **every** one of the 1,150 row-eleven adjacency candidates, one of those
`WL` departures has a four-step path of the form

```text
12:WL_i -> 11:SR -> 8:WR -> 9:NR -> 12:E_j,
       i in {0,1,2}, j in {0,2,4}.
```

Here `i` is an outgoing-south ordinal on row twelve and `j` is an incoming-east
ordinal. The verifier checks the actual ordinal successor path separately
for every candidate; it does not assert that every displayed `(i,j)` pair
occurs. The path has net horizontal voltage zero and no intermediate row-twelve
event, so it is the first return to the same physical cell after `WL_i`.
Consequently the `E_j` event must immediately follow `WL_i` in stable order.
Yet `ER=0` makes every east-arrival event on row twelve `EL`. Both `WL_i` and
`EL_j` are left turns, impossible as
consecutive events in the alternating word. The checker independently
enumerates the zero-`ER` row-twelve count
rows and finds zero adjacency words. Thus none of the 1,038 fully physical or
565 clock-feasible row-eleven prefixes can lead to a zero-`ER` row twelve.
No period or width cutoff is used.

Run `python code/python/verify_family_b_row12_er.py` from the repository
root. It recomputes the 25 row-ten words with
`code/python/verify_family_b_row10_words.py`, independently rebuilds
the row-eleven adjacency and physical frontiers, and writes
`results/family_b_row12_er_positive_2026-09-24.json`. The checker uses the
stable-word and return machinery in `code/python/p2_research.py`; the
earlier hand lower-cap normal form and the row-ten word certificate remain
its prerequisites.

This does not force a unique row-twelve word or exclude Family B. A separate
necessary-condition scan still retains row-twelve candidates above each of
the 24 previously viable row-ten words; those candidates are not certified
full tours.
