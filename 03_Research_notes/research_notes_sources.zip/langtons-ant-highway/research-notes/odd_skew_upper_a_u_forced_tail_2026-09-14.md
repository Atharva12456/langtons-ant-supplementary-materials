# Forced returns above the remaining upper U word

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Consider the remaining single-`ER` word at the upper cap of
family A, as reduced in
`odd_skew_upper_a_single_er_reduction_2026-09-14.md`.
Offsets seven through eleven are non-wake. This note proves:

* The fifth and sixth east arrivals on offset eight are the
  consecutive final pair `E5=ER,E6=EL`.
* The final four events on offset nine are `SR,NL,SR,SL`.
* The final four events on offset ten are `ER,WL,WR,EL`.
* The final three events on offset eleven are `NL,NR,SL`.
* The final four offset-six visits `WL,WR,EL,WR` have
  successive gaps of exactly four steps.

These are necessary restrictions. The remaining U word is
not excluded here. No search or longitudinal time inequality
is used in deriving the forced returns.

## Fixed rows and matching labels

Use inward offsets and rotated headings throughout. The fixed
rows are

```text
5: NR1,SL1,SR,NL,NR2,SL2,NR3,SL3
6: WR1,WL1,WR2,EL1,WR3,WL2,ER,WL3,WR4,EL2,WR5
7: SR,SL,NR,NL,NR,SL,NR,NL,NR,NL,SR,SL.
```

Label the west departures on seven by `W1,...,W5` and its
north arrivals by `N1,...,N7`. In particular,

```text
W3=NL=N5,       N6=NR,       W4=NL=N7,       W5=SR.
```

There are six east arrivals `Ei` on eight. They are supplied
by `5:NR1,SL1,NR2,SL2,NR3,SL3`, in that order. The preceding
reduction gives `E1=ER,E3=EL`. There are five south departures
on eight; `W5` is the fourth south arrival on seven, followed
by its last `SL`.

The eight west departures `Di` on nine feed

```text
6:WR1,WL1,WR2,WR3,WL2,WL3,WR4,WR5.
```

Let `F1,...,F7` be the east arrivals on ten. We will use
that `F5` is supplied by `7:N4=NR`, from `6:WR3`; `F6`
by `7:N6=NR`, from `6:EL2`; and `F7` by the final `SL`
on seven.

## E5 cannot turn left

Suppose `E5=EL`. The square through `W5` forces the
consecutive pair `E4=ER,E5=EL`, with `E4` the fourth south
departure on eight. If `E6=ER`, it would be both the last
east arrival and the last south departure. No left turn could
follow it, so offset eight would be wake. Thus `E6=EL`.

There is a twelve-step first return

```text
D5 -> 6:WL2 -> 5:SR -> 2:WR -> 3:NR -> 6:ER
   -> 5:SL2 -> 8:E4=ER -> 7:W5=SR -> 4:last WR
   -> 5:NR3 -> 8:E5=EL -> north arrival on 9.
```

If `D5=SR`, its consecutive target is `D6=NL`, supplied
by `8:E5=EL`. The square

```text
8:E5=EL -> 9:D6=NL -> 6:WL3 -> 5:SL3 -> 8:E6=EL
```

would have two left-turn endpoints. Hence `D5=NL`.

Its incoming predecessor `X` on eight is the north departure
immediately preceding `E5`, and therefore precedes `E4`.
The first part of the long return gives the eight-step first
return

```text
8:X -> 9:D5=NL -> 6:WL2 -> 5:SR -> 2:WR -> 3:NR
    -> 6:ER -> 5:SL2 -> 8:E4=ER.
```

Its source must be `X=E3=EL`. But then

```text
5:NR2 -> 8:E3=EL -> 9:D5=NL -> 6:WL2 -> 5:SR
```

is a square with two right-turn endpoints. This excludes
`E5=EL`.

Consequently `E5=ER` supplies the fifth and last south arrival
on seven. The only later east arrival is `E6=EL`, immediately
after `E5`. No event can follow `E6`: the only possible right
turn would be `WR`, and no left turn would remain to make
offset eight non-wake. Thus `E5,E6` are its final two events.

## The last three west departures on nine

The square from `D6` through `6:WL3,5:SL3,E6=EL` cannot
have an `NL` source. It would require an incoming `WR`
immediately before `E6`, where the predecessor is `E5=ER`.
Therefore `D6=SR`, with consecutive target `D7=NL`.

The next forced path is

```text
D7 -> 6:WR4 -> 7:W3=NL -> 4:second WL -> 3:last SL
   -> 6:EL2 -> 7:N6=NR -> 10:F6.
```

If `F6=EL`, the south predecessor of `D6` on ten would
have a twelve-step first return to `F6`. It would be
`F5=ER`. The square

```text
6:WR3 -> 7:N4=NR -> 10:F5=ER -> 9:D6=SR -> 6:WL3
```

would then skip `WL2,ER` in the offset-six word. Hence
`F6=ER`. Its south step completes the eight-step first
return from `D7=NL` to `D8=SR`.

The north arrival `D7` is supplied by the final event `E6`
on eight. There are no later north arrivals on nine and no
west departures after `D8`. Since nine is non-wake, it
therefore ends exactly

```text
D6=SR,D7=NL,D8=SR,SL.                               (1)
```

## The final east arrival on ten

The south departure `F6=ER` feeds `D8`, the penultimate
south arrival in (1). Only one further south departure is
available. If `F7=ER`, alternation between the consecutive
east arrivals `F6,F7` would require a `WL` between them.
That would consume two further south departures. Thus
`F7=EL`.

Let `J` be the south departure on eight feeding `W5`.
The square through `4:last WR,5:NR3` forces `J=WL`,
immediately before `E5=ER`. It is the last west arrival
on eight, since that word ends `J,E5,E6`.

Let `P_J` be its matching west departure on eleven. The
eight-step first return

```text
P_J -> 8:J=WL -> 7:W5=SR -> 4:last WR -> 5:NR3
    -> 8:E5=ER -> 7:last SL -> 10:F7=EL
    -> north arrival on 11
```

cannot have an `SR` source: its `NL` target would be a
further west departure after the last one. Hence `P_J=NL`.
Its incoming predecessor `X` on ten is the north departure
immediately preceding `F7`. Starting one step earlier gives
an eight-step first return from `X` to `F7=EL`, so `X=WR`
immediately precedes `F7`.

Between `F6=ER` and this `WR` there must be a left turn.
The only available one is the final south departure `K=WL`.
Alternation therefore fixes the ending on ten as

```text
F6=ER,K=WL,X=WR,F7=EL.                              (2)
```

There are no events after `F7`: every east arrival and south
departure has occurred, and ten is non-wake. The last north
arrival on eleven is consequently the `NR` supplied by
`F7`, immediately following `P_J=NL`. Since eleven is
non-wake and has no further west departures, its final
three events are `P_J=NL,NR,SL`.

## Three consecutive square gaps on six

The forced matches give three first square returns:

```text
6:WL3 -> 5:SL3 -> 8:E6=EL -> 9:D7=NL -> 6:WR4;
6:WR4 -> 7:W3=NL -> 4:second WL -> 3:last SL -> 6:EL2;
6:EL2 -> 7:N6=NR -> 10:F6=ER -> 9:D8=SR -> 6:WR5.
```

These are the final four stable visits on six. If the first
has time `T`, their times are exactly `T,T+4,T+8,T+12`.
There is also the square

```text
7:N6=NR -> 10:F6=ER -> 9:D8=SR -> 6:WR5 -> 7:W4=NL.
```

All these returns have zero displacement and remain valid
with rotated inward headings. They further restrict the U
continuation but do not yet contradict it.
