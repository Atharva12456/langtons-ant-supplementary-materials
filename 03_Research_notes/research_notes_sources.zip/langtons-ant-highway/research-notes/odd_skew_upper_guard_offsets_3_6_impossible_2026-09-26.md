# Upper guard: offsets three through six cannot all be quiet

Later result (26 September 2026): [the upper-guard early-wake exclusions](odd_skew_upper_guard_early_wakes_2026-09-26.md) remove the remaining width-20 placements discussed below. The earlier local lemma remains valid; larger widths and the full drift orbit are not closed by these results.

For the `(1,-3)` drift, write the upper cap in inward coordinates after
rotating headings by 180 degrees. Suppose its first three wake words are

```text
0: WR       1: NR       2: WR.
```

There is no stable extension with offsets `3,4,5,6` all non-wake. This is a
local, all-period statement: no wake/rank/moment restriction, period upper
bound, width upper bound, row-size cutoff, or quotient-cycle extrapolation is
used. We require a positive integer period and strict integer order of events
on each row. The argument applies wherever upper offsets zero through seven
are defined by the usual stable-row flow equations.

## The five row-six cases

The existing hand certificate
`research-notes/odd_skew_upper_guard_hand_certificate_2026-09-24.md` derives,
without a solver, all prefixes through offset six. In particular the row-five
alternative `SR SL NR SL` is impossible because exact clock paths make a sum
of three positive row-time differences equal `2-N`. Their lower bounds total
five, forcing `N<=-3`. The remaining offset-six words are

| Case | Row six |
|---|---|
| A | `WR EL WR WL WR WL ER EL` |
| B | `WR WL ER EL WR EL WR WL` |
| C | `WR WL ER EL WR WL WR EL` |
| D | `WR WL WR EL WR WL ER EL` |
| E | `ER WL ER EL` |

That certificate already proves offset seven cannot be a wake. It remains to
exclude the non-wake choice.

## Exhausting non-wake row seven

For A--D, the old rows force five north arrivals and three west departures on
row seven. The exact flow equation gives the following `(NR,NL,SR,SL)` count
options when `omega_7=0`:

```text
(5,0,3,8), (4,1,2,5), (3,2,1,2).
```

Alternation admits respectively `56`, `90`, and `24` words, so there are
exactly `170` raw words per case. For E, the count options are `(1,0,3,4)`
and `(0,1,2,1)`, with `4+2=6` raw alternating words. These counts have no
length cutoff: the exact flow equations determine their finite lengths.

The three west departures on row seven enter row-four west arrivals in
ordinal order. The already determined rows give the following zero-voltage
first returns to row seven, where `W_k` is west departure ordinal `k` and
`N_j` is north arrival ordinal `j` (one-based):

| Case | Return from `W_2` | Return from `W_3` | Adjacent row-seven word(s) |
|---|---|---|---|
| A | `N_2` | `N_5` | `SR NL NR SL NR NL NR SL` |
| B | `N_2` | `N_4` | `SR NL NR NL NR SL NR SL` |
| C | `N_2` | `N_5` | `SR NL NR SL NR NL NR SL` |
| D | `N_3` | `N_5` | `NR SL SR NL NR NL NR SL`; `SR SL NR NL NR NL NR SL` |
| E | unknown | `N_1` | none |

These returns are traced explicitly in section 4 of the existing hand
certificate and are independent of the wake value at seven. A zero-voltage
first return must land on the immediately next event of its starting row.
Checking that adjacency against the just-listed alternating words leaves
exactly the table's five candidates. This can also be seen by a small case
split: zero `NL` cannot follow the needed `SR` returns; one `NL` makes two
required target north ordinals consecutive although their indices differ by
at least two; with two `NL`, only `4*6=24` arrangements remain and direct
placement of the one `SR` and two `SL` gives the displayed words. The E
options fail the `W_3 -> N_1` adjacency.

All five candidates have the same first seven events as the corresponding
offset-seven-wake candidates, followed by one `SL`. Their decisive finite
first-return walks are therefore unchanged:

* In A and both D words,
  `6:5 WR -> 7:6 NL -> 4:4 WL -> 3:4 SL -> 6:8 EL` has cumulative voltage
  `0,0,-1,-1,0`. It returns to row six at event eight without visiting that
  row in between; event six should have been next.
* In B and C,
  `6:1 WR -> 7:2 NL -> 4:2 WL -> 3:1 SR -> 0:1 WR -> 1:1 NR -> 4:3 ER -> 3:2 SL -> 6:3 ER`
  has cumulative voltage `0,0,-1,-1,-2,-2,-1,-1,0`. It returns to row six
  at event three without visiting that row in between; event two should have
  been next.

Thus the non-wake choice at seven is impossible. The existing hand
certificate excludes the wake choice. Both are exhaustive, proving the
stated local lemma.

`code/python/verify_upper_guard_quiet7_hand.py` is a standard
library checker. It regenerates every row-three-through-six alternating
word from the exact count equations, applies the displayed row-five clock
identity, enumerates all `686` raw quiet-row-seven words, checks the old-row
boundary returns, and records the five explicit wrong-return paths in
`results/upper_guard_quiet7_hand_result_2026-09-26.json`.

## Consequence for lower fat `(0,1,111)` and upper guard

The independent static wake classification fixes lower wakes `{0,2,4}` and
upper wakes `{W-2,W-1,W}`. Its two remaining wakes have upper inward offsets
either `(6i+4,6j+4)` with `0<=i<j`, or `(6i+1,6j+1)` with `1<=i<j`.
The new lemma eliminates every odd-offset family and every even-offset
family with `i>=1`: each has upper offsets `3,4,5,6` quiet. The sole static
shape still allowed by this local lemma is

```text
O = {0,2,4, W-2,W-1,W, W-4, W-(6j+4)},   j>=1,
```

subject to the classification's width bound, rank and moment parity.
This is a necessary remaining family, not a realized highway or closure of
the full orbit.

## The lower `(0,0,111)` band at width twenty

The earlier static audit finds six upper-guard wake placements at its
minimum width twenty. Three have quiet inward offsets three through six
and wake seven, so the earlier hand lemma excludes them. The stronger
lemma also excludes the placement
`{0,2,7,8,11,18,19,20}`: its inward offsets three through seven are all
quiet. Only `{0,2,7,12,15,18,19,20}` and
`{0,2,7,14,17,18,19,20}` remain at width twenty. This is a
width-specific corollary, not an exclusion of the upper-guard cap pair.
