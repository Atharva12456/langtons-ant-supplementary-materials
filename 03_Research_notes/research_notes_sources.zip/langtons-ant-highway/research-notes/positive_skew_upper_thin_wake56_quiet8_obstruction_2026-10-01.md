# Saturated lower111/upperF122 is impossible

Work at literal drift `(1,3)`, growth eight, lower thin bits
`omega5=omega6=omega7=1`, and upper `(1,2,2)`. The exact compact
endpoint family is

```
W=6m+4,
O={0,4,5,6,7,6q-2,6p-1,W},
2<=q<=p<=m,  m+p+q even.
```

This note excludes the **saturated** subfamily `q=p=m`. Its parity gives
even m, and the established W>=18 exclusion gives even m>=4. Thus

```
W>=28,
O={0,4,5,6,7,W-6,W-5,W}.
```

The upper inward wake offsets are zero, five, six, and then offsets at
least `W-7>=21`. In particular upper offsets seven through twenty are
quiet. The necessary local continuation already fails at offset eight.
This is an all-width exclusion of the saturated subfamily, not a bounded
coordinate search or a closure of the whole drift orbit.

## A stronger weak local statement

An upper F122 cap with quiet offsets three and four and wake offsets
five and six has just one necessary prefix through offset seven. Its
offset seven is quiet. That prefix cannot have quiet offset eight.

The prefix classification is computer-assisted, using exact port counts,
raw R-first alternating words, directed ordinal matching, witnessed
physical first returns, and integer clocks with only N>=1 and strict
stable order. It uses no P22, growth budget, period congruence, stable
gap four, period upper bound, or visit-count cutoff. Consequently the
local result is stronger than the original growth-eight strong-domain
calculation. Once the unique prefix is supplied, the final quiet-eight
obstruction has the short hand proof below.

Display upper rows in the orientation-preserving half-turn gauge. The
ports below have lower orientation; physical upper ports exchange E/W
and N/S. The lifted equation has the actual upper sign
`tau(target)=tau(source)+1+N*lambda`.

The unique prefix is

```
0 NR
1 WR,WL
2 NR,SL
3 WR,WL,ER,WL
4 NR,SL,NR,NL,SR,SL
5 WR,WL,WR,EL,ER
6 NR,SL,NR,NL,SR,NL,NR
7 WR,WL,WR,EL,ER,WL,ER,WL,WR,EL
```

## Hand obstruction at quiet offset eight

Row seven has five south departures and row five has three west
arrivals. Therefore on a quiet row eight, for some nonnegative integer s,

```
SR=s, SL=5-s, NL=3-s, NR=8-3s.
```

Nonnegativity gives s<=2. There are exactly three west departures
`D1,D2,D3` and five south arrivals `S1,...,S5` on this row. A west
departure is SR or NL.

Tracing the assigned older rows gives two physical first returns:

```
D1 -> S2, direction word WNENWNENWNESWSESWSES;
D3 -> S4, direction word WNES.
```

Both words have zero physical displacement. Neither contains an
intermediate row-eight visit. The returned event is therefore the
immediately next stable event in the same class and has opposite turn.
The second west departure exits into the unassigned row nine; no
adjacency implication is imposed on that excursion.

D3 cannot be NL. If it were, S4 would be SR and a fourth west departure
after D3, contradicting the exact total three. Thus D3 is SR and S4 is
SL.

Suppose D1 is NL. Its returned S2 is SR and therefore D2. D3 must be
the next possible SR south arrival, S3. These two SR events exhaust
s=2, leaving exactly one NL, already used at D1. Between S2 and S3
there can be no SL, because S3 is the next south arrival, and no NL,
because its count is exhausted. Thus there is no L event between two R
events, contrary to stable alternation. This rules out D1=NL.

Hence D1 is SR, specifically S1, and its next event is S2=SL. D3 is
S3=SR and its next event S4=SL. We have s=2 and D2=NL. The only
remaining ports are two NR and S5=SL. No event can precede S1: a
preceding NR would require an earlier NL or SL to separate two R
events, contradicting D1 and S1 being the first corresponding
departures/arrivals. Alternation and the stated consecutive pairs now
force the entire quiet row:

```
8 SR,SL,NR,NL,SR,SL,NR,SL.
```

There is then the four-step physical square

```
7:first WL -> 8:first SR -> 5:first WR -> 4:first NR -> 7:first EL,
                 S             W              N              E.
```

Its endpoint is the next physical visit to the starting cell. On the
fixed row-seven word, however, the intervening second WR lies between
that first WL and first EL. The square returns from stable index one
to index three, skipping index two. This is impossible.

Thus the unique prefix must wake at offset eight, contradicting the
saturated family's arithmetic quiet-eight requirement. No extension
through offsets nine to twenty is needed.

## Fresh independent finite-domain verification

`extend_quiet_upper.py` extracts the single `10000110` prefix from the
saved complete strong upper domain, preserves its source hash and
settings, and calls the audited exact frontier and unbounded clock.
Its quiet-eight stage is complete: three count vectors represent 170
raw alternating words, 79 adjacency recursion nodes emit one word,
and the square above rejects it. No resource cutoff or clock rejection
was reached. `quiet_extension.json` records closure of this necessary
local domain only; its time/node caps are explicitly reported and would
produce INCOMPLETE status if reached.

More importantly, `independent_weak_raw.py` imports no frontier or older
probe. It independently generates every raw alternating word and traces
literal compass coordinates with ordinal matching. Its exact integer
clock is directly encoded in Z3 with N>=1, no upper bound, and strict
row order. Both wake bits at offset seven are enumerated. The complete
stages are:

| Offset | Parents | Raw words | Physical rejections | Clock rejections | Survivors |
|---|---:|---:|---:|---:|---:|
| 3 | 1 | 2 | 0 | 0 | 2 |
| 4 | 2 | 38 | 34 | 1 | 3 |
| 5 | 3 | 48 | 45 | 0 | 3 |
| 6 | 3 | 69 | 65 | 1 | 3 |
| 7, either wake bit | 3 | 2,610 | 2,609 | 0 | 1 |
| 8, quiet | 1 | 170 | 170 | 0 | 0 |

The three weak six-row normals share rows zero through three. They are
the following, before the seventh-row raw check reduces them to the
unique prefix displayed above:

```
A: 4 NR,SL,NR,NL,SR,SL
   5 WR,WL,WR,EL,ER
   6 NR,SL,NR,NL,SR,NL,NR

B: 4 SR,SL,NR,NL,NR,SL
   5 WR,EL,ER,WL,WR
   6 NR,NL,SR,SL,NR,NL,NR

C: 4 SR,SL,NR,SL,NR,NL
   5 WR,WL,WR,EL,ER
   6 NR,SL,NR,NL,SR,NL,NR
```

All 2,923 finite physical-return certificates and both exact UNSAT
integer-clock inputs are retained in per-stage JSONL files. Each uses
the immediately previous stage's saved parent index and its new row.
A repeated quotient cycle without a finite physical witness is kept;
it never causes rejection. Thus this conservative physical tracing
cannot omit a true prefix, and the completed empty quiet-eight domain
is a valid exclusion.

Run from the project root:

```
python work_positive_skew_saturated111_20261001/extend_quiet_upper.py --depth 20
python work_positive_skew_saturated111_20261001/independent_weak_raw.py
```

Reproduction code and evidence are retained in
`work_positive_skew_saturated111_20261001`.


The canonical copy was integrated on 1 October 2026. The complete
[lower-thin111 exclusion](positive_skew_lower_thin_111_exclusion_2026-10-01.md)
combines these local results with all-width arithmetic; the whole orbit
remains open.
