# Lower fat `(1,2,3)`, `omega_3=0`, `(j,k,l)=111`: bounded frontier

22 September 2026. Both `omega_4` branches remain open. This is a necessary-prefix computation, not a periodic ant construction.

The initial stable rows are

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: SR,SL,NR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,WR,WL,[WR]^b     b = omega_4 in {0,1}.
```

`probe_111.py` derives every later port-count row from the flow and binary wake equations, generates all alternating stable words subject to necessary zero-voltage boundary return adjacency, rejects witnessed finite wrong first returns, and solves the exact lower-sign lifted clock equations over the integers with `N>=6` and successive same-cell gaps at least four. It uses no period upper bound, width, row-size, or lifetime cutoff, and no wake restriction. `probe_111_p22.py` adds only the necessary condition that the partial wake set extend to P22's `4+2+2` signed residue-three fibres. It does not infer a quotient-cycle return from repeated vertices.

| `omega_4` | Wake filter | Level 5 | Level 6 | Level 7 | Level 8 | Level 9 |
|---|---|---:|---:|---:|---:|---:|
| 0 | P22 partial extension | 14 | 50 | 32 | 102 | 394 |
| 1 | none | 16 | 80 | 319 | 675 | not checked |

For `omega_4=0`, P22 rejects no wake choice through level nine, so the same counts hold without that filter. At level nine, the 102 incoming prefixes induce 1,024 port-count rows and 3,016 alternating words satisfying necessary adjacency. Of these, 1,408 fail a witnessed first return and 1,214 fail the exact lifted clocks, leaving 394. The saved JSON includes wake-pattern counts and three full survivor prefixes. For `omega_4=1`, the unrestricted level-eight computation finds 4,192 port-count rows and 11,834 adjacency words; 8,475 fail returns and 2,684 fail clocks, leaving 675. Its JSON includes the complete level-by-level counts.

The level-ten `omega_4=0` expansion was stopped without a result. No level-nine `omega_4=1` expansion was run. A nonempty prefix does not establish a consistent infinite orbit or a periodic trace; neither branch is excluded by these tests.

Reproduce from the repository root with:

```text
python work_a0_111/probe_111_p22.py 4 0 9
python work_a0_111/probe_111.py 4 1 8
```

The corresponding saved results are `probe_111_p22_b0_through9.json` and `probe_111_b1_through8.json` in `work_a0_111/`.
