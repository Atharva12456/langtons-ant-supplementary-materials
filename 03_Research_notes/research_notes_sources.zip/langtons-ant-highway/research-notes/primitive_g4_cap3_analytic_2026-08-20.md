# Primitive-diagonal growth four under crossing cap three

Subsequent status: the unrestricted primitive-diagonal growth-four case is
excluded by the analytic reduction and computer-assisted affine classification
in [the top-boundary note](primitive_g4_cap5_symbolic_2026-08-22.md). The
growth-eight cases remain open. The entries below preserve the earlier
checkpoint and its intermediate questions.

## Status

This note proves an **analytic conditional exclusion**.  It does not prove the
unrestricted primitive-diagonal case, `g>=12`, or highway uniqueness.

Normalize a hypothetical primitive-diagonal growth-four trace to drift
`d=(1,-1)`, put its singleton bottom rail at transverse level zero, and let
`f_c` be the number of upward (equivalently downward) crossings of the cut between
levels `c` and `c+1`.  Assume

```text
f_c <= 3 for every transverse cut c.
```

Then the stabilized lower-prefix condition already fails whenever `W>=6`.
Since every finite-support diagonal highway has `W>=10`, no primitive-diagonal
growth-four highway can have crossing cap three.

The proof uses neither ordinary same-cell alternation nor the upper-prefix half of
the periodic-realisability criterion.  It is therefore an exclusion of a strictly
larger projected-tour class.

## Tree state

The positive transverse excursion is the contour of a rooted plane tree.  At a
fixed depth, list the current nodes in contour order.  A state consists of

```text
(b_1,...,b_n)       longitudinal bases of the nodes,
(v_1,...,v_n)       horizontal voltages of their complete subtrees,
(e,o)               numbers of used interior even/odd wake levels.
```

At depth `t`, put `s_t=+1` for even `t` and `s_t=-1` for odd `t`.  If a node has
children of voltages `w_1,...,w_k`, then

```text
v = s_t + w_1 + ... + w_k.                         (1)
```

Thus a leaf at odd depth has voltage `-1`.  The turns made at an odd-depth node
are `R`, then one `L` between consecutive children, then `R`; an odd-depth leaf
contributes one `L`.  The even-depth statement has `R` and `L` interchanged.
At each level the events are ordered by decreasing longitudinal coordinate, with
phase order breaking ties.  The lower-prefix hypothesis says that every prefix of
that stable word has nonnegative `#R-#L`.

The line-parity laws and total growth four imply that there is one interior wake
level of each parity.  Together with `f_c<=3`, these facts leave only finitely many
degree patterns at each of the first four depths.

## Four-level classification

Starting from the bottom state `((0),(1),0,0)`, apply (1), the cap, the one-wake-
per-parity budget, and the lower-prefix condition through depth four.  A direct
finite case split gives exactly the following five affine families.  Translation
of all bases has already been fixed by the bottom rail.

| cut prefix `(f_1,f_2,f_3,f_4)` | bases at depth 4 | voltages at depth 4 | wake budget `(e,o)` | parameter domain |
|---|---|---|---|---|
| `(3,1,2,2)` | `(2,b)` | `(b-2,-b)` | `(0,1)` | `b>=3` |
| `(3,1,2,3)` | `(2,b,c)` | `(b-2,c-b,-c)` | `(1,1)` | `max(b,c)>=3` |
| `(3,1,3,2)` | `(2,b)` | `(b-2,-b-1)` | `(1,0)` | `b>=3` |
| `(3,2,1,3)` | `(2,b,c)` | `(b-2,c-b,2-c)` | `(1,1)` | `b,c>=2` and `(b,c)!=(2,2)` |
| `(3,2,2,2)` | `(2,b)` | `(b-2,1-b)` | `(1,0)` | `b>=3` |

For completeness, the corresponding degree rows through depth four are

```text
(3),(1,0,0),(2),(2,0)
(3),(1,0,0),(2),(3,0)
(3),(1,0,0),(3),(2,0,0)
(3),(2,0,0),(1,0),(3)
(3),(2,0,0),(2,0),(2,0),
```

respectively.  This makes the table a short algebraic check rather than an
unbounded enumeration: substitute the degree row in (1), write the child bases as
successive partial voltage sums, and compare the at most seven level events.  The
nonnegative Catalan words of the required lengths give exactly the displayed
parameter domains.  In particular, every lower-prefix branch with `f_c<=3` is in
the table; no bound on `b`, `c`, the period, or the width is used.

The width-four positive control is not lost in this reduction.  It closes one
depth earlier, with cut profile `(1,3,2,1)` and stabilized level words
`R, RLRL, RLRRL, RRL, R`.

## Fifth-level obstruction

At depth five, every possible continuation under the cap has exactly one nonleaf
parent.  Consequently every other parent must be a leaf and, by (1), must have
voltage `-1`.

In the first, third and fifth rows of the table there are two parents, but neither
displayed voltage can equal `-1` in the stated parameter domain.  Those families
cannot continue.

In the second row there are three parents.  Requiring two of

```text
b-2, c-b, -c
```

to equal `-1` gives only

```text
(b,c)=(1,0), (1,1), (2,1),
```

all excluded by `max(b,c)>=3`.

In the fourth row, requiring two of

```text
b-2, c-b, 2-c
```

to equal `-1` leaves only the admissible point `(b,c)=(4,3)`.  The state there is

```text
bases    (2,4,3),
voltages (2,-1,-1).
```

The first parent is the unique nonleaf.  Its two `R` endpoints have coordinates
`2` and `5`, while the two leaves contribute `L` at coordinates `4` and `3`.
Stable decreasing-coordinate order is therefore

```text
R(5), L(4), L(3), R(2),
```

namely `RLLR`; its third prefix has charge `-1`.  This last continuation also
fails.  Hence no lower-prefix state reaches depth five.

## Consequence and boundary

Every width at least six contains these first five levels above the bottom rail,
so the obstruction is width-uniform:

> **Conditional theorem.**  No primitive-diagonal growth-four finite-support
> periodic highway can satisfy `f_c<=3` on every transverse cut.

This upgrades the earlier bounded rows `W=6,8,10,12,14` to an analytic all-width
conditional theorem.  It still does not touch the literal period-62 near-model
whose profile contains `f_c=9`. At this checkpoint, the unrestricted problem was to
control a fat cut (`f_c>=5`, since the line-parity law forbids `f_c=4` in the
relevant interior regime), or to derive a different contradiction that does not
bound the crossing profile.
