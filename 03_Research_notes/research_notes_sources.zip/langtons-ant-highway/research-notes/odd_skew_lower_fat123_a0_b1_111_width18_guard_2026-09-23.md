# The width-18 upper guard is excluded for lower fat `(0,1,111)`

Later result (24 September 2026): [the final width-18 fat placement exclusion](odd_skew_lower_fat123_a0_b1_111_width18_b_2026-09-24.md), together with the other width-18 exclusions, strengthens the uniform lower-band width bound beyond the earlier value recorded below. The lower band at arbitrary width remains open.

24 September 2026. This concerns drift `(1,-3)` and the lower `(1,2,3)`
stable-word band with `omega_3=0`, `omega_4=1`, and `(j,k,l)=(1,1,1)`.
The endpoint P22, odd-skew moment, and rank conditions leave exactly one
upper-guard wake placement at width 18:

```text
O={0,2,4,5,11,16,17,18}.
```

From the upper cap, its inward wake offsets are
`{0,1,2,7,13,14,16,18}`. A complete upper-guard stable-word frontier,
using the exact unbounded integer clock and finite witnessed first returns,
has the following counts:

| Inward offset | Wake | Surviving prefixes | Count rows | Adjacency words | Rejection |
|---:|---:|---:|---:|---:|---|
| 3 | 0 | 2 | 1 | 2 | — |
| 4 | 0 | 1 | 4 | 1 | — |
| 5 | 0 | 1 | 1 | 2 | one clock contradiction |
| 6 | 0 | 5 | 3 | 5 | — |
| 7 | 1 | **0** | 14 | 5 | all five wrong witnessed returns |

Thus the upper cap cannot reach the center. No lower/upper word join is
needed for this placement. The period variable satisfies `N=6 (mod 8)`
and is otherwise unbounded above; a quotient repeat is never treated as a
physical first return without a finite witness.

Run `python code/python/verify_lower_fat123_a0_b1_111_width18_guard.py`
from the repository root. The checker writes
`results/lower_fat123_a0_b1_111_width18_guard_checks_2026-09-23.json`.
The other two width-18 upper-fat placements under study are not addressed
by this result; the uniform bound for this lower band remains `W>=18`.
