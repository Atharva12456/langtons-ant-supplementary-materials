# Upper (1,2,2): quiet three through six require quiet seven

For literal drift `(1,3)`, an upper F122 cap with quiet inward offsets
three through six must also have quiet seven. The result holds at
every growth, width and positive integer period. It is a
computer-assisted local obstruction, with a complete raw-word domain
and independent geometric and clock verification. The full
growth-eight orbit remains **open**.

The upper half-turn gauge has seed rows `0:NR`, `1:WR,WL`,
`2:NR,SL` and clock shift `1+N*dx`. The only clock assumptions are
unbounded integer `N>=1` and strict stable order. No growth, P22,
period residue, four-step gap, imposed visit ceiling or width cutoff
is used.

The independently written raw generator uses the exact finite
port-count recurrence from flow and R-minus-L balance. It enumerates
every alternating word for each nonnegative count vector. At offset
seven it requires wake; at offset eight it includes both wake bits.
Every rejection has a saved physical first-return witness or a
rederived Z3 UNSAT clock system. No adjacency pruning or frontier
engine is imported.

| Offset | Input prefixes | Count vectors | Raw words | Physical rejects | Clock rejects | Prefixes left |
|---|---:|---:|---:|---:|---:|---:|
| 3 | 1 | 1 | 2 | 0 | 0 | 2 |
| 4 | 2 | 4 | 38 | 34 | 1 | 3 |
| 5 | 3 | 6 | 57 | 52 | 0 | 5 |
| 6 | 5 | 15 | 230 | 214 | 5 | 11 |
| 7 | 11 | 32 | 3,967 | 3,963 | 0 | 4 |
| 8, both bits | 4 | 28 | 1,992 | 1,992 | 0 | 0 |

Thus there is no necessary extension at eight for the proposed
wake-seven schedule. All 6,255 physical certificates were independently
replayed using compass coordinates and ordinal edge matching. All six
clock rejects were independently rederived. Run

```text
python work_positive_skew_upper_quiet6_wake7_20261001/verify_raw.py
```

Together with the earlier quiet-three-through-seven lemma, quiet
three through six therefore require **wake eight**, with quiet seven.

## Consequence for lower band C and upper F122

Band C's lower fixed wakes are `0,2,3,4`. Its only possible negative
wakes belong to fibre zero, at levels `3 mod6`. Suppose upper seven
were wake. Then `W-7=3 mod6`, so `W=4 mod6`. The positive wakes
`4,W` already fill fibre two; upper six would be a third positive wake
in that fibre and is quiet. Upper four must also be quiet: otherwise
the pair `W-4,W-7` is an opposite-sign pair disjoint from the lower
pair `0,3`, forbidden by growth-eight P22. Established `W>=18`
ensures those four cells are distinct.

Band C already forces quiet upper three and five. It would consequently
have quiet three through six and wake seven, contrary to the new
local theorem. Hence **C/upper-F122 has quiet upper seven at every
width and period**. This excludes its entire upper-wake-seven branch;
the same assertion is not made for the distinct upper F123 cap.

If upper four is quiet and six is also quiet, the allquiet local lemma
forces wake eight. If six is wake, the separately checked
[upper-six obstruction](positive_skew_bandC_upper6_wake8_reduction_2026-10-01.md)
forces wake eight by the C endpoint classification. Thus
**C/upper-F122 quiet four always requires wake eight**.

## Exact quiet-four/quiet-six endpoint families

For the quiet-six case, the fixed wake set is
`F={0,2,3,4,W-8,W}`. The two residuals are strictly between four and
`W-8`. P22 gives the following four exhaustive arithmetic families:

| W | Residuals | Bounds and parity | Minimal endpoint width |
|---|---|---|---:|
| `6m` | `{6q,6p+2}` | `1<=q<=p<=m-2`, p+q even | 18 |
| `6m+2` | `{6q,6p+4}` | `1<=q<p<=m-2`, p+q odd | 26 |
| `6m+4` | `{6p,6q}` | `1<=p<q<=m-1`, p+q odd | 22 |
| `6m+4` | `{6p+3,6q+3}` | `1<=p<q<=m-2`, p+q even | 34 |

At W zero modulo six the extra signs are positive fibres zero/one;
at W two they are positive fibres zero/two. At W four both residuals
are in the already mixed fibre zero, with either common sign. Every
other fibre/sign choice violates the required `4,2,2` distribution.

For the first two rows, the fixed increasing-fibre rank is seven;
the two residuals add four cross terms and a mutual term
`[q<=p]`. Rank is therefore `11+[q<=p]` and requires q<=p.
Their moments modulo four are `1+2(p+q)` and `3+2(p+q)`.
The latter parity forces q<p. For the last two rows, fixed rank is
ten and residual cross terms add four; rank is even without another
condition. Moments are `3+2(p+q)` and `1-2(p+q)`, respectively.
The residual interval gives exactly the bounds in the table.
Substitution proves sufficiency for P22, moment and rank only.

The independent original-coordinate checker exhausts all residual
positions at every even width 18 through 150. It finds exactly
1,222, 946, 1,078 and 825 accepted sets in table order and matches
every formula and minimum. Run

```text
python work_positive_skew_upper_quiet6_wake7_20261001/verify_C_quiet4_quiet6_families.py
```

The hand sign/rank/moment derivation establishes the unbounded
arithmetic scope; the finite checks regress it. These families still
have unbounded endpoint freedom. Their coupled physical chronology,
the quiet-four/wake-six family, and the upper-wake-four branches remain
unresolved.
