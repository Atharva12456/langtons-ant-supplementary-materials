# Primitive-diagonal growth four: exact chronology frontier (20 August 2026)

Subsequent status: the unrestricted primitive-diagonal growth-four case is
excluded by the analytic reduction and computer-assisted affine classification
in [the top-boundary note](primitive_g4_cap5_symbolic_2026-08-22.md). The
growth-eight cases remain open. The entries below preserve the earlier
checkpoint and its intermediate questions.

## Status

This note continues `line_parity_research_2026-08-18.md`. It does **not** prove
`g>=8`, `g>=12`, or uniqueness of the standard highway.

What is proved before this note:

- diagonal periodic highways have even transverse width `W>=10` (the exclusions
  at widths four, six and eight are computer-assisted all-period results);
- axis and even-diagonal growth-four drift are impossible at every period;
- for primitive drift `d=(1,-1)` and growth four, the four wake levels split
  `3` horizontal to `1` vertical and `N=6 (mod 8)`;
- the extremal levels are singleton right-turn rails, and the adjacent level has
  the forced arrival strings recorded in the 18 August note.

At this checkpoint, primitive-diagonal growth four was the only remaining
`g=4` family. Every `g=8` geometry remains open.

## Stable prefix charge

For one transverse class, order its period events by the stabilised key

```text
tau_i = i - N x_i                       (d=(1,-1)).
```

For the resulting turn word define the prefix charge

```text
q(k) = #R in the first k events - #L in the first k events.
```

The stabilised-word part of the exact finite-support criterion is

```text
q(k) in {0,1} for every k, with q(0)=0.
```

Equivalently, the word is `R,L,R,L,...`. The full criterion also includes its
finite partial-class conditions. The lower inequality `q(k)>=0` is the
right-before-matching-left (black-lifetime) half; the upper inequality `q(k)<=1`
is the left-before-next-right (white-lifetime) half. Neither half may be silently
replaced by a sum over the class: earlier exact countermodels have all class sums
nonpositive while retaining positive individual arcs.

## Exact countermodel to the upper-half-only route

The word

```text
RRRRRRLRLRLLRRRLLLLLRLRRLLRRLLRRRLLLLRLLLRLRRRRRRLRRLL
```

with initial heading north has:

```text
N = 54
endpoint = (1,-1)
heading reset = yes
growth = 4
transverse width W = 10
extremal levels = -7,3, both singleton
odd/excess-one levels = {-7,-5,2,3}, with the required 3-to-1 parity split
every class excess in {0,1}
```

Every intended left-to-next-right lifted-time inequality holds: in prefix language,
`q(k)<=1` in every stabilised class. Nevertheless the word is not finite-support
realisable: it fails full P3 and ordinary same-cell alternation. More precisely,
nine within-period cells are defective, containing eleven adjacent
equal-turn pairs. It is therefore a **near-model, not a highway**, and proves that the upper half alone
cannot follow from the counting laws, singleton rails, endpoint, and one-tour
geometry.

The complementary lower-half route has survived stronger hostile searches that also
imposed ordinary same-cell alternation, but only as bounded evidence. Double-swap
searches reached candidates with two ordinary alternation defects and six negative
prefix defects; no exact lower-half model was found. This is not a theorem and no
absence claim should be promoted.

A separate 20 August hill-climb put ordinary same-cell defects directly into the
objective. Its best exact structural point had `W=12`, one ordinary defect, and nine
negative-prefix defects; it found no zero-defect countermodel before the bounded run
was stopped. This is a different Pareto point, not stronger absence evidence, and
the scratch search is not a released certificate.

Small-period checks also delimit its scope. At `N=14`, one physically alternating
primitive structural word satisfies every lower prefix inequality, and at `N=22`
one satisfies every upper prefix inequality. Both have width below ten. Any viable
one-sided theorem must therefore use the proved `W>=10` barrier, not merely primitive
growth four and ordinary same-cell alternation.

## Standard-highway deletion counterexample

The standard period-104 highway itself rules out a general pose-factor deletion
lemma. In one unwrapped period there are 36 proper same-heading factors whose
displacement is the full `(2,-2)`. None of the 36 repeated factors passes the exact
finite-support criterion. Only one complementary zero-pose factor is the word
`RRRR`; the other complements have lengths from 8 to 100 and arbitrary turn words.
Hence neither “the boundary factor has an `RRRR` cap” nor “delete a zero-displacement
pose loop and inherit P3” is valid without a new, much stronger separation theorem.

## Narrowest viable next theorem

The remaining proof target must retain literal same-cell chronology, lifted class
order, and the proved width barrier. A useful sufficient contradiction would be:

> In every heading-reset, single-tour primitive-diagonal growth-four trace with
> `W>=10`, singleton extremal rails, and ordinary same-cell alternation, some
> stabilised class has a prefix with `q(k)<0`.

Proving instead that some prefix has `q(k)>1` would also work, but the exact
upper-half countermodel makes that direction less plausible. Aggregate class
voltages, start-only or end-only conditions, deletion inheritance, and a bounded
offset transfer matrix have all been falsified and should not be revisited without
new input.

## A proved Dyck reduction for the lower half

There is a useful exact reduction that does not solve the remaining problem.  Put

```text
delta_t = #R_t - #L_t
```

for a complete stabilised level word, and let `omega_t` be its odd-class indicator.
The per-level mod-four theorem gives `delta_t = omega_t (mod 4)`.  If every prefix
charge is nonnegative, then in particular `delta_t>=0`.  Since

```text
sum_t delta_t = growth = 4 = sum_t omega_t,
```

every nonnegative difference `delta_t-omega_t`, being divisible by four, must
vanish.  Therefore

```text
delta_t = omega_t  for every level t.
```

Thus every even class word is a Dyck word, and every odd class word is a Dyck
prefix ending at height one.  This is a proved consequence of the lower half, not a
computational observation.  It converts the remaining chronology question into a
simultaneous Catalan-order problem on all transverse levels.

## Crossing cap three: analytic all-width conditional exclusion

The restriction `f_c<=3` is not automatic, but within it the counting layer is
completely explicit.  Normalize the unique bottom rail to level zero.  If the two
interior wake levels are the even (horizontal-arrival) level `h` and odd
(vertical-arrival) level `v`, then the level multiplicities are one on the rails,
five at `h`, three at `v`, and four elsewhere.  The recurrence

```text
f_t = m_t - f_{t-1},   f_0=1
```

determines the whole crossing profile.  Before imposing the endpoint there are
`(W/2)(W/2-1)` weak profiles.  The endpoint identity

```text
y = sum_c (-1)^c f_c = -1
```

is equivalent to `h+v=W+1`; hence exactly `W/2-1` profiles remain, all with
`N=4W-2`.  This profile classification is analytic.

The earlier bounded computation has now been replaced by an all-width analytic
argument.  Encode the positive transverse excursion as the contour of a rooted
plane tree.  A frontier node records its longitudinal base and the horizontal
voltage of its complete subtree.  If the frontier is at depth `t`, put
`s_t=+1` for even `t` and `s_t=-1` for odd `t`; a parent with child voltages
`w_1,...,w_k` has

```text
v=s_t+w_1+...+w_k.
```

The cap, the one-wake-per-parity budget, and the lower-prefix condition leave
exactly five affine frontier families after four levels:

```text
profile       bases       voltages             budgets       domain
3,1,2,2       2,b         b-2,-b               0,1           b>=3
3,1,2,3       2,b,c       b-2,c-b,-c           1,1           max(b,c)>=3
3,1,3,2       2,b         b-2,-b-1             1,0           b>=3
3,2,1,3       2,b,c       b-2,c-b,2-c          1,1           b,c>=2, not both 2
3,2,2,2       2,b         b-2,1-b              1,0           b>=3
```

At the fifth level every cap-three continuation has exactly one nonleaf parent,
so every other parent must have leaf voltage `-1`.  The first, third, and fifth
families have no such leaf; the second has no admissible pair of them.  The fourth
has one candidate, `(b,c)=(4,3)`, but its stable word is `RLLR`, whose third
prefix is negative.  Hence no branch reaches the fifth interior level.  The full
case split, including the corresponding degree rows, is recorded in
`primitive_g4_cap3_analytic_2026-08-20.md`.

Therefore no primitive-diagonal growth-four periodic highway with `W>=6` can have
`f_c<=3` on every transverse cut.  Since the proved width bound is `W>=10`, this
excludes the cap-three regime for all periods and widths.  The proof deliberately
uses neither ordinary same-cell chronology nor the upper-prefix half of the
periodic-realisability criterion.

The two separately structured projected-tour enumerators remain useful independent
bounded corroboration and a width-four positive control:

```text
W    weak profiles    raw tours    endpoint/growth    q>=0
4          2               24               6          1
6          6              360              60          0
8         12            3,888             498          0
10        20           37,584           4,008          0
12        30          347,976          32,430          0
```

The width-four survivor is the known positive control
`LLLRLRRRRLRRRR` in the north-facing phase, with profile `(1,3,2,1)` and stable
level words

```text
R, RLRL, RLRRL, RRL, R.
```

At width six, exactly seven endpoint/growth tours keep levels zero through three
Dyck; all seven first fail at level four, with word `LRRRL`, `LRRL`, or `LLLL`.
The affine frontier proof explains this first failure uniformly, without bounding
the longitudinal offsets, period, or width.

Reproduction:

```text
python code/python/primitive_g4_projected_tours.py --max-width 12 --assert-known
python code/python/verify_primitive_g4_projected_indep.py --max-width 12
python code/python/audit_primitive_g4_projected.py
results/primitive_g4_projected_w12.json
```

The table is a **bounded computer-assisted cross-check** of the analytic conditional
theorem.  The theorem still says nothing about an unrestricted profile with a fat
cut.  In the relevant interior regime the line-parity law rules out `f_c=4`, so the
remaining branch has some `f_c>=5`.

## A literal fat-profile near-model

Ordinary same-cell alternation alone is not the missing theorem.  A direct search
over finite initial colourings found the north-facing word

```text
LRRLRLRLRRRRLRLLRLLRLRRRRLLLLRLRRRRLLLLRLRRLRLLRRRRLLRLLLLRRRR
```

with the following independently replayed data:

```text
N=62, endpoint=(1,-1), heading restored, growth=4, W=10,
crossing profile=(1,3,5,2,3,9,3,1,3,1),
singleton bottom and top rails, four class excesses equal to one,
ordinary same-cell defects=0.
```

It is a literal one-period Langton trace from a finite initial colouring, not merely
an abstract turn word.  It is nevertheless not a highway certificate.  Its total
negative lower-prefix depth is seven, on four levels:

```text
t=-1: RLLRLRLR
t= 1: LRRLR
t= 4: LRLR
t= 5: LRRL
```

The largest crossing number is nine, so the example also shows exactly why the
cap-three computation cannot be promoted to the general primitive case.  An
exhaustive tape-bit neighbourhood through radius four visited 410,847 finite
colourings and found no exact structural point with a smaller lower deficit; this
last sentence is local search evidence only.

## Failed spatial-chain/connectivity interpretation

The lower condition `q(k)>=0` defines nonnegative black-lifetime intervals on the
disjoint union of lifted class-time lines. It does **not** make the projected
one-period ant curve the boundary of a nonnegative finite spatial 2-chain. The
period curve has homology one on the translation cylinder, whereas every finite
2-chain boundary is null-homologous. Subtracting any of the canonical straight
single-cut cylinder generators does not repair the sign problem: the literal
primitive word `LLLRLRRRRLRRRR` has ordinary same-cell alternation and nonnegative
stable prefixes, but every relative filling in that canonical family has both
positive and negative coefficients. This statement is deliberately not made for
an arbitrary homologous representative (choosing the period curve itself would
make the difference zero).

Connectivity also does not transfer to net growth. In that word the four stable
wake representatives have two Tait components, while the seven positive toggles
form one spanning component and three negative toggles reduce the net growth to
four. The genuine standard highway is decisive at `W=10`: full P3 holds, yet its
twelve canonical strand bases form four Tait components, and its 22 positive
one-period toggles form five components before ten removals. The dynamically shed
twelve-edge tree is a different, phase-aligned object containing carried widget
edges. Consequently neither stable representatives nor positive toggles support a
connectivity bound on `g`; the representative choice is also gauge-dependent under
shifts by the drift. Do not infer `g>=W/2+2` from `q>=0`.
