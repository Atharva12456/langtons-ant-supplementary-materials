# Necessary chronology at quiet bridges for literal drift (1,3)

Update, 4 October: the later width-22 investigation described in section
5 is now [completely and independently verified as an exclusion](positive_skew_thin011_width22_exclusion_2026-10-04.md).
The remainder of this note records the earlier verified state and scopes.

The growth-eight orbit remains **OPEN**. This note excludes the saturated
lower-thin101 / upper-F123 wakes-seven/eight family at width 24 and adds
a hand bridge restriction, a complete independently checked upper-thin110
frontier through inward row twelve, and two proved early pruning rules.
Neither the 5,114 remaining thin/F122 arithmetic templates nor the whole
orbit is excluded by these results. Those templates are necessary endpoint
data, not trajectories or a completion measure.

## 1. A positive horizontal transfer after lower thin101

Use `t=3x-y`, physical cell `(k,-t+3k)`, and lower clock
`tau(target)-tau(source)=1-N*dx`. The hand-forced thin101 rows zero
through seven have thirty events. Condition on quiet row eight being
`SR SL` and on quiet row nine. Flow forces row nine to `(ER WL)^5`.
Allow either bit `omega10` at row ten, and assume row eleven is quiet.

All exact row-ten count vectors are

```text
SR=s, SL=10-s, NL=6-s, NR=16+omega10-3s, 0<=s<=5.
```

Let `D_i` be its i-th west departure and `S_j` its j-th south arrival.
Three four-step physical first returns, each with direction word `WNES`,
force the adjacencies

```text
D1 -> S1, D4 -> S3, D6 -> S7.
```

The paths traverse old row-seven W arrivals one, four, six; the
corresponding row-six N arrivals one, four, five; and row-nine E arrivals
one, two, four. Their physical positions are
`(0,-10),(-1,-10),(-1,-9),(0,-9),(0,-10)`. Thus their endpoints must
be the immediately next stable visits, with the opposite turn.

The first adjacency gives `D1=NL`, followed by `S1=SR=D2`. The last
gives `D6=SR=S6`, followed by `S7=SL`: otherwise another west departure
would be required. Two SR events cannot be consecutive in both the
departure and arrival ordinal lists, since their intervening L adds either
an N-arrival/west departure or a south arrival/east departure.

If `D4=NL`, then `S3=SR=D5`, and the departure types must be
`NL,SR,NL,NL,SR,SR`, giving `s=3`. If `D4=SR=S2`, its preceding
L is necessarily `D3=NL`; the two possible types of D5 give `s=3`
or `s=4`. This exhausts the cases. Consequently

```text
SR10 is 3 or 4;
H10 = east_departures10-west_departures10 = 8+omega10 or 4+omega10.
```

The restriction is independent of period, width, growth, and later
events, subject to the stated local prefix. In particular, it excludes
the previously exhibited zero-displacement count pump's choice `s=5`.
It does not prove positive transfer at every later cut, or force row eight
to have this word.

The [full hand classification](../work_positive_skew_thin101_pump_chronology_20261002/pump_hand_obstruction.md)
lists the six exact row-ten words. The wake-ten versions append a final
NR to the quiet-ten versions. Independent all-raw enumeration covers
85,102 quiet-ten and 100,102 wake-ten words and gives exactly these forms.
For quiet eleven, 112 raw extensions of the quiet-ten forms leave three
prefixes: 103 physical rejects and six clock rejects. The wake-ten forms
have 124 raw extensions, with 114 physical rejects, seven strong-clock
rejects, and three survivors.

The surviving local clock witnesses are `N=82,82,74` in the quiet-ten
case and `N=86,86,78` in the wake-ten case. These satisfy gap four,
`N=2 mod4`, and `N>=max(62,assigned lower events)`; they are necessary
local models, not periods of constructed highways. The complete
1,296-word pump regression rejects every proposed block by a finite
wrong physical first return. A tentative eighteen-step clock path was
an ordinal error and is not part of the proof.

At **W=24** in the saturated upper-F123 wakes-seven/eight family,
the row-eight choice `SR SL` is impossible. The complete upper domain
through offset ten has 32 prefixes and four displacement profiles. It
has been freshly independently regenerated through offsets three to ten,
covering 1,647 exact vectors and 112,685,722 raw words represented, with
2,274 physical certificates and 96 unbounded upper-clock contradictions.

The two surviving quiet-ten A words give 17 W arrivals at lower row
eleven. Upper offset ten, mapped to global row fourteen, has at most
13 west departures, so these cannot join. The B word has 13 W arrivals,
forcing the upper profile `(Hu,Vu)=(19,-5)`. That profile has 13 W
arrivals at upper offset nine, hence 13 E arrivals at global row fifteen.
For lower row twelve, exact quiet flow gives E departures `21-4s12`;
the edge from twelve to fifteen therefore forces `s12=2`. Its horizontal
contribution is eight, and lower bridge eight through thirteen contributes
horizontal total `0+4+8=12`. The upper profile instead requires sixteen,
since the fixed lower cap contributes four and the physical upper cap
contributes minus nineteen to the required full displacement one.
This is a contradiction before any word search at twelve/thirteen.

The corrected full count audit finds exactly one balanced profile in
this row-eight branch, with net displacement `(-3,-9)` instead of
`(1,3)`. A first draft of that regression mishandled explicit zero count
fields; it was corrected and rerun before use. See the
[width-24 conditional proof](../work_positive_skew_thin101_pump_chronology_20261002/W24_SRSL_count_obstruction.md).
The other row-eight words are excluded by a complete
independently audited two-cap join. Their common count vector is
`NR3,NL1,SL2`, giving three raw words. The complete raw row-nine audit
covers 1,422 words: 1,352 wrong physical returns, sixteen weak clock
contradictions, and 54 necessary lower prefixes. Exact full-strip flow
and literal displacement leave sixteen primitive count profiles. With
their matching upper words these give 1,728 boundary pairs, of which
432 already fail the fixed-period clock.

Each period is the sum of the event counts on all 25 rows, in the derived
range 174 through 254. This range is not a search ceiling. The remaining
joined extension is complete:

| Added lower row | Necessary words | Physical rejects | Clock rejects | Survivors |
|---|---:|---:|---:|---:|
| 10 | 4,608 | 2,624 | 880 | 1,104 |
| 11 | 15,700 | 11,120 | 3,956 | 624 |
| 12 | 1,918 | 1,902 | 16 | 0 |

The independent checker imports no frontier, join, or clock
implementation. It regenerates all words with zero-copy adjacency and
applies translated order afterward; no complete word is removed at that
extra step, so signed pruning is unnecessary to this exclusion's proof.
Fresh compass traces replay all 16,998 physical certificates, including
raw row nine. All 5,284 fixed-period clock contradictions have separately
checked positive stable-order cycles; every clock component is checked
to be exactly one connected component of the equality graph, so separate
free roots cannot be merged. The sixteen weak row-nine
clocks were freshly proved UNSAT in Z3. The
[independent joined audit](../work_positive_skew_thin101_pump_chronology_20261002/W24_join_independent_audit.json)
therefore closes this **entire saturated cap family at W=24**. Together
with its previously excluded W=18 member, its remaining possible widths
are `W=6m>=30`. The [complete proof chain](../work_positive_skew_thin101_pump_chronology_20261002/W24_saturated_thin101_exclusion.md)
also derives every one of the sixteen count profiles without a count
ceiling. Other cap families and arbitrary widths remain open.

## 2. The forced upper quiet band for lower thin110

The remaining lower-thin110 / upper-F122 wakes-four/seven family has
exact endpoint parameters

```text
W=6m+4,
O={0,4,5,6,6r+5,W-7,W-4,W},
1<=r<=m-3, m-r odd.
```

Its minimum width is 28, and the residual upper wake is at distance
`17+12h`. Upper inward offsets eight through sixteen are therefore quiet.
The lower rows zero through seven contain 34 events. Their band is
disjoint from the assigned upper band through sixteen for every such
width, so every actual period satisfies

```text
N >= max(62, assigned upper events + 34), N=2 mod4.
```

The upper half-turn preserves R/L and uses clock increments `1+N*dx`.
No upper bound on N or visit counts is imposed.

The complete weak source through upper row eleven has 97 words. A fresh
independent reconstruction of stages three through eleven accounts for
1,294 vectors and 18,609,809 raw words; its geometry and weak clocks
agree with the saved source. Imposing the shared period domain retains
55 source words and rejects 42, with independent original-variable Z3
checks of all 97 statuses and all supplied SAT periods.

Extending these 55 parents through quiet row twelve is complete:

| Quantity | Count |
|---|---:|
| Exact count vectors | 262 |
| Raw alternating words represented | 46,445,636 |
| Necessary words emitted by the original generator | 38,960 |
| Wrong physical first returns | 12,377 |
| Shared-period clock contradictions | 24,507 |
| Necessary survivors | 2,076 |

Every vector and emitted word was independently regenerated without
memoization. Every physical certificate was replayed; every clock reject
has an independent affine proof. All 2,076 survivors passed literal
integer event-time checks and original-variable Z3 checks. Another 275
UNSAT coefficient-signature/floor representatives were checked in Z3.
The [independent review](../work_positive_skew_upper47_audit_20261002/independent_review.md)
and [verified seed](../work_positive_skew_upper47_audit_20261002/verified_shared12_seed.json)
record the scope. The historically incomplete parent 030 is superseded
by its complete report and supplies no exclusion itself.

## 3. Translated excursion order before word completion

Suppose a new-row departure follows old assigned ordinal events and
first re-enters the new row after L steps in copy k. A found excursion
visits no old ordinal twice, so `L<=old assigned events+1`. Whenever a
proved period floor gives `N>L`, the upper clock equation is

```text
tau(target)-tau(departure)=L+N*k.
```

For k positive the target event is strictly later; for k negative it is
strictly earlier. The lower gauge reverses these voltage signs. For k
zero the physical next-visit adjacency still applies.

When appending a port to a generated word, a positive upper excursion
requires its target incoming ordinal to be at least the heading's arrival
count **after** appending that port. A negative upper excursion requires
it to be smaller than that count **before** appending. This distinction
excludes a false self-target. These counters are determined by remaining
port counts, so the existing adjacency memoization remains valid.

The shared floor in section 2 proves the strict length premise. An
independent nonmemoized generator and a direct full-word filter agree
with the isolated implementation for all 262 complete row-twelve
domains. They retain 27,096 of the original 38,960 candidates and every
one of the 2,076 survivors. The 11,864 removed words are independently
clock-infeasible in this domain, including 3,751 words that the original
pipeline rejected first by geometry. Both clock signs and self-target
boundaries were additionally checked on 55,200 direct comparisons.
See the [signed-excursion proof](../work_positive_skew_upper47_audit_20261002/signed_excursion_order_20261003.md).

## 4. Wrong returns to old rows using one new visit

There is also a period-independent necessary filter. Start at an old
stable event and follow the assigned old ordinal graph until its first
physical return or its first new-row entry. In the latter case, the
incoming heading and ordinal are fixed. A proposed new port and outgoing
ordinal determine the next old event. Follow that old path until its
first physical return to the starting cell or its next unassigned entry.
If the first physical return is to an old stable index other than the
starting index plus one, that incoming/port/outgoing-ordinal combination
is impossible.

This uses exactly one new-row event. Excursions requiring more such
events are left untested. Nonzero-copy quotient returns are never used
as physical adjacencies. The forbidden pair depends only on the incoming
and outgoing counters and port, so it also preserves the memoization key.

Independent compass traces replay all 3,876 conditional pair witnesses
across the complete row-twelve domain. On all 38,960 original candidates,
this filter removes exactly the 12,377 physical rejects and no clock or
SAT word. Together with translated order it emits 18,470 candidates:
16,394 clock rejects and all 2,076 survivors. No extra phase, period,
growth, or width premise is added by the physical-pair rule.
The [physical-pair proof and audit](../work_positive_skew_upper47_audit_20261002/physical_pair_guard_20261003.md)
records the independently replayed witnesses and current source hashes.

On fourteen already complete row-thirteen parents, the combined generator
reproduces all 1,442 survivors. It reduces emitted words from 39,544
to 8,780 and recursion nodes from 576,085 to 147,132. This is a
calibration on a subset, not completion of row thirteen or orbit closure.

## 5. Incomplete work at the 3 October checkpoint

At the 3 October checkpoint, the guarded row-thirteen continuation had
completed 17 of 2,076 parents, carrying fourteen earlier complete parents without shrinking
their domains. Parent 17 hit the explicit invocation wall-time limit.
Its partial output is **INCOMPLETE**, and neither that output nor the
3,906 survivors from completed parents is a complete row-thirteen domain.
The prefix-clock prototype agrees with three complete parent outputs but
is slower on that sample; it is not used in the certified continuation.
A twenty-prefix quiet-fourteen diagnostic has fourteen empty next-row
domains and six nonempty ones. This is a diagnostic subset only.

Separately, the width-22 lower-thin011 / upper-F123 wake-six join has an
independently checked full count domain: 921 balanced matrices, of which
221 have literal displacement `(1,3)`. The complete row-eight word join
has 3,450 candidates, 1,932 fixed-period/gap-four clock rejects, and
1,518 survivors. Periods 210, 226, 242 are derived from the complete
event counts rather than imposed as a numerical search ceiling. At that
checkpoint, later joining stages remained under investigation; these
preliminary results did not close width 22 or the arbitrary-width cap family.
The 4 October update above records the subsequent width-22 exclusion.

All seven remaining lower-thin members and the remaining fat lower cap
pairs retain open cases. Arbitrary-width physical and chronological
coupling remains the step required for whole-orbit closure. The paper
artifacts are unchanged in this continuation.

## Reproduction

Run from the project root:

```text
python work_positive_skew_thin101_pump_chronology_20261002/verify_pump.py
python work_positive_skew_thin101_pump_chronology_20261002/audit_row10_row11_raw.py
python work_positive_skew_thin101_pump_chronology_20261002/audit_wake10_quiet11.py
python work_positive_skew_thin101_pump_chronology_20261002/audit_upper32_source.py
python work_positive_skew_thin101_pump_chronology_20261002/audit_W24_join.py
python work_positive_skew_upper47_audit_20261002/audit_shared12.py
python work_positive_skew_upper47_audit_20261002/audit_ordered_excursions.py
python work_positive_skew_upper47_audit_20261002/audit_physical_pairs.py
```

The proof programs and independent reports preserve exact source hashes.
The continuation script's wall-time and node limits only produce explicit
incompleteness; they never imply an exclusion.
