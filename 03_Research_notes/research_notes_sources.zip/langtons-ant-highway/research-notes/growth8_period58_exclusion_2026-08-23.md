# Growth eight does not occur at period 58

## Result

There is no finite-support periodic highway with ant period `N=58` and growth
`g=8`.

The fixed-growth search used a normalized length-12 prefix. Its 2,048 ranks
were divided into 256 half-open intervals of eight ranks. Every interval was
searched to completion, no node cap was present, and the optional deficit rule
was disabled. The aggregate counters are

```text
prefix ranks                    2,048
search nodes          638,341,904,284
endpoint prunes       110,337,123,373
growth prunes         120,193,469,311
residue checks         13,798,101,325
residue prunes         13,060,756,064
P3 checks                 737,345,261
accepted words                      0
aggregate core time       74,789.300 s
```

The residue filter is a proved necessary condition. Every leaf that passes it
is checked by the exact stabilized translation-class criterion P3.

## Certificate audit

The 256 raw shards and their manifest are archived in
`records/g8_p58_shards`. The aggregate auditor reconstructed each prefix from
its rank, checked every interval and per-rank counter sum, required uncapped
completion, compared the two copies of every hit list, and recorded a SHA-256
digest for every shard. Re-aggregating the archive reproduced the result file
byte for byte:

```text
results/growth8_period58_exclusion.json
c823cf229a5204e9d8ff34ea4dd8b65738aaf023cd5d712199101fba77c17e1f
```

The source digests used by the archived audit are

```text
code/java/PositiveGrowthResidueSearch.java
315c18bd3f7749750fc8c618d5b3f464756d2ddd64bda5dd9be4cbb1f33e9c23

code/python/run_target_growth_shards.py
6c0e1db9b6ca7d6a34a9528cdf2905d9ddfd98bd995765bddef675ca894b1cc7

code/python/aggregate_target_growth_shards.py
c4db9da60a9b19e634a51d552420528e1cf43868d4754bf3d633cf951f920925
```

The archive can be re-audited with

```text
python code/python/aggregate_target_growth_shards.py records/g8_p58_shards \
  --output results/growth8_period58_exclusion.json
```

Together with the exclusions through period 56, this removes growth eight
through period 58. It is a finite-period result; all ten drift orbits retain
open cases. The subsequent [period-60 record](growth8_period60_exclusion_2026-08-25.md)
extends the finite exclusion through period 60.

