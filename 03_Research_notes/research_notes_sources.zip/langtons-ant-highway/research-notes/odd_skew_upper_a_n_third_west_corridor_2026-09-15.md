# The third west departure in continuation N

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: the whole N continuation, including
R1, R2, L1, and L2, is excluded in
`odd_skew_upper_a_r_exclusion_2026-09-15.md`.

The four offset-ten words R1, R2, L1, and L2 remain
open. Their possible north arrivals on eleven can be
restricted further without choosing a word on twelve.

In both right-turn cases R1 and R2, the second west
departure on eleven is `SR`. In R2 the third is also
`SR`. In L1, if the third west departure is `NL`, it
must be the fifth north arrival, supplied by the fourth
`WR` on ten. In either turn case, L1 requires a gap of
at least sixteen between `E1=ER` and `I=WL` on eight.

Use the notation of
`odd_skew_upper_a_n_first_east_reduction_2026-09-15.md`.
The labels R1 and R2 here name words on ten, not the
upper-cap form or distinct drift orbits.

## A twelve-step segment with no return to ten

Let `P3` be the third west departure on eleven, feeding
`8:I=WL`. Suppose `P3=NL`, and let `U` be its north
predecessor on ten. Thus `U` is either `WR` or `EL`.
There is a fixed path

```text
10:U -> 11:P3=NL -> 8:I=WL -> 7:second SR -> 4:first WL
     -> 3:SR -> 0:WR -> 1:NR -> 4:ER -> 3:first SL
     -> 6:first ER -> 5:first SL -> 8:E2=EL.
```

Its direction word is

```text
N W S W S W N E S E S E.
```

The voltage is zero, giving

```text
tau(E2) = tau(U) + 12.                              (1)
```

There is no visit to offset ten after the starting event
anywhere in these twelve steps. Hence there is no return
to the starting physical cell during that segment. The
next stable visit on ten is at least sixteen steps after
`U`, since same-cell return lengths are multiples of four.
In particular,

```text
U is the last stable event on ten before E2.          (2)
```

On nine, the second `SL`, the third `NR`, and the third
`SL` are supplied by `S2`, `E2`, and `S3` respectively,
by zero-voltage vertical steps. Therefore

```text
S2 < E2 < S3.                                       (3)
```

These restrictions are stronger than the order of north
arrivals alone: a north predecessor earlier in the word
would require a visit to ten inside the fixed segment.

## The possible predecessors of P3=NL

Combining (2) and (3) with the four words on ten gives
the following list. Subscripts on `WR` count west right
turns on ten.

| Word on ten | Possible predecessor U of P3=NL |
|---|---|
| R1 | `WR1`, between `S2` and `S3` |
| R2 | none |
| L1 | `WR4`, between `S2` and `S3` |
| L2 | `F1=EL` or the following `WR4` |

For R2, `S2=F1=ER` immediately precedes `S3=WL`.
Neither event departs north, and there is no intervening
event that could be `U`. Thus `P3=SR` in R2.

In L1, the relevant segment is

```text
F1=EL, WR3, S2=WL, WR4, S3=WL.
```

The north arrival from `F1` is already `NR`, by the
previous reduction. Only `WR4` can satisfy (2). It is
the fifth north departure on ten, so `P3` is the fifth
north arrival on eleven. In particular, the fourth north
arrival, supplied by `WR3`, is `NR`.

In L2, the segment is

```text
S2=WL, WR3, F1=EL, WR4, S3=WL.
```

The event `WR3` cannot be `U`, because `F1<E2` would
then be an intervening visit to ten. If `U=F1`, (1)
gives `E2=F1+12`, and the following `WR4` is at least
sixteen steps after `F1`; in particular, `E2<WR4`.
This is precisely the possibility with `P2=SR` and
`P3=NL` supplied by `F1`. If instead `U=WR4`, the
north arrival from `F1` is `NR`, and `P2=NL`.

## P2 turns right in R1 and R2

The fixed square through the first `SR` on seven gives

```text
tau(8:C=WL) = tau(E1) - 4.
```

The west step from `P2` to `C` has upper voltage one,
while the two-step path from `E1` to `F1` has voltage
minus one. Consequently

```text
tau(P2) = tau(C) + N - 1 = tau(F1) - 7.              (4)
```

In R1, `F1=ER` is the first event on ten. No north
arrival on eleven can occur before it, so (4) excludes
`P2=NL`. Thus `P2=SR`. There is also no north arrival
before `P1`, fixing the prefix

```text
11: P1=SR,SL,P2=SR,... .
```

In R2 the only north departure on ten before `F1` is
its initial `WR1`. If `P2=NL`, it must therefore be
the first north arrival on eleven. Then `P1=SR`
immediately precedes it. The first-east obstruction
already used in the L0 exclusion applies: the path

```text
P1 -> 8:first WR -> 9:first NR -> 12:first east arrival
```

cannot end at `ER`, which would return to `SL` instead
of `P2=NL`, or at `EL`, which would require an earlier
east arrival on twelve. Thus `P2=SR` in R2 as well.

The first west departure is again `P1=SR`: an `NL`
there would be the first north arrival, with no earlier
right turn available. The initial `WR1` on ten precedes
`S1=WL,F1=ER` by at least eight steps. Its north arrival
therefore precedes `P2`, strictly since `P2=SR`.

The next north departure on ten is after `S3`, hence
after `E2`. But `tau(P3)=tau(E2)-11`. There is only
one north arrival before `P3`, and it precedes `P2`.
The two possible prefixes in R2 are therefore

```text
11: P1=SR,SL,first NR,SL,P2=SR,SL,P3=SR,...;
11: first NR,SL,P1=SR,SL,P2=SR,SL,P3=SR,... .
```

## The gap in L1 is at least sixteen

Put `d=tau(I)-tau(E1)`. In L1 the north arrival from
`F1=EL` is `NR`; call it `V`. Since

```text
tau(P3) = tau(I) + N - 1,
tau(V)  = tau(F1) + 1 = tau(E1) + N + 3,
```

one has

```text
tau(P3) - tau(V) = d - 4.                           (5)
```

If `P3=NL`, its predecessor is `WR4`, as above. The
three consecutive gaps in

```text
10: F1=EL,WR3,S2=WL,WR4
```

total at least twelve. Comparing the north predecessors
of `V` and `P3` in (5) gives `d-4>=12`, hence `d>=16`.

Suppose instead that `P3=SR`. There must be at least
one event between the right turns `V=NR` and `P3=SR`,
so (5) gives `d>=12`. Equality would force exactly
three consecutive events

```text
11: V=NR,SL,P3=SR
```

with both gaps equal to four. Each four-step return
starts with an east departure and ends with a south
arrival, so both are the square `E N W S`. The two
east arrivals on fourteen supplied by `V` and `SL`
would consequently both be `EL`, four steps apart
at the same physical cell. This violates turn alternation.
Thus `d=12` is impossible. Since `d` is a multiple of
four, this also gives `d>=16` in the `SR` case.

No entire word on ten is excluded by these further
restrictions. R1, R2, L1, L2, continuation N, and the
`(1,-3)` orbit remain open.
