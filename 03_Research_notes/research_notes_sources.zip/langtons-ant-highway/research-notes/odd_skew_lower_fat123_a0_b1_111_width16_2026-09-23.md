# Widths through 16 excluded for the lower `(0,1,111)` fat cap

23 September 2026. This note concerns only drift `(1,-3)` and the lower
`(1,2,3)` stable-word band with `omega_3=0`, `omega_4=1`,
`(j,k,l)=(1,1,1)`. It proves the necessary width bound **`W>=18`**.
It does not exclude this band at arbitrary width or close the drift orbit.

Normalize the lower level to zero and write `t=3x+y`; the upper level is the
even integer `W`, because both extreme arrivals are horizontal. The lower cap
has wakes `{0,2,4}`. Each lies in a different residue-three fibre and has
even checker sign. P22 gives a `4+2+2` distribution: the four-class fibre has
three even and one odd wake, while the other fibres each have two even wakes.
Thus every full wake set has exactly seven even levels and one odd level.
The growth-eight period congruence therefore gives `N=6 (mod 8)`.

The upper missing cap is already excluded for this lower band, and the upper
`(1,2,2)` fat cap is excluded for the entire drift orbit. An upper guard cap
requires wakes at `W-2,W-1,W`; an upper `(1,2,3)` fat cap requires wakes at
`W-2,W` and a non-wake at `W-1`. The exact endpoint checker
`code/python/verify_lower_fat123_a0_b1_111_width16.py` enumerates all eight-wake sets at even widths 8 through
16, imposing these cap requirements, the lower wakes, P22, the odd-skew
moment `sum_{t in O}(-1)^t floor(t/3)=3 (mod 4)`, and the even rank
interlacing. It finds none through width 12. At width 14 only the upper fat
cap and

```text
O={0,2,4,8,10,11,12,14}
```

remain. At width 16 only the upper guard cap and

```text
O={0,2,4,6,12,14,15,16}
```

remain. Its output is `results/lower_fat123_a0_b1_111_width16_checks_2026-09-23.json`. The width-12 P22 placement is
`{0,2,4,6,8,9,10,12}` and has moment 1 rather than 3. At width 16, the
upper fat cap has no placement satisfying all three endpoint conditions.

For width 14, the standalone checker exhausts lower stable words through level
8 with the fixed wake pattern. It derives each row count from directional
flow and binary excess, enumerates alternating words subject to necessary
boundary-return adjacency, rejects witnessed finite wrong first returns,
and solves the exact lower-sign lifted integer clock. The 82 surviving
level-eight rows have lengths **17, 21, or 25**. On the upper side, the
initial `(1,2,3)` bands are `101`, `110`, and `200` because upper inward
offsets three and four are wakes. The checker enumerates those three seeds
directly, then excludes `101` at
offset five. The `110` and `200` bands have respectively 17 and 7 prefixes
through upper inward offset six, and all their offset-six rows have length
**9 or 13**. At `W=14`, upper inward offset six is lower level eight.
One physical quotient row cannot have both lengths, so width 14 is excluded.

For width 16, the checker leaves 82 prefixes through lower level
eight, whose row lengths are **18, 22, or 26**. Its upper-guard frontier
leaves 124 upper-guard prefixes through inward offset eight, with row lengths
**10 or 14**. These again describe the same level (`16-8=8`), so width 16
is excluded. The result JSON records the counts and row lengths. The
independent scratch frontiers and complete state lists are in
`work_a0_111_next/` in the local workspace.

All frontiers use the exact clock equations
`tau(target)-tau(source)=1+SIGN*N*voltage`, with `SIGN=-1` below and `+1`
above, `N>=max(6,represented events)`, `N=6 (mod 8)`, and same-cell gaps at
least four. A quotient-node repeat is **not** extrapolated into a physical
return. The width bound follows from the paper-level P22, moment, rank and
stable-word laws, not from a period cutoff or a claim about larger widths.

## Partial width-18 check

The standalone checker `code/python/verify_lower_fat123_a0_b1_111_width18_d.py`
finds four endpoint placements at width 18: one upper
guard placement and three upper fat placements. The fat placement

```text
O={0,2,4,12,14,15,16,18}
```

is also impossible. Its upper inward wake set is
`{0,2,3,4,6,14,16,18}`. The upper `101` and `200` initial words die by
inward offsets five and seven. The upper `110` word leaves 74 prefixes
through inward offset nine. Its four center-row port-count patterns, after
the 180-degree heading rotation, have no intersection with the three
port-count patterns of the 64 lower prefixes through level nine. The center
row is `t=9` from both ends. The canonical counts and port patterns are in
`results/lower_fat123_a0_b1_111_width18_d_checks_2026-09-23.json`;
the independent scratch states remain in `work_a0_111_next/`. The other three width-18
placements have not been excluded by this check, so **the proved uniform
bound remains `W>=18`**.

Reproduce from the repository root:

```text
python code/python/verify_lower_fat123_a0_b1_111_width16.py
python code/python/verify_lower_fat123_a0_b1_111_width18_d.py
```
