# Growth eight does not occur at period 50

The existing residue-free search excludes every finite-support periodic highway
through period 48.  The next possible period for some growth-eight residue types
is 50.  This note records a complete targeted search of that single period.

## Statement

There is no finite-support periodic highway with ant period `N=50` and growth
`g=8`.

This is a finite computer-assisted exclusion, and it does not close any
growth-eight drift family by itself.  Period 52 was subsequently excluded by a
separate run recorded in `growth8_period52_exclusion_2026-08-22.md`.

## Search

`PositiveGrowthResidueSearch.java` was run with
`--period 50 --target-growth 8 --prefix-length 12 --deficit-depths 0`.  The
normalization rotates a positive-growth cyclic word to a global minimum of its
turn balance.  The normalized word begins with `R`, so the remaining eleven
prefix symbols give exactly `2^11=2048` prefix ranks.

The ranks were divided into eight disjoint half-open intervals of length 256.
No shard used a node cap or the optional deficit rule.  At a leaf the program
first checks the signed mod-four wake-residue identity and then applies the exact
periodic-realisability criterion to every survivor.  Thus the computation uses
the proved residue theorem as a pruning lemma; it is not the residue-free search
used for the period-at-most-48 result.

The aggregate counts are

```text
prefix ranks                  2,048
search nodes         15,488,130,188
endpoint prunes       2,593,511,002
growth prunes         2,994,063,495
residue checks          327,932,571
residue prunes          313,638,967
P3 checks                14,293,604
accepted words                    0
```

Here an accepted word is a normalized turn word that passes the exact P3 test,
not merely a trace satisfying the arithmetic filters.

## Audit record

`code/python/aggregate_target_growth_shards.py` reconstructs the expected prefix
and independently recomputes its normalization/alternation validity for every
rank, checks that the rank intervals cover `0,...,2047` exactly
once, rejects a shard with a node cap or active deficit rule, compares every
top-level count with the sum of its per-rank counts, and compares the per-rank
and per-shard hit lists.  It also hashes the eight raw shard files.

The checked aggregate is
`results/growth8_period50_exclusion.json`.  It reports
`ranks_covered_exactly_once=true`, `all_checks_passed=true`, and an empty hit
list.  Its SHA-256 digest is

```text
e0b9e7637061ebfa317c4abb019e5ad3da654716b652709803aa901d791f789c
```

The search engine digest at the time of the run and the digest of the current
aggregate audit are

```text
PositiveGrowthResidueSearch.java
315c18bd3f7749750fc8c618d5b3f464756d2ddd64bda5dd9be4cbb1f33e9c23

aggregate_target_growth_shards.py
c4db9da60a9b19e634a51d552420528e1cf43868d4754bf3d633cf951f920925
```

The fixed-growth branch was also compared with the original all-growth traversal
on every even period from 4 through 18.  At each period, the sum of the separate
fixed-growth leaf, residue, and P3 counts equals the original count, and the hit
lists partition exactly.  The audit and its output are

```text
code/python/audit_target_growth_mode.py
76c62d8a893045064b5fdbc3d61c525c11a969758b383e8c634e529705b1d4ad

results/target_growth_mode_cross_check.json
1fe944da4d7903084d3b9ccffc26921c97367799cef168520ec794fcfa42fe54
```

This cross-check tests the new restriction against the prior search mode.  It
does not independently prove the residue theorem or the P3 criterion.

The raw shards are reproducible from the following command pattern, with the
eight consecutive intervals `[0,256)`, `[256,512)`, ..., `[1792,2048)`:

```text
java -cp build/residue PositiveGrowthResidueSearch \
  --period 50 --prefix-length 12 \
  --rank-start START --rank-stop STOP \
  --deficit-depths 0 --target-growth 8 \
  --output shard.json

python code/python/aggregate_target_growth_shards.py SHARD_DIRECTORY \
  --output results/growth8_period50_exclusion.json
```

Together with the residue-free period-at-most-48 computation, this run moved the
shortest possible growth-eight period to 52.  The later period-52 computation
moved it again to 54.  The all-period problem is unchanged.
