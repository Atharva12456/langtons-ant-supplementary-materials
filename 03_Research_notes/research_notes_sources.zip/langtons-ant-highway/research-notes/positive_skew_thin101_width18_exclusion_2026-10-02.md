# Lower thin 101 is impossible at width eighteen

For literal `(1,3)` at growth eight, the lower-thin `101` member cannot
have transverse width eighteen. Along with the prior width-sixteen
exclusion this gives `W>=20` for that member. It does not exclude the
member at arbitrary width, and the full orbit remains **open**.

The lower hand-rigidity theorem fixes these necessary words:

```
0 NR; 1 WR WL; 2 NR SL; 3 WR WL ER WL; 4 SR SL SR;
5 ER WL ER;
6 NR NL SR NL NR SL NR SL;
7 WR WL WR EL WR WL WR.
```

They have wakes `{0,4,5,7}`, with every other lower offset through seven
quiet. The upper extremum at eighteen is wake. Exhausting the three
other wakes among levels eight through seventeen under the original
P22, signed moment and increasing-fibre rank definitions leaves only

```
O={0,4,5,7,10,11,16,18}.
```

The upper cap is therefore F123, with upper wake offsets `{0,2,7,8}`
and quiet three through six. In particular the upper guard is impossible
because its offset one wakes, and upper F122 is impossible because its
offset two is quiet. Missing upper caps have the separate all-growth
local exclusion. This exhausts the upper possibilities.

Starting from upper `0:NR`, `1:WR,WL`, `2:NR,SL,NR`, a complete weak
unbounded-clock domain for quiet three through six and wake seven has
four, nine, 29, 140 and 99 prefixes at the successive offsets three
through seven. The independent audit rederives all 788 count vectors
and 2,146,312 raw alternating words, regenerates every emitted
candidate, replays all 428 physical rejections and proves all 69 rejected
integer clocks in Z3. The only clock assumptions are strict stable order
and integer `N>=1`, with the upper sign `+N`.

Join each of these 99 upper prefixes to the fixed lower cap, mapping
upper offset s to original level `18-s` and applying the half-turn
`E<->W`, `N<->S`, with R/L and event order unchanged. Extend to upper
offset eight, which is original level ten and must wake. The exact
port-count recurrence yields 567 count vectors. Full directed flow
against the assigned lower rows and the empty outer exteriors rejects
468. The other 99 vectors represent 61,046 raw alternating words;
zero-copy physical first-return adjacency emits 427 candidates. All
fail: 424 have wrong physical first returns and three have inconsistent
joined clocks in the original `-N` gauge.

The independently written audit imports neither frontier nor fast-clock
code. It reconstructs the lower hand formula for bits101, repeats the
endpoint exhaustion, rederives the vector and raw-word counts, regenerates
every emitted candidate with a separate nonmemoized geometric generator,
replays all physical witnesses, and proves the three joined clocks
directly in Z3. All checks pass. The contradiction already uses only
original rows zero through seven and ten through eighteen; unassigned
rows eight/nine cannot repair a contradiction among the assigned rows.
No visit or period ceiling enters the proof.

Reproduction from the project root:

```text
python work_positive_skew_thin101_W18_join_20261002/probe.py --weak
python work_positive_skew_thin101_W18_join_20261002/audit_weak.py
```

The earlier strong-seed experiment is retained separately and agrees.
The conclusion uses the freshly independently audited 99-word weak seed,
so period congruences and gap-four filters are unnecessary here.
