# Hand rigidity through level seven of the lower thin cap

Assume a finite-support periodic Langton highway with literal drift `(1,3)`,
clockwise R, lower cap zero, and transverse coordinate `t=3x-y`. Stable
words start R and alternate R,L. Use representatives `c_t=(0,-t)` and
lifted times `tau=i-Nk`, with `N>=1`. Directed edge blocks match by ordinal;
their time shifts are `1-N` for E, `1+N` for W, and 1 for N/S.

The lower thin profile `(1,2,2)` forces exactly the following necessary
words through level seven:

```
0: NR;
1: WR,WL;
2: NR,SL;
3: WR,WL,ER,WL;
4: SR,SL,SR;
5: ER,WL,ER,[WL]^(1-c);
6: NR,NL,SR,NL,(NR,SL)^(3-c),[NR]^e;
7: WR,WL,WR,EL,(WR,WL)^(3-c+e-f),[WR]^f,
```

where `c=omega_5`, `e=omega_6`, `f=omega_7` are bits. This supplies a hand
replacement for the previously computer-assisted rigidity theorem. It uses
no P22, growth budget, period congruence, width bound, lifetime bound, or
enumeration of level-seven words. The two W-first one-SR families use
positivity of N in the lower lifted clock, whose E shift is `1-N`; the other
exclusions use physical returns and ordinal order.
The eight displayed partial templates are necessary data, not highways.
No whole-orbit closure or existence claim is made.

## 1. Complete third- and fourth-row forms

The fixed thin rows are `0:NR`, `1:WR,WL`, `2:NR,SL`. On three, flow gives
one east arrival and one north departure. If its east arrival were EL,
there would be no R port and a negative WL count, so its counts are
`ER=WR=1`, `EL=0`, `WL=2-a`, with `a=omega_3`. Thus the complete words are

```
E: ER,WL,WR,[WL]^(1-a);
W: WR,WL,ER,[WL]^(1-a).
```

Write `b=omega_4`. There are two west departures on four, feeding
`1:WR,WL`. Let D be the first. The square

```
D -> 1:WR -> 0:NR -> 3:ER -> 4:S arrival
                     W,N,E,S
```

is a physical first return. Its two endpoints must be consecutive stable
events and have opposite turns.

In form E, ER is the first south departure on three. Its arrival on four
is therefore the first south arrival. D cannot be an earlier SR, so it is
NL and its next event is SR, the second west departure. Before D all ports
are NR; alternation leaves just one. The other ports on four are NR/SL.
Therefore the complete E fourth rows are

```
NR,NL,SR,SL,(NR,SL)^(1-a),[NR]^b.                 (E4)
```

In form W, ER is the second south departure, so the return endpoint is the
second south arrival. If D=NL, its endpoint is SR, the second west departure;
the earlier south arrival is SL. Alternation and the remaining NR/SL counts
give

```
NR,SL,NR,NL,SR,[SL]^(1-a),[NR]^(b-a), b>=a.     (W4-A)
```

If D=SR, it is the first south arrival and is immediately followed by the
second one, SL. No event can precede it, since there is no earlier west
departure or south arrival. If the other west departure is NL, the
remaining R ports are NR and the remaining L multiset is one NL plus
`1-a` copies of SL. Thus

```
SR,SL,F_(1-a)(b),                              (W4-B)
```

where `F_q(b)` consists of NR immediately before each member of the L
multiset `{NL,SL repeated q times}`, in any order, then `[NR]^b`.
If the other west departure is SR, there are two SR and zero NL. The exact
NR count is `b-1-a`, which is nonnegative only for `a=0,b=1`. This gives

```
SR,SL,SR, a=0,b=1.                            (W4-C)
```

These families follow from the square, alternation and exact flow counts;
no finite search is used to declare them complete.

## 2. The ER-first third row is impossible

Use (E4). If `a=1`, the same derivation below already forces a third west
departure on six, whereas three has only two west arrivals. Hence it will
suffice to consider the additional return when `a=0`.

Let E1,E2 denote the east arrivals on five, supplied by `2:NR,SL`.
If E2=EL, the square `4:SR ->1:WL ->2:SL ->5:E2 ->4:N arrival`, directions
WSEN, contradicts the next event SL after this SR. Thus E2=ER.

The second north departure on five feeds `4:NL`. Its eight-step first return
to E2 has directions NWNESWSE:

```
F2 -> 4:NL -> 1:WR -> 0:NR -> 3:ER -> 4:SR
   -> 1:WL -> 2:SL -> E2=ER.
```

Therefore F2=EL and is E1, immediately preceding E2. R-first alternation and
the fact that only one north departure precedes E1 force five to begin
`WR,EL,ER`.

The second west departure D2 on six then has the twelve-step physical return

```
D2 -> 3:WR -> 2:NR -> E1=EL -> 4:NL -> 1:WR -> 0:NR
   -> 3:ER -> 4:SR -> 1:WL -> 2:SL -> E2=ER -> first 6:S arrival.
```

Its directions are WNENWNESWSES. D2 cannot be SR, which would be a south
arrival before the first one. Thus D2=NL and its immediately next event is
SR. The first west departure is an earlier NL, and no south arrival can
precede D2. Alternation forces six to begin `NR,NL,NR,NL,SR`, with three
west departures. This already excludes `a=1`.

For `a=0`, write H1,...,H4 for the east arrivals on seven supplied in order
by the first NR, first SL, second NR, second SL on four. The second and
fourth north departures F2,F4 on seven have the physical first returns

```
F2 -> first 6:NL -> first 3:WL -> first 4:SL -> H2,  NWSE;

F4 -> second 6:NL -> 3:WR -> 2:NR -> E1=EL -> 4:NL -> 1:WR
   -> 0:NR -> 3:ER -> 4:SR -> 1:WL -> 2:SL -> E2=ER -> 6:SR
   -> second 3:WL -> second 4:SL -> H4, NWNENWNESWSESWSE.
```

Consequently F2 immediately precedes H2 and F4 immediately precedes H4.
If H1=EL, R-first alternation requires an earlier WR, but two earlier WR
would put F2 and its successor H2 before H1. Hence H1 itself is F2.
The return `first 4:NR ->H1=EL ->first 6:NL ->first 3:WL ->first 4:SL`,
directions ENWS, then skips the next `4:NL,SR`. Therefore H1=ER.
F2 cannot be EL, since the only earlier east arrival is H1=ER. Thus F2=WR,
H2=EL, and H2 is the third north departure. The next R after H2 cannot be
WR: it would be F4, followed immediately by H4, skipping H3. So H3=ER.
F4 cannot be EL, since the only earlier EL is already the third north
departure H2. Hence F4=WR and H4=EL, the fifth north departure.

Now `6:SR ->second 3:WL ->second 4:SL ->H4=EL ->fifth 6:N arrival`,
directions WSEN, forces this fifth north arrival to be the next stable
event after the SR. Its turn is L, so it is NL, the fourth west departure.
But three has only three west arrivals. This excludes all (E4) forms.

## 3. Excluding W4-A using N>0 in the lower lifted clock

The row starts `NR,SL,NR,NL,SR`. Its unique NL precedes SR. If E2=EL,
the return WSEN from `4:SR` to a north arrival would force an NL after SR;
none exists. Thus E2=ER.

The third north departure on five feeds `4:NL`. The eight-step return
NWNESWSE above makes it EL, hence E1, immediately preceding E2. Therefore
the second north departure F2 precedes E1 in stable order.

Put `v=tau(3:WR)`, `w=tau(first 3:WL)`, so `w>=v+1`. E1 is supplied by
`3:WR ->2:NR ->E1`, giving `tau(E1)=v+2-N<=v+1`. The first SL on four
is supplied by the first WL on three and has time `w+1`. F2 feeds the
second NR on four, which lies strictly after that SL. Hence

```
tau(F2) = tau(second 4:NR)-1 >= w+1 >= v+2 > tau(E1).
```

This contradicts F2 preceding E1. All W4-A forms are excluded.

## 4. Excluding W4-B by skipped physical return

Put `v=tau(3:WR)`, `w=tau(first 3:WL)>v`. The first SR on four is fed by
the first WL on three, and it returns via `1:WR ->0:NR` to `3:ER`.
Thus `tau(3:ER)=w+4` and `tau(first 4:SL)=w+5`. Every north arrival on
four occurs after this SL, so every north departure on five has time
strictly greater than `w+4`. But `tau(E1)=v+2-N<w+4`. Therefore E1=ER
and no WR precedes it; five starts with E1=ER, its first south departure.

The first west departure on six has the square WNES
`D1 ->3:WR ->2:NR ->E1=ER ->first 6:S arrival`.
It is NL, immediately followed by SR, and alternation forces the prefix
`6:NR,NL,SR`.

The second north departure U on seven has the twelve-step first return

```
U -> 6:NL -> 3:WR -> 2:NR -> E1=ER -> 6:SR -> first 3:WL
  -> first 4:SR -> 1:WR -> 0:NR -> 3:ER -> first 4:SL -> first 7:E arrival H1,
```

with directions NWNESWSWNESE. U cannot be EL, since H1 is the first east
arrival. Thus U=WR, H1=EL, and H1 is the third north departure.
The eight-step return from `6:SR`, directions WSWNESEN, therefore forces
the third north arrival on six to be the next event after SR, hence NL.
Six begins `NR,NL,SR,NL`, with a third west departure. If `a=1`, three
has only two west arrivals, a contradiction.

If `a=0`, this last NL feeds the second WL on three, which feeds the
second SL on four. Between the first and second SL on four is at least
one NR, by the definition of F. Its east departure supplies an east arrival
strictly between H1 and the east arrival supplied by the second SL.
But the path `H1=EL ->last 6:NL ->second 3:WL ->second 4:SL ->7:E arrival`,
directions NWSE, is a physical first return. It makes these endpoint events
consecutive while an east arrival lies between them. This excludes W4-B.

Only W4-C remains: `a=0,b=1`, `3:WR,WL,ER,WL`, `4:SR,SL,SR`.

## 5. Exact templates on five through seven

Four has no north arrivals, so five has no north departures: no WR or EL.
Its two east arrivals are ER. With `c=omega_5`, exact flow and alternation
give `5:ER,WL,ER,[WL]^(1-c)`.

The first west departure on six again makes the square WNES through
`3:WR ->2:NR ->first 5:ER`, forcing `6:NR,NL,SR`. The twelve-step return
NWNESWSWNESE from the second north departure on seven ends at its unique
east arrival H1, forcing that departure WR and H1=EL, the third north
departure. The eight-step return WSWNESEN from `6:SR` then forces the next
event on six to be its third north arrival NL. Thus six starts `NR,NL,SR,NL`.

These two NL and one SR exhaust its three west departures, which feed the
three W arrivals on three. No further NL or SR is possible. Let `e=omega_6`.
Five has `4-c` south departures; hence six has `SL=3-c`, `NR=4-c+e`.
Alternation uniquely determines

```
6: NR,NL,SR,NL,(NR,SL)^(3-c),[NR]^e.
```

Seven has exactly one east arrival, H1=EL, and `6-c+e` north departures.
H1 is its third north departure, immediately preceded by the second WR;
R-first alternation therefore forces `7:WR,WL,WR,EL`. Let `f=omega_7`.
The exact odd-row counts are `ER=0`, `EL=1`, `WR=5-c+e`, `WL=4-c+e-f`.
The remaining suffix has only WR/WL, so

```
7: WR,WL,WR,EL,(WR,WL)^(3-c+e-f),[WR]^f.
```

This establishes every displayed row for all bits c,e,f. The proof ends
at necessary local templates and makes no assertion that they extend.

## Independent verification

`verify_thin_hand_rigidity.py` constructs headings and physical coordinates
without importing the cap/frontier implementations. It audits every return
word, source/destination level, zero voltage, and absence of an intermediate
visit to the starting physical cell. It also regresses directed matching
ordinals in the eight displayed templates and the small seven-prefix
implication used to reject E4. No large frontier or period search is run.
The hand arguments above establish completeness; this audit checks their
geometric and finite algebraic consequences.


The canonical copy was integrated on 1 October 2026. The complete
[lower-thin111 exclusion](positive_skew_lower_thin_111_exclusion_2026-10-01.md)
combines these local results with all-width arithmetic; the whole orbit
remains open.
