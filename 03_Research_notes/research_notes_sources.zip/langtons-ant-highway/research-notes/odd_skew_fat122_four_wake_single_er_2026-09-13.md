# The single-`ER` branch after a wake at offset four

Consider a `(1,2,2)` cap in the `(1,-3)` orbit, with inward wake
indicator `omega_4=1`. Put `c=omega_5` and `e=omega_6`. If offset six
has exactly one `ER` port, the following are necessary stable words:

```text
5: NR,SL,SR,NL,NR,SL,NR,[SL]^(1-c);

c=0:
6 T: WR,WL,WR,EL,WR,WL,ER,EL,WR,WL,[WR]^e;
6 U: WR,WL,WR,EL,WR,WL,ER,WL,WR,EL,[WR]^e.

c=1:
6 V: WR,WL,WR,EL,WR,WL,ER,EL,[WR]^e.
```

This restriction holds at either cap, with heading labels rotated at
the upper cap. It does not require growth eight, a bound on the period,
or any wake information beyond offset six.

At a lower cap, all these words are impossible. This last conclusion
uses the sign of the longitudinal voltage and is not asserted for the
upper cap. Combined with the earlier wake-five argument, it proves
that every lower `(1,2,2)` cap has exactly two `ER` ports at offset six.

The upper words T and V are subsequently excluded by a zero-
displacement return in
`odd_skew_upper_a_single_er_reduction_2026-09-14.md`.
For family A, that note also reduces U to a wake at upper offset
six and one fixed offset-seven word. The two-`ER` continuation,
this remaining U order, and family A itself remain open.

## The square and the possible prefixes

The two-sided `(1,2,2)` normal form gives

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,WR
5 A: SR,SL,NR,NL,NR,SL,NR,[SL]^(1-c)
  B: NR,SL,SR,NL,NR,SL,NR,[SL]^(1-c).
```

With one `ER` on offset six, its port counts are

```text
(ER,EL,WR,WL)=(1,2,4-c+e,3-c).
```

The south predecessor of `5:SR` has the four-step first same-cell
return through `5:SR,2:WR,3:NR` to the second east arrival on offset
six. If that arrival is `EL`, its consecutive predecessor is the first
east arrival `ER`. If it is `ER`, the predecessor is `WL`, with the
first east arrival `EL` earlier in the word.

For word A, this predecessor is the first south departure. For word B,
it is the second. Alternation gives the following prefix groups; all
unspecified right turns are `WR`:

| Word at five | Second east arrival | Prefix at six | Remaining left turns |
|---|---|---|---|
| A | `EL` | `ER,EL` | one `EL`, `3-c` copies of `WL` |
| B | `EL` | `WR,WL,ER,EL` | one `EL`, `2-c` copies of `WL` |
| A | `ER` | `WR,EL,WR,WL,ER` | one `EL`, `2-c` copies of `WL` |
| B | `ER` | `WR,EL,WR,WL,WR,WL,ER` | one `EL`, `1-c` copies of `WL` |
| B | `ER` | `WR,WL,WR,EL,WR,WL,ER` | one `EL`, `1-c` copies of `WL` |

The table follows directly by placing the first `EL` and the south
predecessor before the second east arrival. In the last two groups,
one `WL` must occur before that predecessor; the first `EL` can lie
on either side of this earlier `WL`. Every row ends with a left turn
when `e=0`, or an additional final `WR` when `e=1`.

## The first north-return pair

Let `W1,...,W5` be the west departures on offset seven. Their targets
on offset four have ordered headings

```text
WR,WL,WL,WR,WR.
```

Write `Ni` for the north arrivals on offset seven. There are two fixed
returns. The first starts

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> first east arrival on 6.
```

If this east arrival is `EL`, its north step completes an eight-step
return. Otherwise the path continues through `5:SR,2:WR,3:NR` to the
second east arrival `EL`, then north, completing a twelve-step return.
The second fixed return is

```text
W3 -> 4:second WL -> 3:last SL -> last EL on 6 -> north arrival on 7.
```

It has length four. Neither return has an intermediate offset-seven
visit, and both have zero displacement.

Suppose these adjacent west departures return to `Na,Nb`. If `W2=SR`,
its consecutive target `Na=NL` is `W3`; the second return must then
end at `N(a+1)`. Thus, whenever `b!=a+1`, one instead has
`W2=NL=N(a-1)`. In particular, `a=1` and `b!=2` are incompatible.

For the first prefix group in the table, the return targets are `N1`
and one of `N3,...,N6`. This excludes that group. For the second group
they are `N2` and one of `N4,...,N6`. Hence `W2=NL=N1`, producing
the eight-step return

```text
6:first WR -> 7:W2 -> 4:first WL -> 3:SR -> 0:WR
           -> 1:NR -> 4:ER -> 3:first SL -> 6:first ER.
```

Both endpoints turn right. The second group is therefore impossible
as well.

## An immediate `SR,NL` pair at offset seven

For the third and fourth prefix groups, the return from `W2` ends at
`N2`; the one from `W3` ends at an ordinal at least four. Thus
`W2=NL=N1`. The earlier west departure `W1` is `SR`, immediately
followed by this `NL`. An intervening stable event would require
either another west departure or a north arrival before `N1`.

Consider the fourth prefix group, whose offset-five word is B. The
three-step path from `W1` through `4:first WR,5:first NR` reaches the
first east arrival on offset eight. Its south-departure predecessor
has a four-step return to that first east arrival. The predecessor
cannot be `ER`, since it lies before the first east arrival, so it is
`WL`; the first east arrival is consequently `ER`.

Its south step now completes a four-step return from `W1=SR` to a
south arrival, contradicting the immediate `NL` successor of `W1`.
This excludes the fourth prefix group.

For the third group, the offset-five word is A. Label the east
arrivals on offset eight by `Ei`, fed in order by

```text
5:SL1,NR1,NR2,SL2,NR3,[SL3]^(1-c).
```

The same three-step path from `W1` now ends at `E2`. Its south step
cannot return to the immediate successor `NL`, so `E2=EL`. The source
of the four-step return to it must be `E1=ER`. They are consecutive
stable events, and they are the initial two events on offset eight:
their source is the first south departure, while no west arrival can
occur earlier without an intervening left turn and an earlier south
departure.

The third group consists of the following words, each followed by
`[WR]^e`. The final word C3 occurs only for `c=0`:

```text
C1: WR,EL,WR,WL,ER,EL,(WR,WL)^(2-c);
C2: WR,EL,WR,WL,ER,WL,WR,EL,(WR,WL)^(1-c);
C3: WR,EL,WR,WL,ER,WL,WR,WL,WR,EL.
```

## The word C1 is impossible

For C1, the second fixed return is `W3 -> N4`. If `W3=NL`, its source
is `N3`, fed by the second `WR` on offset six. The resulting four-step
return to the last `EL` there skips `WL,ER`. Hence `W3=SR`, followed
immediately by `N4=NL=W4`.

The path

```text
W4 -> 4:second WR -> 5:NL -> 2:WL -> 1:SL
   -> 4:EL -> 5:second NR -> E3
```

has length seven. If `E3=ER`, its south step returns to the next
stable event after `W4=NL`. That event must be `SR`, necessarily `W5`.
But then

```text
8:E3=ER -> 7:W5=SR -> 4:last WR -> 5:last NR -> 8:E5
```

is a four-step first return that skips `E4`. Thus `E3=EL`.

The south predecessor of `W3` on offset eight follows the four-step
return to `W4`, then this seven-step path to `E3`. It has a twelve-step
first return, forcing its source to be the immediately preceding
east arrival `E2=ER`. This contradicts the already established
`E2=EL` and excludes C1.

## The adjacent `WL` ports exclude C2 and C3

In either C2 or C3, the first four west arrivals on offset six are

```text
WR,WR,WL,WL.
```

Let `D1,D2,...` be the west departures on offset nine feeding them.
The third has the twelve-step first return

```text
D3 -> 6:first WL -> 5:SR -> 2:WR -> 3:NR -> 6:ER
   -> 5:first SL -> 8:E1=ER -> 7:W1=SR -> 4:first WR
   -> 5:first NR -> 8:E2=EL -> first north arrival on 9.
```

The target is the first north arrival because `E1=ER,E2=EL` are the
initial events on offset eight. The source cannot be `NL` before
that first north arrival. Hence `D3=SR`, and its consecutive target
is `NL=D4`.

It follows that

```text
8:E2=EL -> 9:D4=NL -> 6:second WL -> 5:second SL -> 8:E4
```

is a four-step first same-cell return. It skips `E3` in east-arrival
order, which is impossible. This excludes C2 and C3, completing the
exclusion of the third prefix group.

## The last prefix group

Only the fifth group remains. For `c=0`, its remaining `EL` and `WL`
can occur in either order, giving words T and U. For `c=1`, only the
final `EL` remains, giving word V. The first north-return pair gives

```text
W2=NL=N2;
T: W3 returns to N5;
U: W3 returns to N6.
V: W3 returns to N5.
```

In T and V, `W3=NL` would mean `W3=N4`, fed by the third `WR` on
offset six. The return to its last `EL` would skip `WL,ER`. Thus
these words require `W3=SR`, with consecutive target `NL=W4`.
For U, either turn at `W3` has not yet been excluded.

## The delayed fourth west departure excludes the lower words

Let `L` be the last `EL` on offset six and `R` its unique `ER`.
In every remaining word, `R` precedes `L`. The fixed four-step
return from `W3` ends at the north arrival fed by `L`.

If `W3=SR`, this target is `NL=W4`. If `W3=NL`, its target is the
immediately following `NR`, and `W4` occurs later. In either case,
writing stable lifted times in the lower-cap coordinates gives

```text
tau(W4) >= tau(L)+1.
```

The offset-five word is B. Its third and fourth east departures are
`NR2` and `SL2`; call the corresponding east arrivals on offset eight
`E3,E4`. The fixed path

```text
W4 -> 4:second WR -> 5:NL -> 2:WL -> 1:SL
   -> 4:EL -> 5:second NR -> E3
```

has length seven and zero longitudinal voltage. Hence

```text
tau(E3) = tau(W4)+7 >= tau(L)+8.
```

The first three south departures on offset six are `WL,WL,ER`.
They feed `5:SL1,SR,SL2`, respectively. Thus `R` supplies `E4`
through the two-step path `6:R -> 5:SL2 -> 8:E4`. At the lower cap
this path has voltage one, giving

```text
tau(E4) = tau(R)+2-N.
```

Since `tau(R)<tau(L)` and `N>=6`, these two equations imply
`tau(E4)<tau(E3)`. But `E3` is the third east arrival and `E4` the
fourth. Order-preserving edge matching requires the opposite strict
inequality. This excludes every lower word T, U, and V.

At the upper cap the last equation is instead
`tau(E4)=tau(R)+2+N`. There is no contradiction from these bounds
in that orientation. The upper continuations remain open.

## Consequence for every lower `(1,2,2)` cap

Put `b=omega_4`, retaining `c=omega_5` and `e=omega_6`. If `z` is
the number of `ER` ports on offset six, the general count row is

```text
(ER,EL,WR,WL)=(z,3-z,6+b-c+e-3z,3+b-c-z).
```

Nonnegative counts give `z<=2`. The square through
`5:SR,2:WR,3:NR` excludes `z=0`, since both endpoints would turn
left. For `b=1`, the preceding proof excludes `z=1` for either
value of `c`.

For `b=0`, the lower early-wake theorem forces `c=1`, and
`odd_skew_fat122_rigid_five_wake_2026-09-13.md` already excludes
`z=1`. Consequently every lower `(1,2,2)` cap has `z=2`, with

```text
(ER,EL,WR,WL)=(2,1,b-c+e,1+b-c).
```

When `(b,c)=(0,1)`, nonnegativity forces `e=1` and three visits.
When `(b,c)=(1,0)`, offset six has `6+e` visits. When `(b,c)=(1,1)`,
it has `4+e` visits. This is a uniform local restriction on the
lower fat-cap profile, not an exclusion of that profile or of the
whole `(1,-3)` orbit.

## The last east arrival also turns right

Every lower `(1,2,2)` cap has `ER` as the last east arrival on offset
six. For `b=0`, this follows from its already forced word `ER,EL,ER`.
Suppose `b=1` and, to the contrary, the last east arrival is `EL`.
The first two east arrivals are then both `ER`.

The square through `5:SR,2:WR,3:NR` ends at the second of these
east arrivals. Its consecutive predecessor is `WL`. The first `ER`
is an earlier south departure, so `5:SR` cannot be the first south
arrival. Therefore the offset-five word is B: the first south
arrival is `SL1`, the second is `SR`, and the third is `SL2`.
The south departures supplying them are respectively the first
`ER`, its later `WL`, and the second `ER` on offset six.

Write `R` for that second `ER` and `L` for the final `EL`. Again,
the return from `7:W3` ends at the north arrival supplied by `L`,
so `tau(W4)>=tau(L)+1`. The seven-step path from `W4` to the third
east arrival on offset eight gives `tau(E3)>=tau(L)+8`. Meanwhile
`R -> 5:SL2 -> 8:E4` gives `tau(E4)=tau(R)+2-N`.

Since `R` precedes `L`, these inequalities contradict `E3<E4` in
stable order, exactly as above. The last east arrival on offset six
must therefore turn right. Together with the count theorem, its
east-arrival subsequence is either `ER,EL,ER` or `EL,ER,ER`.
