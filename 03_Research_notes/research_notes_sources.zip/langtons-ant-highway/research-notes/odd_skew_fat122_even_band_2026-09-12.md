# The first even band at a lower `(1,2,2)` cap

Later result: [the lower early-wake theorem](odd_skew_fat122_early_wake_2026-09-12.md) excludes the quiet-four/five/six hypothesis studied below. The four local orders are intermediate necessary cases, not remaining highway candidates.

Consider a lower cap of profile `(1,2,2)` for drift `(1,-3)`. If levels four,
five, and six are all non-wake, the four-visit alternative on level six is
impossible. Level six must have eight visits, in one of four orders listed
below. The proof has no period, width, or inward multiplicity cutoff.

This closes a branch of the cap problem. The four surviving orders and cap
patterns having a wake on level four, five, or six remain unresolved.

Use `t=3x+y`, representatives `(0,t)`, and the port and lifted-time conventions
of `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`. That argument gives

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL
5 A: SR,SL,NR,NL,NR,SL
  B: NR,SL,SR,NL,NR,SL.
```

The two `SL` ports on level three are numbered in their stable order, and
the same convention applies to repeated ports on other levels.

## The two level-six count rows

Level six has three east arrivals from level three and three south departures
feeding level five. Since its excess is zero, its possible count rows are

```text
(ER,EL,WR,WL) = (r,3-r,6-3r,3-r),       r=0,1,2.
```

Let `E2` be its second east arrival and let `J` be the south departure feeding
the unique `5:SR`. Order-preserving edge matching gives the four-step return

```text
J -> 5:SR -> 2:WR -> 3:NR -> E2.
```

It has direction word `SWNE`. Its endpoints are consecutive visits to the
same physical level-six cell with opposite turns. This excludes `r=0`,
since neither endpoint can then supply a right turn.

## Suppose level six has four visits

For `r=2`, the two alternating words are `ER,EL,ER,WL` and `ER,WL,ER,EL`.
The latter would make `J=WL` and `E2=ER`. The `WL` is the second south
departure, so level five would have to use word B. But the south step from
this `ER` completes a four-step return from `5:SR` to a south arrival on
level five, whereas the next stable event after `SR` in B is `NL`.
Thus the only possibility is

```text
5: SR,SL,NR,NL,NR,SL
6: ER,EL,ER,WL.
```

Let `W1,...,W4` be the west departures on level seven in stable order.
They feed the west arrivals `WR,WL,WL,WR` on level four. Level seven has
one north arrival, fed by `6:EL`. Its second west departure has the forced
return

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> 6:first ER -> 5:SR -> 2:WR
   -> 3:NR -> 6:EL -> only north arrival on 7.
```

The direction word is `WSWNESESWNEN`. These twelve steps have zero
displacement and no intermediate level-seven visit. If the north arrival
were `NR`, all west departures would be `SR`, giving two right turns at
the endpoints. Therefore the north arrival is `NL`. The source is `SR`,
immediately followed by this `NL` in stable order. Since it is the second
west departure, the complete level-seven word is

```text
SR,SL,SR,NL,SR,[SL]^(1-f),       f=omega_7.
```

Write its right-turn south arrivals as `SR1,SR2,SR3`. In west-departure
order they are `W1,W2,W4`, with `NL=W3`.

## Two returns through level eight

Level eight has four east arrivals `E1,...,E4`, supplied by the east
departures `SL1,NR1,NR2,SL2` on level five. Two fixed paths are

```text
7:SR1 -> 4:first WR -> 5:first NR -> E2,
7:SR3 -> 4:last WR -> 5:NL -> 2:WL -> 1:SL
      -> 4:EL -> 5:last NR -> E3.
```

They have lengths three and seven respectively and both end at the same
physical level-eight cell immediately north of the starting level-seven
cell.

The arrival `E3` must be `ER`. If it were `EL`, take the level-eight south
departure `D` feeding `7:SR3`. Its path through the second displayed chain
would return to `E3` in eight steps, with no intermediate level-eight
visit. The opposite-turn source would be `ER`, and consecutive stable
order makes it `E2`: choosing `E1` would skip the intervening east arrival
`E2`. The first displayed chain would then give a four-step return from
`7:SR1` to `7:SR3`, with right turns at both endpoints. This is impossible.

Thus `E3=ER`. Its south step completes an eight-step return from `7:SR3`
to a south arrival on the same level-seven cell. Hence `SR3` must have a
following stable event. This excludes `f=1` and forces

```text
7: SR,SL,SR,NL,SR,SL.
```

The level-eight predecessor `D` of `SR3` must now be `WL`, immediately
followed by `E3=ER`. The five south arrivals on level seven, in order, are
`SR1,SL1,SR2,SR3,SL2`. Therefore this `WL` is the fourth south departure
on level eight and `E3` is the fifth and last. In particular `E4=EL`.

The south departure feeding `SR1` has a four-step return to `E2`. If
`E2=EL`, its source is `ER` and must be `E1`. Since it is the first south
departure, stable order makes `E1,E2` the initial pair `ER,EL`.
If `E2=ER`, its source is `WL`, again the first south departure. Then
`E1` cannot be `ER`, so `E1=EL`, and alternation forces the prefix
`WR,EL,WR,WL,ER` through `E2`.

There are exactly two `ER` ports in either case. With `e=omega_8`, flow
gives the level-eight counts `(ER,EL,WR,WL)=(2,2,3+e,3)`. The fourth and
fifth south departures are the consecutive `WL,E3` pair, and the last east
arrival is `E4=EL`. The resulting words are exactly

```text
8 A: ER,EL,WR,WL,WR,WL,WR,WL,ER,EL,[WR]^e,
  B: WR,EL,WR,WL,ER,WL,WR,WL,ER,EL,[WR]^e.
```

## Level nine cannot extend either word

There is only one west arrival on level six, namely its final `WL`.
Consequently level nine has exactly one west departure. Both level-eight
words have `5+e` north departures, and their fifth is `E4=EL`.

The sole west departure `W` on level nine has the four-step return

```text
W -> 6:WL -> 5:last SL -> 8:E4 -> fifth north arrival on 9.
```

If `W=SR`, there is no `NL` on level nine, and both endpoints turn right.
Thus `W=NL`, its target is `NR`, and consecutive stable order makes `W`
the fourth north arrival.

The fourth north departure on level eight is the `WR` immediately before
its final `WL,ER,EL` block. Call this event `Z`. There is therefore a
second four-step return

```text
Z -> 9:NL -> 6:WL -> 5:last SL -> 8:E4.
```

It has direction word `NWSE` and no intermediate level-eight visit. Its
endpoints would have to be consecutive, but both displayed level-eight
words have the intervening visits `WL,ER`. This contradiction excludes
the four-visit level-six branch, for either parity on levels eight and nine.

## The remaining eight-visit level-six rows

Under the three non-wake assumptions, level six must therefore have

```text
(ER,EL,WR,WL)=(1,2,3,2).
```

The following short time comparison reduces its stable orders. Put
`A=tau(0:WR)`, `V=tau(2:WL)`, and `Z=tau(4:second WL)`. The forced return
`4:last WR -> 5:NL -> 2:WL -> 1:SL -> 4:EL` gives

```text
tau(4:last WR)=V-N-2,       Z<=V-N-6.
```

The third east arrival on level six, fed by `3:last SL`, has time
`Z+2-N<=V-2N-4`. The last north arrival on level five is at `V-N+3`,
and its last `SL` is later. Thus the last south departure on level six
occurs after its third east arrival and must be `WL`.

Use again the four-step return from the south predecessor of `5:SR` to
the second east arrival on level six. If that arrival is `EL`, its
opposite-turn predecessor is the unique `ER`, namely the first east arrival.
It is the first south departure for word A on level five and the second
for word B. If the second east arrival is `ER`, its predecessor is `WL`;
the resulting return to level five forces word A, since B has `NL` after
`SR`. Alternation, followed by the final-`WL` condition just proved, gives
the four remaining possibilities:

| Level-five word | Level-six word |
|---|---|
| A | `ER,EL,WR,EL,WR,WL,WR,WL` |
| A | `ER,EL,WR,WL,WR,EL,WR,WL` |
| B | `WR,WL,ER,EL,WR,EL,WR,WL` |
| A | `WR,EL,WR,WL,ER,EL,WR,WL` |

These four orders are the unresolved continuation of this even-band branch.
They are not a claim of existence and do not close the orbit.
