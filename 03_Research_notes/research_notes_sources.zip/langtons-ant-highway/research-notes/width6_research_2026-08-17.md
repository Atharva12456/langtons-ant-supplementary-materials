# Width-six research log — 17 August 2026

The completed audit at the end of this log records the computer-assisted
all-period width-six exclusion. The opening objectives and candidate sections
retain the status of the earlier exploratory stages.

## Objective and claim discipline

The target is an all-period exclusion of diagonal finite-support periodic highways
of transverse width six.  Together with the proved even-width theorem and the
width-two and width-four exclusions, this would prove `W >= 8`.

Nothing in this file is a theorem merely because it appears here.  Each item is
labelled as one of:

- **proved input** — already established in the paper;
- **exact computation** — exhaustive only over the stated finite range;
- **candidate lemma** — requires a complete proof and adversarial audit; or
- **failed route / countermodel** — retained to prevent its reuse.

The universal highway conjecture remains open.  No width-six exclusion is claimed
at the start of this log.

## Proved inputs

Normalize diagonal drift to `d=(m,-m)`, `m>0`, put `t=x+y`, and shift the
transverse range to the seven lines `0,...,6`.  Lines `0,2,4,6` have horizontal
arrivals and lines `1,3,5` have vertical arrivals.  Every reached cell on the two
extremal lines `0,6` is a singleton translation class, is entered once, and turns
`R`.  The exact finite-support criterion says that the stabilized word in every
translation class alternates and starts with `R`.

Observe the ant only on odd lines.  A macro step contains one turn on an odd line
and one on an even line.  Its state is `(odd line, vertical arrival heading)`, so
there are six states.  The longitudinal coordinate is `ell=x`; each macro changes
`ell` by `+1` or `-1`.  A width-six highway can be cyclically based immediately
after a bottom-extremal visit, in state `(1,N)`, and returns to that state translated
by `m` after one macro period.  It must also visit line `6`.

## Known local obstruction to the width-four method

The one-column all-white entry graph is recurrent at width six.  Suppressing the
extremal-use flags, it contains the literal two-state rotor

```text
(black rows {1,2}, enter row 2 east)
    <->
(black rows {1,3}, enter row 2 west).
```

The eastward half turns `L` at black row 2 and `R` at white row 3; the westward
half turns `R` at white row 2 and `L` at black row 3.  Both reused cells alternate
correctly, and neither extreme is touched.  Therefore per-cell alternation and the
four extremal singleton flags cannot make the width-six blank-column graph acyclic.
This rotor is only a local transcript: no global periodic path, nonzero drift, or
start-with-`R` translation-class ordering follows from it.

## Exact exploration apparatus

`code/python/search_width6.py` generates the complete six-state macro table directly
from the turn rule, enforces ordinary physical-cell alternation during DFS, and
applies the full stabilized P3 criterion at every closed positive-drift width-six
leaf.  A reported hit would therefore be a genuine periodic trace admitted by a
finite seed.  A zero row is only a bounded exact computation.

The immediate purpose is diagnostic:

1. find the smallest structural and start-with-`R` near-models;
2. identify which line and class order kills them;
3. test candidate transition-count inequalities before attempting a proof; and
4. decide whether coupled-column recurrence survives the complete P3 ordering.

## Live questions

1. Does P3 force a period--drift bound at width six analogous to `P<=7m` at width
   four?  A finite bound at fixed `m` is useful but is not by itself an all-drift
   exclusion.
2. Can the centre rotor appear on infinitely many initially white columns while the
   stabilized word of every translated class starts with `R`?
3. Does coupling two consecutive blank columns eliminate all recurrent components,
   or merely create a larger rotor?
4. Can the signed residue identities restrict the seven-bit odd masks strongly
   enough that every recurrent local component misses a required wake class?

## Candidate breakthrough: five blank columns are impassable

**Status: candidate computer-assisted lemma, awaiting independent implementation
and hostile bridge audit.  Do not cite as a theorem yet.**

The bounded crossing graph has no directed cycle through maximum signature length
21.  More strongly, its longest observed directed path is four from length cap nine
onward.  This suggested eliminating the unbounded signature alphabet by simulating
several adjacent columns at once.

`code/python/width6_block_exclusion.py` performs an exact finite-state exploration of
a blank `k`-column by seven-line block.  Its state retains:

- all `7k` colour bits;
- the entry line and heading at the current outer boundary;
- a bit for every physical extremal cell already visited; and
- the four possible exceptional extreme events on the two outer cuts.

Between outer-boundary crossings the program runs literal Langton dynamics.  At an
outer exit it nondeterministically permits every geometrically possible later
re-entry line.  Thus it deliberately over-approximates the unknown computation
outside the block.  A right exit is recorded as a possible final exit before any
return is chosen.  Previously seen full states are merged because the retained
state determines every future in-block update and every permitted outer re-entry.

Fresh output:

```text
columns=1 states=429   transitions=814   terminals=162
columns=2 states=2,052 transitions=2,966 terminals=824
columns=3 states=811   transitions=1,043 terminals=259
columns=4 states=257   transitions=324   terminals=36
columns=5 states=151   transitions=212   terminals=0
columns=6 states=151   transitions=212   terminals=0
```

The four-column terminals are a positive control.  The zero at five columns agrees
with the independently generated bounded boundary graph's longest path four, but
those programs currently share the same turn convention and are not independent
implementations.

### Proposed global bridge

A positive-drift periodic highway crosses each fixed far-ahead longitudinal cut
only finitely many times.  Finite initial support and the finite preperiod imply that
five sufficiently far consecutive strip columns are initially white and untouched
when the periodic tail begins.  The ant starts to their left.  Its first entry into
the block is therefore a rightward crossing of the left boundary; positive drift
forces an eventual final rightward exit from the right boundary.  The intervening
literal history, with arbitrary excursions outside either outer cut, is one of the
states explored by the block program.  Extremal-line rigidity supplies the
once-visit constraints on the physical extreme cells and the two outside extreme
cells represented only by outer-cut flags.  A zero-terminal certificate would
contradict the required final exit.

If the finite classifier and this bridge pass audit, no diagonal width-six periodic
highway exists.  With even transverse width and the already accepted width-two and
width-four exclusions, this proves `W >= 8`.

### Required attacks before promotion

1. Verify independently that horizontal moves update `(column,t)` by `(±1,±1)` and
   vertical moves by `(0,±1)`, and that the stored crossing labels are destination
   transverse lines.
2. Check that all information influencing future in-block dynamics survives state
   merging; in particular, no boundary-word history beyond the four extreme flags
   may affect legality.
3. Prove that internal-cut extreme events are already represented by physical
   extremal-cell visit bits and that only the two outward-facing extreme cells need
   the outer flags.
4. Write a separately structured verifier using compass headings and set-valued
   colours/visits, with no import from either width-six classifier.
5. Extract at least one four-column terminal transcript and replay it literally as a
   positive control.
6. Have an adversarial referee attempt to embed a hypothetical highway transcript
   that enters first from the right, bypasses a column, or lacks a final right exit.

## Stronger flag-free form: six blank columns are impassable

**Computer-assisted theorem; supersedes the five-column formulation.**

The five-column classifier is sound, but it remembers four flags for extreme events
immediately outside the block.  A hostile relaxation removes all four flags, forgets
the entire exterior history after every exit, and permits every geometrically allowed
return after every outer excursion.  With that strictly larger transition system,
five columns have 46 right-exit terminals but six columns have none:

```text
relaxed columns=1 states=192   transitions=480   terminals=72
relaxed columns=2 states=3,453 transitions=6,951 terminals=1,131
relaxed columns=3 states=5,208 transitions=7,977 terminals=1,867
relaxed columns=4 states=633   transitions=900   terminals=102
relaxed columns=5 states=555   transitions=819   terminals=46
relaxed columns=6 states=357   transitions=555   terminals=0
```

For six columns the 357 boundary-entry states produce 172 rejected attempts to
revisit one of the 12 physical extremal cells, no trapped deterministic in-block
cycle, and at most 58 literal cell visits between outer crossings.  The only legal
exits are through the left boundary: destination lines 0, 2, and 4 occur 38, 78,
and 69 times respectively.  No state reaches the right boundary.

`verify_width6_block_indep.py --relaxed` reproduces every state, transition,
terminal, rejection, maximum-segment, and exit count using compass headings and
immutable sets, with no imports from the primary classifier.  A third single-cell
state exploration (not boundary-compressed) independently reached 3,186 in-block
states plus 118 explicit left-outside nodes (3,304 total), with no right-outside
node.  The boundary-compressed scripts
retain a positive control: five columns have 46 terminals after the relaxation.

### Paper-grade local lemma

Let a `6 x 7` block consist of six consecutive longitudinal columns and transverse
lines `0,...,6`, initially all white.  Suppose every one of its 12 cells on lines
0 and 6 may be entered at most once.  Start with an eastward entry through the left
boundary on destination line 2, 4, or 6.  Between literal in-block segments, allow
an exit through either outer boundary to be followed by an arbitrary return through
the same boundary on any geometrically permitted destination line, forgetting all
outside state.  Then no right-boundary exit is reachable.

The finite premise is computer-assisted.  It is a reachability calculation on 357
reachable boundary states, not a bounded-period or bounded-crossing-length search.
The arbitrary-return rule is an over-approximation, so the classifier does not need
to prove that a chosen exterior excursion is itself dynamically realizable.

### Global contradiction

For a hypothetical width-six periodic highway, normalize `d=(m,-m)`, `m>0`, and
`t=x+y in {0,...,6}`.  Let `N` be the ant period.  At phase `i` of translated
period `q`,

```text
x(qN+i) = qm + x(i),
```

so `x` tends to `+infinity`, and every fixed longitudinal cut is crossed only
finitely many times.  Choose six consecutive columns beyond both the finite initial
black support and the finite past footprint at the start of the periodic tail.  They
are initially white and untouched.  Continuity and the fact that the ant starts to
their left force the first block entry to be eastward through the left boundary.
Since `x` tends to infinity and both outer cuts have finite crossing sequences, the
block history has a final eastward exit through the right boundary.

Every actual outside excursion is included among the classifier's arbitrary return
choices.  It returns through the same outer boundary: moving from one side of the
block to the other while staying in `t in {0,...,6}` would already cross an in-block
column.  Extremal-line rigidity says that each of the 12 in-block cells on lines 0
and 6 is entered at most once, exactly the classifier's only history-sensitive
rejection.  The actual block history would therefore reach a right-exit terminal,
contradicting the exact zero-terminal result.

With the exact certificate and mathematical reduction recorded below, this
excludes every diagonal
finite-support periodic highway of transverse width six.  Combining it with even
width and the accepted width-two and width-four exclusions gives `W >= 8`.  It says
nothing about universal entrance, non-diagonal translators, or whether width eight
is possible.

## Promotion gate and completed audit

The `W>=8` statement entered the paper only after all of the following held:

1. a complete mathematical reduction from a hypothetical width-six highway to the
   proposed finite obstruction;
2. an exact classifier whose completeness assumptions are stated explicitly;
3. an independently written verifier or a fully formal enumeration;
4. hostile review of coordinate conventions, boundary ordering, finite-support tail
   selection, and the global-to-local bridge; and
5. isolated fresh-process reruns with archived outputs and hashes.

The released primary classifier, separate verifier, and certificate audit
check the flag-free six-column formulation. Their SHA-256 hashes are

```text
width6_block_exclusion.py       3f1c92c831e45bcc0e60a282e4652bf72a07da22a1dc7ef711de2172a78c24af
verify_width6_block_indep.py    7121555c44eb96eda955002136b8cda35ea8f9d2f979da3416f7e62fb422c65f
audit_width6_block.py           68aba194450ba05872fe37bbd20c260916c5718dc805e15b09be76d11a4c1908
```

The machine-readable record is `results/width6_block_certificate.json`.  Promotion
status is **computer-assisted all-period exclusion of diagonal width six**, with the
global reduction proved in the manuscript and the finite reachability premise
reproduced by two separately written enumerators.  It is not an end-to-end Lean
formalization and does not settle the universal highway conjecture.
