# Coordinate-fibre visit counts

Let a finite-support periodic highway have nonzero drift `d=(a,b)`. An `x`
fibre means a residue class modulo `|a|` when `a` is nonzero, and an exact
column when `a=0`. Define `y` fibres in the same way. For a fibre `F`, write
`nu_F` for the number of period events it contains and `Omega_F` for the number
of odd translation classes there. Then

```text
nu^x_F-Omega^x_F = 2*[a != 0]  (mod 4),
nu^y_F-Omega^y_F = 2*[b != 0]  (mod 4).                (1)
```

Thus the difference is two in every residue fibre associated with a nonzero
drift component and zero on every exact coordinate line associated with a zero
component. This is an all-period consequence of the coordinate reversal count
and the trace criterion.

## Derivation

Put `ell_i=1` when phase `i` is a left turn and zero otherwise. A vertical step
after phase `i` has equal flanking turns with parity indicator

```text
1+ell_i+ell_(i+1).
```

Fix one `x` fibre. Summing over its vertical steps gives

```text
rho^x_F = V_F+L^x_F  (mod 2),                           (2)
```

because every turn event in the fibre is an endpoint of exactly one vertical
step. The one-dimensional reversal count gives

```text
rho^x_F = H_F+epsilon_a  (mod 2),                       (3)
```

where `epsilon_a=1` if `a` is nonzero and `0` otherwise. For a nonzero
component, the coordinate walk makes one net passage around the residue quotient
modulo two. When `a=0`, the walk has zero net passage across each exact column.
A horizontal landing and the following vertical departure meet at the same
horizontal-arrival event, so `V_F=H_F` exactly. Equations (2)--(3) therefore say

```text
L^x_F = epsilon_a  (mod 2).                             (4)
```

The row argument is identical, with the two axes exchanged.

The finite-support trace criterion supplies the mod-four form. A translation
class of multiplicity `n` has stable word `RLRL...`, and so contributes
`floor(n/2)` left turns. Summing over one fibre gives

```text
L^x_F=(nu^x_F-Omega^x_F)/2,
L^y_F=(nu^y_F-Omega^y_F)/2.
```

Combining these identities with (4) proves (1). The start-with-`R` part of the
trace criterion is essential in this last step.

## Growth-eight consequences

The law applies to all ten representatives in the growth-eight ledger.

- At `(1,-1)`, the single fibre on either axis has eight odd classes, recovering
  `N=2 (mod 4)`.
- At `(2,0)`, each `x` residue contains four odd classes and therefore has visit
  count two modulo four. Each of the four wake-bearing rows contains two odd classes
  and also has visit count two modulo four.
- At `(2,-2)`, a coordinate residue containing two or six odd classes has visit
  count zero modulo four; one containing four has visit count two. This holds
  independently on both axes.
- At `(1,3)` and `(1,-3)`, the lone `x` fibre has visit count two modulo four.
  The three `y` fibres have visit counts `2+0+0`, with the `2` in the four-class
  fibre.
- At `(3,-3)`, the `4+2+2` margins give visit counts `2+0+0` on both axes.
  Under the additional full-rail hypothesis, the transverse cut residues give
  `N>=4W+12|k|+2`, where `k=(v-h)/3`, and hence `N>=4W+14`.
- At `(4,0)`, every `x` residue has visit count zero modulo four. On each exact
  row the visit count is congruent modulo four to the number of odd classes on
  that row.
- At `(2,4)` and `(2,-4)`, every coordinate residue on both axes has visit count
  zero modulo four.
- At `(4,-4)`, every coordinate residue has visit count zero modulo four. This
  does not strengthen the period congruence to modulo sixteen: summing four
  quantities divisible by four gives only a multiple of four. The
  full-rail subfamily is excluded by the independent rank argument; the
  whole orbit remains open.

These congruences do not close another orbit. After writing each class
multiplicity as its odd-class indicator plus twice a binary variable, the full
transverse, longitudinal, column, and row system remains feasible on all 185
additive `(3,-3)` boundary placements through width thirty. The recorded
width-ten, period-64 `(4,-4)` arithmetic skeleton also remains feasible, with
binary-system nullity 24.

Scope correction, 3 September 2026: the 185 `(3,-3)` placements assume full
rail occupancy. Extremal singleton visits do not prove that hypothesis.
The coordinate-fibre law (1) is unaffected; the conditional period bound is
qualified in `rail_occupancy_scope_audit_2026-09-03.md`.

## Audit

```text
python code/python/growth8_diagonal_coordinate_residue_audit.py \
  --output results/growth8_diagonal_coordinate_residue_audit.json
```

The kinematic part enumerates all 10,702 heading-resetting turn words of period
at most fourteen having nonzero drift. It checks both reversal identities and
the predicted left-turn parity in every residue fibre or exact coordinate line,
with no failures. This enumeration is a regression for the all-period counting
proof, not its premise.

The direct finite-support control is the standard period-104 highway. Each of
its two `x` residues, and each of its two `y` residues, contains 52 events, six
odd classes, and 23 left turns. The program also checks the period bound on all
185 additive `(3,-3)` placements through width thirty and solves the combined
binary congruence systems described above.

```text
growth8_diagonal_coordinate_residue_audit.py
79b1c6d8df03c193bf5583c3ea41e6a1231fff2efedb9005b5d857ee52970435

test_growth8_diagonal_coordinate_residue_audit.py
e7282d395a00951cc6d6f84d84a5f8fd102fb8d0f979318179cf854ba8ae53e4

growth8_diagonal_coordinate_residue_audit.json
21af23a91f774f2b581b07ec7d4a3f34aef0981605c44554e81ccf0aaaf874a3
```
