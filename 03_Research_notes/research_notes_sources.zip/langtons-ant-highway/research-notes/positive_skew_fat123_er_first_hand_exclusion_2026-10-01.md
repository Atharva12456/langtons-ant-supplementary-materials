# Hand exclusion of the lower fat-(1,2,3) ER-first branch

Assume a finite-support periodic Langton highway with literal drift
`d=(1,3)`, clockwise R, `t=3x-y`, and lower cap normalized to zero.
Stable words begin R and alternate R,L. Directed edge blocks match by
arrival/departure ordinal, retaining physical copy voltage. The lower
fat-(1,2,3) ER-first (`k=0`) branch is impossible at every growth, width,
and positive period.

This is a hand obstruction. It does not use P22, a wake budget, a bound
on N, a period congruence, or enumeration of later words. In fact every
return used below has zero voltage, so no inequality involving N is used.
This excludes this local branch; it does not close the drift orbit.

## Starting forms and notation

The fixed rows are

```
0: NR;
1: WR,WL;
2: NR,SL,NR;
3: ER,WL,WR,WL,WR,[WL]^(1-a), a in {0,1}.
```

For completeness, the ER-first fourth-row normal form follows directly
from the four-step square. Let D be its first west departure. The path
`D -> 1:WR -> 0:NR -> 3:ER -> 4:first S arrival` has directions WNES.
The ER is the first south departure on three. Therefore D cannot be SR,
which would be an earlier south arrival. Thus D=NL and its immediately
next stable event is SR, the second west departure on four. Before D
there is no south arrival or west departure; alternation leaves exactly
one NR. Afterwards no west departure remains, so the other ports are NR
and SL. The exact counts give

```
4: NR,NL,SR,SL,(NR,SL)^(2-a),[NR]^b, b in {0,1}.
```

This is precisely the four starting pairs in the saved k0 domain. Only
their common prefix `NR,NL,SR,SL,NR,SL` will be used below.

Write E1,E2,E3 for the three east arrivals on five, supplied in order by
`2:NR,SL,NR`. Write H1,H2,H3,H4 for the first four east arrivals on seven,
supplied by `4:first NR,first SL,second NR,second SL`. Write Fj for the
jth north departure on the row currently under discussion. A physical
first return means that the endpoint is the immediately next stable
event at the starting physical cell, with opposite turn.

## 1. Forced prefixes on five and six

If E2 were EL, the path

```
4:SR -> 1:WL -> 2:SL -> 5:E2=EL -> 4:N arrival
```

would have directions WSEN and be a physical first return. But the next
stable event after that SR is SL. Therefore **E2=ER**.

The second north departure F2 on five feeds `4:NL`. Its forced path is

```
F2 -> 4:NL -> 1:WR -> 0:NR -> 3:ER -> 4:SR
   -> 1:WL -> 2:SL -> 5:E2=ER.
```

Its directions are NWNESWSE. It returns physically to five, with no
intermediate level-five visit. Thus F2=EL and immediately precedes E2.
The only earlier east arrival is E1, so F2=E1. Before E1 there is exactly
one north departure, necessarily WR. R-first alternation allows no
additional port before E1: another WR would be an additional north
departure, while inserting a WL would require another R before the EL.
Hence

```
5 begins WR,EL,ER, with E1=EL and E2=ER.
```

Now let D2 be the second west departure on six. Its path is

```
D2 -> first 3:WR -> first 2:NR -> 5:E1=EL -> 4:NL
   -> 1:WR -> 0:NR -> 3:ER -> 4:SR -> 1:WL -> 2:SL
   -> 5:E2=ER -> first 6:S arrival.
```

The directions WNENWNESWSES give a twelve-step physical first return.
E2 is the first south departure on five, so its endpoint is the first
south arrival on six. D2 cannot be SR, an earlier south arrival; it is
NL and its next stable event is SR, the third west departure. Before D2
there are no south arrivals and exactly one west departure, also NL.
Alternation therefore forces

```
6 begins NR,NL,NR,NL,SR.
```

## 2. Four east arrivals on seven

The second north departure F2 on seven feeds the first NL on six. The
four-step return

```
F2 -> first 6:NL -> first 3:WL -> first 4:SL -> H2
                         N,W,S,E
```

forces F2,H2 to be consecutive stable events with opposite turns.
The fourth north departure F4 feeds the second NL on six. Its path is

```
F4 -> second 6:NL -> first 3:WR -> first 2:NR -> 5:E1=EL
   -> 4:NL -> 1:WR -> 0:NR -> 3:ER -> 4:SR -> 1:WL
   -> 2:SL -> 5:E2=ER -> 6:SR -> second 3:WL
   -> second 4:SL -> H4.
```

Its directions NWNENWNESWSESWSE give a sixteen-step physical first
return with no intermediate level-seven visit. Thus F4,H4 are likewise
consecutive with opposite turns.

Suppose H1=EL. All earlier ports on seven are W arrivals. There must be
at least one earlier WR because the row starts R. There cannot be two:
then F2 would precede H1 and its immediately next event H2 would also
precede H1, contrary to east-arrival order. Thus H1 itself is F2. The path

```
first 4:NR -> H1=EL -> first 6:NL -> first 3:WL -> first 4:SL
                           E,N,W,S
```

is a physical first return which skips `4:NL,SR`. This is impossible.
Consequently **H1=ER**.

F2 precedes H2. It cannot be EL: the only earlier east arrival is H1,
which is ER. Hence F2=WR and **H2=EL**, the third north departure.
The next event after H2 is R. If it were WR, it would be F4 and its
immediate successor H4 would skip H3. Therefore that next event is
**H3=ER**. F4 cannot be EL, since the earlier east arrivals are H1=ER,
H2=EL (already F3), and H3=ER. Thus F4=WR and **H4=EL**, the fifth north
departure on seven.

## 3. The final dichotomy

The path

```
6:SR -> second 3:WL -> second 4:SL -> H4=EL -> fifth 6:N arrival
                            W,S,E,N
```

is a physical first return. The fifth north arrival is therefore the
immediately next stable event after this SR, and its turn is L. Thus

```
6 begins NR,NL,NR,NL,SR,NL.
```

This last NL is the fourth west departure on six. It feeds the last WR
on three, which feeds the last NR on two, which feeds E3 on five.

If E3=EL, there is the twelve-step physical first return

```
4:SR -> 1:WL -> 2:SL -> 5:E2=ER -> 6:SR
     -> second 3:WL -> second 4:SL -> H4=EL -> last 6:NL
     -> last 3:WR -> last 2:NR -> 5:E3=EL -> 4:N arrival.
```

Its directions are WSESWSENWNEN. Its endpoint is a north arrival,
although the next stable event after `4:SR` is SL. This is impossible.
There is an intermediate quotient level-four visit after six moves,
at displacement `(-1,-3)=-d`; it is **not** the starting physical cell.
The first physical return is after twelve moves. No adjacency claim is
made at the nonzero-copy quotient return.

If E3=ER, the four-step path

```
last 6:NL -> last 3:WR -> last 2:NR -> 5:E3=ER -> 6:S arrival
                              W,N,E,S
```

forces the immediately next event on six to be SR. Since the prefix
before it contains exactly one south arrival, this would be the second
south arrival. But E3 cannot be the second south departure on five:
E2=ER is the first, and R/L alternation requires a left turn between
E2=ER and E3=ER. No other east arrival lies between E2 and E3, so that
left turn must be WL, an intervening south departure. E3 is therefore
at least the third south departure. Directed ordinal matching contradicts
the endpoint being the second south arrival.

Both possibilities for E3 are impossible. This proves the k0 exclusion
for all four starting pairs and all later wake choices.

## Independent audit and relation to the saved finite certificate

`verify_k0_hand_obstruction.py` uses a fresh geometric heading map and
physical coordinates; it imports no cap/frontier code. It checks every
displayed return's direction word, displacement, edge target levels,
absence of an intermediate return to the starting physical cell, and
zero accumulated voltage. It also checks the purely alternating-word
argument on seven using only the two required next-event implications,
the directed ordinals of seven named paths across all four cap forms and
both necessary row-seven prefixes, and the final ER/ER south-departure
ordinal contradiction. Its small
word check enumerates only words over ER,EL,WR,WL through H4. F4 immediately
precedes H4, so this prefix has at most four WR ports and four east arrivals,
hence at most eight R ports and length sixteen. The two implications and
ENWS exclusion leave exactly two prefixes, both of length ten. This small
check uses no N, width, wakes, row counts, or frontier.

The existing independent k0 certificate has stages 4 -> 33 -> 122 -> 0;
all 6,292 terminal emitted words fail a physical return. This proof
replaces that terminal enumeration as mathematical justification. It
needs neither the 33 fifth-row survivors nor the 122 sixth-row survivors.
The prior finite check remains a useful separate regression.


Run from the project root:

```text
python work_positive_skew_k0_20261001/verify_k0_hand_obstruction.py
```

The canonical copy was integrated on 1 October 2026 after an independent
structural review and fresh checker run. The whole orbit remains open.
