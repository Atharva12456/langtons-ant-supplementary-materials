# Wake family for lower fat `(0,0,111)` with an upper missing cap

24 September 2026. At drift `(1,-3)`, let the lower `(1,2,3)` cap have
`omega_3=omega_4=0` and `(j,k,l)=(1,1,1)`. If the upper cap is missing,
then P22, the even rank condition, the additive moment, and the all-period
missing-cap offset-five/six theorem leave exactly one wake family:

```text
W = 6m+4,
O = {0,2,6i+2,6j,W-6,W-4,W-1,W},
1 <= i < j <= m-1,  i+j even.
```

In particular **`W>=28`**. This is a necessary wake classification, not an
exclusion of the cap pair or a construction of an ant orbit. The first
placement is `W=28`, `O={0,2,8,18,22,24,27,28}`.

The lower cap supplies wakes `0,2` and non-wakes `1,3,4`. The upper missing
cap supplies wakes `W,W-1,W-4`, non-wakes `W-2,W-3`, and, by the missing-cap
theorem, a non-wake at inward offset five and a wake at offset six.
Thus `W-6` is wake and `W-5` is non-wake. Both cap arrivals are horizontal, so
`W` is even. The six fixed wakes are distinct in any admissible placement.

P22 requires signed wake sum `2 mod 4` in each residue-three fibre. If
`W=0 mod 6`, the fixed residue-zero fibre already has three even wakes
and needs an odd fourth. The residue-two fibre has two even and one odd
and needs an even fourth. The residue-one fibre is empty and needs at least
two more wakes. Four extras would be needed, but only two remain.
If `W=2 mod 6`, residue two has three even fixed wakes and needs one
more; residue one has one even and one odd, so it needs at least two more;
residue zero contains only level zero and needs another. Again two extras
cannot suffice.

For `W=6m+4`, residue one already has the even pair `{W-6,W}`.
Residue zero has `{0,W-4,W-1}`, two even and one odd, and needs one
even wake `6j`. Residue two has only the even wake `2` and needs one
even wake `6i+2`. Distinctness and cap non-wakes give
`1<=i,j<=m-1`. These are all eight wakes.

The even-rank interlacing count across the three fibres is
`I=8+[6j<6i+2]`. Hence `I=0 mod 2` exactly when `i<j`.
The normalized odd-skew moment is
`M=sum_{t in O}(-1)^t floor(t/3)=4m-1+2(i+j) mod 4`.
Its required value `3 mod 4` is equivalent to `i+j` even. The smallest
indices with `1<=i<j` and even sum are `(i,j)=(1,3)`, requiring `m>=4`
and therefore `W>=28`.

From the upper cap, the only possible wake patterns through inward
offset fourteen are `{0,1,4,6}` and `{0,1,4,6,10}`. Offset ten is wake
exactly when `j=m-1`. The other free wake has upper offset at least
fourteen; equality at fourteen would require `i=m-2,j=m-1`, whose sum is
odd, so offset fourteen is in fact non-wake. This agrees with the earlier
finite upper-prefix audit. On the lower side, levels five through seven
are non-wake, and level eight can be wake only when `i=1`.

The independent checker
`code/python/lower_fat123_a0_b0_111_upper_missing_schedules.py` enumerates
all eight-wake sets through even width 160 under the stated endpoint,
P22, rank and moment conditions, and compares them exactly with the
closed form. It finds 1,222 placements and records its output in
`results/lower_fat123_a0_b0_111_upper_missing_schedules_2026-09-24.json`.
The derivation above, rather than the finite audit, establishes the
all-width scope. Stable words and clocks have not yet ruled out the
remaining family.
