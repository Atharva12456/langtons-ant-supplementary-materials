# Strong quiet-row lookahead for thin110 / upper F122 wakes four and seven

The literal `(1,3)` growth-eight orbit remains **OPEN**. The arbitrary-width
lower-thin110 / upper-F122 wakes-four/seven family has

```text
W=6m+4,
O={0,4,5,6,6r+5,W-7,W-4,W},
1<=r<=m-3, m-r odd.
```

Its minimum width is 28. Upper inward rows eight through sixteen are
quiet, and the 34-event lower cap is disjoint from the assigned upper
band through sixteen. Hence every possible period satisfies
`N>=max(62,assigned upper events+34)`, `N=2 mod4`, with no upper bound.

The complete independently audited upper domain through row twelve has
2,076 necessary words. The new continuation tests each row-thirteen word
against **every** exact quiet-row-fourteen count vector. A row-thirteen
word is rejected only if all these finite necessary word domains are
empty. A resource cap produces explicit incompleteness.

Two versions are kept separate. The first imposes only zero-copy
immediate-next returns from the new row. The stronger version also checks
wrong first physical returns to old cells through exactly one new-row
visit, using the [proved physical-pair rule](../work_positive_skew_upper47_audit_20261002/physical_pair_guard_20261003.md).
It can additionally impose translated excursion order when the proved
period floor gives `N>old assigned events+1`. Both rules use incoming and
outgoing ordinals determined by consumed port counts. Together with the
required next arrival, these counts form a complete finite recursion
state. Each recursion transition consumes one port. The stronger cache
includes its full physical, translated, and zero-copy constraint context;
zero-only outcomes are never reused as stronger outcomes.

## Two complete upper prefixes are excluded at every family width

The first word of the complete upper-row-twelve source has these literal
inward rows; headings use the upper half-turn gauge:

```text
0  NR
1  WR WL
2  NR SL
3  WR WL ER WL
4  SR SL NR SL NR NL NR
5  WR WL WR WL ER WL WR EL
6  NR SL SR SL SR NL
7  WR WL ER EL ER WL ER WL ER
8  NR SL SR SL NR NL SR SL NR NL NR NL SR SL
9  WR WL WR EL ER WL WR WL WR EL WR WL
10 NR SL NR NL SR SL NR SL NR NL NR NL NR SL
11 WR WL WR EL ER WL WR WL ER WL ER WL WR WL WR EL ER WL ER WL WR EL
12 NR SL NR NL SR SL NR SL NR SL SR SL NR NL NR SL NR SL NR NL SR SL NR NL SR SL NR NL
```

A fresh independent enumeration checks this word's entire row-thirteen
domain, including every earlier physical and unbounded clock rejection.
There are 28 necessary clock-SAT extensions. Twenty-one have no
zero-copy necessary quiet-fourteen word. The remaining seven are all
excluded by the stronger necessary physical constraints: every one of
their 78 exact count vectors is empty.

The stronger independent checker imports no producer code. It reconstructs
all forbidden ordinal combinations in literal `(x,y)` coordinates and
replays all 10,239 supplied wrong-old-cell first-return certificates.
Each uses exactly one new-row visit. Its separate consumed-count graph
exhausts 15,051 states and proves all 78 domains empty. No translated
order restriction is used in these actual 78 cases; all signed-pair
lists are empty. Thus neither a period ceiling nor a signed-order
implementation is needed for this particular exclusion.

The second source prefix has the same rows zero through eleven and
instead has row twelve

```text
NR SL NR NL SR SL NR SL NR SL SR SL NR SL NR NL NR SL NR NL SR SL NR NL SR SL NR NL
```

Its entire row-thirteen domain was also independently regenerated.
Twenty-seven of its 36 clock-SAT extensions have empty zero-only
quiet-fourteen domains; the remaining nine have empty strong domains.
The separate fixed-source strong audit for selected parents zero through
seven checks all 490 vector queries for 44 candidates, including these
nine. It independently verifies all 302 distinct Boolean signatures,
64,275 literal physical-return instances, and 212 real translated-return
predicates under freshly checked length and period-floor premises.

These two displayed upper prefixes therefore cannot occur in this cap
family at **any width**. These are prefix exclusions, not closure of the
whole cap family or the whole orbit. The other upper prefixes require
separate complete continuation.

The [independent source review](../work_positive_skew_upper47_lookahead_audit_20261004/independent_reviewer_note.md)
and [strong-domain audit](../work_positive_skew_upper47_lookahead_audit_20261004/strong14_independent_audit.json)
give the exact scope and bindings. The
[literal diagnostic](../work_positive_skew_upper47_lookahead_20261004/strong14_parent0_diagnostic.json)
contains all seven row-thirteen words, all count vectors, and physical
certificates.

## Incomplete larger continuation

The frozen fifth zero-only pass completes 25 of the 2,076 source parents.
It disposes of 39,509 candidate cases: 19,362 empty quiet-fourteen domains,
17,907 clock rejects, and 2,240 necessary survivors. These are complete
outputs for those 25 parents, not a complete new source domain. Parent 25
also has 1,669 partial dispositions; these do not imply an exclusion.
The [saved forward state](../work_positive_skew_upper47_lookahead_20261004/forward_resume_pass5.json)
binds the completed and partial records and specifies exact resume behavior.

The separate source audit independently reconstructs all 111,451
row-fourteen count-vector queries and all zero-copy geometry for the first
18 completed parents, checking 25,178 positive witnesses. It independently
checks every Boolean domain for the first two source parents; it does
**not** claim independent verification of the entire later Boolean cache.
At the 4 October checkpoint, the stronger continuation over the 2,240
retained candidates was complete for those 25 selected source parents: all 26,074 vector queries
are empty, with 10,686 distinct strong signatures and no necessary
survivor. At that checkpoint, independent verification covered the first
eight selected parents; the rest of this computation remained under
independent audit. Moreover, the full 2,076-parent source has not been exhausted.
Thus this result cannot close the cap family.
