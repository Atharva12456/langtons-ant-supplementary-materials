# A checker-pure growth-eight exclusion at drift `(2,-2)`

## Status

This note proves an **analytic all-period conditional exclusion**:

> Let a finite-support periodic highway have growth `g=8` and drift in the
> quarter-turn orbit of `(2,-2)`.  Its eight odd translation classes cannot all
> have the same checkerboard parity.

Equivalently, the checker-pure subfamily of the minimal even-diagonal growth-eight
case is impossible.  This does not exclude mixed-checker wakes, the other
growth-eight drift geometries, or primitive-diagonal growth four.  In particular,
it is not a proof of `g>=12`.

The proof reuses the cardinality-free two-lane rank lemma proved for the
even-diagonal growth-four theorem.  No bounded period, bounded transverse width,
or finite search enters the argument.

## Two-lane rank lemma

Normalize the drift to `d=(2,-2)`, put

```text
t=x+y,   r=x mod 2,   ell=(x-r)/2,   tau=i-N*ell,
```

and order every translation class `(t,r)` by increasing `tau`.  Let `K` be the
sum modulo two of the zero-based stable ranks of all left turns.  Write `Q` for
the even-`t` vertical-arrival classes and `C` for the odd-`t`
horizontal-arrival classes.

For a class `v`, let `D_v=#R-#L`.  Exact periodic realisability gives
`D_v in {0,1}`; let `O={v:D_v=1}` and let `o_r` count the members of `O` in lane
`r`.  The two-lane edge-block calculation in the paper proves the following
statement whenever all of `O` lies on `Q` or all of `O` lies on `C`:

Since `chi(x,y)=(-1)^(x+y)=(-1)^t`, checker-pure is exactly the hypothesis
`O subset Q` or `O subset C` (for the chosen vertical-arrival phase).

```text
K = 1 + E + L                                  (mod 2),
E + L = sum_r binom(o_r,2)                     (mod 2).       (1)
```

Here `E` is the edge-block permutation sign and `L` is the sum of the local
binary-inversion corrections.  The proof of (1) is independent of `|O|`.  In one
lane the relevant finite binary edge chain splits into `k_r` runs.  Its boundary
contains `o_r=2k_r` odd classes, while its edge/local sign is `k_r`; hence

```text
k_r = binom(2k_r,2) = binom(o_r,2)             (mod 2).
```

Summing the two lanes gives (1).  Pairwise gadget inversions suffice for an
arbitrary finite chain because inversion parity is quadratic in the mod-two edge
indicators; overlapping gadgets combine by symmetric difference.

## Application at growth eight

Assume for contradiction that all eight odd classes have one checker sign.  The
endpoint decomposition has one canonical strand base for each odd class, and
translation by `(2,-2)` preserves checker parity.  The signed residue theorem,
applied in each `x mod 2` lane, therefore gives

```text
+/- o_r = 2                                    (mod 4).
```

The sign is common to all eight classes, and either choice gives
`o_r=2 (mod 4)`.  Since `o_0+o_1=8`, necessarily

```text
{o_0,o_1}={2,6}.
```

Consequently

```text
E+L = binom(2,2)+binom(6,2) = 1+15 = 0         (mod 2),
```

and the one-cycle sign in (1) gives `K=1`.

On the other hand, exact stable alternation places every left turn at an odd
zero-based rank, so `K=#L (mod 2)`.  Write `N=2M`.  Heading reset makes exactly
`M` moves horizontal, and horizontal displacement two forces `M` to be even.
At growth eight,

```text
#L=(N-8)/2=M-4 = 0                             (mod 2).
```

Thus `K=0`, contradicting `K=1`.  Quarter-turn rotations cover all four sign
choices with `|d_x|=|d_y|=2`.

## Audit and the remaining case

The existing regression

```text
python code/python/even_diagonal_rank_parity_audit.py
```

checks the local correction truth tables, both parity gadgets, their complete
pairwise interaction table in a representative window, and finite two-lane chains.
The additional arithmetic and cardinality check is

```text
python code/python/growth8_checker_pure_audit.py
```

Both programs are bounded regressions of the displayed algebra, not proof oracles.
The proof is the finite-support run decomposition and parity argument above.

The unresolved `(2,-2), g=8` family is therefore **mixed checker** and remains
open, as do the other growth-eight drift geometries.
