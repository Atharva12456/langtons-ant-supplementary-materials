# Mixed-checker rank parity at drift `(2,-2)`

## Result and scope

Let a finite-support periodic trace have drift `(2,-2)`.  Write `t=x+y` and
`r=x mod 2`, and split the excess-one translation classes into

```text
Q = {t even},                 C = {t odd}.
```

Put

```text
q_r = |O intersect Q intersect {r}|,
c_r = |O intersect C intersect {r}|.
```

When the four counts have a common parity, denote it by `p`.  Define

```text
I = #{(c,q) in (O intersect C) x (O intersect Q): t(c)<t(q)}  (mod 2).
```

The two-lane rank factorisation has the following boundary form:

```text
E+L = sum_r [binom(q_r,2)+binom(c_r,2)] + I + p  (mod 2).       (1)
```

Here `E` is the directed-edge block sign and `L` is the sum of the local port
corrections.  Formula (1) holds for every finite parity flow, without a period or
width bound.

For growth eight, P22 gives

```text
q_r-c_r       = 2  (mod 4),
q_r-c_(1-r)   = 2  (mod 4).
```

Thus `q_0=q_1 (mod 4)` and `c_0=c_1 (mod 4)`.  The four binomial terms in (1)
cancel in pairs, and the one-tour sign reduces to

```text
I+p=1.                                                        (2)
```

This is an all-period necessary condition.  It recovers the checker-pure
exclusion and narrows the two mixed families as follows:

```text
checker split 2:6 or 6:2:    p=1 and I=0,
checker split 4:4:           p=0 and I=1.
```

## A second additive charge

The same quotient has a useful mod-four charge which is independent of the
coordinate indicators used in P22.  Put

```text
w(x,y) = (-1)^(x+y) (floor(x/2)+floor(y/2))  (mod 4).
```

Its four-corner sum is zero, it is periodic under `(x,y) -> (x+2,y-2)`, and
the north-heading potential changes by `3` around the translation cycle.  The
usual charge-conservation argument therefore gives

```text
sum_(q in Q) floor(t(q)/2)
  - sum_(c in C) floor(t(c)/2) - q_1 = 1  (mod 4),             (3)
```

where `q_1` is the number of even-`t` classes in lane `r=1`.  In the normalized
`4:4` residue matrix this says that the raw `Q-C` moment is `3 mod 4`; in the
normalized `6:2` matrix it is `0 mod 4`.

Equations (2) and (3) are genuinely separate restrictions, but they do not yet
give an exclusion.  There are finite boundary placements satisfying both.  A
further argument must use more of the visit order than its sign and this one
additive moment.

## Audit

`code/python/mixed_checker_rank_parity_audit.py` checks the local gadget table,
reconstructs every finite parity flow in a strip of width six, and verifies the
weight and monodromy identities above.  Its current run reports

```text
finite flows:            32768
mixed table checks:         53
additive-weight checks:    773
failures:                    0
```

The finite enumeration is a regression check.  The all-period statements are
the finite-support factorisation and the additive-charge calculation above.

Both alternatives survive the present residue, additive-weight, and aggregate
level filters.  Consequently (2) is not a complete exclusion of mixed-checker
wakes.

## Proof of the boundary formula

First suppose all four lane counts are even.  Pair the `C` boundary in each lane
by a finite binary chain `alpha[j,r]`, and pair the `Q` boundary by a chain
`beta[j,r]`.  The centres `j` are odd.  The parity flow is the symmetric
difference of the two four-edge gadgets

```text
G_C(j,r)={N[j,r],S[j+2,r],W[j+1,1-r],E[j+1,1-r]},
G_Q(j,r)={S[j,r],N[j,r],E[j-1,r],W[j+1,r]}.
```

This decomposition is unique.  A finite zero-boundary flow has `w=e` on `Q` and
`s=n` on `C`; conservation then makes the remaining binary edge sequences
constant in the transverse direction.  Finite support forces those constants to
vanish.

The sign `E+L` is a quadratic function of the directed-edge parity bits.  Each
gadget has value one.  Two gadgets of the same type have cross value one exactly
when their centres are adjacent in the same lane.  The usual finite-run count
therefore gives

```text
sum_r binom(q_r,2)+sum_r binom(c_r,2).
```

For a mixed pair `G_C(j,r),G_Q(k,s)`, the cross value is independent of the lane
choices and is one exactly when `k-j` is `0` or `2`.  Hence the mixed contribution
is

```text
sum_(j,r,s) alpha[j,r](beta[j,s]+beta[j+2,s]).
```

The second factor is the `Q` boundary at level `j+1`; the sum over `r` in the
first factor is the parity of the number of `C` boundary points below that level.
The displayed sum is precisely `I`.  This proves (1) in the even sector.

If all four counts are odd, choose an even level `k` below the support and add

```text
H(k)={E[k,0],E[k,1],S[k+1,0],S[k+1,1]}.
```

Its boundary has one point of each type in each lane, and its value is one.  Being
below the original support, it has zero cross term with the original flow.  The
four binomial changes sum to zero, while `I` is unchanged.  Applying the even
formula after this toggle supplies the final `+p` in (1).

## Growth-eight consequence

Port sorting factors the one-cycle phase successor as

```text
K=1+E+L  (mod 2),
```

where `K` is the sum of the stable ranks of all left turns.  Exact alternation
puts every left turn at odd zero-based rank, so `K=#L (mod 2)`.  Write the period
as `N=2M`.  There are `M` horizontal moves, and horizontal displacement two makes
`M` even.  At growth eight,

```text
#L=(N-8)/2=M-4=0  (mod 2).
```

Therefore `K=0`, whereas the factorisation gives `K=1+I+p`.  This proves (2).

The bounded regression is

```text
python code/python/mixed_checker_rank_parity_audit.py
```

It checks the complete mixed gadget table and every reconstructed finite parity
flow in a configurable strip.  The proof is the finite-support decomposition
above, not the bounded strip enumeration.
