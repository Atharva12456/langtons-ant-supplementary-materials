# Form R requires a wake at six and one of two orders at seven

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: M and N are both excluded. See
`odd_skew_upper_a_r_exclusion_2026-09-15.md` for the
completion of the upper form-R exclusion in family A.

Consider form R at the upper cap of family A:

```text
5: NR,SL,SR,NL,NR,SL,NR,SL
6: ER,WL,ER,WL,WR,EL,[WR]^e,       e=omega_6.
```

The non-wake conditions at offsets seven and eight exclude
`e=0`. If `e=1`, only the following two words on seven
remain:

```text
M: SR,SL,SR,NL,NR,SL,SR,SL,NR,SL,SR,SL;
N: SR,SL,SR,NL,NR,NL,SR,SL.
```

In M, the tail on eight is forced to be

```text
E3=ER,WL,WR,E4=EL,WR,WL,E5=ER,E6=EL.
```

In N, the complete word on eight is

```text
WR,WL,ER,WL,WR,EL,WR,EL,WR,EL,WR,WL,ER,EL.
```

Neither continuation is excluded here. Thus form R in
family A now requires `h=1`, or `p=m-1`. Forms P and
Q from the two-`ER` normal form, family B, and the other
cap profiles remain open.

## The prefix on seven

Let `Wi` be the west departures on seven and `Ni` its
north arrivals. The last-`EL` obstruction for word B
already forces `W3=NL`, supplied by `6:WR`. This is
the first north arrival `N1`; its square through
`4:second WL,3:last SL,6:EL` ends at `N2=NR`.
The earlier west departures must both be `SR`, giving
the fixed prefix

```text
7: W1=SR,SL,W2=SR,W3=NL,N2=NR,... .                 (1)
```

If `e=1`, there is one further north arrival, supplied
by the final `WR` on six. Write it as `N3`.

Label the six east arrivals on eight by `Ei`; they are
supplied by `5:NR1,SL1,NR2,SL2,NR3,SL3`. The square
through `W1,4:first WR,5:NR1` forces `E1=ER`, the
second south departure on eight. Its first south departure
is a `WL` immediately before `E1`.

If `W4=SR`, then `E3=ER`. Otherwise its seven-step
path through `4:second WR,5:NL,2:WL,1:SL,4:EL,5:NR2`
would end at `E3=EL`. The south predecessor of `W4`
would then be `E2=ER`, forcing the square

```text
5:SL1 -> 8:E2=ER -> 7:W4=SR -> 4:second WR -> 5:NL
```

with two left-turn endpoints. Thus `W4=SR` is immediately
followed by `SL`. In that case `W5` cannot be `NL=N3`,
since no right turn is available between that `SL` and
the next `NL`. Hence `W5=SR` too.

If `W4` instead turns left, it must be `N3`, forcing
`e=1`. There are then no north arrivals left for `W5`,
so `W5=SR`. Alternation gives word N in the statement.

## The possibilities with W4=SR

For `e=0`, append `SL,SR,SL,SR,SL` to (1). For
`e=1`, the remaining `NR=N3` can precede `W4`, lie
between `W4,W5`, or follow `W5`. Since seven is
non-wake, the respective tails after (1) are

```text
before W4:       SL,NR,SL,SR,SL,SR,SL;
between W4,W5:   SL,SR,SL,NR,SL,SR,SL;
after W5:        SL,SR,SL,SR,SL,NR,SL.
```

The relevant south ordinals are

| Case | E3=ER | W5 | Total south arrivals on seven |
|---|---:|---:|---:|
| `e=0` | 6 | 7 | 8 |
| `N3` before `W4` | 7 | 8 | 9 |
| `N3` between `W4,W5` | 6 | 8 | 9 |
| `N3` after `W5` | 6 | 7 | 9 |

If `E5=EL`, the square through `W5` forces the
consecutive pair `E4=ER,E5=EL`, with `E4` supplying
`W5`. In the first, second, and fourth rows, its south
ordinal would be immediately after that of `E3=ER`.
Successive east right turns require an intervening `WL`,
so this is impossible. In those rows `E5=ER` instead,
at south ordinal eight, nine, or eight respectively.

In every row, `E6=EL`. In the first two, `E5` is
already the last south departure. In the fourth, another
east right turn after `E5` would require an intervening
`WL` and exceed the nine south departures. In the middle
row, `E5=ER` would already be the ninth south departure;
if `E5=EL`, a right turn at `E6` would be both the last
east arrival and last south departure, making eight wake.

## A common obstruction at D1

The west departures on nine feed the offset-six west
arrivals in order:

```text
D1 -> first WL,       D2 -> second WL,
D3 -> WR,            [D4 -> final WR]^e.
```

Whenever `E4=EL`, `D1` has the eight-step first return

```text
D1 -> 6:first WL -> 5:SR -> 2:WR -> 3:NR
   -> 6:second ER -> 5:SL2 -> 8:E4=EL
   -> north arrival on 9.
```

Its source cannot be `SR`: its consecutive target would
be `D2=NL`, and the square from `E4=EL` through
`D2,6:second WL,5:SL3` to `E6=EL` would have two
left-turn endpoints. Therefore `D1=NL`, and its incoming
predecessor on eight must be `WR` immediately before `E4`.

In the `e=0`, `N3`-before-`W4`, and `N3`-after-`W5`
rows, the south ordinals force `E4=EL`. The `WL`
supplying `W5` immediately precedes `E5=ER`, by its
square return. It is the only south departure between
`E3` and `E5`, so `E3=ER,E4=EL` are consecutive.
There is no incoming `WR` before `E4`. The obstruction
therefore excludes all three rows, including the whole
`e=0` band.

## The middle row

Suppose first that `E5=EL`. Then `E4=ER,E5=EL` are
consecutive. Extending the path from `D1` through `E4`
by the square through `W5,4:last WR,5:NR3,E5` gives a
twelve-step first return to a north arrival on nine.
An `SR` source would again force `D2=NL`, and the
square from `E5=EL` to `E6=EL` would have two left
endpoints. An `NL` source would have an incoming north
predecessor before `E4`; its eight-step first return to
`E4=ER` would force that predecessor to be `E3=EL`,
contrary to `E3=ER`. Hence `E5=ER`.

This is the ninth and last south departure. Thus `E6=EL`
immediately follows it. Since `E3=ER` is the sixth south
departure, `E4` must be `EL`: taking it to be `ER`
would put `E5` at south ordinal at least ten.

The common obstruction forces a `WR` immediately before
`E4`. The eighth south departure is a `WL` immediately
before `E5`. Alternation fixes the remaining tail as

```text
E3=ER,WL,WR,E4=EL,WR,WL,E5=ER,E6=EL.
```

The corresponding word on seven is M. This tail is not
excluded here.

## The word N on seven

In word N, `W4=NL=N3`. Its seven-step path to `E3`
cannot end at `ER`: that would return from `W4` to
`W5=SR`, whose square to `E5` would skip `E4`.
Hence `E3=EL`.

If `E5=EL`, the square through `W5` forces the
consecutive pair `E4=ER,E5=EL`, with `E4` the fourth
south departure. A right turn at `E6` would then be
the last east arrival and south departure, contradicting
the non-wake condition at eight. Thus `E6=EL`.

The twelve-step return from `D1` through `E4,E5` has
neither possible source turn. An `SR` source gives
`D2=NL` and the left/left square from `E5` to `E6`.
An `NL` source forces its incoming predecessor to be
`E3=EL` by the eight-step return to `E4=ER`; then

```text
5:NR2 -> 8:E3=EL -> 9:D1=NL -> 6:first WL -> 5:SR
```

is a square with two right-turn endpoints. Therefore
`E5=ER`, the fifth and last south departure, followed
immediately by `E6=EL`.

As in the U reduction, `E1=ER` is the second south
departure and the `WL` before `E5` is the fourth.
Taking `E2=ER` would require an intervening `WL`
after `E1`, putting `E2` at ordinal at least four,
where that fixed `WL` already occurs. Thus `E2=EL`.

Let `I` be the third south departure on eight, supplying
`7:W2=SR`. The nine-step path from `W2` through
`4:first WL,3:SR,0:WR,1:NR,4:ER,3:first SL,6:first ER,
5:SL1` ends at `8:E2`. Its upper inward voltage is
minus one. Including the initial south step gives

```text
tau(E2)=tau(I)+10+N > tau(I).
```

Hence the third south departure occurs before `E2`.
It cannot be `E4=ER`, and its only possible position
as `WL` in the alternating word is immediately after
`E1`, before the `WR` preceding `E2`. This fixes

```text
8: WR,WL,ER,WL,WR,EL,WR,EL,WR,EL,WR,WL,ER,EL.
```

The final comparison is an upper-orientation comparison.
The later note `odd_skew_upper_a_r_middle_exclusion_2026-09-15.md`
excludes M and further restricts N. The full R form and
family A remain open.
