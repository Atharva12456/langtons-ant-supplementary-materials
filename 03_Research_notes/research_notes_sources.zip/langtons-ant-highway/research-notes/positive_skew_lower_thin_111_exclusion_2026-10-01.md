# The lower thin 111 wake pattern is excluded at growth eight

Consider a finite-support periodic highway for the clockwise Langton rule,
with literal drift `(1,3)` and growth eight. Normalize `t=3x-y` so its
lower boundary is zero and its even levels have vertical arrivals.

**Theorem.** A lower `(1,2,2)` cap cannot have all three levels five,
six and seven wake. This excludes the entire `111` member of the eight
lower-thin templates at every width and positive period, for every
possible upper cap. The full drift orbit remains **open**.

The proof combines exact endpoint arithmetic with three local upper-cap
lemmas. Two new local lemmas use complete finite word domains with an
unbounded integer period, independently reproduced without the frontier
engine. The all-width conclusion is not inferred from a width search.

## 1. Endpoint arithmetic leaves only upper `(1,2,2)`

The lower thin rigidity theorem forces wakes zero and four and quiet
levels one, two and three. In the `111` branch the complete lower wake
set through seven is therefore `0,4,5,6,7`. Eight distinct wake classes
and those three quiet levels require at least eleven transverse levels,
so the even width W is at least ten. In particular `W-2>7`, and the
outer upper wake band is disjoint from these five lower wakes.

For a wake at t write `j=-t mod3` and `epsilon=(-1)^t`. P22 requires
signed charge two modulo four in each fibre. At growth eight the
unsigned fibre sizes are `4,2,2`. Each two-class fibre is uniform in
sign; the four-class fibre has a `3+1` sign split.

The fixed lower signs are two positive wakes in fibre zero, one
negative wake in fibre one, and an opposite-sign pair in fibre two.
Hence fibre two is the unique four-class fibre, and the full signs are

```text
fibre zero: two positive, zero negative;
fibre one:  zero positive, two negative;
fibre two:  three positive/one negative, or one positive/three negative.
```

The upper extremum W is positive. It cannot enter the already full
fibre zero or the uniformly negative fibre one. Therefore `W=4 mod6`.
Its fibre-two sign together with the positive lower level four forces
the positive-dominant fibre-two alternative.

An upper guard would add the negative fibre-zero wake `W-1`, which
is impossible. An upper `(1,2,3)` cap would add the positive fibre-one
wake `W-2`, also impossible. The missing upper profile was already
excluded by cap geometry. Thus the only remaining upper cap is
`(1,2,2)`.

## 2. The complete two-parameter endpoint family

Write `W=6m+4`. P22 forces the two remaining wakes to be a positive
fibre-two level `u=6q-2` and a negative fibre-one level `v=6p-1`.
They are above seven and strictly below W, so

```text
O={0,4,5,6,7,6q-2,6p-1,6m+4},
2<=q,p<=m.
```

The rank sign is the parity of increasing-fibre pairs in the ordered
transverse wake word. This follows from
`n_i<n_j iff 3n_i-i<3n_j-j` for `i<j`, with `n=ceil(t/3)`;
it includes tied longitudinal coordinates.

The fixed lower/upper fibre word is `0,2,1,0,2,2` and has eight
increasing pairs. Each residual contributes three pairs with those
fixed wakes. Their mutual pair contributes one precisely when the
fibre-one residual v precedes the fibre-two residual u. Thus the full
rank is `14+[q>p]`, forcing `q<=p`.

The moment is

```text
sum_O (-1)^t ceil(t/3) = 1+2(m+q-p)  (mod4).
```

The required moment one is equivalent to even `m+p+q`. The exact
endpoint family is therefore

```text
2<=q<=p<=m,  m+p+q even.
```

These bounds imply `m>=2` and `W>=16`. No use of the separate
computer-assisted width-sixteen exclusion is required in this proof.

All these endpoint sets have quiet upper offsets three, four, seven
and eight. Those levels lie above the fixed lower band and have
residues incompatible with the two residual wakes. Offset five is
wake exactly when `p=m`; offset six is wake exactly when `q=m`.

## 3. Three local upper lemmas exhaust the parameters

Use the orientation-preserving half-turn to express upper inward rows
with the same port letters as lower rows. The clock equation then has
the upper sign `tau(target)=tau(source)+1+N*lambda`, with integer
`N>=1` and strict stable order. There is no upper bound on N.

The following necessary implications hold independently of growth:

1. Upper `(1,2,2)` with quiet offsets three and four and wake five
   must wake six. This was proved in
   [the previous local reduction](positive_skew_tight_thin_reductions_2026-10-01.md).
2. Upper `(1,2,2)` with offsets three through seven all quiet must
   wake eight. The new complete weak domains at offsets three through
   eight have survivor counts `2,3,5,11,5,0` when eight is quiet.
3. Upper `(1,2,2)` with quiet three/four and wake five/six has one
   necessary prefix through seven, whose seventh offset is quiet;
   that prefix must wake eight. With eight quiet, the new weak
   survivor counts are `2,3,3,3,1,0`, including both wake bits at seven.

If `p<m`, then also `q<m`. Offsets three through eight are all quiet,
contradicting lemma 2. If `p=m` and `q<m`, there is wake five with
quiet six, contradicting lemma 1. If `p=q=m`, there are wake five and
six but quiet eight, contradicting lemma 3. These cases exhaust every
endpoint parameter choice.

Therefore lower thin `111` is impossible at growth eight for all widths
and periods. This closes one entire wake-pattern subfamily; it does
not exclude the remaining seven lower-thin templates or the fat bands.

## 4. Complete finite certificates and independent checks

The local domains are finite by the exact port-count recurrence, not
by an imposed visit bound. On an odd new row, if A is the number of
east departures three rows earlier and D the north arrivals one row
earlier, its counts are

```text
ER=A-e, EL=e, WR=D-e, WL=A+D-3e-omega.
```

On an even new row, with B south departures one row earlier and C
west arrivals three rows earlier, they are

```text
SR=s, SL=B-s, NL=C-s, NR=omega+B+C-3s.
```

Nonnegativity gives finite complete count domains inductively from
the fixed cap. Every raw R-first alternating word is enumerated.
Only a witnessed wrong physical first return or an UNSAT exact integer
clock system rejects one. A trace limit or repeated quotient cycle
without a physical witness retains the candidate. No P22, growth
budget, period congruence, event-count bound, or imposed four-step
stable gap is used in the two new local derivations.

| Upper offsets | Complete raw counts at three through eight | Survivors |
|---|---|---|
| three through eight quiet | `2,38,57,230,4748,2370` | `2,3,5,11,5,0` |
| quiet three/four; wake five/six; quiet eight | `2,38,48,69,2610,170` | `2,3,3,3,1,0` |

The independent weak implementations retain all rejections. Root's
separate compass/ordinal implementation freshly replayed all 7,413
physical returns and six clock rejections in the first domain, and
all 2,923 physical returns and two clock rejections in the second.
It rederived each clock system with the correct `+N` sign. A further
raw implementation independently checks every one of the 2,540 row-eight
words, without adjacency pruning, clocks, or frontier imports.

In the second domain, the final hand obstruction forces row eight to
`SR,SL,NR,NL,SR,SL,NR,SL`. A four-step `SWNE` return then goes from
the first WL on seven to its first EL, skipping the intervening WR.
The prefix classification remains computer-assisted; the terminal
square has a short hand proof.

Reproduction from the project root:

```text
python work_positive_skew_unsaturated111_20261001/verify_allquiet_raw.py
python work_positive_skew_saturated111_20261001/independent_weak_raw.py
python work_positive_skew_root_followup_20261001/verify_upper111_quiet8.py
python work_positive_skew_root_followup_20261001/replay_weak_upper111_certificates.py
```

The saved lower-thin domain through level nine has 179 `111` prefixes.
All are now excluded at growth eight. The reduced domain, with 25,099
necessary prefixes and its source hash, is saved as
`results/positive_skew_lower_thin_depth9_without111_2026-10-01.json`.
The endpoint regression
`work_positive_skew_root_followup_20261001/verify_lower111_endpoints.py`
checks the two full P22 sign patterns, every residual pair at even
widths ten through 180, and exact agreement with the formula. Its
2,030 accepted endpoint shadows fall into the three contradictory
local cases; saturated width sixteen is included. This finite check
regresses the preceding all-width derivation.

The full `(1,3)` problem still
requires an obstruction or construction for the other lower-thin
patterns and lower fat bands across arbitrary widths.
