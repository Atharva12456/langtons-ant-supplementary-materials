# Thin 101 and 110 cannot meet an upper (1,2,2) cap with wakes zero and six through eight

For literal drift `(1,3)` at growth eight, lower-thin bits 101 or 110
cannot meet an upper F122 cap whose inward wake set through eight is
exactly `{0,6}`. The result covers every width and positive period.
The whole orbit remains **open**: both lower members retain other
upper schedules and caps.

The endpoint classification and all four complete local schedule
exclusions below have passed independent verification.

## Exhaustive endpoint classification

Write `t=3x-y`, lower extremum zero, and even width W. The prior
exclusion of widths at most sixteen gives `W>=18`, so the endpoint bands are
disjoint. Lower 101 has fixed wakes `{0,4,5,7}`; lower 110 has
`{0,4,5,6}`. The upper schedule fixes `W-6,W`, with every other
offset one through eight quiet. Exactly two wakes remain, both in
the interval `[8,W-9]`.

Use fibre `j=-t mod3`, checker sign `(-1)^t`, and longitudinal
coordinate `n=ceil(t/3)`. Growth-eight P22 requires fibre sizes 4,2,2,
uniform signs in the two smaller fibres and a 3+1 split in the larger.
The complete possible endpoint families are:

| Lower bits | W | Residual wakes | Bounds and parity |
|---|---|---|---|
| 101 | `6m+4` | `{6q,6p+5}` | `2<=q<=p<=m-2`, p-q even |
| 110 | `6m+2` | `{6p+2,6q+4}` | `1<=p<=q<=m-2`, p+q even |
| 110 | `6m+4` | `{6p+1,6q+5}` | `1<=q<p<=m-1`, p+q even |

In each row the full wake set is the fixed lower band, `W-6,W`,
and the displayed residuals. These are necessary shadows only.

For 101, the lower mixed fibre two must be the four-wake fibre. Width
zero would put a third positive wake into the already uniform fibre
zero; width two would put positive upper wakes into the negative
uniform fibre one. Thus W is four modulo six. Its mixed fibre two is
filled by the two upper positives, leaving a positive fibre-zero
residual and a negative fibre-one residual. Quiet lower six requires
q>=2; the residual interval gives both upper bounds.

For 110, width zero gives four positive fibre-zero wakes, which cannot
satisfy P22. At width two the residuals are positive fibres one/two;
at width four they are negative fibres two/one. Every other sign
assignment violates the prescribed fibre sizes or signs.

The rank and moment of the three rows are respectively:

| Row | Increasing-fibre rank | Signed moment modulo four |
|---|---|---|
| 101 | `13+[q<=p]` | `1+2(q-p)` |
| 110, W two | `11+[p<=q]` | `1+2(p+q)` |
| 110, W four | `15+[q<p]` | `1-2(p+q)` |

The indicators follow from the mutual order of the two residual
fibres. Their fixed-band interactions are constant because both
residuals precede the upper fixed band. Even rank and moment one
give exactly the displayed order/parity conditions. Distinct residual
positions and the interval give the remaining bounds. Direct
substitution proves sufficiency for these arithmetic conditions,
without asserting physical realizability.

Root's original-coordinate audit exhausts both residual positions at
every even width 18 through 150, with no mismatch. It finds 946,
1,078 and 946 accepted endpoint sets in table order. The all-width
scope follows from the preceding sign/rank/moment derivation.

## Forced nearby upper wakes

The previously verified local obstruction excludes upper F122 quiet
three/four/five, wake six, and quiet seven through twelve. Our cap
already has quiet seven/eight, so at least one upper offset nine
through twelve must wake.

In the first family the only possible such wake is eleven, occurring
at p=m-2. Offsets nine, ten and twelve are quiet. In detail the
positive fibre-zero residual can have distance ten only at q=m-1,
forbidden by q<=p<=m-2; the negative fibre-one residual has distance
eleven exactly at p=m-2. The mixed fibre's only negative wake is lower
seven, so no other negative upper offset in this range can wake.
Thus upper eleven is forced, with `2<=q<=m-2` and even `m+q`.

In the W-four 110 family, the only possibility is offset nine, at
p=m-1. Offset eleven would require q=m-2, but q<p and equal parity
give q<=p-2<=m-3. Offsets ten and twelve have signs already excluded
by their filled fibres. Thus upper nine is forced, with
`1<=q<=m-3` and odd `m+q`.

In the W-two 110 family, offset ten is wake iff q=m-2, and twelve is
wake iff p=m-2. Since p<=q, wake twelve implies wake ten. Offsets
nine and eleven are quiet. Hence ten is forced and there are just
two parameter branches: `p<m-2`, quiet twelve, or `p=m-2`, wake
twelve. The required parity is even `m+p`; in the former branch it
also gives p<=m-4.

These exhaust the nearby wake schedules. The independent coordinate
audit separately checks the exact offset-nine-through-twelve schedule
in every accepted endpoint set.

## Complete local exclusions

All four necessary upper schedules have a complete empty domain
through offset twelve:

| Branch | Upper wake offsets through twelve | Prefix counts at new offsets | Terminal raw words | Terminal emitted candidates |
|---|---|---|---:|---:|
| lower101 | `{0,6,11}` | eleven: 43; twelve: 0 | 1,001,698,554 | 14,428 |
| lower110, W four | `{0,6,9}` | nine: 8; ten: 10; eleven: 43; twelve: 0 | 355,128,130 | 7,214 |
| lower110, W two, unsaturated | `{0,6,10}` | ten: 10; eleven: 43; twelve: 0 | 3,704,479,431 | 50,227 |
| lower110, W two, saturated | `{0,6,10,12}` | twelve: 0 from the same 43 eleven-prefixes | 4,363,751,717 | 60,587 |

These are exact necessary word domains, with no imposed visit, width
or period ceiling. At each new row the port-count recurrence has a
finite exhaustive range by nonnegativity. The alternating-word
generator prunes only impossible zero-copy first-return adjacency.
Nonzero-copy returns are not treated as adjacent physical visits.
Every emitted candidate is then rejected by an explicit wrong
physical first return or an inconsistent exact integer clock.

The upper gauge is an orientation-preserving half-turn; R/L labels
remain unchanged and edge clocks have **+N** voltage. The only clock
assumptions are integer `N>=1`, unbounded above, and strict stable
order. No growth/P22/period-residue/gap-four filter enters the local
exclusions. Thus those local schedule exclusions are stronger than
the growth-eight family consequences derived above.

The independent audit imports no frontier or fast-clock engine.
It recomputes every count vector and raw-word total, regenerates
every emitted candidate with a separately written nonmemoized
geometric adjacency generator, replays every physical witness, and
independently reconstructs each affine clock contradiction. Z3
checks every distinct cycle-coefficient signature. The complete
earlier weak domains through eight/nine/ten are taken from the
previously verified upper-six proof, and their source hashes are
checked before extension.

Reproduction from the project root:

```text
python work_positive_skew_thin_upper6_schedules_20261001/verify_endpoints.py
python work_positive_skew_thin_upper6_schedules_20261001/probe_branch.py thin101
python work_positive_skew_thin_upper6_schedules_20261001/audit_branch.py thin101
```

Repeat the last two commands with `thin110_W4`,
`thin110_W2_unsaturated` and `thin110_W2_saturated`.
All artifacts are in separate branch directories. The initial 40-second
probe of the unsaturated row-twelve stage was explicitly incomplete;
the subsequent complete run supersedes it and reached no resource
cap. The saturated branch's first-three-stage seed is the complete
unsaturated branch through eleven, which is identical until the
choice at twelve.

The four branches' independent totals are 8,086 physical /
6,536 clock rejects for 101; 4,192 / 3,361 for 110 W-four;
32,939 / 18,739 for unsaturated 110 W-two; and 38,159 / 22,428
for saturated 110 W-two. All 83,376 physical certificates and 51,064
rejected unbounded integer clocks were independently checked. The
four audits also regenerated every emitted candidate and checked
735 distinct clock signatures with Z3. The whole `(1,3)` orbit and both lower members under
their other remaining upper schedules stay open.
