# Primitive-diagonal crossing cap four: an analytic obstruction

Subsequent status: the unrestricted primitive-diagonal growth-four case is
excluded by the analytic reduction and computer-assisted affine classification
in [the top-boundary note](primitive_g4_cap5_symbolic_2026-08-22.md). The
growth-eight cases remain open. The entries below preserve the earlier
checkpoint and its intermediate questions.

## Status

This note proves an **analytic conditional exclusion**.  It does not prove
`g>=12` or classify all periodic highways.  Its conclusion is:

> **Cap-four obstruction.**  Every primitive-diagonal finite-support periodic
> highway has one of its first four cuts above the bottom rail crossed at least
> five times in each direction.

Equivalently, after normalizing the drift to `d=(1,-1)` and writing `f_c` for
the number of upward (and hence downward) crossings of the cut between transverse
levels `c` and `c+1`, the inequalities `f_c<=4` for all `c` are impossible.

The proof uses extremal-line rigidity, the established width bound `W>=10`, and
the exact stabilized-order part of the periodic-realisability criterion.  It is
not a bounded-period or bounded-width computation. At this checkpoint, the
remaining primitive growth-four and growth-eight cases therefore required a fat
cut `f_c>=5`.

## Rooted-plane-tree state

Put the singleton bottom rail at level zero.  The positive transverse excursion
is the contour of a rooted plane tree.  At a fixed depth list its nodes in contour
order and record

```text
B=(b_1,...,b_n)       longitudinal bases,
V=(v_1,...,v_n)       horizontal voltages of the complete subtrees.
```

The root state is `B=(0), V=(1)`.  At depth `d`, put
`epsilon_d=(-1)^d`.  If a parent has children of voltages
`w_1,...,w_k`, then

```text
v(parent)=epsilon_d+w_1+...+w_k.                    (1)
```

Write `P_j=w_1+...+w_j`.  At odd depth the events of a nonleaf parent
of base `b` are

```text
R_b, L_(b+P_1), ..., L_(b+P_(k-1)), R_(b+P_k),
```

and its child bases are

```text
b+1, b+1+P_1, ..., b+1+P_(k-1).
```

An odd-depth leaf contributes a single `L`.  At even depth interchange `R`
and `L`, and remove the `+1` from the child-base formula.  Events on one level
are ordered by decreasing base, with plane order breaking ties.  Exact stabilized
P3 requires the resulting word to be `RLRL...`.

Let `n=f_(d-1)`, `m=f_d`, and let `p` be the number of nonleaf parents at
depth `d`.  The level contains `n+m` events and has total turn excess
`omega=(n+m) mod 2`.  Counting endpoint and interior turns gives

```text
             n+m+omega
p =          ---------       at odd depth,
                 4

             n+m-omega
p =          ---------       at even depth.          (2)
                 4
```

Equations (1)--(2), the cap `m<=4`, and exact stable alternation make the first
four levels a finite/affine calculation.  The details follow so that no voltage
window or search output is being used as a proof.

## Depth one

Equation (2) permits only `f_1=2` or `3`.

For `f_1=2`, sorting the events `R_0,L_a,R_2` forces `a=1`, hence

```text
B=(1,2),       V=(1,1).                               (3)
```

For `f_1=3`, write the two proper partial sums as `a,q`.  Exact alternation
forces exactly one of them to equal one and the other to be nonpositive.  With
`r<=0`, the complete two-family description is

```text
B=(1,2,1+r),   V=(1,r-1,2-r),
B=(1,1+r,2),   V=(r,1-r,1).                           (4)
```

## Depth two

From (3), equation (2) permits `f_2=2` or `3`, with one nonleaf.
For `f_2=2`, only the first parent can be nonleaf and exact order forces

```text
B=(1,1),       V=(0,0).                               (5)
```

For `f_2=3`, sorting the five events gives exactly four families:

| bases `B` | voltages `V` | domain |
|---|---|---|
| `(1,1,1+r)` | `(0,r,-r)` | `r<=-1` |
| `(1,1+r,1)` | `(r,-r,0)` | `r<=-1` |
| `(2,2,2+r)` | `(0,r,-r)` | `r>=1` |
| `(2,2+r,2)` | `(r,-r,0)` | `r>=1` |

Indeed, if the first parent is nonleaf, its proper partial sums must be zero and
a strictly negative number; if the second parent is nonleaf, they must be zero
and a strictly positive number.  These are the four choices of which partial sum
is zero and which parent is nonleaf.

Now start instead from (4).  At even depth two every leaf has voltage `+1`, and
the permitted degree rows require two such leaves.  The first family in (4) never
has two.  The second has two only at `r=0`, giving the parent state

```text
B=(1,1,2),     V=(0,1,1),
```

with parent zero nonleaf.  If `f_2=1`, this produces

```text
B=(1),         V=(-1).                                (6)
```

If `f_2=2`, exact sorting gives

```text
B=(1,k),       V=(k-1,-k),       k<=-1.               (7)
```

There are no other depth-two states.

## Depth three

State (5) needs an odd-depth leaf of voltage `-1` but has none, so it dies.
The same is true of (7): for `k<=-1`, neither `k-1` nor `-k` is `-1`.

For the four `f_2=3` families, equation (2) permits `f_3=1` or `4`.
The first choice requires two voltage-`-1` leaves and is impossible.  The second
requires exactly one leaf, so `|r|=1`.  Before placing the depth-three children,
the four resulting parent states are

| bases | voltages |
|---|---|
| `(1,1,0)` | `(0,-1,1)` |
| `(1,0,1)` | `(-1,1,0)` |
| `(2,2,3)` | `(0,1,-1)` |
| `(2,3,2)` | `(1,-1,0)` |

The first and fourth cannot alternate: the required insertion lies between
consecutive integer coordinates, while the plane tie order fixes the two adjacent
equal signs.  More explicitly, the fixed stable subsequences of the four states,
with coordinates shown as subscripts, are

```text
R_2 R_2 R_1 L_1 R_0,
R_2 R_2 L_1 R_1 R_0,
R_4 R_3 L_3 R_2 R_2,
R_4 L_3 R_3 R_2 R_2.
```

In the first state the second required `L` would have to lie strictly between
coordinates two and one; a tie occurs on the wrong side in plane order.  The
fourth state has the analogous unfillable gap from three to two.

In the second state both inserted `L` events must belong to the last parent, at
coordinates two and one.  Thus the degree row is `(0,1,3)` and that parent's
proper partial sums are zero and one, in either order, giving

```text
B=(1,2,2,3),   V=(2,0,1,0),
B=(1,2,3,2),   V=(2,1,-1,1).                          (8)
```

In the third state both inserted `L` events must belong to the first parent, at
coordinates three and two.  The degree row is `(3,1,0)`, and the same two orders
of proper partial sums zero and one give

```text
B=(3,3,4,3),   V=(0,1,0,2),
B=(3,4,3,3),   V=(1,-1,1,2).                          (9)
```

Finally, state (6) permits `f_3=2` or `3`.  The first forces proper partial sum
zero and produces

```text
B=(2,2),       V=(0,0).                               (10)
```

For `f_3=3`, one proper partial sum is zero and the other is strictly negative.
Writing the latter base as `k<=1` gives precisely

```text
B=(2,k,2),     V=(k-2,2-k,0),
B=(2,2,k),     V=(0,k-2,2-k).                         (11)
```

Thus (8)--(11) are the complete voltage-unbounded frontier after depth three.

## Depth-four extinction

At even depth four, (2) gives the complete list of possible pairs
`(f_4, number of nonleaves)`:

| `f_3` | possibilities |
|---|---|
| `2` | `(2,1)`, `(3,1)` |
| `3` | `(1,1)`, `(2,1)` |
| `4` | `(1,1)`, `(4,2)` |

Every even-depth leaf has voltage `+1`.

- State (10) has no possible leaf.
- Each parametric state in (11) has at most one voltage `+1`, but needs two
  leaves.
- The first state in (8) and the first state in (9) have only one voltage `+1`,
  but need two or three leaves.

Only the second states of (8) and (9) remain, necessarily with `f_4=4` and two
nonleaves.

For `B=(1,2,3,2), V=(2,1,-1,1)`, parents zero and two are nonleaves.
At coordinate two, the fixed block consists of the final `L` of parent zero,
followed by the two leaf `R` events of parents one and three:

```text
L R R.
```

Every optional interior event at that coordinate is also `R`, so the block cannot
be part of an alternating word.

For `B=(3,4,3,3), V=(1,-1,1,2)`, parents one and three are nonleaves.
At coordinate three, the two leaf `R` events of parents zero and two precede the
starting `L` of parent three:

```text
R R L.
```

Again every optional event there is `R`.  This word cannot alternate either.
The exact frontier is therefore empty at depth four.

Since a primitive-diagonal finite-support periodic highway has `W>=10`, these
four levels always occur above its singleton bottom rail.  In fact the proof gives
the sharper boundary-local statement

```text
max(f_1,f_2,f_3,f_4) >= 5.
```

This proves the stated cap-four obstruction without bounding the period, width, or
subtree voltages.  Applying the same argument from the top rail gives a fat cut
within four levels of that boundary as well.

## Independent checks and the remaining boundary

The symbolic classification was independently hand-audited.  A separate exact
frontier enumeration reproduces the depth-three table for voltage windows
`3,5,10,20`; the two unbounded families contribute exactly twice the window size,
the five remaining states are fixed, and the depth-four frontier is empty.  The
targeted regression is

```text
python code/python/audit_primitive_cap4_frontier.py
```

It imposes cut cap four and no wake budget.  The theorem is the unbounded algebraic
case split above, not an inference from the four finite voltage windows.

There is also an independent all-width cap-three profile identity.  If
`f_c<=3`, put

```text
z_c=(-1)^c(f_c-2).
```

Every nonwake level leaves `z` unchanged and every wake level raises it by one.
Indeed, a nonwake transition has `f_(c-1)+f_c=4`; the odd-level wake cases are
`1<->2`, and the even-level wake cases are `2<->3`.  Substitution in the definition
of `z` gives increments zero and one, respectively.  The singleton rails give
`z_0=-1` and `z_(W-1)=1`, so exactly two interior wake levels occur.  Each
singleton rail is itself one unmatched `R`, hence one wake class; the total growth
is therefore four.  This already excludes primitive growth eight under cap three;
the exact-P3 cap-four obstruction is stronger.

Neither argument controls a fat cut.  The unresolved primitive cases now satisfy

```text
max_c f_c >= 5.
```

Closing that unbounded branch, rather than extending a bounded table, is the next
required step toward `g>=12`.
