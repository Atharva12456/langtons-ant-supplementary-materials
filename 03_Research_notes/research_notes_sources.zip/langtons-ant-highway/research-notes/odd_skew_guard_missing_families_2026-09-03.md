# Wake placements for a lower guard and an upper missing cap

Later result (9 September 2026): [the complete guard/missing exclusion](odd_skew_guard_missing_complete_exclusion_2026-09-09.md) closes both lower-guard / upper-missing families. The remaining-family statements below describe the earlier stage; the full drift orbit remains open.

For drift `(1,-3)` and growth eight, suppose the lower cap has profile
`(1,1,1)` and the upper cap has profile `(1,1,0)`.  Normalize the transverse
levels to `0<=t<=W`.  Every such trace has wake set

```text
O={0,1,2,a,b,W-4,W-1,W},       a<b,
```

in one of the following families:

| Family | Width and extra wake levels | Integer restrictions |
|---|---|---|
| I | `W=6m`, `a=6p+2`, `b=6q+1` | `1<=p<q<=m-2`, `m+p+q` even |
| II | `W=6m+2`, `a=6p+1`, `b=6q` | `1<=p<q<=m-1`, `m+p+q` even |

Family I requires `W>=30`.  Family II requires `W>=20`.  These are necessary
conditions, not constructions.  They do not exclude either family at arbitrary
width, and they do not address the cap profiles `(1,2,2)` or `(1,2,3)`.

The proof uses exact same-cell returns, followed by the previously proved
residue and rank conditions.  The additive moment supplies the final parameter
parity.  No enumeration is used.

## A return lemma valid at either missing cap

Measure offsets inward from a missing cap.  The fixed wake offsets are
`0,1,4`.  If offsets six and seven are non-wake, offset five is also non-wake.

At the lower cap, use the usual port labels, consisting of incoming heading
and turn.  At the upper cap, rotate every heading label by 180 degrees.  This
keeps right and left turns unchanged and puts the local port equations into
the same form.  All returns below have zero displacement, so the argument
does not use the sign of the longitudinal voltage.

In these labels the fixed rows are

```text
0: WR
1: NR
2: empty
3: SR,SL
4: WR,WL,ER.
```

Suppose offset five were wake and offsets six and seven non-wake.  Port flow
and alternating stable order force

```text
5: NR
6: WR,EL.
```

The level-seven counts, in the order `(NR,NL,SR,SL)`, can only be
`(2,0,2,4)` or `(1,1,1,1)`.  Write `W1<W2` for its two west departures.
Order-preserving edge matching forces the return

```text
W2 -> 4:WL -> 3:SR -> 0:WR -> 1:NR
   -> 4:ER -> 3:SL -> 6:EL -> last north arrival on 7.
```

Its direction word is `WSWNESEN`.  There is no intermediate level-seven
event.  The endpoints are therefore consecutive visits to the same physical
cell and must have opposite turns.  This rules out `(2,0,2,4)`, whose
endpoints would both turn right.

In `(1,1,1,1)`, `W2` cannot be `SR`: its opposite-turn target would be the
earlier west departure `NL`.  Thus `W2=NL`, followed immediately by `NR`.
The only alternating stable word with the other west departure earlier is

```text
7: SR,NL,NR,SL.
```

The first departure `SR` follows the path `4:WR -> 5:NR` to the first east
arrival `U` on level eight.  Let `V` be the level-eight south departure
feeding that `SR`.  The path from `V` to `U` is a four-step same-cell return.
It puts `V` before the first east arrival, so `V=WL`.  Alternation forces
`U=ER`.  Its southward step completes a four-step same-cell return starting
at `7:SR`, which must consequently be followed immediately by `SL`.  This
contradicts the displayed level-seven word.

The upper-cap version follows by the stated rotation of labels.  In contrast,
the stronger lower-cap bound `omega_6+omega_7>=1` uses a lifted-time inequality
whose sign changes at the upper cap; that stronger bound is not being
transferred here.

## Residue and rank classification

The width `W` is even.  The cap wakes are distinct once `W>=8`, which is
necessary for eight distinct wake levels.  The upper level `W-2` is empty.
Let `O_j` contain the wake levels congruent to `j mod 3`.

P22 requires each signed fibre sum to be `2 mod 4`.  Thus every fibre has an
even number of wakes, at least two.  The opposite signs at `W-4,W-1` force
their fibre to contain four wakes; the other fibres contain two each.  Each
two-wake fibre has equal checker signs.  We may use `(-1)^t` for these signs,
since changing the common sign does not change `2 mod 4`.

Write

```text
I_ij = #{(u,v) in O_i x O_j : u<v},
I = I_01+I_02+I_12.
```

The rank condition is `I=0 mod 2`.  Replacing the normalized residue labels
`(t+1) mod 3` by `t mod 3` preserves this parity because every fibre has even
cardinality.

If `W=6m+4`, the opposite-sign pair `W-4,W-1` lies in residue zero.  The
opposite-sign pair `1,W` lies in residue one.  Both fibres would need at least
four wakes, and residue two needs at least two.  That exceeds growth eight.

### Width divisible by six

For `W=6m`, the fibres have the form

```text
O_0={0,W},
O_1={1,b},
O_2={2,a,W-4,W-1}.
```

P22 gives `a=2 mod 6` and `b=1 mod 6`.  Since the cap levels are already
occupied, `a>=8`, `b>=7`, and both extra wakes lie below `W-4`.  Direct pair
counts give

```text
I_01=2,       I_02=4,       I_12=6+[b<a].
```

The rank condition forces `a<b`.  Put `a=6p+2` and `b=6q+1`.  Then
`1<=p<q<=m-1` before using chronology.

In upper inward coordinates `u=W-t`, offsets six and seven cannot be wake.
Offset six would be an additional member of `O_0={0,W}`.  Offset seven has
residue two and odd parity, whereas the only non-cap member of that fibre,
`a`, is even.  The return lemma therefore makes upper offset five non-wake
too.  That offset is `b=W-5` precisely when `q=m-1`.  Removing it gives

```text
1<=p<q<=m-2.
```

### Width equal to two modulo six

For `W=6m+2`, P22 gives

```text
O_0={0,b},
O_1={1,a,W-4,W-1},
O_2={2,W},
```

with `a=1 mod 6` and `b=0 mod 6`.  Thus `a>=7` and `b>=6`.  The extra wakes
again lie below `W-4`; in particular `b` cannot be the empty level `W-2`.
The pair counts are

```text
I_01=6+[b<a],       I_02=3,       I_12=5.
```

Hence `a<b`.  Writing `a=6p+1` and `b=6q` gives

```text
1<=p<q<=m-1.
```

Upper offset six is excluded by `O_2={2,W}`.  A wake at upper offset seven
would mean `a=W-7`, or `p=m-1`, contrary to `p<q<=m-1`.  Upper offset five
already has the wrong parity for `b`.  Thus upper offsets five through seven
are non-wake in both families.

## The additive moment and the width bounds

In cap-normalized levels, the odd-skew moment condition is

```text
M = sum_(t in O) (-1)^(t+1) floor((t+1)/3) = 3 mod 4.
```

This is the `(1,-3)` specialization proved in
`growth8_odd_skew_additive_2026-08-23.md`.  Substitution of the wake levels gives

```text
Family I:  M=2(q-p-m)-1,
Family II: M=2(p-q-m)-1.
```

In either case, `M=3 mod 4` is equivalent to `m+p+q` being even.

In Family I, `1<=p<q<=m-2` first permits `m=4`, with `p=1,q=2`.  Their sum
with `m` is odd, so `m=4` fails the moment condition.  Thus `m>=5` and
`W>=30`.  The parameters `m=5,p=1,q=2` pass the displayed conditions.

In Family II, `1<=p<q<=m-1` first permits `m=3,p=1,q=2`, whose sum is even.
Thus `W>=20`.  At that width, the only possible wake placement is

```text
O={0,1,2,7,12,16,19,20}.
```

Its normalized moment is `-9=3 mod 4`.  Passing these conditions does not
settle its full chronology.

The earlier width-18 placement

```text
O={0,1,2,8,13,14,17,18}
```

passes the static tests, but has an upper wake at
offset five while offsets six and seven are non-wake.  The short return lemma
therefore rules it out at every period.

## The first even band above the lower guard

Both parameter families make lower levels three through six non-wake.  This
also imposes a short local restriction on their visit multiplicities.  In the
port-count order `(ER,EL,WR,WL)`, level six must have either

```text
(1,2,3,2) or (2,1,0,1).
```

The second case forces the stable rows

```text
5: SR,SL,NR,SL
6: ER,EL,ER,WL
7: SR,SL,SR,NL.
```

In particular, a wake at lower level seven requires the first count row on
level six, with eight visits.  This applies to the width-20 candidate above.

To prove the restriction, begin with the singleton lower-guard rows
`0:WR`, `1:NR`, and `2:WR`.  Even level three has port counts
`(NR,NL,SR,SL)=(1,0,1,2)`.  Its unique `SR` follows `0:WR -> 1:NR` to the sole
east arrival on level four.  The south departure feeding that `SR` and the
returning east arrival form a four-step same-cell return.  The source cannot
itself be the sole east arrival, so it is `WL` and the target is `ER`.

The even level-four count equations now force `WR,WL,ER,WL`.  Its first
south departure is the `WL` feeding `3:SR`, so `SR` is the first south arrival
on level three.  Hence

```text
3: SR,SL,NR,SL
4: WR,WL,ER,WL.
```

Even level five has the same counts as level three and one of two words:

```text
A: NR,SL,SR,SL
B: SR,SL,NR,SL.
```

Level six has three east arrivals and three south departures.  If it has
`h` copies of `ER`, its complete count row is

```text
(ER,EL,WR,WL)=(h,3-h,6-3h,3-h),       h=0,1,2.
```

The unique `5:SR` follows `2:WR -> 3:NR` to the second east arrival `E2` on
level six.  Its south predecessor `D` on level six satisfies the four-step
same-cell return

```text
D -> 5:SR -> 2:WR -> 3:NR -> E2.
```

When `h=0`, the target is `EL` but no right-turn south source exists.  Thus
`h=0` is impossible.

For `h=2`, the only alternating words are

```text
X: ER,WL,ER,EL
Y: ER,EL,ER,WL.
```

In X, the displayed return has `D=WL`, the second south departure.  Thus
`5:SR` is the second south arrival, which gives word A on level five.
In Y, `D` is the first `ER`, hence the first south departure, giving word B.

Word X is impossible without any assumption on level seven.  Its last west
departure has the forced four-step return

```text
last W on 7 -> 4:last WL -> 3:last SL -> 6:EL -> only N arrival on 7.
```

If the target were `NL`, it would be a west departure after the last west
departure.  If the target were `NR`, there would be no `NL` on level seven,
so the source would be `SR` and both endpoints would turn right.

It remains to consider Y with word B.  Let `W2` be the second of the three
west departures on level seven.  Its successor path is

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> 6:first ER -> 5:SR -> 2:WR
   -> 3:NR -> 6:EL -> only N arrival on 7.
```

This has direction word `WSWNESESWNEN`, zero displacement, and no intermediate
level-seven event.  A target `NR` again gives two right turns.  Therefore the
only north arrival is `NL`.  It follows `W2=SR` and is the last west departure.

The level-seven count equations now leave `(NR,NL,SR,SL)=(0,1,2,0)` if wake,
or `(0,1,2,1)` if non-wake.  In the wake case the `NL` cannot be last among
the west departures in an alternating `RLR` word.  In the non-wake case the
only compatible word is `SR,SL,SR,NL`, as claimed.  The middle level-six row
`(1,2,3,2)` has not been excluded.
