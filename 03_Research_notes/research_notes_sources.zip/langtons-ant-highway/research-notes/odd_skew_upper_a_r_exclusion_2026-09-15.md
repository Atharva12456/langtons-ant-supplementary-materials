# Excluding form R at the upper cap of family A

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Form R is impossible. Its zero-wake band was excluded in
`odd_skew_upper_a_r_requires_wake_six_2026-09-15.md`,
and continuation M in
`odd_skew_upper_a_r_middle_exclusion_2026-09-15.md`.
The argument below excludes the remaining continuation N.

The upper clock forces the last two unresolved west
departures on eleven to be `SR`. Their return paths then
require two consecutive east right turns on twelve with
no possible left turn between them. The alternative east
turn gives an eight-step right/right first return.

The argument covers N directly; it does not split into
the four remaining words on ten. Thus all of R1, R2,
L1, and L2 from the first-east reduction are excluded.
Forms P and Q, family B, and the other cap profiles of
the `(1,-3)` orbit remain open.

## The fixed words and notation

Use upper inward headings and lifted times. In N,

```text
5: NR1,SL1,SR,NL,NR2,SL2,NR3,SL3;
6: ER1,WL1,ER2,WL2,WR1,EL,WR2;
7: SR,SL,SR,NL,NR,NL,SR,SL;
8: a=WR,C=WL,E1=ER,I=WL,b=WR,E2=EL,c=WR,E3=EL,
   d=WR,E4=EL,e=WR,J=WL,E5=ER,E6=EL.
```

The four west departures on nine feed, in order,
`6:WL1,WL2,WR1,WR2`. Its full word is

```text
9: NR,SL,NR,SL,NR,SL,NR,SL,NR,D1=NL,NR,SL,NR,SL,
   D2=SR,D3=NL,D4=SR,SL.
```

Let `P1,...,P8` be the west departures on eleven,
feeding `8:a,C,I,b,c,d,e,J` in order. The existing
reduction fixes

```text
10: ...,Y=WL,F2=ER,K=WL,X=WR,F3=EL;
11: ...,P8=NL,NR,SL.
```

Here `X` supplies `P8`, and `F3` supplies the following
`NR`. Let `G1,...,G14` be the east arrivals on twelve.
The four needed below are supplied as follows:

```text
G9:  8:E3 -> 9:fifth NR -> 12:G9;
G10: 8:E4 -> 9:seventh NR -> 12:G10;
G11: 10:fifth south departure -> 9:fifth SL -> 12:G11;
G12: 8:e -> 9:eighth NR -> 12:G12.
```

In particular, `G10,G11` are consecutive east arrivals.

## P6 and P7 occur after the early north arrivals

The established square gaps on six give

```text
tau(6:WR2) = tau(6:WL2) + 12.
```

There is an eight-step, zero-voltage path

```text
6:WR2 -> 7:second NL -> 4:second WR -> 5:NL -> 2:WL
      -> 1:SL -> 4:EL -> 5:NR2 -> 8:E3=EL.
```

Thus `tau(E3)=tau(6:WL2)+20`. The two-step path
`6:WL2 -> 5:SL3 -> 8:E6` has upper voltage minus one,
so

```text
tau(E6) = tau(E3) + N - 18.
```

The path

```text
10:Y=WL -> 9:D2=SR -> 6:WL2 -> 5:SL3 -> 8:E6=EL
```

has length four and zero voltage. Consequently

```text
tau(Y) = tau(E3) + N - 22.                          (1)
```

The west steps from `P6,P7` to `d,e` have upper voltage
one. Since both `d` and `e` follow `E3` on eight,

```text
tau(P6) = tau(d) + N - 1 > tau(Y) + 21;
tau(P7) = tau(e) + N - 1 > tau(Y) + 21.              (2)
```

Every north departure on ten before `Y` supplies a
north arrival on eleven before `tau(Y)+1`. After `Y`,
the only north departures on ten are `X` and `F3`,
whose targets are already `P8=NL` and the final `NR`.
Neither can supply `P6` or `P7`. Equation (2) therefore
forces both departures to be `SR`.

There is no remaining north arrival between `P6` and
`P8`. Alternation fixes the ending

```text
11: ...,P6=SR,SL,P7=SR,P8=NL,NR,SL.                 (3)
```

In particular, the `SL` following `P6` and `P7` itself
are consecutive south arrivals on eleven.

## The square at P7 forces G11=ER

The path

```text
P7 -> 8:e=WR -> 9:eighth NR -> 12:G12
```

has three steps. If `G12=ER`, its south step completes
a square first return from `P7=SR` to `SL`. But the
immediate successor in (3) is `P8=NL`. Hence `G12=EL`.

Starting instead at the south predecessor of `P7` on
twelve gives a square first return to `G12=EL`. That
predecessor must be `ER`, immediately before `G12`.
It is therefore `G11=ER`, and it supplies `P7`.

## A left turn at G10 gives a right/right return

There is an eleven-step path

```text
P6 -> 8:d=WR -> 9:D1=NL -> 6:WL1 -> 5:SR -> 2:WR
   -> 3:NR -> 6:ER2 -> 5:SL2 -> 8:E4=EL
   -> 9:seventh NR -> 12:G10.
```

Starting at the south predecessor of `P6` on twelve
gives a twelve-step first return to `G10`. Suppose
`G10=EL`. Its predecessor must then be `ER`, immediately
before it, so it is `G9=ER` and supplies `P6`.

This forces the eight-step path

```text
5:NR2 -> 8:E3=EL -> 9:fifth NR -> 12:G9=ER
      -> 11:P6=SR -> 8:d=WR -> 9:D1=NL -> 6:WL1 -> 5:SR.
```

Its direction word is

```text
E N E S W N W S.
```

The displayed endpoint is its first return to the starting
physical cell. Both endpoint ports, `NR2` and `SR`, turn
right. This violates turn alternation. Hence `G10=ER`.

## Two east right turns with no intervening left turn

With `G10=ER`, the eleven-step path from `P6` followed
by its south step is a twelve-step first return on eleven.
It supplies the `SL` immediately after `P6` in (3).

Thus the consecutive east arrivals `G10=ER,G11=ER`
on twelve supply consecutive south arrivals on eleven:
the `SL` after `P6`, and `P7=SR`. There can be no `WL`
between them on twelve, since it would supply another
south arrival between those two. There can be no `EL`
between them either, since they are consecutive east
arrivals. No left turn is available between these two
right turns, contradicting alternation on twelve.

This excludes N and completes the exclusion of form R
at the upper cap of family A. The remaining upper forms
in this family are P and Q, each with `omega_6=0` or
`1`. This is not an exclusion of the whole `(1,-3)` orbit.
