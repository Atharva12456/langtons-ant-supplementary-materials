# Wake families above the lower `0,5,6,8` band

Later result (21 September 2026): [the upper fat-cap theorem](odd_skew_upper_fat122_exclusion_2026-09-21.md) excludes family A. Family B remains open. The local derivation and earlier family status below are retained.

Consider growth eight and drift `(1,-3)`. Assume a lower `(1,2,2)` cap,
with `omega_4=0`, `omega_5=1`, and two `ER` ports on level six. The
return argument in `odd_skew_fat122_three_visit_six_2026-09-12.md` forces

```text
O intersect [0,8] = {0,5,6,8},
O_0={0,6},                 |O_1|=2,                 |O_2|=4,
```

where `O_j` is the wake fibre modulo three. The upper cap is fat. The
two-sided cap bound from `odd_skew_fat122_two_sided_wake_2026-09-13.md`
reduces the remaining wake placements to the families below.

| Family | Width and wake set | Restrictions | Upper cap |
|---|---|---|---|
| A | `W=6m+2`, `O={0,5,6,8,6r+4,6p+2,W-4,W}` | `1<=r<p<=m-1`, `r+p` even | `(1,2,2)` |
| B | `W=6m+4`, `O={0,5,6,8,6p+2,6r+4,W-2,W}` | `2<=p<r<=m-1`, `p+r` odd | `(1,2,3)` |
| C | `W=6m+4`, `O={0,5,6,8,6p+5,6r+4,W-5,W}` | `1<=p<r<=m-1`, `p+r` odd | `(1,2,2)` |

These are necessary conditions. They do not construct a trace. The further
return argument in `odd_skew_fat122_rigid_five_wake_2026-09-13.md` excludes
family C; families A and B remain open. In particular, the table is a reduction
of this lower-band branch, not a classification of the entire drift orbit.

The subsequent exclusions of the lower bands with `omega_4=1`
now make A and B exhaustive for a lower `(1,2,2)` cap. See
`odd_skew_fat122_adjacent_wake_band_exclusion_2026-09-14.md` and
the case ledger for that extension of scope. This still does not
classify the other cap profiles in the drift orbit.

The minimum widths allowed by the table are respectively `26`, `28`, and
`22`. No bounded search is used in the derivation.

## The rank condition fixes the order of the extra wakes

The width is even and at least twelve. Since `W` is wake and `O_0={0,6}`,
it is not divisible by three. The four-wake fibre `O_2` already contains
the opposite-parity pair `5,8`. Its other two wakes must have equal
parity: the checker split in this fibre is `3+1`. Each two-wake fibre
also has equal checker signs.

Use the odd-skew rank condition

```text
I_01+I_02+I_12 = 0 mod 2,
I_ij = #{(u,v) in O_i x O_j : u<v}.
```

The usual cyclic shift of residue labels does not affect this parity,
since every fibre has even cardinality.

If `W=6m+2`, write

```text
O_1={b,c},       b<c,
O_2={5,8,a,W}.
```

All the extra wakes exceed eight; P22 makes `a` even. Direct pair counts
give

```text
I_01=4,       I_02=7,       I_12=2+[b<a]+[c<a].
```

The rank condition is therefore equivalent to `b<a<c`.

If `W=6m+4`, instead write

```text
O_1={b,W},
O_2={5,8,u,v},       u<v.
```

Here `b` is even, and

```text
I_01=4,       I_02=7,       I_12=[b<u]+[b<v].
```

Thus `u<b<v`. These interlacings will prevent a wake at upper offset
six from replacing the wake forced at offset four or five.

## Width `W=6m+2`

The upper cap must have profile `(1,2,2)`: a `(1,2,3)` cap would put
an additional wake at `W-2` in `O_0`. Write `a=6p+2`, with `p>=2`.

Suppose first that the two wakes `b,c` are odd. Set
`b=6r+1`, `c=6s+1`. The interlacing gives `r<=p<s`. Upper offset one
is non-wake, so `s<=m-1`. Upper offset four has even parity in the
odd-only fibre `O_1`, and offset five belongs to the already full fibre
`O_0`. Neither is wake. Offset six could be wake only if `a=W-6`, or
`p=m-1`; that contradicts `p<s<=m-1`. Hence all of upper offsets four
through six are non-wake, contrary to the two-sided `(1,2,2)` cap bound.
This excludes the odd-`O_1` family at every width.

Consequently `b=6r+4`, `c=6s+4`, with

```text
1<=r<p<=s<=m-1.
```

Upper offset five is still non-wake. Offset four is wake exactly when
`s=m-1`. If offset six is wake, then `p=m-1`, which itself implies
`s=m-1`. The cap bound therefore forces `c=W-4`. This gives family A
apart from its moment parity.

## Width `W=6m+4`

Write `b=6r+4`. If the extra wakes in `O_2` are even, put
`u=6p+2`, `v=6q+2`. The rank interlacing gives

```text
2<=p<=r<q<=m.
```

An upper `(1,2,2)` cap would make offset two non-wake, so `q<=m-1`.
Offset four is in `O_0`, and offset five is odd in a fibre whose only
odd wake is the lower level five. Both offsets are non-wake. Offset six
could be wake only for `b=W-6`, or `r=m-1`, contrary to
`r<q<=m-1`. The two-sided bound again excludes this entire cap pairing.

Thus the upper cap is `(1,2,3)`, and its wake at offset two gives
`v=W-2`, or `q=m`. This is family B before the moment condition.

If the extra wakes in `O_2` are odd, instead put
`u=6p+5`, `v=6q+5`. Interlacing gives

```text
1<=p<r<=q<=m-1.
```

The upper cap must now be `(1,2,2)`, since its offset two is even and
cannot equal the only even wake eight in `O_2`. Upper offset four is
non-wake. Offset five is wake exactly when `q=m-1`; offset six can be
wake only when `r=m-1`, which implies `q=m-1` as well. The cap bound
forces `v=W-5`, giving family C.

## The moment parity

In cap-normalized levels the remaining additive condition is

```text
M = sum_(t in O) (-1)^(t+1) floor((t+1)/3) = 3 mod 4.
```

This is the same normalization used in
`odd_skew_guard_missing_families_2026-09-03.md`. The fixed lower wakes
`0,5,6,8` contribute `-3`.

For family A, substitution gives

```text
M = -5-2(r+p+2m).
```

Hence `r+p` is even. In family B the result is

```text
M = -7-2(p+r+2m),
```

so `p+r` is odd. This also rules out the earlier endpoint `p=r` and
strengthens `p<=r` to `p<r`. Family C gives

```text
M = -3+2(p-r),
```

again requiring `p+r` odd. The least possible parameter choices are
`(r,p,m)=(1,3,4)` in A, `(p,r,m)=(2,3,4)` in B, and `(p,r,m)=(1,2,3)`
in C, proving the stated width bounds.

## A further restriction on family C

In upper inward coordinates family C has `omega_4=0`, `omega_5=1`.
Its offset six is wake exactly when `r=m-1`. Its offset eight is always
non-wake: `W-8` is even in residue two, but the only even wake of that
fibre is eight, and `W>=22`.

Let `e=omega_6` in these upper coordinates and let `z` count the `ER`
ports there after rotating the heading labels. The level-six count row is

```text
(ER,EL,WR,WL)=(z,3-z,5+e-3z,2-z).
```

The square through `5:SR,2:WR,3:NR` excludes `z=0`. If `z=2`,
nonnegativity forces the three-visit row `ER,EL,ER`, with `e=1`.
The level-seven and level-eight return argument in
`odd_skew_fat122_three_visit_six_2026-09-12.md` then forces a wake at
offset eight. That part of the argument uses only zero-displacement
returns and applies at the upper cap unchanged. It contradicts the
placement just established.

Therefore family C requires `z=1`: upper offset six would have exactly
`6+e` visits, with count row `(1,2,2+e,1)`. The subsequent return argument
in `odd_skew_fat122_rigid_five_wake_2026-09-13.md` excludes this last
possibility and hence family C. Families A and B remain open.
