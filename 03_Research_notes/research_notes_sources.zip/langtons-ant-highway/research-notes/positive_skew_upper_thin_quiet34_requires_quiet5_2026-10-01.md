# Upper (1,2,2): quiet three and four require quiet five

For literal drift `(1,3)`, an upper `(1,2,2)` cap with quiet inward
offsets three and four must also have quiet offset five. This holds
at every growth, width and positive integer period. The whole
growth-eight orbit remains **open**.

Use the upper orientation-preserving half-turn gauge. Its ports are
written in lower orientation, and the lifted clock is
`tau_target=tau_source+1+N*dx`, with `N>=1`. R/L labels are preserved.
Only strict stable order is needed; no growth budget, period congruence,
gap-four condition, width bound or visit-count cutoff enters this result.

The earlier checked local lemma says that quiet three/four and wake
five imply wake six. The raw weak-clock classification with those
first six rows, allowing **either** wake bit at seven, leaves exactly
one prefix. Its seventh row is quiet:

```text
0 NR
1 WR,WL
2 NR,SL
3 WR,WL,ER,WL
4 NR,SL,NR,NL,SR,SL
5 WR,WL,WR,EL,ER
6 NR,SL,NR,NL,SR,NL,NR
7 WR,WL,WR,EL,ER,WL,ER,WL,WR,EL
```

This first-seven-row classification is computer-assisted. The complete
raw domains and every rejection are saved in
`work_positive_skew_saturated111_20261001/weak_raw_{3..7}.json`
and their rejection files. The independent weak generator uses no
frontier engine; its count recurrence has a finite exhaustive range
by nonnegativity. Root's earlier independent geometric and Z3 audit
checked every saved rejection. The former result required quiet eight;
the following terminal hand argument removes that requirement.

Let `h=omega8`, either zero or one. Row seven has five south departures
and row five has three west arrivals, so the exact row-eight counts are

```text
SR=s, SL=5-s, NL=3-s, NR=8+h-3s.
```

Thus `0<=s<=2` if h=0 and `0<=s<=3` if h=1. Write `D1,D2,D3` for
the three west departures on row eight and `S1,...,S5` for its five
south arrivals. A west departure is SR or NL. Tracing the assigned
older rows gives two zero-copy physical first returns:

```text
D1 -> S2, direction word WNENWNENWNESWSESWSES;
D3 -> S4, direction word WNES.
```

Neither excursion visits row eight before its displayed return. That
arrival must be the immediately next stable event at the same physical
cell and must have the opposite turn. The second west departure exits
the assigned domain, so no adjacency implication is imposed on it.

If D3 were NL, its returned S4 would be SR, making a fourth west
departure after D3. Therefore D3 is SR and S4 is SL. If D1 were NL,
its returned S2 would be SR, namely D2. The next SR, D3, must be S3.
There are at least two SR events and at least one NL, so s=2. The
single NL is already used at D1; no SL can lie between S2 and S3,
which are consecutive south arrivals. No L event could then separate
the two R events S2 and S3. This is impossible.

Hence D1 is SR, necessarily S1, and its next event is S2=SL. Similarly
D3 is S3=SR and is followed by S4=SL. The new option s=3 is impossible:
it would give no NL events, so all three west departures would be SR,
yet D3 is already S3 and S2 is SL. Only two SR events could occur up
to D3. We therefore again have s=2 and D2=NL.

No event precedes S1: an earlier NR would need an earlier NL or SL
to separate R events, contradicting D1 or S1 being the first relevant
departure or arrival. Alternation now forces the entire row:

```text
h=0: 8 SR,SL,NR,NL,SR,SL,NR,SL
h=1: 8 SR,SL,NR,NL,SR,SL,NR,SL,NR
```

Both contain exactly the same physical square:

```text
(7,1) --S--> (8,0) --W--> (5,0) --N--> (4,0) --E--> (7,3).
```

The compass word SWNE has zero displacement and no intermediate
return to the starting cell. It returns from row-seven event one to
event three, skipping event two. A physical first return must hit
event two. This contradiction rejects both possible wake bits eight.

The new independent terminal checker exhausts all 170 quiet-eight
and 202 wake-eight raw alternating words. Every one has a witnessed
wrong physical first return, separately replayed by root's compass
checker. A second generator reconstructs the unique necessary row
in each case and checks the displayed square. Run

```text
python work_positive_skew_upper_wake56_all8_20261001/verify_terminal.py
```

Consequently quiet three/four plus wake five cannot occur at all. This
strictly strengthens the earlier result that such a wake five merely
forces wake six/eight. In particular **both** compact lower-thin
000/010 families under the upper `{0,5,6,8}` schedule are now excluded
for every width and period. The seven other lower-thin templates and
the remaining cap schedules still require further coupled chronology.
