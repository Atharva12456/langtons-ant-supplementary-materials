# Growth eight, diagonal drift four: partial-rail progress

Research checkpoint: 2026-09-07. Target: the drift orbit represented by
\((-4,4)\), normalized below to \(d=(4,-4)\).

**The orbit remains open.** This checkpoint adds checked local exclusions,
excludes the particular width-ten placement displayed in the previous note,
and classifies the remaining boundary-only wake patterns at every width.
It does not establish nonexistence of every growth-eight highway in this orbit.
There is no defensible completion date or percentage: the remaining obstacle
is an argument for unbounded visit orders and transverse separation.

## 1. Assumptions and conventions

Use the project's finite-seed P3 criterion and its established reductions:
the mixed wake branch is excluded; in the remaining branch all eight wake
classes have horizontal arrivals; each x-residue and each y-residue modulo
four contains exactly two wakes; the period is divisible by eight; and the
extremal occupied levels are separated by even width \(W\ge10\).
The existing small-period work gives \(N\ge64\). The September 6 full-rail
exclusion shows that each extremal rail occupies one, two, or three lanes.

Write \(t=x+y\), \(r=x\bmod4\), normalize the lower rail to \(L=1\),
and put \(H=L+W\). Horizontal-arrival classes C have odd t; vertical-arrival
classes Q have even t. A wake is a translation class whose stable visit word
has odd length. Stable words alternate R,L, starting R. An actual upper
rail class is the singleton word ER; an actual lower rail class is WR.
A lane mask m means \(\{r: m\mathbin{\&}2^r\ne0\}\).

These are research proofs with executable independent checks. They are not
formally verified in a proof assistant or externally peer reviewed.

## 2. Singleton companion and the six-wake boundary budget

**Companion theorem.** If the upper rail occupies only lane r, then both
\((H-2,r)\) and \((H-2,r+1)\) are wakes. At a singleton lower rail in lane s,
both \((L+2,s)\) and \((L+2,s-1)\) are wakes. Lane arithmetic is modulo four.

The previous local lemma supplies the same-lane companion. For the new
companion normalize r=0. If lane 1 at H-2 is not a wake, the mask there is
one of 1,5,9,13. Lane 0 at H-4 cannot be a wake: its two x-residue wakes are
already used. The other three bits at H-4 are arbitrary. The three intervening
Q levels have no wakes. These are exactly 32 finite local cases.

`verify_singleton_hand.py` exhausts their count and word domains. It rebuilds
excursions using integer (x,y) coordinates and the chronological matching of
the nth directed-edge occurrences. Its independent count-box and word-position
enumerator agrees with the faster generator on every domain. The final audit
performs 24,740 excursion comparisons and 24,740 complete domain comparisons,
and checks 102,538 physical-return contradictions and 5,178 time cycles.
All 32 cases have no extension through H-5. Every time cycle retained here has
zero period coefficient, so the proof applies to either drift orientation and
every positive period. No finite period cutoff establishes this conclusion.

The full companion theorem presently has a finite certificate proof. The
following short hand argument explains some, but not all, of its rejections.
At a Q cell, suppose its kth east departure first returns to the same physical
cell as its first south arrival. The two visits must be consecutive. The
departure is NR and the return SL; that return is therefore also east
departure k+1. A return from the last east departure to the first south arrival
is impossible. More generally, prescribed subsequent returns cannot skip an
intermediate south arrival. Multicell constraints handle the other branches.

A singleton rail now consumes at least three wakes in its rail and the level
two steps inward. An adjacent or alternating two-lane rail consumes two rail
wakes and at least one nearby wake by the previous lemmas. A three-lane rail
already consumes three. The upper and lower boundary pairs are disjoint.
Consequently

\[
\#\{\text{wakes outside }L,L+2,H-2,H\}\le2.
\]

If both rails are singleton, their occupied lanes r above and s below must
satisfy \(s-r\in\{2,3\}\pmod4\), by the same two-per-x-residue budget.

## 3. A further classification of ends with only three wakes

Suppose exactly three wakes occur on an upper end's first three horizontal
levels H,H-2,H-4. The preceding budget forces all three onto H,H-2, with no
wakes at H-4. Up to cyclic lane shifts, the possible (rail, inward) masks
before the next local checks are

\[
(1,3),\ (3,1),\ (3,2),\ (3,4),\ (3,8),\ (5,1),\ (7,0).
\]

Only **(3,8) and (7,0)** remain after the checked local exclusions. This
statement concerns any end with that three-wake budget, even when other wakes
occur farther inside the strip. The lower-end statement uses the half-turn
and the corresponding reversed lane order.

For boundary-only classification we also exclude (5,11), assuming no wakes
at H-4. The finite audit is:

| Rail mask | H-2 mask | Generated words | Checked rejection certificates | Complete extensions through H-5 |
|---:|---:|---:|---:|---:|
| 1 | 3 | 1,455 | 660 | 0 |
| 3 | 1 | 90 | 28 | 0 |
| 3 | 2 | 320 | 110 | 0 |
| 3 | 4 | 157 | 66 | 0 |
| 5 | 1 | 345 | 141 | 0 |
| 5 | 11 | 2,499 | 1,640 | 0 |

`verify_m4_boundary_classification.py` reruns all six cases with independently
reconstructed domains, checked rejection certificates, and no timeout.
All time contradictions used are independent of the drift sign. The actual
finite domains follow from count balance and nonnegativity, without a visit
count cutoff. Physical first-return constraints then eliminate word orders.

## 4. The displayed width-ten placement is excluded

The September 6 note displayed the algebraically surviving placement

\[
D=\{(1,0),(1,1),(1,2),(7,3),(9,3),(11,0),(11,1),(11,2)\}.
\]

It still passes the degree, additive, and rank tests, but **it cannot be the
wake set of an admissible highway at any period**, using the established
project reductions. The proof reconstructs the two end bands and joins them
at the middle Q level t=6.

The lower band has 1,546 possible locally surviving words; the upper band has
32,066. Their port counts determine the middle count row, rather than leaving
an unbounded period search. At middle lane r, let X be the number of north
departures from lower C(5,r), Y the west arrivals at lower C(5,r-1), U the
south departures from upper C(7,r), and V the east arrivals at upper C(7,r+1).
The required equations are

\[
X+U=Y+V,\qquad a=\frac{2V+X-U}{4},\qquad
(NR,NL,SR,SL)=(a,X-a,U-V+a,V-a).
\]

Reject a row unless all four entries are nonnegative integers. Exact excursions
through each end impose consecutive departure/return ordinals at the middle
cells. There are 10,078,210 count-compatible full-band pairs. Testing their
9,822,702 distinct projected self-return pairs leaves exactly 171 full-band
pairs. Every surviving projection has one member, so no unchecked replacement
of a group by one representative is used in the final step.

The final join rejects all 171 pairs after 185 partial middle assignments:
174 physical-return contradictions and 11 time-cycle contradictions. The only
periods permitted by those surviving count rows are 224,240,256,272,288; these
are consequences of the enumeration, not an imposed search ceiling.

`verify_m4_two_ended.py` rebuilds the complete inputs, checks the local domains
independently, and checks each rejection certificate. It also tests a known
period-208 highway in both drift orientations. The lower band is generated
with **negative drift before half-turn**; using positive-drift pruning there
would be an invalid symmetry shortcut.

`verify_m4_interface.py` separately reconstructs all 33,610 excursion signatures
using physical coordinates and checks all 14,506 distinct middle-word domains
with a different generator. Its surviving set agrees exactly. Both audit
files report success. This excludes this one placement; it does not exclude
every width-ten placement or every pair of three-lane rails.

## 5. Boundary-only wakes: an all-width algebraic reduction

Now assume every wake lies on L,L+2,H-2,H. Record their four masks in the order
\((B,B_I,U_I,U)\). Two wakes in each x-residue means choosing two of four
levels for each of four lanes: exactly \(6^4=1296\) raw patterns. The partial
rail and nearby-wake conditions reduce this to 466.

Use the project's pure-wake additive normal form: if a and b count the
t=1 modulo 4 wakes in each even and odd x lane, respectively, and
\(Z=\sum_{(t,r)\in D}\lfloor t/4\rfloor\), the additive condition is
\(Z\equiv a+b-1\pmod4\). The rank condition requires \(E+\Lambda=1\pmod2\).

### Why sixteen-level padding preserves these algebraic conditions

Insert sixteen wake-free transverse levels into the gap between the two
boundary pairs, shifting the upper pair up by sixteen. Wake x/y residues are
unchanged. Each shifted wake increases its contribution to Z by four, so the
additive congruence is unchanged.

For completeness, consider the parity-flow masks used in the project's rank
formulas. In a wake-free gap the C-edge mask b is a constant B. The Q-edge
mask a alternates between A and its two-lane rotation \(P^2A\); its transverse
period is four. Sixteen inserted levels contain eight C and eight Q levels,
with the same phase at both ends. The original boundary transition terms are
therefore preserved.

The local correction on each Q level has parity \(|B|+|A|\). Eight copies
sum to zero; no new wake-C correction appears. For C-source edge inversions,
the unchanged-gap summand is

\[
\binom{|B|}{2}+|B|+\sum_{r<s}B_rB_s\equiv |B|\pmod2,
\]

so eight inserted copies also sum to zero. For Q-source terms, write

\[
F(A)=\binom{|A|}{2}+A_0(|A|-A_0)+A_3(|A|-A_3),
\]

\[
C(A,A')=\sum_{r,s}A_rA'_s
\mathbf1_{(r+1\bmod4)\ge(s-1\bmod4)}.
\]

The inserted contribution is four copies of
\(F(A)+C(A,P^2A)\) and four of
\(F(P^2A)+C(P^2A,A)\), hence zero modulo two.
Adjacent-source-level inversion terms cancel in pairs by the original rank
factorization. Thus E and Lambda are individually unchanged.

This proves algebraic periodicity in H modulo sixteen. Every H>=11 reduces
to one of 11,13,15,17,19,21,23,25 while keeping the boundary levels distinct.
The program checks all 256 gap parity states and also corroborates the padding
on 3,728 pattern/height combinations. Those finite checks supplement the
preceding argument. **Padding is not a rule for extending or shortening a P3
trace:** it does not preserve visit words, integer flows, or chronology.

### Exact surviving patterns

After y-degree, additive, and rank conditions, the eight representative heights
have 4,0,20,4,4,0,20,4 patterns, respectively: 56 in total. The local exclusions
remove 40, leaving the following four rows and their cyclic lane translations.

| H modulo 16 | Least H>=11 | One mask tuple (B,BI,UI,U) | Canonical lower cap | Canonical upper cap |
|---:|---:|---|---|---|
| 15 | 15 | (7,12,8,3) | (7,9) | (3,8) |
| 1 | 17 | (13,0,10,7) | (7,0) | (7,10) |
| 7 | 23 | (3,4,12,11) | (3,8) | (7,9) |
| 9 | 25 | (13,10,0,7) | (7,10) | (7,0) |

For the lower cap, canonicalization includes reversing lane order under the
half-turn. Each row represents four translated masks, giving sixteen patterns.
They form two types of cap pairing, in the two listed orders. Keep the stated
height congruences: simply exchanging ends does not preserve the positive-drift
additive condition. Every survivor uses three wakes at one end and five at the
other. Boundary-only arrangements with four wakes at each end are excluded.

These are necessary patterns, not constructed highways. All four cap types
admit depth-five local words in both drift directions. A further depth-six
probe found local words for (3,8) with negative drift and (7,0) with positive
drift; the other six runs reached their 25-second budgets. None exhausted.
These probes add **no exclusion**. Even the surviving local words only satisfy
the recorded partial constraints; they do not establish global P3 realizability.

## 6. Exact remaining task

The current cases are zero, one, or two wake classes outside L,L+2,H-2,H.
The zero case has been reduced to the table above but remains open. The one-
and two-interior-wake cases have not been classified completely. Both width
and period remain unbounded across the whole problem.

A concrete conceptual target is a theorem controlling continuation of the
three-wake cap types (3,8) and (7,0) through a wake-free strip, or a compatibility
obstruction between the paired ends. Excluding those two cap types at all
depths would close the boundary-only branch. It would still leave the cases
with interior wakes. Finite-depth timeouts and the sixteen-level algebraic
periodicity do not supply the missing theorem.

The progress is therefore a reduction in the shape of the unresolved problem,
not evidence for a promised completion time.

## 7. Source and verification record

- The September 6 full-rail and alternating-half-rail notes are included in
  the accompanying archive, together with their original audits.
- The singleton proof and its hand lemma are documented in
  `singleton_conceptual_review.md`; the final orientation-independent audit is
  in `m4_singleton_companion_audit_2026-09-07.log`.
- The complete width-ten checks are
  `m4_two_ended_audit_2026-09-06.json` and
  `m4_interface_independent_audit_2026-09-06.json`.
- The new classification is in
  `m4_boundary_classification_audit_2026-09-07.json`.
- The source parity formulas are in the project's
  [September 4 partial-rail note](growth8_m4_partial_rail_obstruction_2026-09-04.md),
  and the pure-wake additive reduction is in the
  [additive normal-form note](growth8_m4_pure_additive_normal_form_2026-09-04.md).

See `README.md` in the archive for commands and the exact distinction between
the proof drivers and exploratory probes.
