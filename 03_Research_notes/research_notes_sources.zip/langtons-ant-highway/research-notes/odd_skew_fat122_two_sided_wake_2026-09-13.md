# A wake by inward offset six at either `(1,2,2)` cap

At either cap in the `(1,-3)` drift orbit, a profile `(1,2,2)` satisfies

```text
omega_4 + omega_5 + omega_6 >= 1,
```

where offsets are measured inward from that cap. Every return in this proof
has zero displacement. Thus the argument applies at the upper cap after
rotating the heading labels by 180 degrees, without a longitudinal time
inequality. The stronger lower-cap bound `omega_4+omega_5>=1` remains
specific to that orientation.

## An ordinal test for adjacent west departures

Suppose two adjacent west departures `Wi,Wi+1` from a class have forced
first same-cell returns to north arrivals `Na,Nb`. These returns must
join consecutive stable events. If `Wi=SR`, its target is `Na=NL`;
being the next stable west departure, this target is `Wi+1`. The return
from `Wi+1` must then end at the next north arrival, `N(a+1)`.

Consequently, if `b!=a+1`, then `Wi` must instead be `NL`, with target
`Na=NR`. Consecutive order makes its source `N(a-1)`. In particular,
if `a=1` and `b!=2`, the two returns are impossible.

## The six-offset band

Suppose offsets four, five, and six are non-wake. The cap normal form,
valid at either end, is

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL
5 A: SR,SL,NR,NL,NR,SL
  B: NR,SL,SR,NL,NR,SL.
```

Level six has counts `(ER,EL,WR,WL)=(r,3-r,6-3r,3-r)` for `r=0,1,2`.
The four-step return through `5:SR,2:WR,3:NR` to the second east arrival
excludes `r=0`. For `r=2`, it leaves only word `ER,EL,ER,WL` with word
A on level five. Its exclusion by level nine in
`odd_skew_fat122_even_band_2026-09-12.md` uses only zero-displacement
returns and applies at either cap.

For `r=1`, there are seven possibilities after imposing that same square
return. Four end with `WL`. They are `U1,...,U4` in
`odd_skew_fat122_early_wake_2026-09-12.md`; their exclusions in the
sections on the two adjacent west departures and the remaining `U`
branches also use only zero-displacement returns.

For clarity, the seven possibilities here are obtained without the
lower-cap restriction on the last south departure. If the second east
arrival is `EL`, its consecutive opposite-turn source is the first east
arrival `ER`. For word A on level five these are the initial `ER,EL`;
for word B they have prefix `WR,WL,ER,EL`. If the second east arrival is
`ER`, the source is `WL` and word A is required, since B does not have
a south arrival after its `SR`. Placing the remaining `WR,WL,EL` ports
in alternating slots gives the four `U` words and precisely these three
additional words:

| Name | Level five | Level six |
|---|---|---|
| `V1` | A | `ER,EL,WR,WL,WR,WL,WR,EL` |
| `V2` | B | `WR,WL,ER,EL,WR,WL,WR,EL` |
| `V3` | A | `WR,EL,WR,WL,ER,WL,WR,EL` |

These three end with `EL`; their exclusion is the part still needed for
the upper-cap statement.

## Removing `V1` and `V2`

Number the four west departures on level seven as `W1,...,W4`. They
feed `WR,WL,WL,WR` on level four. The same return paths used for the
`U` branches now give

| Branch | First return | Second return |
|---|---|---|
| `V1` | `W2 -> N1` | `W3 -> N5` |
| `V2` | `W2 -> N2` | `W3 -> N5` |
| `V3` | `W2 -> N2` | `W3 -> N5` |

The second return is the four-step path through
`4:second WL,3:last SL,6:last EL`. The first has length twelve for
`V1,V2` and eight for `V3`.

The ordinal test excludes `V1`. In `V2`, it gives `W2=NL=N1`. The
resulting path

```text
6:first WR -> 7:W2 -> 4:first WL -> 3:SR -> 0:WR
           -> 1:NR -> 4:ER -> 3:first SL -> 6:first ER
```

returns to level six in eight steps with two right-turn endpoints and
no intermediate visit there. Thus `V2` is impossible.

## The two level-seven words for `V3`

The ordinal test again gives `W2=NL=N1`, immediately followed by `N2=NR`.
If `W3=NL`, its return to `N5=NR` makes it `N4`. Then `W1=SR` and
`W4=SR`: another `NL` after `N4` would have to be the already specified
`N5=NR`. If `W3=SR`, its consecutive target `N5=NL` is `W4`.
R-first order and the five north arrivals give exactly

```text
A7: SR,NL,NR,SL,NR,NL,NR,SL,SR,[SL]^(1-f),
B7: SR,NL,NR,SL,NR,SL,NR,SL,SR,NL,
```

where `f=omega_7`; word B7 requires `f=0` because its last north arrival
is the final left-turn west departure.

Let `E1,...,E4` be the east arrivals on level eight, supplied by
`SL1,NR1,NR2,SL2` on level five.

In B7, the path from `W4=NL` through
`4:last WR,5:NL,2:WL,1:SL,4:EL,5:last NR` ends at `E3`.
It cannot end at `ER`: the following south step would return to the
same level-seven cell after its last stable visit. Thus `E3=EL`.
The south predecessor of `W3=SR` has a twelve-step return to this
`EL`, first following the four-step return to `W4`, then the displayed
path. Its source is consequently `E2=ER`. But the three-step path
`W1=SR -> 4:first WR -> 5:first NR -> E2` then completes a four-step
return to `W3=SR` with two right-turn endpoints. This excludes B7.

In A7, the same three-step path from `W1=SR` and seven-step path from
`W4=SR` imply `E3=ER`: otherwise its opposite-turn south predecessor
would again be `E2=ER`, producing the same right-to-right return.
The south step from `E3` must lead to `SL` after `W4`, so `f=0`.

Here `W1=SR` is immediately followed by `NL`. Thus `E2` cannot be
`ER`, since that would complete a four-step return from `W1` to a
south arrival instead. Consequently `E2=EL` and its south-departure
predecessor is `E1=ER`. These are the initial two stable visits on
level eight. Its eight-step return through `W4` forces a consecutive
`WL,E3=ER` pair, which supplies the fourth and fifth south departures.
The fifth is last, so `E4=EL`. Flow and alternation leave

```text
8: ER,EL,WR,WL,WR,WL,WR,WL,ER,EL,[WR]^e,
   e=omega_8.
```

## The final pair of returns

There are five west departures on level nine, feeding the west arrivals
`WR,WR,WL,WL,WR` on level six. Write them as `D1,...,D5`. The third has
the twelve-step return

```text
D3 -> 6:first WL -> 5:SR -> 2:WR -> 3:NR -> 6:ER
   -> 5:first SL -> 8:first ER -> 7:first SR -> 4:first WR
   -> 5:first NR -> 8:first EL -> first north arrival on 9.
```

The fourth has the four-step return

```text
D4 -> 6:last WL -> 5:last SL -> 8:last EL
   -> fifth north arrival on 9.
```

They have no intermediate level-nine visits. Their targets are `N1,N5`.
The ordinal test for adjacent west departures makes these returns
incompatible. This excludes A7 and finishes the proof.

All paths used here have zero net displacement. Rotating the labels at the
upper cap preserves both their motion and their stable successor relations.
No estimate involving `N` was transferred between the two cap orientations.
