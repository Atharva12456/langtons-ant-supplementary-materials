# Growth eight does not occur at period 56

The fixed-growth search has now been completed at period 56. This is the fourth
targeted run after the general residue-free exclusion through period 48.

## Result

There is no finite-support periodic highway with ant period `N=56` and growth
`g=8`.

The search used

```text
--period 56 --target-growth 8 --prefix-length 12 --deficit-depths 0
```

A normalized positive-growth word starts with `R`, so there are 2,048 possible
length-12 prefixes. Two hundred fifty-six half-open intervals of eight ranks
cover them exactly once. Every shard completed without a node cap, and the
optional deficit rule was disabled. The aggregate counts are

```text
prefix ranks                    2,048
search nodes          246,883,217,080
endpoint prunes        39,482,207,076
growth prunes          45,748,124,938
residue checks          9,343,985,497
residue prunes          9,333,168,099
P3 checks                  10,817,398
accepted words                      0
```

The residue test is a proved pruning lemma. Every leaf that passes it is sent
to the exact periodic-realisability test.

## Audit trail

The raw records are archived in `records/g8_p56_shards`. The aggregate checker
reconstructs every prefix from its rank, checks the normalization directly,
verifies exact rank coverage and every per-rank counter sum, rejects capped or
deficit-pruned shards, compares the two copies of the hit lists, and records a
SHA-256 digest for each shard. Rebuilding the aggregate from the archive gives

```text
results/growth8_period56_exclusion.json
4b7b2ec752ce9fd24a9e0dcceb604a1ab44209f848f6fe28f51b580b9ffa8afa
```

The relevant source digests are

```text
code/java/PositiveGrowthResidueSearch.java
315c18bd3f7749750fc8c618d5b3f464756d2ddd64bda5dd9be4cbb1f33e9c23

code/python/run_target_growth_shards.py
6c0e1db9b6ca7d6a34a9528cdf2905d9ddfd98bd995765bddef675ca894b1cc7

code/python/aggregate_target_growth_shards.py
c4db9da60a9b19e634a51d552420528e1cf43868d4754bf3d633cf951f920925
```

The fixed-growth branch was previously compared with the original all-growth
mode at every even period through 18. Those runs partition the original leaf,
residue, P3, and hit records exactly. That regression checks the new search
restriction; it does not replace the proof of the residue theorem or the P3
criterion.

The run and aggregate can be reproduced with

```text
python code/python/run_target_growth_shards.py --period 56 --target-growth 8 \
  --prefix-length 12 --chunk-size 8 --workers 4 \
  --output-dir tmp/g8_p56_shards_v1 \
  --summary results/growth8_period56_exclusion.json

python code/python/aggregate_target_growth_shards.py records/g8_p56_shards \
  --output results/growth8_period56_exclusion.json
```

Together with the general period-at-most-48 result and the targeted period-50,
period-52, and period-54 runs, this excludes growth eight through period 56.
Period 58 was the first possibility left by those runs; later computations
extend the exclusion through period 60. The result is finite: all ten drift
orbits retain open cases. See
[the period-60 record](growth8_period60_exclusion_2026-08-25.md).
