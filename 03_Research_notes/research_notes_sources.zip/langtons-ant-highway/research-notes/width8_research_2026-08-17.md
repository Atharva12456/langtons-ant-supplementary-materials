# Width-eight research log — 17 August 2026

The promotion-audit section at the end records the computer-assisted
all-period width-eight exclusion and the resulting diagonal bound `W>=10`.
The initial candidate sections retain the status at the start of the log.

## Objective and claim discipline

The target is an all-period exclusion of diagonal finite-support periodic highways
of transverse width eight.  If accepted, the even-width theorem and the exclusions
of widths two, four, six, and eight would imply `W>=10`, matching the standard
period-104 highway's width.

Current status at creation: **exact exploratory computation, not yet a theorem**.
Nothing here proves `g>=12`, universal entrance, or uniqueness.  The universal
highway conjecture remains open.

## Candidate finite obstruction

Normalize diagonal drift to `(m,-m)`, `m>0`, and put `t=x+y in {0,...,8}`.  Explore
an initially white block of consecutive longitudinal columns while retaining all
in-block colours, once-entry status of the in-block extremal cells on `t=0,8`, and
the inward boundary pose.  After every outer exit, erase all exterior history and
allow every geometrically possible return through that same boundary:

- eastward left entries on destination lines `2,4,6,8`;
- westward right entries on destination lines `0,2,4,6`.

This is a strict over-approximation of actual exterior dynamics.  The first
exploratory implementation found 1,188 right-exit terminals for seven columns and
zero for eight columns.  A separately structured in-memory set/compass verifier
reproduced its eight-column counts: 20,320 states, 42,004 return transitions, 9,819
repeated-extremal rejections, zero local loops, maximum 90 cell visits within one
segment, and left exit counts 1,586, 3,090, 3,114, 2,711 at labels 0,2,4,6.

Released candidate implementations are being added as
`code/python/width8_block_exclusion.py` and
`code/python/verify_width8_block_indep.py`.  Their complete counts, hashes, and a
deterministic cross-audit are required before promotion.

## Candidate global bridge

Let `N` be the ant period.  At phase `i` of translated period `q`,
`x(qN+i)=qm+x(i)`, so the longitudinal coordinate tends to infinity.  Choose eight
consecutive columns beyond both finite initial black support and the finite past
footprint at periodic-tail start.  They are untouched and white.  The first block
entry is eastward from the left, and some later right exit is forced.

Every excursion between maximal in-block segments returns through the same outer
boundary before the next segment: within the full strip `t in {0,...,8}`, changing
longitudinal sides would already cross the block.  All actual returns are therefore
allowed by the relaxation.  Extremal-line rigidity supplies once-entry for the 16
in-block extremal cells.  A certified zero right-exit result would contradict the
hypothetical highway transcript.

## Promotion gates

1. Primary and separately written on-disk enumerators reproduce every certified
   count.  The release certificate records columns six through eight; smaller
   blocks are not claimed as an archived complete table.
2. A deterministic audit checks exact tables, source hashes, and positive controls.
3. A hostile referee audits coordinate conventions, state completeness, and the
   global same-side-return bridge against the actual released code.
4. The paper and public summaries state the computer-assisted boundary and keep
   `g>=12`, uniqueness, and universal entrance open.
5. Fresh-process reruns, a clean LaTeX build, visual PDF review, and regenerated
   artifact hashes succeed.

## Promotion audit and accepted status

The primary and separate verifier reproduce every certified row, and
`audit_width8_block.py` checks the complete row data, headline fields, positive
controls, and embedded source hashes. The global reduction is the mathematical
argument stated above; these finite checks do not replace that argument.



Official source SHA-256 values are:

```text
width8_block_exclusion.py       fe879d015e716a4b3e4aa951d20069d8c6b323d272563b776115ebf993c603f9
verify_width8_block_indep.py    29cf021cb92027d4ec090238ca0ece2cbb6ad32f02f298cf9943c6196d2ea70e
audit_width8_block.py           fc59b26d515533c5d559cf31cd2d008a6931675c2b99a8510ec4587c6f56f693
```

Promoted claim: **computer-assisted all-period exclusion of diagonal transverse
width eight; hence diagonal `W>=10`**.  The global reduction is a conventional proof;
the exhaustive local reachability premise is computer checked by two separately
written implementations and is not formalized in Lean.  This lower bound is attained
by the standard highway, but no uniqueness at width ten follows.  `g>=12`,
non-diagonal translators, universal entrance, and the highway conjecture remain open.
