# The third west departure is NL in Q's middle placement

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: `M_L0` is excluded in
`odd_skew_upper_a_q_ml0_exclusion_2026-09-15.md`.
Only `M_L1` remains in the middle placement.
Its `D4=SR`-after-the-last-north-arrival order is
excluded in
`odd_skew_upper_a_q_ml1_last_west_orders_2026-09-15.md`.

In both remaining middle suffixes of Q, `D3=NL` on
nine. The right-turn alternative is impossible for all
four prefixes on eight. This fixes its north predecessor
to be the `WR` immediately before `E6=EL`.

In `M_L0`, the last west departure is then `D4=SR`.
The east arrival `F5` on ten must also be `ER`.
In `M_L1`, either turn at `D4` remains possible, with
the restricted endings on nine given below. Neither
whole suffix is excluded here; Q and the `(1,-3)`
orbit remain open.

## Fixed data

After excluding the right-turn middle branch, the two
suffixes on eight, starting at `E3`, are

```text
M_L0: E3=ER,L7=WL,E4=ER,E5=EL,b=WR,L9=WL,c=WR,E6=EL;
M_L1: E3=ER,L7=WL,E4=ER,E5=EL,b=WR,E6=EL,c=WR,L9=WL.
```

Here `Li` denotes the south departure at ordinal `i`
on eight. The `WL` at ordinal five, `L5`, immediately
precedes `E3`. On seven, `L5` supplies `W4=SR`,
`E3` supplies the following `SL`, `L7` supplies the
`SL` after the middle north arrival `V=NR`, and `L9`
supplies the final `SL`.

Thus the last four east arrivals on ten are supplied by

```text
F4: SL after W4;
F5: V=NR;
F6: SL after V;
F7: final SL.
```

The west targets of `D3,D4` on nine are `6:WL2,WR2`.

## What D3=SR would force

Assume `D3=SR`. Its square through
`6:WL2,5:SL3,E6=EL` has consecutive target `D4=NL`,
supplied by `E6`. Since `D4` is the last west
departure, the square through `6:WR2,V,F5` forces
`F5=EL`. The south predecessor of `D3` on ten then
has an eight-step first return to `F5`, forcing the
consecutive pair

```text
F4=ER,F5=EL.
```

Let `P` be the west departure on eleven feeding `L5`.
The same argument used in
`odd_skew_upper_a_q_middle_right_exclusion_2026-09-15.md`
forces `P=SR`: if it were `NL`, its north predecessor
would be `F3=EL`, immediately before `F4=ER`. The
square from the south predecessor of `F3` on eight
to `L5` would skip `E2`.

Its fixed twenty-step first return ends at the north
arrival supplied by `F5=EL`:

```text
P -> 8:L5 -> 7:W4 -> 4:WR2 -> 5:NL -> 2:WL -> 1:SL
  -> 4:EL -> 5:NR2 -> 8:E3 -> 7:SL after W4 -> 10:F4
  -> 9:D3 -> 6:WL2 -> 5:SL3 -> 8:E6 -> 9:D4
  -> 6:WR2 -> 7:V -> 10:F5 -> north arrival on eleven.
```

Therefore the next west departure after `P` is `NL`,
supplied by `F5`. In both current suffixes the next
west arrival on eight is `L7=WL`. Hence

```text
10:F5=EL -> 11:that NL -> 8:L7=WL -> 7:SL after V -> 10:F6
```

is a square first return. It forces `F6=ER`.

## M_L0 has no south departure left for F6

In `M_L0`, `E6` is the last north departure on eight,
so its target `D4=NL` would be both the last north
arrival and last west departure on nine. The word
on nine must end there. Its immediate predecessor
`D3=SR` is then the last south arrival.

Thus `F4=ER`, which supplies `D3`, is the last south
departure on ten. This contradicts `F6=ER`.

## M_L1 contradicts the final square on eleven

In `M_L1`, exactly one north departure on eight follows
`E6`: the port `c=WR`. With `D4` already the last
west departure, its target is `NR`, and the non-wake
word on nine ends

```text
D3=SR,D4=NL,NR,SL.
```

There is only one south arrival after `D3`. Hence
`F4=ER` is the penultimate south departure on ten,
and the forced `F6=ER` is the last. Alternation and
east-arrival order give the final four events

```text
10: ...,F4=ER,F5=EL,F6=ER,F7=EL.                    (1)
```

The last west arrival on eight is `L9=WL`. Let `T`
be the last west departure on eleven, feeding it.
There is a square first return

```text
T -> 8:L9=WL -> 7:final SL -> 10:F7=EL -> north arrival on eleven.
```

An `SR` source would produce another west departure
`NL` after the last one. Thus `T=NL`. Starting at its
north predecessor on ten gives a square first return
to `F7=EL`; that predecessor must be `WR`, immediately
before `F7`. But in (1) the predecessor is `F6=ER`.
This is impossible.

Both suffixes therefore require `D3=NL`.

## The remaining endings on nine

The incoming square at `D3=NL` now forces a `WR`
immediately before `E6=EL` on eight. Its consecutive
target on nine is the `NR` supplied by `E6`.

In `M_L0`, this predecessor is `c`. No further north
arrival remains for `D4`, so `D4=SR`. The ending is

```text
9: ...,NR from b,D3=NL,NR from E6,SL,D4=SR,SL.
```

In `M_L1`, the predecessor is `b`, and the final
north arrival is supplied by `c`. It is either
`D4=NL`, or an `NR` before or after `D4=SR`. The
three possible endings are

```text
...,D3=NL,NR from E6,D4=NL;
...,D3=NL,NR from E6,SL,NR from c,SL,D4=SR,SL;
...,D3=NL,NR from E6,SL,D4=SR,SL,NR from c,SL.
```

The earlier restrictions on `D1,D2` and the four
prefixes on eight still apply. These endings narrow
the remaining middle cases without excluding either
whole suffix.

## M_L0 also requires F5=ER

In `M_L0`, we now have `D3=NL,D4=SR`. Suppose
`F5=EL`. The south predecessor of `D4` on ten has
the square first return through `D4,6:WR2,V,F5`,
forcing the consecutive pair `F4=ER,F5=EL`.

The west departure `P` on eleven feeding `L5` must
again be `SR`, by the skipped-`E2` argument above.
Its eleven-step path to `F4` now continues through
`D4,6:WR2,V,F5` and north. This is a sixteen-step
first return on eleven. Hence the next west departure,
feeding `L7`, is `NL`, supplied by `F5`.

Its square through `L7` and the `SL` after `V` forces
`F6=ER`. The last two south arrivals on nine are
`D4=SR,SL`, so `F4` is the penultimate south departure
on ten and `F6` is the last. Its ending is again

```text
F4=ER,F5=EL,F6=ER,F7=EL.                            (2)
```

Let `Pb,PL,Pc` be the west departures on eleven
feeding `8:b=WR,L9=WL,c=WR`, in that order. The
last of these is the last west departure on eleven.

The square from `PL` through `L9`, the final `SL`
on seven, and `F7=EL` cannot have an `NL` source:
its incoming north predecessor on ten would have to
be `WR` immediately before `F7`, contrary to (2).
Thus `PL=SR`, and its consecutive target is `Pc=NL`,
supplied by `F7`.

Write `H` for the east arrival on twelve supplied by
the north arrival from `E6` on nine. The path

```text
Pc -> 8:c=WR -> 9:D3=NL -> 6:WL2 -> 5:SL3 -> 8:E6=EL
   -> 9:north arrival from E6 -> 12:H
```

has seven steps. A right turn at `H` would complete
a first return from `Pc=NL` to another west departure
`SR`, after the last one. Hence `H=EL`.

Starting at the south predecessor `Q` of `PL` on
twelve, use the square from `PL` to `Pc` and then
this seven-step path. The resulting twelve-step first
return to `H=EL` forces `Q=ER`, immediately before H.

The north arrival from `b` on nine is `NR` and
immediately precedes `D3=NL`; that pair is followed
by the `NR` from `E6`. Therefore the east arrival
immediately before `H` is the one supplied by the
north arrival from `b`. Call it `Gb`. We have
`Gb=Q=ER`, supplying `PL`.

Now

```text
Pb -> 8:b=WR -> 9:north arrival from b -> 12:Gb=ER -> 11:PL=SR
```

is a square first return. It forces `Pb=NL`.

But `Pb` occurs strictly between the west departure
feeding `L7`, supplied by `F5=EL`, and `Pc`, supplied
by `F7=EL`. There is no north departure on ten between
`F5` and `F7` in (2): their only intervening event is
`F6=ER`. No north arrival is available for `Pb=NL`.
This contradiction proves `F5=ER` in `M_L0`.

Its south step completes the square from `D4=SR`
to the final `SL` on nine, so `F5` is the last south
departure on ten. The last east arrivals are consequently
`F6=EL,F7=EL`, with `WR` between them. The south
predecessor of `D4` is `WL`, immediately before `F5`.
Thus the necessary ending in this suffix is

```text
10: ...,WL,F5=ER,F6=EL,WR,F7=EL.
```

The turn at `F4` and the rest of `M_L0` remain open.
