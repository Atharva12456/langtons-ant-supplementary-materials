# Four initial bands at an upper `(1,2,3)` cap

21 September 2026

## Result and scope

At drift `(1,-3)`, an upper `(1,2,3)` cap whose inward levels three and four are non-wake has only the following four possible initial stable bands. This is an all-period necessary condition. None of these four bands is asserted realizable or excluded here.

The common first three rows, in inward coordinates with headings rotated by 180 degrees, are

```text
0: WR
1: NR,SL
2: WR,WL,WR.
```

| Case | Row 3 | Row 4 |
|---|---|---|
| Short row | `NR,NL` | `WR,EL,WR,EL` |
| `(j,k,l)=(1,1,1)` | `SR,SL,NR,SL,NR,SL` | `WR,WL,ER,WL,WR,EL,WR,WL` |
| `(j,k,l)=(1,2,0)` | `SR,SL,NR,SL,NR,SL` | `WR,WL,ER,WL,WR,WL,WR,EL` |
| `(j,k,l)=(2,1,0)` | `NR,SL,SR,SL,NR,SL` | `WR,WL,WR,WL,ER,WL,WR,EL` |

The three removed long-row cases are `(1,0,2)`, `(2,0,1)`, and `(3,0,0)`. No wake assumption at level five or deeper is needed. The proof uses first-return order and two exact clock contradictions, not a period cutoff or a lifetime bound.

Family B in the September 13 wake classification has non-wake upper levels three and four, so this theorem applies to it. Combined with the separate upper `(1,2,2)` exclusion, it narrows the sole remaining recorded family with a lower `(1,2,2)` cap. Family B and the full growth-eight `(1,-3)` orbit remain open. Other lower-cap profiles remain separate.

## Conventions and prerequisites

Use inward transverse coordinate `t=3x+y`, with the upper drift now `(-1,3)`. A port records arrival heading and turn. The outgoing headings are

```text
ER -> S, EL -> N, WR -> N, WL -> S,
NR -> E, NL -> W, SR -> W, SL -> E.
```

For representatives `(0,t)`, stable time obeys

```text
tau(target)=tau(source)+1+N*dx,
dx(E)=1, dx(W)=-1, dx(N)=dx(S)=0.
```

These are the upper-cap signs. In particular, the clock arguments below must not be transferred to a lower cap without changing signs. A period has `N>=6`, since alternating axes must supply at least three vertical steps.

We use the stable-word framework of `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`: a nonempty stable row begins with R and alternates R/L; successive visits to one physical cell are at least four steps apart; matching departures and arrivals along an edge preserves their ordinal order. A forced walk with zero displacement and no intermediate return to its starting cell joins consecutive stable visits there. Its endpoint turns must be opposite. Visiting the same transverse level at a different translate is not a physical return.

Repeated ports on a fixed row are numbered in stable order. On row five write `D1,D2,D3` for its three west departures, feeding respectively `2:WR1,WL,WR2`. On row six write `E1,...,E5` for east arrivals when row three is long. On row seven write `W1,...,W6` for west departures, feeding the six west arrivals on row four in order. Labels such as `4:WL2` number that port type on row four.

The return paths below can be checked directly by the departure table. The accompanying Python checker verifies their headings, displacements, absence of intermediate physical returns, and the exact affine clock sums.

## The initial seven alternatives

Let `h` count the `NL` ports on row three. Two north arrivals, one west departure, and zero wake give

```text
(NR,NL,SR,SL)=(2-h,h,1-h,3-3h).
```

For `h=1`, alternation gives the short row `NR,NL`. Row four then has no south departures and two east arrivals, forcing `WR,EL,WR,EL`. We retain this branch. The earlier lower-cap exclusion of the short row does not apply here.

For `h=0`, row three has two `NR`, one `SR`, and three `SL`. Let `J` be the south departure on row four feeding that `SR`. The forced first return

```text
J -> 3:SR -> 0:WR -> 1:NR -> first east arrival on 4
```

has directions `SWNE`. Since `J` precedes the first east arrival, it is `WL`; the endpoint is `ER`. Thus `WL,ER` are consecutive on row four. The same square makes `SR,SL` consecutive on row three.

If `e` is the number of row-four `ER` ports, its counts are

```text
(ER,EL,WR,WL)=(e,2-e,6-3e,4-e).
```

The forced `ER` gives `e>=1`. If `e=2`, no `WR` remains to start the row before the required `WL,ER` pair. Hence `e=1`. Alternation therefore gives

```text
4: (WR,WL)^j, ER, (WL,WR)^k, EL, (WR,WL)^l,
j>=1, k>=0, l>=0, j+k+l=3.
```

The `j`th south departure feeds `3:SR`, fixing row three as

```text
3: (NR,SL)^(j-1), SR, (SL,NR)^(3-j), SL.
```

There are six triples, plus the short-row case. It remains to exclude the three with `k=0`.

## A common return when `k=0`

In all three cases `4:ER,EL` are consecutive. Suppose `D2=NL`. Its north-arrival source `U` on row four would participate in the first return

```text
U -> 5:D2 -> 2:WL -> 1:SL -> 4:EL.
```

This forces `U` to be the immediate predecessor of `4:EL`. That predecessor is `ER`, which departs south, so it cannot supply `D2` from the north. Thus `D2=SR`.

The first return

```text
5:D2 -> 2:WL -> 1:SL -> 4:EL -> north arrival on 5
```

then forces `D2=SR,D3=NL` consecutively, with `D3` supplied by `4:EL`. It is the `(j+1)`st north arrival on row five. Because `D3` is its last west departure, every later north arrival is `NR`.

## Excluding `(j,k,l)=(1,0,2)`

Here

```text
3: SR,SL1,NR1,SL2,NR2,SL3
4: WR1,WL1,ER,EL,WR2,WL2,WR3,WL3.
```

Put `C=tau(2:WR2)`. The edge into `3:NR2` gives its time as `C+1`, while the edge from `5:D3` to `2:WR2` gives `tau(D3)=C+N-1`.

The next north arrival on row five is supplied by `4:WR2`. Stable order gives

```text
tau(4:WR2) >= tau(D3)+3 = C+N+2,
tau(4:WL2) >= C+N+6,
tau(3:SL2) >= C+N+7,
tau(3:NR2) >= C+N+11.
```

Comparing the last line with `tau(3:NR2)=C+1` yields `0>=N+10`, impossible.

## Excluding `(j,k,l)=(2,0,1)`

Now

```text
3: NR1,SL1,SR,SL2,NR2,SL3
4: WR1,WL1,WR2,WL2,ER,EL,WR3,WL3.
```

The east arrivals on row six are supplied by `NR1,SL1,SL2,NR2,SL3`, in that order. In particular, the second north arrival on row three supplies `E4`.

If `E4=ER`, the square starting at `5:D3=NL` and passing through `2:WR2,3:NR2,E4` returns to row five with port `SR`. This would be another west departure after `D3`. Hence `E4=EL`.

Let `Z` be the south departure on row six feeding `5:D2`. The first return

```text
Z -> 5:D2 -> 2:WL -> 1:SL -> 4:EL -> 5:D3
  -> 2:WR2 -> 3:NR2 -> 6:E4
```

forces `Z=ER` immediately before `E4=EL`. Thus `Z=E3`.

There are two possibilities for `W4`, the west departure on row seven feeding `4:WL2`.

If `W4=NL`, its north-arrival source `U` on row six has the eight-step first return

```text
U -> 7:W4 -> 4:WL2 -> 3:SR -> 0:WR -> 1:NR
  -> 4:ER -> 3:SL2 -> 6:E3.
```

It forces `U=EL` immediately before `E3=ER`, so `U=E2`. But then

```text
4:WL1 -> 3:SL1 -> 6:E2 -> 7:W4 -> 4:WL2
```

is a four-step physical first return with L at both endpoints. This is impossible.

If `W4=SR`, the following sixteen-step first return on row seven forces `W5=NL`, supplied by `6:E4`:

```text
7:W4 -> 4:WL2 -> 3:SR -> 0:WR -> 1:NR -> 4:ER
  -> 3:SL2 -> 6:E3 -> 5:D2 -> 2:WL -> 1:SL -> 4:EL
  -> 5:D3 -> 2:WR2 -> 3:NR2 -> 6:E4 -> 7:W5.
```

Here `W5` feeds `4:WR3`, which feeds the last north arrival on row five. The resulting six-step path is

```text
5:D3 -> 2:WR2 -> 3:NR2 -> 6:E4 -> 7:W5
  -> 4:WR3 -> 5:last NR.
```

Its displacement is `(-1,3)`, the upper drift. Consequently

```text
tau(5:last NR)-tau(5:D3)=6-N.
```

These are the fourth and third north arrivals on row five, respectively, so their stable time difference is at least four. This would require `N<=2`, contrary to `N>=6`. Both choices for `W4` are excluded.

## Excluding `(j,k,l)=(3,0,0)`

Finally

```text
3: NR1,SL1,NR2,SL2,SR,SL3
4: WR1,WL1,WR2,WL2,WR3,WL3,ER,EL.
```

Now `D3=NL` is both the last north arrival and the last west departure on row five. No later right turn is possible: `NR` would add a north arrival and `SR` a west departure. Thus row five ends with `D2=SR,D3=NL`, and `D2` is its last south arrival.

The east arrivals on row six are supplied by `NR1,SL1,NR2,SL2,SL3`. As in the preceding case, the square from `D3` rules out `E3=ER`. The eight-step first return through `D2,2:WL,1:SL,4:EL,D3,2:WR2,3:NR2` then forces the south departure supplying `D2` to be `E2=ER`, immediately followed by `E3=EL`.

This is the last south departure on row six. Hence `E4,E5` are also `EL`, and alternation gives the tail

```text
6: ..., E2=ER, E3=EL, X=WR, E4=EL, Y=WR, E5=EL,
```

possibly followed by one final `WR`. No other port can be inserted after `E2`: `ER` and `WL` would add south departures, while the remaining east arrivals are already listed.

First consider `W2`, feeding `4:WL1`. If `W2=NL`, the square

```text
U -> 7:W2 -> 4:WL1 -> 3:SL1 -> 6:E2
```

forces its north-arrival source `U` to be `E1=EL`, immediately before `E2=ER`. The eight-step first return

```text
5:D1 -> 2:WR1 -> 3:NR1 -> 6:E1 -> 7:W2 -> 4:WL1
  -> 3:SL1 -> 6:E2 -> 5:D2
```

then forces `D1=NL` immediately before `D2=SR`. Since `D3` is the fourth north arrival, `D1` is the third and is supplied by `4:WR3`. This gives the twelve-step first return

```text
4:WR3 -> 5:D1 -> 2:WR1 -> 3:NR1 -> 6:E1 -> 7:W2
  -> 4:WL1 -> 3:SL1 -> 6:E2 -> 5:D2 -> 2:WL -> 1:SL -> 4:EL.
```

It skips the prescribed stable visits `4:WL3,ER` between `4:WR3` and `4:EL`. The intermediate `4:WL1` is a different physical translate, so it does not break the first return. This is impossible.

Therefore `W2=SR`. The twelve-step first return

```text
7:W2 -> 4:WL1 -> 3:SL1 -> 6:E2 -> 5:D2 -> 2:WL
  -> 1:SL -> 4:EL -> 5:D3 -> 2:WR2 -> 3:NR2 -> 6:E3 -> 7:W3
```

forces `W3=NL`, supplied by `E3`.

If `W4=NL`, its square through `4:WL2,3:SL2,6:E4` forces its source to be `X=WR`, immediately before `E4`. Then `W3,W4` are consecutive both among north arrivals (supplied by consecutive north departures `E3,X`) and among west departures. They are both `NL`. No intervening right turn is possible: `NR` would be an intervening north arrival and `SR` an intervening west departure. This contradicts alternation.

Thus `W4=SR`; the same square forces `W5=NL`, supplied by `E4`.

If the last west departure `W6` were `SR`, the first return

```text
7:W6 -> 4:WL3 -> 3:SR -> 0:WR -> 1:NR -> 4:ER
  -> 3:SL3 -> 6:E5 -> north arrival on 7
```

would force an additional `NL` west departure. Therefore `W6=NL`. Its north-arrival source `V` has the eight-step first return

```text
V -> 7:W6 -> 4:WL3 -> 3:SR -> 0:WR -> 1:NR
  -> 4:ER -> 3:SL3 -> 6:E5.
```

It forces `V=Y=WR`, immediately before `E5=EL`. Now `W5,W6` are consecutive both among north arrivals (supplied by `E4,Y`) and among west departures, yet both are `NL`. The same no-intervening-right-turn argument is contradictory.

This removes the last `k=0` case and proves the four-band table.

## Verification and continuation

Run

```bash
python verify_upper_fat123_four_bands.py
```

The saved result `upper_fat123_four_band_checks_2026-09-21.json` has `all_checks_passed=true`. It checks fifteen closed first-return paths, the translated six-step path, the two exact clock sums `N+10` and `N-2`, and the remaining parameter list. The second clock sum is positive for all `N>=6`.

This is a hand proof with finite certificate checks. The prior stable-word framework, completeness reasoning, and deductions connecting the certificates are not mechanically formalized. Exploratory inward-extension counts are not premises.

For family B, continue from the four rows in the table, splitting the wake indicator on upper level six as required by its wake placement. The short-row branch and all three listed long-row branches remain unresolved. An exclusion of those branches would still leave the other lower-cap profiles to handle before closing the full `(1,-3)` orbit.

References: `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`, `odd_skew_fat122_three_visit_wake_families_2026-09-13.md`, and `odd_skew_upper_fat122_exclusion_2026-09-21.md`.
