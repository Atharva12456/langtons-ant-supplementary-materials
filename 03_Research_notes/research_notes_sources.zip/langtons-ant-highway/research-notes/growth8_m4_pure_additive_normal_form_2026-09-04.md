# Additive normal form for the pure `(4,-4)` wake

Date: 2026-09-04.

## Scope

Assume a growth-eight `(4,-4)` candidate has eight horizontal-arrival wake
classes and no vertical-arrival wake class.  This note reduces the complete
family of drift-periodic additive mod-four endpoint charges to one congruence
on the transverse wake heights.  It is a hand calculation and is not an
exclusion.

## Residue parameters

Use \(t=x+y\), \(r=x\pmod4\), with the wake on odd levels.  Every `x` and
`y` residue contains exactly two wakes.  Let \(a\) be the number of wakes on
levels \(t\equiv1\pmod4\) in each even `x` residue, and let \(b\) be the
same number in each odd `x` residue.  The `y`-degree equations force the two
even residues to have the same count and likewise for the two odd residues,
so

\[
 a,b\in\{0,1,2\}.
\]

For a wake at level \(t\), put

\[
 h(t)=
 \begin{cases}
 (t-1)/4,&t\equiv1\pmod4,\\
 (t-3)/4,&t\equiv3\pmod4,
 \end{cases}
 \qquad Z=\sum_{D_{t,r}=1}h(t).
\tag{1}
\]

## Complete additive condition

Every drift-periodic zero-four-corner endpoint charge vanishes if and only if

\[
 \boxed{Z\equiv a+b-1\pmod4.}
\tag{2}
\]

To prove this, let \(w_t=(w_{r,t})_r\) be an arbitrary quotient weight,
put \(A_t=\sum_rw_{r,t}\), and set \(S=A_0+A_1\).  The four-corner
recurrence gives

\[
 w_{t+4}=w_t+S\mathbf1
\tag{3}
\]

on odd levels.  Write \(U_e,U_o\) for the even- and odd-lane sums of
\(w_1\), and \(V_e,V_o\) for those of \(w_3\).  The first three recurrence
steps give

\[
 V_e=A_0+A_1+U_e,qquad V_o=A_0-2A_1-U_e.
\tag{4}
\]

The base-level part of the wake sum is therefore

\[
 aU_e+(2-a)V_e+bU_o+(2-b)V_o
 =-(a+b)A_0+(2-a+3b)A_1.
\tag{5}
\]

The height shifts in (3) add \(ZS\), and the north-heading monodromy is
\(A_0-A_1\).  The complete endpoint defect is consequently

\[
 (Z+1-a-b)A_0+(Z+1-a+3b)A_1.
\tag{6}
\]

The coefficients differ by \(4b\), while \(A_0,A_1\) are arbitrary.  This
proves (2), without selecting a finite basis of test weights.

The 2-regular wake graph splits into two checker blocks.  In either block,
the residue graph is a four-cycle when its parameter is one and is two
doubled edges when its parameter is zero or two.  Thus a `CP` graph has one
of \(a,b\) equal to one and the other equal to zero or two; (2) then makes
\(Z\) even.  The explicit partial-rail family has
\((a,b)=(1,2)\), \(Z=2L\), so (2) recovers \(L\) odd and
\(W=8j+4\).

The congruence leaves infinitely many labelled pure wake graphs.  Chronology,
not another additive weight of this family, is needed to finish the orbit.
