# Wake families for the last wake-three lower `(1,2,3)` band

**Scope.** Drift is `(1,-3)`, growth is eight, and the lower fat
`(1,2,3)` band has `omega_3=omega_4=1`, `(j,k,l)=(1,1,0)`.
The other current results exclude a missing or guard upper cap for this
band, so its upper cap must be fat `(1,2,3)`. This note applies P22,
the rank parity, and the additive moment to that cap pair. It classifies
wake placements, not stable words or actual ant orbits. The band remains open.

The lower cap supplies wakes `0,2,3,4` and non-wakes `1,5,7`. The upper
fat cap supplies wakes `W-2,W` and non-wake `W-1`, with even width `W`.
These six fixed wakes are distinct for `W>=12`. Write `O` for the full
eight-wake set. We use the normalized necessary equations

```text
sum_{t in O, t mod 3 = r} (-1)^t = 2 mod 4  (r=0,1,2),
I = sum_{r<s} #{(u,v) in O_r x O_s : u<v} = 0 mod 2,
M = sum_{t in O} (-1)^(t+1) floor((t+1)/3) = 3 mod 4.
```

The `0 mod 3` fibre already has opposite signs from levels zero and
three. It must be the four-wake fibre, with its two other wakes of the
same parity. The other fibres each contain two even wakes. Sorting the
two free wake levels gives **all** placements satisfying the three
equations:

| Family | Width and complete wake set | Parameter conditions |
|---|---|---|
| A | `W=6m`; `{0,2,3,4,6i,6j+2,6m-2,6m}` | `1<=i<=j<=m-1`, `i+j` even |
| B | `W=6m+2`; `{0,2,3,4,6i,6j+4,6m,6m+2}` | `1<=i<j<=m-1`, `i+j` odd |
| C-even | `W=6m+4`; `{0,2,3,4,6i,6j,6m+2,6m+4}` | `1<=i<j<=m`, `i+j` odd |
| C-odd | `W=6m+4`; `{0,2,3,4,6i+3,6j+3,6m+2,6m+4}` | `1<=i<j<=m-1`, `i+j` even |

Here is the arithmetic check. In A, the two free levels must be
`x=6i,y=6j+2`; direct cross-fibre counting gives
`I=9+[x<y]`, and the moment is `M=3-2(i+j) mod 4`.
Thus `i<=j` and `i+j` is even. In B the free levels must be
`x=6i,y=6j+4`; `I=11+[x<y]`, while
`M=1-2(i+j) mod 4`. The first requires `i<=j`; the second makes
`i+j` odd, hence `i<j`. In C both free wakes lie in the zero fibre.
They are either both even, `6i,6j`, or both odd, `6i+3,6j+3`.
The rank count is `I=12` in either case. The moments are respectively
`1-2(i+j)` and `3+2(i+j)` modulo four, giving the conditions in the
table. The index ranges enforce distinct levels and the non-wake
`W-1`. This derives the table for every width, without a width cutoff.

`code/python/lower_fat123_a1_b1_110_wake_schedules.py` independently enumerates all eight-element wake
sets through even width 160 and finds exactly the four closed forms:
5,694 schedules before the cap-overlap check. This finite run audits
the algebra; it is not the reason the table applies at all widths. Its
output is `results/lower_fat123_a1_b1_110_wake_schedules_2026-09-23.json`.

The sole width-twelve schedule is family A with `i=j=1`, namely
`{0,2,3,4,6,8,10,12}`. At `W=12`, lower level nine is upper inward
offset three. The exhaustive lower prefix verifier through level nine
leaves 104 states, and their level-nine row lengths are
`11,12,13,14,16,18,20,22` (minimum 11). An upper fat `(1,2,3)`
cap has at most six events at inward offset three, including its
short-row option. Therefore width twelve cannot occur. The first
remaining width is sixteen.

For every surviving family, lower level ten is non-wake. Upper inward
offsets **3, 5, 8, 9, and 11** are non-wake. Family A has an upper wake at
offset six only if `i=j=m-1`, which also makes offset four wake.
Family C-odd has an upper wake at offset seven only if `j=m-1`.
The other families have non-wake upper offsets six and seven. These are
direct checks of the four formulas; the excluded width-twelve overlap
is why offset eight is included in the universal quiet list.

At the lower end, `omega_8=1` occurs only in family A with `i=j=1`,
which forces `omega_6=1` and `W>=18`. A wake at level nine occurs only
in family C-odd with `i=1`, forcing `omega_6=omega_8=0` and `W>=28`.
The existing exact level-nine frontier has 104 prefixes: six with
`(omega_6,omega_8,omega_9)=(0,1,0)` and four with `(0,1,1)` violate
these global wake rules. **Ninety-four** local prefixes remain possible
under this cap coupling; this is not an orbit exclusion.

The upper-`210` local lemma in
`odd_skew_upper_fat123_210_near_wake_2026-09-23.md` requires an upper wake
at offset five or six. Offset five is quiet in all four families, and offset
six is wake only in A with `i=j=m-1`. Thus an upper `210` initial band is
possible only in that A edge subfamily. The short, `111`, and `120` upper
bands remain open, as does the A edge `210` branch.

`code/python/verify_lower_fat123_a1_b1_110_cap_coupling.py` reproduces the
104-to-94 prefix audit and writes
`results/lower_fat123_a1_b1_110_cap_coupling_2026-09-23.json`.

The independent `work_a1_110_next/level10_returns.py` screen completed the earlier
pair-filtered level-ten frontier: all 282,823 words pass the explicit
finite physical-return check, of which 137,394 have `omega_10=0`.
Those counts precede this global wake-family filter and do not include
new-row lifted-clock feasibility. In particular they give no closure
claim. They show that a further return-order check at level ten alone
will not dispose of the band.
