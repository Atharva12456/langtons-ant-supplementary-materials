# Langton-ant proof and compute handoff

Last scope correction: 2026-09-03 (full rail occupancy remains unproved)

The later primitive-growth-four classification supersedes the open status in
this historical checkpoint. Use the accompanying report and detailed reference
for the current theorem statements and their computational premises.

> **Historical checkpoint: 3 September 2026.** The July live-session text immediately below is retained
> as history. It is superseded by the dated August addenda later in this file:
> widths six and eight are now computer-assisted all-period exclusions, axis and
> even-diagonal growth four are analytically excluded, T1/T2 line parity is promoted,
> and primitive-diagonal growth four remains open. At growth eight, only the
> full-rail subfamily at `(4,-4)` is excluded by the four-lane argument;
> checker-pure `(2,-2)` is excluded and its mixed part has an exact interlacing
> parity. All ten drift orbits retain unresolved cases. Existing targeted records
> exclude growth eight through period 60.
> In particular, `g>=12` has not been proved.

The 3 September scope audit supersedes the unconditional rail claims in the
historical addenda below. Extremal rigidity does not prove full rail occupancy;
the `(3,-3)` six-rail boundary is conditional as well. See
`rail_occupancy_scope_audit_2026-09-03.md` before using those reductions.

The 4 September conceptual continuation is recorded in
`first_entry_detour_charges_2026-09-04.md`. It proves
`N>=6 max(|a|,|b|)+2(|a|+|b|)` and, at growth-eight diagonal drift,
`N>=10m+4` (hence `N>=48` for `(4,-4)`). The exact first-entry detour
charges sum to `g/4`; four-step waits have charge one, eight-step waits
have charge zero, and simple waits have charge one. An explicit local
zero-charge detour shows why positivity cannot be assumed from root colour
and an unvisited future ray. Periodic coupling is still missing.

The same continuation gives partial-rail `(4,-4)` boundary placements at
widths `12,20,28,...` satisfying the rank sign, the complete additive
mod-four endpoint family, and coordinate-fibre visit residues. These are
not integer tours or P3 traces; see
`growth8_m4_partial_rail_obstruction_2026-09-04.md`. All ten drift orbits
remain open. No simulations or new mathematical enumeration runs were performed.
The manuscript renders have not been rebuilt, and nothing was committed or pushed.

## Historical session checkpoint: 21 July 2026

The research interval ended at 19:00 CDT on 21 July 2026.  The corrected width-four result has now been integrated into both manuscripts.
The correction adds an omitted label hypothesis and narrows the claim scope;
Journal Section 38.16 records the repair and formalisation boundary.  Final PDF/release QA and the requested unsent Gmail drafts remain in
progress.  No universal proof or counterexample exists at this checkpoint.

Codebase audit note: the Java class whose filename contains `Indep` is best
described as the **residue-theorem-free variant**, not as an independent
implementation. All three Java variants share enumeration and representation;
the separate Python literal-criterion verifier supplies the implementation-level
cross-check. Preserve the larger residue-free counts in the paper. Before release,
repair the principal paper's lifetime-state wording and explicitly qualify the
labelled touch-graph theorem under physical row/column pushforward.

## Truth status

The finite-seed Langton-ant highway conjecture is still open. Nothing in this project is a universal proof or a counterexample.

The exact target used here is:

> Every initial coloring with finite black support, with the ant at a specified lattice pose, eventually enters an exact translating periodic regime equivalent under a lattice symmetry and phase shift to the standard period-104 highway.

Finite computation can exclude bounded periods and test candidate mechanisms, but it cannot by itself prove this universal entrance statement.

## Rigorous frontier at the historical checkpoint

The principal new theorem is P22, the signed mod-four wake-residue theorem. For a finite-support repeating trace with nonzero drift d=(a,b), canonical wake bases c_i, and growth g:

- if a is nonzero, then for every residue r modulo |a|,
  sum over c_ix congruent to r of (-1)^(c_ix+c_iy) is 2 modulo 4;
- if b is nonzero, the analogous row sum is 2 modulo 4;
- exact columns or rows in a zero drift coordinate have signed sum 0 modulo 4.

Consequently every nonzero drift residue contains a positive even number of strands and

    g >= 2|a|  and  g >= 2|b|.

In particular g=0 is impossible for every exact finite-support repeating trace. This is an independent proof of the no-clean-translator conclusion previously obtained from the cylinder argument. It is not an entrance theorem and does not classify all positive-growth traces.

The exterior-dynamics continuation proves:

- P23, a finite-history renewal theorem for quiet flights;
- P24, if active Tait cycles are eventually bounded, every black Tait component has uniformly bounded size and diameter;
- P25, arbitrarily long bad seam episodes contain detached stationary seam islands with unbounded stationary duration and excursion radius; and
- P26, a warmed nonzero-drift renewal flight that moves its complete footprint beyond the finite black support present when that flight began can never be interrupted and escapes forever as a positive-growth periodic trace;
- P27, the row-column incidence boundary of every finite color defect is exactly the two endpoint ant tokens, so arbitrary collision checkpoints telescope and all but at most one defect component are Eulerian;
- P28, every L collision is exactly a bridge split or a nonbridge merge, with the old live successor selecting the active daughter; and
- P29, every completed R-to-L black lifetime has an Eulerian odd-visit component through its paired cell and therefore involves at least four distinct cells. In the four-cell case, signed mod-four charges determine the rectangle's add/remove pattern from arrival type and side parities.

Thus a returning bad core needs an unbounded chronological chain of flight changes/ancestral-debris collisions, or quiet intervals repeatedly too short to complete a warmed record cycle. Abstract planar binary-counter and one-marker returners prove that locality, finite state, bounded components, finite support, a fixed anchor, and even injectivity on the reachable orbit do not alone exclude this behavior. P27 rules out their displayed one-row tape mechanisms as literal Langton dynamics, but neutral row-column cycles can have arbitrary span. The exact remaining bounded-loop obstruction is the Langton-specific production and ordering of those neutral cycle packets among uniformly small Tait islands. The unbounded-active-loop branch remains open.

## Exact periodic search status

**Update (paper/repo continuation, 14 Jul 2026):** two-engine, rank-audited exclusion now extends to **period 46 and 48**. Period 46: both engines 3,463,441,745 nodes / 98,568,824 leaves / 0 hits. Period 48: both engines 8,677,026,370 nodes / 451,962,870 leaves / 0 hits; residue engine pruned 439,705,662 leaves via P22. All per-rank counters agree. Therefore **no finite-support periodic highway of nonzero drift has period at most 48.** Shards: work/p46_*_shards/, work/p48_*_shards/. Aggregated summary: langtons-ant-highway/results/period_exclusion_summary.json. The Lean project now includes Langton/P3Endpoint.lean in the build graph (previously silently broken); clean 16-job build, no sorry.


Odd heading-reset periods are analytically impossible. Zero-growth repeating traces are analytically impossible at every period by P22.

Two independent complete period-42 searches cover prefix ranks 0 through 8191 exactly once:

    nodes             528,451,911
    leaves             14,561,206
    hits                        0

The original implementation applied exact P3 to all 14,561,206 leaves. The residue-aware implementation rejected 13,487,309 leaves using P22 and applied P3 to the remaining 1,073,897. All shared per-rank counters agree. Together with earlier searches, no finite-support periodic highway has period at most 42.

Two independent complete period-44 runs have finished over prefix ranks 0 through 16383:

    nodes           1,319,080,456
    leaves             67,839,409
    residue prunes      65,050,414
    P3 checks            2,788,995
    hits                        0

Both ten-shard families are contiguous and exhaustive; every shard has search_complete=true, node_cap=null, the exact expected number of per-rank records, and zero hits. The original engine checked P3 on all 67,839,409 leaves. The residue-aware engine rejected 65,050,414 with P22 and checked P3 on the remaining 2,788,995. Nodes, growth prunes, endpoint prunes, leaves, and hits agree at every one of the 16,384 ranks. Therefore no finite-support periodic Langton highway has period at most 44, conditional on the written mathematical and implementation audit dependencies.

Period-44 residue shards:

    work\p44_residue_shards_v2\shard_00.json
    ...
    work\p44_residue_shards_v2\shard_09.json

Period-44 original-engine shards:

    work\p44_original_shards_independent_20260714\shard_00.json
    ...
    work\p44_original_shards_independent_20260714\shard_09.json

Deterministic cross-audit:

    python work\p44_independent_audit.py

    script SHA-256 35d134a3f4bd98c51ce8a9bf3814e156e303adada3cda93881621a94fea0e0ba
    summary SHA-256 682b9bf0118684f3c2595e7deae39c785dd5d31bf38812df0ac47ca8c4869ada
    note SHA-256 49aea8b22b068e04bb9d6d330acb229a13f2ef18e5b5a2c725fa1780673ab5c7

Validated search sources:

    outputs\PositiveGrowthSearch.java
    SHA-256 f2fadea8b323bf7bc817505e36b83146e4489ee5954d98dc1a87b52adb8dbf8d

    work\PositiveGrowthResidueSearch.java
    SHA-256 859a5c683898375cd8e94637cdbb50824b59eb88f83e6876e225c82c8c421b17

Period-42 records:

    work\positive_growth_original_p42_complete.json
    SHA-256 daef0982d24dd84e0a889f6f4f84795d670f32c29886d990f7b709b683ef4136

    work\positive_growth_residue_p42_complete.json
    SHA-256 bd8634a72855805d3913560b177b9d71eb5dfebc51b3ca07a241f8737246a2c7

To rerun a complete period N search with prefix length k, divide the half-open prefix-rank interval [0,2^(k-1)) into disjoint worker intervals. A representative original-engine period-44 command is:

    java -cp outputs PositiveGrowthSearch --period 44 --prefix-length 15 --rank-start START --rank-stop STOP --deficit-depths 0 --output OUTPUT.json

For the residue-aware engine use class path work and class PositiveGrowthResidueSearch with the same arguments. A complete exclusion requires exact rank coverage once each, search_complete=true, node_cap=null, empty hit lists, identical source/settings, and aggregate counters equal to the sums of all per-rank counters.

Any nonstandard hit must immediately be rechecked using finite_seed_for_periodic_trace in outputs\langton_research.py. A verified hit would disprove uniqueness of the standard highway, not automatically disprove eventual periodicity for every finite seed.

## Lean checkpoint

The portable Lean project is at:

    work\lean_langton

Build from the project root with:

    powershell -ExecutionPolicy Bypass -File work\lean_langton\build.ps1

The current independent clean build completes 16 jobs and a source scan reports no `sorry` or `admit` declarations. It machine-checks the finite-support transition kernel, heading residue, the finite parity telescope core, four-corner checker-signed weights, the mod-four fiber arithmetic, fiber positivity/evenness, the finite counting implication g>=2n, collision-chain endpoint parity, and exact directed-pose row/column discrepancy charges.

The module work\lean_langton\Langton\ChargeTelescoping.lean proves finite potential telescoping, checker-cycle monodromy 2*sum(alpha), translated-widget cancellation, and derivation of the residue identity from a structured LocalResidueCertificate. It has SHA-256 990adca871641dfbc3a4563d72e8a83f2e40ff21ed4c931cfc88b19b026b1da9.

`Langton\TraceGeometry.lean` now derives exact phase/address lists, finite per-level toggle totals, 0/1 orbit totals, the canonical strand-plus-widget decomposition, terminal widget zero, grouped phase-to-strand charge, the residue alpha cycle, widget cancellation, and the old local certificate fields. Its SHA-256 is 4e58c91dcf272fe3cf06c2517fe303cc038921c0f5b062182309ae52f397d596.

Important limitation: P22 is still not formalized end to end. The remaining explicit inputs are the endpoint binary normal form derived on paper from P3, a physical closed residue traversal, its local potential law, and exact grouped trace-charge conservation. The exact boundary is in work\lean_langton\FORMALIZATION_BOUNDARY.md, SHA-256 71bb7718328fac3b6f426c4e59ace55d634d5e4193df433e1de2cc1b982f503d.

`Langton\CollisionParity.lean` proves the one-step/run endpoint boundary and arbitrary checkpoint telescoping (SHA-256 80a83a42be952d75870ccd55cbedbb2d8b44eb63767add5908430fe75f745be2). `Langton\DirectedPoseDiscrepancy.lean` constructs explicit exact-column and exact-row mod-four potentials, verifies all eight R/L cases, proves unconditional same-pose endpoint congruences, and checks the minimum-rectangle sign formula (SHA-256 ee53b7aa884effb94b42213affe37bab4762075cc672ba77a4fa3d2a763a7c17).

## Independent P22 audit

Run:

    python work\translator_residue_charge_audit.py
    python work\residue_theorem_adversarial_audit.py

The first audit checked 944,640 local turn equations, 3,360,000 nonzero-drift monodromy equations including both drift signs, and 2,016,000 zero-coordinate equations. The adversarial audit enumerated all 524,286 words through length 18; all 172,092 heading-reset, nonzero-drift candidates satisfied the direct residue identity. It also independently checked known standard phase/power words and their dihedral transforms. No failure was found.

## Structured positive-growth searches

The following finite families produced no nonstandard P3 certificate:

- 196,762 delete-one-return-loop / insert-one-closed-standard-subword splices;
- all 10,816 concatenations of two cyclic standard phases;
- 70,616 same-rotated-drift phase triples; and
- 9,568 targeted low-score mixed-drift triples.

These data show isolation of the period-104 word in selected families. They do not prove unbounded uniqueness. The missing periodic theorem is a single-tour chronology/interlacement result strong enough to eliminate abstract signed-residue configurations not realizable by one ant tour.

The growth-four case is now completely classified at the wake-residue level. Possible drifts are only (±1,±1), (±2,0), (0,±2), and (±2,±2). Axis skeletons are two residue-paired rows or columns separated by an arbitrary even distance; diagonal skeletons have the parity patterns forced by P22. The additional kinematic congruence is

    N/2 + a + b + A = 0 modulo 4,

where A is the number of even-checker odd classes for a P3-valid word. Every even-drift growth-four case has N divisible by 8; primitive diagonal cases have the corresponding 2 or 6 residue modulo 8 and analytic lower bounds 10 or 14.

Most importantly, exact heading-reset chronological countermodels exist for every growth-four drift type. They satisfy within-period physical-cell alternation, local class excess, and all residue equations, but fail cross-period P3; one period-24 drift-(2,-2) model has only one bad stabilized adjacency. Reproduce all six with:

    python work\g4_case_audit.py

Source SHA-256: 0c7e001c68d7333e544f94f41ffe88d14f35d0b83b3bf34de3838e375ef06360. This establishes that additional incidence or residue counts cannot close even growth four; the missing information is exactly stabilized level/phase chronology.

## Exterior computation and warnings

The centered 3-by-3 mask 0x16d sheds a length-eight inner loop at step 14,989 and reabsorbs that unchanged loop at step 38,262, after an age of 23,273. This is a finite obstruction witness, not a counterexample; the orbit later highways.

An isolated obstacle added to a certified immediate highway can force a deep exact reversal: obstacle (-23,26) is first hit at step 1,173, the ant returns to the launch cell at step 6,636 heading north, and an exact standard-highway certificate appears at step 10,668. A scan of 682 leading-cell/level obstacle placements found eventual standard gateways in every case before 200,000 steps. This refutes naive local monotonicity but supplies no universal scattering bound.

The collision-time audit is sharper. At time 1,173 the ancestral obstacle edge is a degree-(3,1) leaf bridge in a 34-edge, cycle-rank-two component. Its length-120 active boundary splits into a pristine live four-cycle and a non-pristine shed length-116 boundary, yet the eventual drift reverses from (-2,2) to (2,-2). Therefore ancestry, bridge status, boundary rotation, and a pristine live exit do not impose a nonnegative drift projection. Reproduce the single witness with:

    python work\one_obstacle_collision_audit.py

The script SHA-256 is 21d77bbb8404ae75888341df7e55eb855680339d113091a2b16d46ba45960ecb. Between times 0 and 6,636 its 524-cell defect is one Eulerian row-column incidence component of cycle rank 444, showing exactly how a reversal hides in endpoint-neutral cycle storage.

The blank orbit also contains 35 pairwise-crossing R-to-next-L black-lifetime intervals. Do not assume black-memory intervals are laminar or LIFO.

For the periodic chronology branch, read `work\chronology_pairing_hostile_audit.md` and `work\interlace_touchgraph_notes.md`. Every completed R-to-L interval has at least three other odd-visited cells. The Dyck-versus-physical exchange formulas are correct but also hold for nonchronological within-class bijections; all six fixed g=4 near-models pass them, so do not use them as a P3-order obstruction.

The stronger voltage/touch-graph reduction is rigorous. Paired lifetimes become 4-valent phase-cylinder vertices; wake R events are degree-2 H/V switches. After suppressing those switches, Traldi's modified interlacement rows span the full cycle space of the contracted touch graph, with rank

    m - c - kappa + 1,

where c counts closed H/V smoothing circuits and kappa counts cycles in the 2-regular wake-edge subgraph. The uncontracted graph has kappa additional wake-cycle directions. On the standard trace, m=46, c=5, kappa=1, and both predicted and measured projected rank are 41, while the full boundary rank is 42. For g=4, kappa can be 1 or 2 and arbitrarily many closed H/V backtracking circuits remain possible. The exact unresolved lemma is to control that wake-cycle lift and those closed circuits using voltage/lattice/signed-charge data.

Reproduce the narrow audit (standard trace plus the six already fixed near-models only) with:

    python work\chronology_pairing_audit.py

Script SHA-256: e0b063427e30428c8d43b09bd8621bcf0456ee87c3292a721ff7025653f780e1. The independent rerun exited successfully; for the standard word it reproduced the integer chord identity 192=192 and ranks 41/41 versus boundary rank 42.

## Highest-value next work

1. Finish the exact P3-to-`NormalizedTrace` bridge in Lean: derive the endpoint binary normal form, physical residue traversal, local potential law, and grouped charge conservation rather than supplying them as structure fields.
2. Attack the bounded-loop island-collision ordering problem: prove that uniformly bounded detached islands cannot generate infinitely many returns to an old stationary seam island, or construct an exact Langton counterexample gadget.
3. Find a coercive invariant or normalization for the unbounded-active-loop branch.
4. For the periodic branch, control the `Z(W)` wake-cycle lift and the unbounded closed H/V smoothing circuits in the now-rigorous voltage boundary touch graph. General circuit nullity already closes the contracted graph and cannot supply this missing restriction.
5. Do not spend compute merely extending a numerical horizon. Run a search only when it certifies a stated bounded theorem, independently checks a proof dependency, or targets a precise counterexample mechanism.

## Files to read first after interruption

1. outputs\langton_proof_journal.md — authoritative detailed proof journal.
2. outputs\langton_highway_research_note.md — shorter research exposition.
3. work\translator_classification_notes.md — P22 derivation and periodic classification notes.
4. work\residue_theorem_independent_audit.md — hostile independent rederivation.
5. work\exterior_gap_notes.md — P23–P25 and exact obstruction witnesses.
6. work\lean_langton\Langton\ResidueCharge.lean — checked arithmetic kernel.

7. work\chronology_pairing_notes.md — Dyck/physical matching, all-lifetimes discrepancy theorem, and current interlacement frontier.
8. work\directed_pose_discrepancy_audit.md — independent paper and Lean audit of the signed lifetime theorem.
9. work\lean_langton\FORMALIZATION_BOUNDARY.md — exact current Lean assumptions and derived layers.

All project material is organized under the project root directory. Paths beginning
with `work/` and `outputs/` in this note are relative to that root. In this public
repository the corresponding sources live under `code/`, `lean/`, and `results/`;
the bulk search-shard data referenced here is regenerable via the commands in the
top-level `README.md`.

## 20 July 2026 publication-continuation handoff (supersedes stale counts above)

The conjecture remains open. The current submission is
`paper/main.tex`, retitled *Finite-Support Periodic Highways of Langton's Ant:
Necessary Conditions and Short-Period Exclusion*. It states two separate open
obligations: eventual entrance for every finite seed and unbounded-period
classification/uniqueness of positive-growth periodic traces.

### Formal boundary

`lean/Langton/P3Endpoint.lean` now contains
`StabilizedP3Word.toOrbitEndpointData`. Given an explicit stabilized nonincreasing P3
level word, it derives the first positive endpoint, zero-sum balanced remainder, and
binary widget prefix. It does not extract that word from every actual periodic ant
trace, and the lifted residue path/local potential geometry remains explicit. A clean
official-Lean-4.32.0 Docker build completed all 18 jobs; the axiom audit lists only
`propext`, `Quot.sound`, and where used `Classical.choice`. Use `lean/Dockerfile` or
the repaired `lean/build.ps1`.

### Exact computation boundary

Do not call `PositiveGrowthSearchIndep.java` an independent implementation. It is the
**residue-free variant** of the shared Java enumeration framework. It certifies the
period-34--48 rows by applying P3 to every positive-growth nonzero-drift leaf; the
P16/P22 variants are conditional consistency checks.

The period-at-most-32 tree was freshly regenerated under current Python source:
59 unprefixed nodes through depth 5 plus 46,185,421 nodes in the 32 length-six prefix
shards, 46,185,480 total, zero hits, all complete. The current source SHA-256 is
`b395ed3aac53bb9f43aea375ffd7257cd81ec3df5404df098783ed0656c4bcfc`.

`records/aggregate_indep.py` now checks all eight counters and fails on a missing
period. The archive described at this historical checkpoint was later rebuilt. Do
not use its obsolete checksum; the canonical archive and checksum are specified in
the superseding final-release section below.
Period 48 is 51,856.023 aggregate shard-seconds (14.404 shard-hours), with recorded
wall time 1:28:48 using 11 workers.

### Narrow growth-four result

The compatible abstract wake matchings have (kappa=1) for axis drift,
(kappa=2) for even diagonal drift, and (kappa\in\{1,2\}) for primitive diagonal
drift. This is a topology classification only. `cycle_functionals` uses alternating
oriented coefficients and is not P22; do not infer that P22 annihilates or controls
the wake kernel.

### Paper corrections already applied

The cyclic-minimum normalization now has a proof. Bare reflection was removed as a
symmetry. The affine-invariant theorem was narrowed to what it proves. The unsupported
clean-translator refinement and Hamming-isolation proposition were removed. The
completed-lifetime token argument was repaired. The touch-graph statement now keeps
labels/multigraph conventions and explicitly limits physical pushforward to
(pi_*Z(T/W)). Bibliographic metadata and runtime/cap claims were corrected.

### Immediate continuation checklist

1. Check the final mathematical corrections against the proof notes and released
   artifacts.
2. Recompile twice and require zero undefined references and zero overfull boxes.
3. Render all PDF pages and inspect every page visually.
4. Regenerate `results/artifact_hashes.json` after final source/PDF changes.
5. Finish `professor_outreach_email.md` with placeholders; state clearly that the
   preprint does not solve the conjecture and request targeted technical feedback.
6. Mirror this handoff and the proof journal to `outputs/` after every final correction.

## 20 July 2026 final release handoff (supersedes every earlier checkpoint above)

### Mathematical status

The finite-support highway conjecture is **not proved or disproved**. No
counterexample certificate was found. The release proves necessary conditions on
finite-support periodic highways and one exact bounded computation. A complete proof
still needs both:

1. a bounded-active-core/entrance theorem placing the ant and every cell or
   Tait-boundary component capable of influencing the future in one finite translated
   window, with all outside debris permanently inert; and
2. an unbounded-period chronology theorem showing that every positive-growth
   periodic highway agrees in path and turn trace with the standard period-104
   highway up to translation, quarter-turn rotation, and cyclic phase.

Do not revive the earlier exterior-dynamics, centered-3-by-3, Hamming-isolation,
minimum-rectangle, or physical touch-graph-rank claims. They were removed from the
release because their proof or publication certificate was incomplete. The narrow
growth-four wake-port matching audit is only an abstract topology classification;
its alternating oriented functionals are not the signed all-`+1` P22 charges.

### Canonical documents

- Principal source: `paper/main.tex`
- Principal PDF: `paper/main.pdf` (18 pages), SHA-256
  `d3b30f6ca9c9656690c12a9ed637649ad721f72f8d1826d7687e9d0ca0183ea3`
- Technical companion: `companion/main.tex`
- Companion PDF: `companion/main.pdf` (15 pages), SHA-256
  `8c711ae8cdb5b94f006db9a73b8ffdc8753effc16582044ee585349a108afa74`
- Accessible copies: `docs/paper.pdf` and `docs/companion.pdf`; each is byte-identical
  to its source PDF.
- Outreach template: `docs/professor_outreach_email.md`
- Detailed audit trail: `research-notes/proof_journal.md`

Both LaTeX files were compiled twice after the final source edit. Their logs contain
no LaTeX warning, undefined citation/reference, overfull box, underfull box, or fatal
error. The PDFs have explicit title/author metadata. All companion pages and all
changed main-paper pages were rendered and visually inspected; the main paper had
already received a complete all-page visual pass earlier in the same session.



### Exact computation certificate

The period-at-most-32 records are a complete **first-R cyclic-phase-normalised**
enumeration, not a literally unnormalised binary tree: 59 unprefixed nodes through
depth 5 plus 46,185,421 nodes in all 32 `R` plus five-symbol prefix shards through
depth 32, for 46,185,480 nodes total. Every positive-growth heading-resetting word
contains `R`, and cyclic phase shift preserves the represented periodic orbit and
finite-support realisability. All shards completed below their 100,000,000-node cap
and found zero highways.

Periods 34--48 are certified by the residue-theorem-free shared-framework Java
variant, applying the exact criterion at every positive-growth nonzero-drift leaf.
The strand- and residue-pruned variants are conditional consistency checks, not
independent implementations. The certifying Java source SHA-256 is
`dacd32f6ab2f0c033c4e8226987333f21582e5aecad25322863439065645d68f`.

The frozen archive `records/langton_search_records.tar.gz` contains exactly 460
members and has SHA-256
`7052f3070829bf804ae317a40379f6bb045b00775aff826b4e347880747bcc1a`.
Its constructor verified the exact member set and every inner hash. A fresh extraction
passed both:

    python audit_p32.py
    python aggregate_indep.py

The latter reported `all_checks_passed = True` for every even period 34--48, with
exact rank coverage and zero hits.

The post-normalisation cold extraction was run at 20:32 CDT on 20 July 2026 into a
new directory, without reusing repository-side generated files. `audit_p32.py`
reported schema `langton-p32-exclusion-v2`, all 32 prefixes exactly once,
46,185,480 cyclic-phase-normalised nodes, and zero problems. `aggregate_indep.py`
reported `[OK]` for each even period 34--48 and `all_checks_passed = True`. The
embedded `RECORDS_MANIFEST.json` contains zero CRLF byte pairs.

### Lean boundary

Lean 4.32.0 cleanly built all 18 jobs in the provided Docker environment. The axiom
audit lists only `propext`, `Quot.sound`, and where used `Classical.choice`; the source
contains no `sorry`, `admit`, custom axiom, `native_decide`, or unsafe escape.
`StabilizedP3Word.toOrbitEndpointData` derives the first positive endpoint, balanced
remainder, and binary widget-prefix facts from an explicitly supplied stabilized P3
word. Lean still does not extract that word or the physical lifted potential geometry
from every periodic ant orbit, so P22 and the conjecture are not end-to-end Lean
theorems.

### Release metadata and remaining human actions

`CITATION.cff` validates against CFF schema 1.2.0. `.zenodo.json` records the mixed
license: code/Lean/data are MIT; papers/prose are CC BY 4.0. The deterministic script
`results/update_artifact_hashes.py` regenerates `results/artifact_hashes.json` from all
tracked and non-ignored untracked release files, excluding the self-referential
manifest itself. The manifest was regenerated only after the final PDFs, journal,
handoff, archive, and mirrored outputs were fixed.

Before emailing or depositing:

1. fill the commented author address and professional-email fields in
   `paper/main.tex`;
2. personalize one targeted theorem/interface request per professor;
3. mint or identify an exact Zenodo version DOI (the concept DOI does not pin these
   bytes); and
4. after any such edit, rebuild the PDFs, resync `docs/`, and rerun
   `python results/update_artifact_hashes.py`.

## 21 July 2026 continuation: transverse rigidity (supersedes the section above on open obligations)

### What changed

Two new theorems were proved, audited, corrected, and added to both papers. They
address obligation 2 (periodic classification), and they are the first results in this
project that hold at **every period** rather than up to a search bound.

- **Extremal-line rigidity.** For diagonal drift $|a|=|b|=m$, normalise by quarter-turn
  rotation so that $ab<0$ and take $t=x+y$. Then both extremal level lines $t=T$ and
  $t=T'$ are horizontal, the arrival is east on $t=T$ and west on $t=T'$, every turn on
  them is `R`, every cell of them the trace reaches is entered exactly once (so every
  class meeting an extremal line is a singleton and its cells end black), and $W=T-T'$
  is even.
- **Width-two exclusion.** No finite-support periodic highway with diagonal drift has
  transverse width $2$; hence $W$ is even and $W\ge4$. The standard highway has $W=10$.

Both use only the HV partition and the *ordering* content of the periodic criterion —
that the stabilised word at a cell alternates and begins with `R`. Neither uses the
residue theorem or any of its corollaries. Full statements, proofs and the audit
record are in journal Section 37.

### Two defects found by adversarial audit, both repaired

Recorded in full in journal 37.6. Summarised because both are traps that will recur:

1. Defining the transverse functional by a case split ($x+y$ when $ab<0$, $x-y$ when
   $ab>0$) and then arguing in one frame gives a **false** conclusion in the other: the
   two frames differ by a quarter turn, which exchanges the axes, so "both extremal
   lines are horizontal" fails for half of all drifts. The counterexample is the
   standard highway itself read from an east-facing start. Repaired by normalising to
   $ab<0$ and writing the proof with explicit compass directions.
2. The width-two proof asserted that a site's first visit turns `R`. That is false:
   criterion (ii) constrains only *stabilised* words, and the seed construction
   blackens cells below their class's maximal level precisely so that some first turns
   are `L`. Repaired by counting **edge crossings** instead of site visits: each gap is
   crossed at most once in each direction (each crossing consumes an extremal cell), and
   drift forces net $+1$ per gap, so every site above the start is entered exactly once,
   arrives heading south, departs east, and therefore turns `L` — contradicting (ii).

`verify_width.py` had hard-coded the same false assumption as defect 2, so it could not
have caught it. It has been rewritten to check the geometric inputs and to run an
adversarial search in which an opponent chooses the colour of every not-yet-visited
site; no opponent survives more than $k+4$ steps on $k$ black seeds.

### Current document state

- `paper/main.tex` → `paper/main.pdf`, **22 pages**, compiles with zero errors, zero
  Type-3 fonts. New Section 9 "Transverse rigidity and a period-unbounded exclusion";
  small-period exclusion is now Section 10 and the gap section Section 11.
- `companion/main.tex` → `companion/main.pdf`, **16 pages**, zero errors.
- `docs/paper.pdf` and `docs/companion.pdf` are byte-identical to their sources.
- New verification scripts, all in `code/python/`: `verify_extremal.py`,
  `verify_width.py`, `explore_chronology.py`, `explore_skeleton.py`.
- `results/artifact_hashes.json` regenerated over 70 files.

### Immediate next steps

1. **Fill the author address and professional email** in `paper/main.tex`, rebuild,
   resync `docs/`, rerun `results/update_artifact_hashes.py`.
2. **Commit and tag** (the working tree is not committed). Mint a version DOI.
3. **Send outreach** from `docs/professor_outreach_email.md` — nine verified
   recipients with individually personalised letters, ordered; send one at a time.
   arXiv now requires a personal endorsement for independent researchers; Propp
   (math.CO) and Troubetzkoy (math.DS) are the best-positioned endorsers.

### The obvious research continuation

Width $4$. Lines $0,2,4$ are horizontal and $1,3$ vertical; the extremal lines $0$ and
$4$ remain single-visit, but the interior horizontal line $2$ may be revisited, so the
one-dimensional collapse used for width two does not apply. For each fixed $W$ the
question is finite-state — a highway of width $W$ is an orbit of a machine whose tape
cells are the strip's columns, with alphabet $2^{\lceil (W+1)/2\rceil}$ — so widths
$4,6,8$ are a well-posed decidable target. Settling them would prove the standard
highway is the narrowest possible, which is the transverse counterpart of the
arithmetic constraints already proved.

## 21 July 2026 width-four checkpoint

This section supersedes the immediately preceding claim that fixed width is
automatically finite-state. A finite alphabet on an unbounded longitudinal tape can
retain unbounded memory. What is now proved finite at width four is the search at each
*fixed diagonal drift*, via the period bound below. Decidability for an arbitrary
fixed width still requires a bounded-memory theorem.

Detailed derivations and failed attempts are in
`research-notes/width4_research_2026-07-21.md`. The new paper-grade statements are:

1. **Diagonal width--growth sandwich.** For normalised drift `(m,-m)`, growth `g`,
   and even transverse width `W`, `2m <= g <= mW`.
2. **Six-mask theorem at width four.** In each `x` residue, and independently in
   each `y` residue, the set of odd transverse levels is exactly one of
   `{0,2}`, `{1,3}`, `{0,4}`, `{2,4}`, `{0,1,2,4}`, `{0,2,3,4}`. If `h` residues
   have four-element masks, then `g=2m+2h` and `h=m (mod 2)`.
3. **Width-four period--drift bound.** For macro period `P` and ant period `N=2P`,
   `P+8x<=7m`, hence `P<=7m`, `N<=14m`, and `P=m (mod 2)`, where `x` counts the
   `LN->LN` bottom-boundary macro transition. This uses P3 and extremal singleton
   rigidity, but not the residue theorem. With strand density it gives `N<=7g`.
4. **Primitive width-four exclusion.** No width-four highway has
   `(|a|,|b|)=(1,1)` at any period. The proof forces `P=7` and lists six possible
   words, each with an explicit stabilised-class ordering failure. It is independent
   of the residue theorem.

The fixed-drift Java search combines item 3 with early extremal-residue uniqueness.
It has now excluded every width-four highway for `1<=m<=9`.  The final theorem-bound
row `(m,P)=(9,63)` visited `17,532,472,230` nodes, reached no structural leaf, and
therefore had no P3 hit. The unrestricted width-four
search has zero hits through ant period 76. Result summary:
`results/width4_drift_exclusion_summary.json`.

Lean 4.32.0 now builds 22 jobs and audits the arithmetic kernels in
`lean/Langton/WidthFour.lean`: the six-mask enumeration, even-fiber upper-bound step,
`P+8x<=7m`, period parity, `N<=7g`, and primitive `P=7`. There are no `sorry` or
`admit` declarations. The macro geometry remains a paper input, not an end-to-end
formalisation.

Two negative lessons must remain in the journal:

- `starts R` alone fails: period-50 structural countermodels satisfy it but violate
  alternation;
- an attempted boundary-transition reduction was false because the two-symbol macro
  label was read in the wrong order; it was deleted before use.

`code/python/width4_smt.py` supplies an independent symbolic P3 ordering model. It
returns exact UNSAT on several small instances but times out on harder ones; timeouts
are not exclusions. An incremental class-arithmetic Java prune reduced nodes by only
0.054% and slowed the `m=9,P=57` benchmark from 329.221 to 410.472 seconds, so it was
removed.

Later in the same research window, P3 was rewritten in **spatial block form**. For a
fixed line and residue, the stabilised word is the concatenation of each physical
cell's ordinary visit word from largest longitudinal coordinate to smallest. Hence
the nonzero physical-cell charges `#R-#L` alternate `+1,-1,+1,...` from front to
back, and every forward prefix charge is `0` or `1`. This is exact all-period
ordering information, not another aggregate incidence identity.

A connected integer-flow relaxation satisfying all those prefix inequalities is
still SAT for `m=2,3`; its Euler order fails ordinary same-cell chronology. Therefore
the outstanding obstruction is specifically an order-compatible Euler-trail
problem. A separate exact density lemma gives a more promising finite-reduction
route: among the `m` longitudinal cuts, at least `m/4` are crossed at most seven
times, because their positive odd crossing counts sum to at most `P<=7m`. Repeated
finite crossing signatures may support a pumping theorem, but the splice must still
be proved to preserve tape colours and the P3 seed/wake relation.

The `m=10` continuation has completed every even row through `P=66` with zero P3
hits. At `P=56=5m+6` there are exactly ten ordinary-alternating/extremal leaves, none
passing the odd-class identity; `P=58` and `P=60` have no structural leaf. The
`P=60` row visited `19,138,313,024` nodes; `P=62` visited `30,238,836,043`; and
`P=64` visited `47,442,673,612`; and `P=66` visited `74,038,045,927`. All four had
no structural leaf. The `P=68` and `P=70` workers were stopped unfinished at
18:56:13 CDT and produced no completed rows. The proved fixed-drift range therefore
remains `m<=9`. The completed partial rows are preserved
in `results/width4_m10_partial_2026-07-21.json`.

### Candidate width-four pumping reduction (research only)

The corrected cut signature for residue `r` contains every macro transition that
crosses a lifted cut `r+qm+1/2`, sorted by the stabilised crossing time `i-Pq`.
The signatures partition the `P` macro steps. Their lengths are positive odd
integers summing to `P<=7m`, so at least `m/4` residues have length at most seven.

The current candidate splice lemma says that equal signatures at two residues let
one delete the intervening slab in every future translate and produce a smaller-
drift width-four highway. Its most precise formulation encodes the strip ant as a
deterministic one-tape machine: a tape symbol is a five-bit longitudinal column and
finite control stores transverse line and heading. The splice-sufficient control
signature keeps direction and destination even line, so the classical
crossing-sequence induction preserves all reads and writes on retained columns.
Start the infinitely many disjoint deletions beyond the finite seed and define them
by a finite-time direct limit; every finite prefix uses only finitely many ordinary
splices and the compressed initial tape still has finite support.

For a rightward crossing the destination is `2` or `4`; for a leftward crossing it
is `0` or `2`. Thus after direction is fixed there are only two choices per event,
and at most `2+2^3+2^5+2^7=170` short control signatures. This supersedes both the
three-line overcount `2460` and the earlier decorated count `287934`.

The full average-length budget improves the cutoff further. The short signatures
can supply at most `6*2+4*8+2*32=108` units below average length seven; every
remaining signature has length at least nine and costs at least two units. Hence
there are at most 54 long signatures and at most `2+8+32+128+54=224` residues total.

Extremal singleton rigidity is stronger still. In a length-`2n+1` control
signature, `(+ ,4)` and `(- ,0)` can each occur at most once, so the capacity is at
most `(n+2)(n+1)`. The length-`1,3,5,7` capacities are `2,6,12,20`; their deficit is
60, allowing at most 30 longer signatures. The resulting strongest conditional
cutoff is `m<=70`.

If an independent audit accepts the remaining equivariance step, a minimal drift
has pairwise-distinct control signatures and therefore satisfies the explicit cutoff
`m<=70`; together with `P<=7m`, width-four existence would be decidable by a
finite search. This does **not** exclude width four and is not yet a manuscript
theorem. The remaining hostile point is to prove that old tail translation by
`(2P,m)` advances the oriented spliced event path by a fixed positive finite number
of events after compression, rather than merely preserving its unoriented image.
The full audit checklist is
`research-notes/width4_crossing_splice_proof_draft.md`.

The current proposed discharge uses the crossing-sequence graph. The all-white
far-tail columns form a closed compatible walk of length `m`; equal control
signatures are equal vertices, so deleting the intervening subwalk gives length
`m'`. Translation by one new cycle maps ordered local transcripts and `j`-th
boundary occurrences to their translates, hence is a successor-preserving map of
the one-way tail event path and must be `n -> n+k`. Since it shifts space by
`m'>0`, `k>0`. The remaining independent-audit question is whether the finite-splice
direct limit rules out truncation of a crossing sequence only at infinity.

The current proof rules it out by chronology monotonicity: paired right crossings
occur left-cut then right-cut, while paired left crossings occur right-cut then
left-cut, so every splice jumps forward and only deletes events. Successive finite
splices form subsequences; each retained occurrence has a nonincreasing natural
event index and stabilises. The one-cut lemma supplies it at every finite stage, and
no extra finite-index event can first appear in the limit. Independent review must
still attack this argument before paper promotion.

### Stronger candidate: direct width-four exclusion

`code/python/width4_crossing_graph.py` simulates one initially white five-cell
column from its exact left/right control crossing sequences. Extremal rigidity lets
each boundary use the exceptional rightward top landing and exceptional leftward
bottom landing at most once. An unbounded recursion over column masks, entry state,
and four flags finds exactly 12 compatible edges on 10 vertices, zero reachable
entry cycles, and a directed graph of longest path three. An independent pairwise
check of all 910 constrained signatures through length 25 gives the same 12 edges.

The edge certificate is:

```
202 -> 4
4220222 -> 2, 202, 20222, 2022224
2042222 -> 2, 202, 20222, 2022224
202242222 -> 422, 42202, 4220222
```

Infinitely many initially white columns ahead of any finite seed would require an
infinite path in this acyclic graph. Hence no diagonal width-four highway exists at
any period. Journal \S38.16 records the corrected label hypothesis.
The result has the explicit status ``computer-assisted; local
classifier completeness not formalised in Lean.'' Source SHA-256:
`2AF99EDCBC355945B547AB1F80CAEE6927FA75D6C1C064C5ADC41D13B5FE3E33`.
The unbounded generator reaches 22 entry states, has maximum entry depth eight, and
finds no reachable entry cycle.

`lean/Langton/WidthFourCrossing.lean` checks that the listed graph has the claimed
rank decrease and no four-edge chain. SHA-256:
`548DF94E2B8B60CE23269153EE446CFF824AC1DB6AA1A41773F4E605205324FF`.
It does not yet formalise the Python enumeration's completeness.

Independent implementation check:
`code/python/verify_width4_crossing_graph_indep.py` imports no project search code,
uses compass-letter headings and set-valued black rows, and reproduces the same 12
edges. SHA-256:
`694C1178B00FA8AB929A5375255E53762C403DE02FC1D2958A4409EF9B84AFE0`.
It also extracts crossings at cuts 100 and 101 of the documented standard-highway
finite seed and exactly replays the initially white column between them (boundary
lengths 31 and 21), validating the convention on a genuine highway.

Why this does not immediately exclude widths six/eight:
`code/python/explore_even_width_crossing_cycles.py` finds a reachable two-state
interior cycle `({1,2},2,E) <-> ({1,3},2,W)` at both widths, while finding none at
width four. It does not reuse an extreme event. This is a local-memory obstruction,
not a highway. SHA-256:
`760CD63D8CCC0292AD5FF2A3134CAE7A4E2CDD1AA16758527BFF5F706806F327`.

Machine-readable table, statistics, hashes, and formalisation boundary:
`results/width4_crossing_graph_certificate.json`.

Final pre-manuscript self-audit of the bridge: with `t=x+y` and longitudinal
coordinate `x`, vertical moves remain in a five-cell tape column and horizontal
moves cross its boundaries.  The even destination line plus alternating event
parity is therefore complete boundary control.  Positive periodic drift makes each
far-boundary sequence finite, nonempty, odd, and right/left alternating.  The four
exception flags are exactly the two extremal-cell singleton constraints on each of
the two sides.  Because the preperiod and initial black support touch only finitely
many cells, all sufficiently far columns are untouched white symbols; their exact
boundary sequences would form an infinite directed path through the 12-edge graph.
This pins the only computer-assisted premise to completeness of the independently
reproduced local edge table.  The global reduction and acyclicity contradiction are
not heuristic.

The width-six/two-state failure was hand-decoded as a centre-line rotor oscillator:
mask `{1,2}` with an eastward entry on line 2 changes to `{1,3}` and exits east;
the westward return on line 2 restores `{1,2}` and exits west.  The two reused cells
turn `L,R,L,R,...` in alternating phases and no extreme repeats.  Thus ordinary
same-cell alternation does not kill the recurrence.  A width-six attack must couple
neighbouring columns or use stabilised class-start order; this local cycle is not a
global highway.

Research froze at 19:00:02 CDT on 21 July 2026.  Immediately before the cutoff the
two width-four classifiers and their standard-highway convention test passed again,
and the Docker-pinned Lean 4.32.0 project built 22/22 targets.  All subsequent edits
belong to the manuscript/review/release phase rather than new mathematical research.

## 21 July 2026 release-packaging note (authoritative on final document state)

Supersedes the page counts in every earlier checkpoint, which were accurate when
written but predate the width-four additions. As frozen for release:

- `paper/main.tex` -> `paper/main.pdf`: **24 pages**, compiles with zero errors and
  zero Type-3 fonts; text layer intact (ligatures extract correctly). Section 9 is
  "Transverse rigidity and period-unbounded exclusions" (plural: it now carries the
  width-two theorem, the blank-column classification lemma, and the width-four
  theorem, W>=6). Small-period exclusion is Section 10, the gap Section 11.
- `companion/main.tex` -> `companion/main.pdf`: **18 pages**, zero errors.
- `docs/paper.pdf` and `docs/companion.pdf` are byte-identical to their sources.
- Corresponding author email on the paper: Atharvajil124@gmail.com; affiliation line
  reads "Independent researcher" (the ASSIP/GMU summer account is deliberately not
  claimed as an institutional affiliation).
- `lean/` is clean of sorry/admit/native_decide/custom axioms across all modules,
  including the two new width-four files.

Not yet done, and explicitly the user's to authorise: (1) commit and push the
width-four working tree -- the live GitHub Pages PDF and the concept DOI still resolve
to the pre-width-four release, so any outreach link is stale until this is pushed;
(2) mint a Zenodo version DOI for the new bytes; (3) send the prepared outreach drafts.

## 22 July 2026 consolidation note (single paper; companion folded in and removed)

The project previously shipped two overlapping documents: `paper/main.tex` and a
`companion/main.tex` technical report. They had drifted to cover essentially the same
results and did not cross-reference each other, so publishing both would read as
redundant self-overlap. Consolidated to a single paper of record:

- The companion's one genuinely unique result -- the width-four six-mask structure and
  the period bound P <= 7m (companion `prop:width4arithmetic`) -- was folded into the
  main paper as a new appendix, "Width-four structure and an independent partial
  exclusion" (`app:width4arith`), with `prop:width4arithmetic` and a corollary framing
  it as a logically independent route: P <= 7m bounds each fixed drift to a finite
  search, excluding width four for m <= 9 WITHOUT the blank-column table
  (Lemma 9.4), corroborating Theorem 9.5 on that range. This is non-vacuous because it
  does not assume the crossing-graph completeness premise.
- Everything else in the companion (criterion, invariant, Tait conjugacy, even-winding,
  residue, collision parity, extremal rigidity, width-two, width-four crossing graph,
  period-<=48 exclusion, gateway seed, Lean) was already present in the main paper, so
  nothing else was lost.
- Removed: `companion/main.tex`, `docs/companion.pdf`, `docs/companion.html`. Updated
  `README.md`, `docs/index.html`, `.zenodo.json`, `LICENSE`, `LICENSE-PAPER.md` to stop
  referencing a companion. `CITATION.cff` already cited only the one paper.

Final state: single paper `paper/main.tex` -> `paper/main.pdf`, **25 pages**, zero
errors, zero Type-3 fonts, ligatures intact; `docs/paper.pdf` byte-identical to source.
Manifest regenerated after removal. The mathematics is unchanged; this is a packaging
consolidation, not a new result. Supersedes the "18-page companion" line in the
21 July release-packaging note above.

## 17 August 2026 continuation: width-six exclusion and W>=8

This is the authoritative handoff for the new result.  The repository now contains
a **computer-assisted all-period exclusion of diagonal transverse width six**.  In
combination with even transverse width and the earlier width-two and width-four
exclusions, it proves that every diagonal finite-support periodic highway has
`W>=8`.

The exact local lemma uses a `6 x 7` initially white block.  It retains all 42
in-block colours, once-visit bits for the 12 in-block extremal cells, and the inward
boundary pose.  It forgets all exterior history and permits every geometrically
possible same-boundary return after an exit.  Despite this relaxation, the complete
graph has 357 reachable boundary states, 555 return transitions, 172
repeated-extremal rejections, zero local loops, and zero right-exit terminals.  Its
left exit counts at labels 0,2,4 are 38,78,69.  Five columns have 46 right terminals,
which is the main positive control.

Primary files:

- `code/python/width6_block_exclusion.py --relaxed`
- `code/python/verify_width6_block_indep.py --relaxed`
- `code/python/audit_width6_block.py`
- `results/width6_block_certificate.json`
- `research-notes/width6_research_2026-08-17.md`

Source SHA-256 values are respectively
`3f1c92c831e45bcc0e60a282e4652bf72a07da22a1dc7ef711de2172a78c24af`,
`7121555c44eb96eda955002136b8cda35ea8f9d2f979da3416f7e62fb422c65f`,
and `68aba194450ba05872fe37bbd20c260916c5718dc805e15b09be76d11a4c1908`.
`audit_width6_block.py` checks those hashes and every certified count.

Global bridge: normalize drift to `(m,-m)`, use `t=x+y in {0,...,6}`, and let `N`
be the ant period.  The formula `x(qN+i)=qm+x(i)` gives longitudinal escape.  Six
columns beyond both finite initial support and finite past footprint are untouched
and white.  First entry is eastward from the left; some later right exit is forced.
Any exterior excursion must return through the same outer side before another
in-block segment, and extremal rigidity makes the 12 extreme cells single-use.
The actual transcript is therefore admitted by the relaxed classifier, contradicting
its zero right exits.

Claim boundary: the global reduction is a conventional proof; the local finite
reachability premise is reproduced by two separately written exact enumerators but
is not formalized in Lean.  The universal highway conjecture is still open.  So are
width eight, `g>=12`, non-diagonal translators, universal entrance, and uniqueness
of the standard period-104 highway.  The one-column rotor at widths six and eight is
a proof-strategy countermodel, not a highway.

## 17 August 2026: width-eight exclusion and W>=10

This section supersedes the preceding handoff only where it lists width eight as
open.  The same flag-free block relaxation has now produced and passed review as a
**computer-assisted all-period exclusion of diagonal transverse width eight**.
Consequently every diagonal finite-support periodic highway has `W>=10`, a sharp
lower bound attained by the standard highway.

The eight-column by nine-line state stores 72 colours, once-entry status for 16
in-block extremal cells, and the inward pose.  It forgets all exterior history and
permits arbitrary same-boundary returns.  Certified row:

```text
states=20320 transitions=42004 terminals=0 rejected=9819 loops=0 max_visits=90
left exits: 0->1586, 2->3090, 4->3114, 6->2711
```

Positive controls: seven columns have 1,188 right-exit events; six columns have
18,250.  Primary files are:

- `code/python/width8_block_exclusion.py`
- `code/python/verify_width8_block_indep.py`
- `code/python/audit_width8_block.py`
- `results/width8_block_certificate.json`
- `research-notes/width8_research_2026-08-17.md`

Their source hashes are, respectively,
`fe879d015e716a4b3e4aa951d20069d8c6b323d272563b776115ebf993c603f9`,
`29cf021cb92027d4ec090238ca0ece2cbb6ad32f02f298cf9943c6196d2ea70e`,
and `fc59b26d515533c5d559cf31cd2d008a6931675c2b99a8510ec4587c6f56f693`.
The audit reads the certificate and checks all certified rows, headline counts,
positive controls, and embedded hashes.

Global bridge: with `t=x+y in {0,...,8}` and drift `(m,-m)`,
`x(qN+i)=qm+x(i)` forces longitudinal escape.  Choose eight untouched white columns
beyond both finite support and finite past footprint.  First entry is from the left,
some later right exit is forced, every exterior return is same-side by strip
separation, and extremal rigidity makes the 16 boundary-line cells single-use.
This embeds the actual transcript in the relaxed graph and contradicts its zero
right exits.

Claim boundary: the reduction is proved in the manuscript; the finite premise is
reproduced by two exact enumerators, but not formalized in Lean.  Still open: `g>=12`, classification/uniqueness
at width ten, non-diagonal translators, universal entrance, and the universal
highway conjecture.

Final local QA for this continuation: both width-six and width-eight certificate
audits pass from fresh Python processes; all new scripts compile; the paper builds
twice to a warning-free 28-page PDF; the new theorem and reproducibility pages were
rendered and visually inspected; and `docs/paper.pdf` is byte-identical to
`paper/main.pdf` with SHA-256
`ad6ee192c3c060c57c010d4b528a12f2671b9cc45e235b8a557beebb51c05bc2`.

## 17 August 2026 analytic advance: axis growth four excluded

The universal target `g>=12` is **not** proved.  A new all-period analytic theorem
does, however, exclude the complete axis part of `g=4`: no finite-support periodic
highway with growth four has drift `(+-2,0)` or `(0,+-2)`.

After normalizing to `d=(2,0)` and writing `N=2M`, rank every event inside its
translation class `(x mod 2,y)` in the stabilized P3 order (decreasing `x`, then
phase), and let `K` be the sum modulo two of the ranks of the `L` events.  A
port-permutation sign factorization proves, for every one-tour heading-reset word
with endpoint `(2,0)`, independently of growth,

```text
K = 1 + N/4 (mod 2).
```

The signed-residue theorem gives two occupied axis wake rows and exactly two
even-checker odd classes.  The elementary macro identity

```text
M+a+b+A = sum_j (1+u_j)(1+v_j) = 0 (mod 4)
```

therefore gives `N=0 (mod 8)`.  P3 makes every `L` rank odd, so for `g=4` it gives
`K=#L=0`, whereas the sign identity gives `K=1`.  Contradiction.

The full derivation is in `research-notes/growth12_research_2026-08-17.md` and the
new continuation section of `research-notes/proof_journal.md`.
`code/python/axis_rank_parity_audit.py` checks the factorization on every endpoint
word through period 16; it is labeled bounded evidence and is not a proof oracle.


Current `g>=12` frontier at that checkpoint: axis `g=4` was closed analytically.

## 17 August 2026 analytic advance: even-diagonal growth four excluded

The universal target `g>=12` is still **not** proved.  A second all-period analytic
theorem now excludes the even-diagonal part of `g=4`.  At growth four, the density
bound reduces this family to `d=(2,-2)` up to quarter-turn rotation.

Use quotient classes `(t=x+y,r=x mod2)`, translation level
`ell=(x-r)/2`, and stable key `tau=i-N*ell`.  For each class, let `p` be the parity
of the positive input plus positive output counts and `D=#R-#L in {0,1}`.  The
binary rank-inversion identity gives local corrections

```text
Q (vertical arrival):   p(D+1),
C (horizontal arrival): D(p+1).
```

Port sorting factors the one-cycle phase successor, yielding
`K=1+E+L mod2`, where `K` is the sum of stable ranks of left turns, `E` is the
two-lane edge-block sign, and `L` is the local correction.

When all odd classes occupy one checker type, finite-support flow decomposes the
odd edge-block parities into four-edge gadgets.  Each gadget has odd self-sign; two
gadgets have odd cross sign exactly when they are adjacent in the same lane.  Hence

```text
E+L = sum_r binom(o_r,2) mod2,
```

where `o_r` counts odd classes in lane `r`.  The signed-residue theorem gives a
doubled perfect-matching matrix, so `o_0=o_1=2`, the right side is zero, and the
single-tour sign gives `K=1`.  P3 makes every left turn have odd rank, while
`#L=(N-4)/2` is even because the horizontal displacement is two.  Thus P3 gives
`K=0`, contradiction.

Full proof: `paper/main.tex`, Theorem `thm:evendiagg4`, and Section 42 of
`research-notes/proof_journal.md`.  The detailed derivation is also in
`research-notes/growth12_research_2026-08-17.md`.
`code/python/even_diagonal_rank_parity_audit.py` checks the local truth tables,
gadget permutations, cross table, and bounded finite chains; it is labelled
bounded evidence and is not a proof oracle.

Current frontier: axis and even-diagonal `g=4` are closed analytically.  Primitive
diagonal `g=4` and every `g=8` geometry remain open.  Do not report `g>=12` as
obtained, and do not claim the universal highway conjecture is solved.

---

# Handoff addendum — line-parity theorems (18 August 2026)

## What is new since the even-diagonal growth-four theorem

Four turn-parity identities for diagonal drift. T1/T2 and their finite-support
mod-four consequences are now promoted in the paper; T3/T4 remain in the research
record because they add no current classification consequence.
Full statement, proof and audit trail: `line_parity_research_2026-08-18.md`;
journal section 43 in `proof_journal.md`.

Frame is the paper's Section 9 frame verbatim: drift quarter-turn rotated so
`ab<0`, `t=x+y`, level index shifted so horizontal-arrival levels are odd.

```text
T1  unconditional form (needs no finite-support hypothesis):
      horizontal-arrival level -> #L in one period is EVEN
      vertical-arrival   level -> #R in one period is EVEN
    mod-four form (needs finite support, i.e. criterion condition (ii)):
      m_t = omega_t (mod 4) at horizontal levels, = -omega_t (mod 4) at vertical
T2  u-line at horizontal levels -> #R over all time is ODD
    u-line at vertical   levels -> #L over all time is ODD
T3/T4  column/row versions via the x- and y-walks (proved and audited; not promoted)
```

`omega_t` = number of odd-multiplicity translation classes at level `t`;
`sum_t omega_t = g`.

## Status of each claim, for whoever writes this up

| claim | status |
|---|---|
| T1 turn-counting form | proved, unconditional; 8,532-word exhaustive check, 0 violations |
| T1 mod-four form | proved under finite support; 8,096 of the same 8,532 words violate it, so the hypothesis is necessary and must be stated |
| T2 | proved unconditionally; verified on 26 highways here and independently re-derived by the auditor |
| T3, T4 | proved and audited, including the `m=2` standard highway; their relation to T1/T2 at `m=1` remains unproved |
| second-line rigidity (note section 7.1) | proved and independently audited for primitive diagonal; not yet promoted because it does not close the case |
| `g = 0 (mod 4)` re-derivation | correct but *weaker in hypothesis* than the paper's even-winding proof; present as an alternative route, not a strengthening |
| 3-1 wake split at primitive-diagonal `g=4` | proved from T1 + `N/2` odd + extremal rigidity (i),(iii); the residue theorem is **not** needed |
| `N = 6 (mod 8)` at primitive-diagonal `g=4` | proved, but depends on extremal rigidity clause (i) |
| "obstruction is local to the bottom rail" | **RETRACTED** — artefact of a first-failure-only diagnostic |

## Where the paper should change

1. Section 9 now contains T1/T2 after extremal-line rigidity, with the additional
   half-turn normalisation `d=(m,-m)` made explicit.
2. The primitive-diagonal 3--1 wake split no longer depends on the signed residue
   theorem; the axis/even-diagonal growth-four exclusions still do.
3. The public result table now records the analytic line-parity theorem. T3/T4 and
   second-line rigidity remain research-note results rather than manuscript claims.

## Reproduction

```text
code/python/line_parity_theorems_audit.py     # T1-T4 on 26 genuine highways
code/python/line_parity_sublemma_audit.py 14  # exhaustive reflect/continue + flow
code/python/primitive_g4_level_dp.py 20       # the counting-level system
```

Scratch (not in the repo) also holds `primitive_g4_dfs.py` / `fast.py`, the complete
chronological search over level profile + arrival strings + single-tour + stabilised
rank. It reproduces the width-four and width-six exclusions as positive controls.

## The open problem, stated precisely

Only **primitive-diagonal growth four** stands between the current results and
`g >= 8`; `g >= 12` additionally needs every growth-eight geometry, which is
untouched.

For primitive diagonal `d=(1,-1)`, growth four, the surviving constraint system is:

```text
levels T'..T, W = T-T' even and >= 10 (width theorems), both extremal levels odd
m_{T'} = m_T = 1, so f_{T'} = f_{T-1} = 1
m_t = f_{t-1} + f_t,  f_t >= 1
t odd  -> m_t = 0 or 1 (mod 4);  t even -> m_t = 0 or 3 (mod 4)
exactly four odd-multiplicity levels, three at odd t and one at even t
|f_{t-1} - f_t| <= rho_t, where rho_t = ceil(m_t/2) (t odd), floor(m_t/2) (t even)
sum over even cuts of f - sum over odd cuts of f = 1
N = 2 sum_t f_t = 6 (mod 8),  and N >= 54 by the period-48 exclusion
```

The arithmetic subsystem obtained by dropping the already-proved width barrier is
**feasible for every even `W >= 4`**; among actual survivors only `W >= 10` remains.
The thin profile
`f = (1,3,2,...,2,1)`, `N = 4W-2`, satisfies all of it. So no purely counting
argument can close the case. The chronological layer (arrival strings, single tour,
stabilised rank) does kill the thin profile at `W = 6,8,10`, but the search is finite
only per width, because `|f_{t-1}-f_t| <= rho_t` permits roughly a factor of three
per level and gives only `f_t <= 3^min(t-T', T-t)`.

**Two concrete sub-targets, either of which finishes the case:**

1. An a priori bound `f_t <= c` (or `m_t <= c`) for primitive-diagonal growth four.
   That alone makes each width a finite computation and, with the growth of `W`
   bounded by `N >= 4W-6`, may close everything.
2. A bound `W <= h(g)`. The Tait-connectivity route to `g >= W/2 + 2` is already
   ruled out (see `growth12_research_2026-08-17.md`), so this needs a new mechanism.

## A transverse transfer matrix -- PROPOSED, THEN DISPROVED

**Read this heading before the section below it.** The route described here was
tested and is dead: the offsets it depends on grow linearly with `W`. The section is
kept because the reasoning is worth not repeating, and the disproof is in
`line_parity_research_2026-08-18.md`, section 12. Do not spend time on it.

## The route as originally proposed

Per-width searches cannot finish an all-width problem, and the counting layer is
provably exhausted (the thin profile satisfies every counting constraint at every
even `W`). What is left is to make the *chronological* layer uniform in `W`. The
transverse direction is the natural one to sweep, because all the data is local to a
cut except two conditions:

* **single tour.** Sweeping levels upward, the state at the cut `(t,t+1)` is the
  linking pattern of the `2 f_t` strand ends crossing it — which partial path
  fragment connects to which. For bounded `f_t` this is a finite set (a matching on
  `2 f_t` points, so Catalan-many at worst), and "is a single cycle" becomes an
  ordinary reachability question in a finite automaton over the level index. This
  half is already a transfer matrix.
* **stabilised rank.** This is the hard half. The turn at a phase is `turnR` exactly
  when its rank is even, and rank is the order by decreasing `x`. `x` changes only on
  departures from vertical levels, by the same sign as the level change, so the
  relative `x`-offsets of the strands crossing a cut are the extra state that would
  have to be carried. Whether those offsets stay bounded is the open modelling
  question; if they do, the whole primitive-diagonal growth-four case becomes a
  finite automaton emptiness check, uniform in `W`, and the case closes.

Concrete first experiment: instrument the existing search to record, for every
surviving partial system, the multiset of relative `x`-offsets of the strands at each
cut, and check empirically whether it stays inside a bounded window. If it does,
build the automaton; if it does not, the offsets themselves are the obstruction to
formalise.

Second experiment, and a **negative result already obtained**: an a priori bound
`f_t <= 3` was conjectured and is false as a consequence of the tour condition. Per
profile at `W=6`:

```text
f=(1,2,3,5,3,1)  max f=5  N=30   complete single tours  2,848   survivors 0
f=(1,3,1,2,3,1)  max f=3  N=22   complete single tours     32   survivors 0
f=(1,3,2,2,2,1)  max f=3  N=22   complete single tours     32   survivors 0
f=(1,3,5,6,3,1)  max f=6  N=38   complete single tours 65,240   survivors 0
f=(1,3,6,6,2,1)  max f=6  N=38   complete single tours 28,464   survivors 0
```

Fat profiles survive the single-tour condition in large numbers; they die only on
the stabilised-rank condition. So nothing in the tour structure alone bounds `f_t`,
and any bound must come from the rank layer. This also explains why the searches
time out: the fat profiles carry three orders of magnitude more work than the thin
one, for the same width.

Consequence for the transfer-matrix plan: the state cannot be taken to be the
linking pattern alone, because `f_t` is not bounded a priori. The relative
`x`-offsets are not a refinement of an already-finite state, they are the whole
difficulty. Establishing that those offsets live in a bounded window is therefore
the single load-bearing step.

### First data on the load-bearing step (18 August 2026)

The experiment above was run. For every **complete single tour** of every profile
with `f_t <= 3`, record at each cut the `x`-coordinates of the upward-crossing moves
and take the spread `max - min`:

```text
W= 6   64 tours    max spread per cut  0,2,1,1,2,0
W= 8  384 tours    max spread per cut  0,2,1,2,2,1,2,0
W=10 2048 tours    max spread per cut  0,2,1,2,2,3,3,1,2,0
```

So the spread is small — bounded by 3 out here — but it is **creeping up** with `W`
(2, 2, 3 at the maximum), and `W=12` did not finish inside the time budget. This is
encouraging but not decisive: `O(1)`, `O(log W)` and slow linear growth are all still
consistent with three data points. Getting `W=12,14,16` at `f<=3`, and then repeating
for `f<=5`, is the cheapest next measurement and it decides whether the transfer
matrix has finite state.

Instrumentation: `offsets.py` in the scratch tree; it installs a hook in `fast.py`
that fires on every complete single tour before the drift and rank checks.

### Why the offsets might, or might not, stay bounded

There is a structural reason the arrivals from below and from above at a level
cannot simply separate in `x`. At a level `t`, stabilised rank is the order by
decreasing `x`, and T1 fixes how many arrivals-from-below sit at even and at odd
ranks: `A_1 = floor(m_t/2)/2` at horizontal levels, `A_0 = ceil(m_t/2)/2` at
vertical ones. If every arrival-from-below had larger `x` than every
arrival-from-above, the `f_{t-1}` of them would occupy ranks `0..f_{t-1}-1`
contiguously, and the odd ranks among those number `floor(f_{t-1}/2)`. So contiguity
is possible only in the exceptional case `floor(m_t/2)/2 = floor(f_{t-1}/2)`; in
general the two families are **forced to interleave in `x`**.

That is good news and bad news. Good: it ties the `x`-range of the up-crossings at
cut `t-1` to the `x`-range of the down-crossings at cut `t`, so the spreads at
adjacent cuts are comparable rather than independent, and at the rail the spread is
`0` because `f = 1`. Bad: comparability only gives `spread(t+1) <= spread(t) + c`,
which propagates from the rail to a bound of order `c W`, not a constant. The
measured values `2, 2, 3` at `W = 6, 8, 10` are consistent with both a constant and
with growth of order `W/4`, which is exactly why the `W = 12, 14, 16` run is the
decisive one: constant spread means the transverse transfer matrix has finite state
and primitive-diagonal growth four closes; spread growing with `W` means it does not,
and the transfer-matrix route should be abandoned rather than pursued.

### Result: the spread is CONSTANT in W (thin profile)

Run on the thin profile alone, over every complete single tour:

```text
W= 6      32 tours   max spread 2   per cut  0,2,1,1,1,0
W= 8     128 tours   max spread 2   per cut  0,2,1,1,1,1,1,0
W=10     512 tours   max spread 2   per cut  0,2,1,1,1,1,1,1,1,0
W=12   2,048 tours   max spread 2   per cut  0,2,1,1,...,1,0
W=14   8,192 tours   max spread 2
W=16  32,768 tours   max spread 2
W=18 131,072 tours   max spread 2
```

Seven widths, seven orders of magnitude of tours, and the maximum spread never
exceeds 2 — and the per-cut profile is literally the same word `0,2,1,1,...,1,0`
with the interior padded. So for this family the spread does **not** grow with `W`;
the earlier `2,2,3` reading came from mixing several profiles at `f<=3`, where the
extra profiles contribute a 3.

This is the evidence the transfer-matrix route needed. Next step is to confirm it
for all profiles with `f<=3` at `W=12,14,16` (bounded spread there too), and then for
`f<=5`; if it holds, build the automaton whose state is (linking pattern, bounded
`x`-offset vector) and decide emptiness once for all `W`.

### Correction: the bounded-offset step is false

The preceding conclusion was tested on the convenient thin profile and is **not**
uniform over the profile family. On the maximally alternating admissible profiles,

```text
W= 8   f=(1,3,1,3,2,1,3,1)                    max spread 2
W=10   f=(1,3,1,3,1,2,3,1,3,1)                max spread 3
W=12   f=(1,3,1,3,1,3,2,1,3,1,3,1)            max spread 4
W=14   f=(1,3,1,3,1,3,1,2,3,1,3,1,3,1)        max spread 5
```

the spread is exactly `W/2-2`. It is unbounded, so the finite-state transverse
transfer matrix proposed above does not exist. The constant thin-profile data remain
correct but are not representative. **Do not pursue this route.** The full audit and
mechanism are in `line_parity_research_2026-08-18.md`, section 12.

---

# Handoff addendum — exact primitive chronology frontier (20 August 2026)

Read `primitive_g4_research_2026-08-20.md` before proposing another scalar rank
sum, cap deletion, or transverse transfer matrix. The current exact formulation is
the stabilised prefix charge `q(k)=#R-#L`; P3 is precisely `q(k) in {0,1}` in every
class, together with the finite partial-class conditions of the realisability
criterion.

An exact `N=54`, `W=10`, growth-four near-model satisfies the entire upper half
`q(k)<=1`, the endpoint, singleton rails, class excesses, and the 3-to-1 wake split,
but has nine defective within-period cells (eleven adjacent equal-turn pairs). Its word and full scope are in
the new note. Thus upper-half-only arguments are dead. The lower half `q(k)>=0`
survives hostile searches only when ordinary same-cell alternation and `W>=10` are
retained; this is bounded evidence, not a theorem. The narrowest live target is to
prove that the single-tour primitive geometry plus ordinary alternation and the
width barrier force some stabilised prefix below zero.

The standard 104-word also supplies 36/36 counterexamples to pose-factor P3
inheritance, so do not revive loop deletion. Universal `g>=12` still additionally
requires all `g=8` geometries after primitive `g=4` is closed.

## 20 August 2026: exact-u mod-four refinement

Combining T2 with finite-support start-R alternation gives, on every exact
longitudinal residue line, `nu=2-Omega (mod 4)` for horizontal lines and
`nu=2+Omega (mod 4)` for vertical lines. Here `Omega` counts odd-visited cells, or
equivalently wake strands, on the line. For primitive `m=1` this is exactly the
existing `N=6 (mod 8)` congruence and makes no progress on the remaining primitive
chronology. For `m>=2` it is new per-`u mod 2m` pruning, but a corrected explicit
`m=4,g=8,W=10,N=64` arithmetic skeleton satisfies it together with T1, both P22
families, singleton rails and local flow. See the line-parity note, Section 13.
Therefore this refinement is proved and worth retaining, but it does not establish
`g>=12`.

The tempting spatial interpretation of the surviving lower-prefix condition is
also closed. `q>=0` is a nonnegative chain of time intervals on separate lifted
classes, not a finite 2-chain on the translation cylinder; the period curve has
homology one. Both an exact primitive lower-prefix model and the genuine standard
highway have disconnected canonical wake representatives despite connected or
spanning transient toggle sets. Connectivity of additions bounds additions, not
net growth after removals, and representative connectivity changes under the
endpoint-decomposition gauge. See the 20 August primitive note; do not revive a
`g>=W/2+2` argument from prefix charge.

## 20 August 2026: analytic cap-three exclusion and the fat-profile boundary

There is now a proved lower-half reduction and an analytic all-width conditional
exclusion. If `q(k)>=0` on every stabilised level, then the per-level excesses
`delta_t` are nonnegative. Since `delta_t=omega_t (mod 4)` and both totals sum to
four, `delta_t=omega_t` on every level. Thus every complete level word is a Dyck
word or a Dyck prefix ending at height one.

Under the explicit restriction `f_c<=3`, the weak profile is determined by the two
interior wake levels. The endpoint is equivalent to `h+v=W+1`, leaving exactly
`W/2-1` profiles, all with `N=4W-2`. A rooted-plane-tree frontier argument then
classifies every lower-prefix state after four levels into five affine families and
proves that none extends through level five. The sole final candidate has bases
`(2,4,3)`, voltages `(2,-1,-1)`, and fifth-level stable word `RLLR`.

Thus no primitive-diagonal growth-four highway of width at least six can have
crossing cap three. This is an analytic all-period conditional theorem. The full
case split is in
`research-notes/primitive_g4_cap3_analytic_2026-08-20.md`.

Two separately structured enumerators remain as bounded corroboration:

```text
W    weak profiles    raw tours    endpoint/growth    q>=0
4          2               24               6          1
6          6              360              60          0
8         12            3,888             498          0
10        20           37,584           4,008          0
12        30          347,976          32,430          0
```

Artifacts:

```text
code/python/primitive_g4_projected_tours.py
code/python/verify_primitive_g4_projected_indep.py
code/python/audit_primitive_g4_projected.py
results/primitive_g4_projected_w12.json
```

The enumerators forget ordinary same-cell chronology, so their zeros are sound for
the bounded crossing-cap rows. They are not the proof of the all-width statement;
the affine frontier classification is. The result remains conditional on
`f_c<=3` and therefore is not an unrestricted primitive exclusion.

The cap cannot be silently removed. The literal north-facing `N=62`, `W=10` word

```text
LRRLRLRLRRRRLRLLRLLRLRRRRLLLLRLRRRRLLLLRLRRLRLLRRRRLLRLLLLRRRR
```

has endpoint `(1,-1)`, restored heading, growth four, singleton rails, four
excess-one levels, and zero ordinary same-cell defects. Its crossing profile is
`(1,3,5,2,3,9,3,1,3,1)`. It still fails the lower half, with total negative depth
seven on four levels. Therefore ordinary alternation alone is not the theorem,
while the largest crossing number nine shows exactly where the analytic cap-three
theorem stops. The active target remains the broad `W>=10` fat-profile obstruction;
after primitive `g=4`, every `g=8` drift family is still required for `g>=12`.

Release hygiene: `results/artifact_hashes.json` is intentionally not regenerated at
this checkpoint. The line-parity source edits have not been rebuilt into a fresh PDF
because the local TeX binary is sandbox-inaccessible; regenerate the PDF first, then
refresh the manifest once from the final source/artifact set.

## 20 August 2026: analytic cap-four obstruction

The cap-three boundary has been strengthened.  A voltage-unbounded rooted-plane-tree
classification now proves:

> Every primitive-diagonal finite-support periodic highway has some transverse
> cut with `f_c>=5`.

This uses full stabilised P3, rather than only its lower-prefix half.  Starting at
the singleton bottom rail, exact alternation leaves five fixed states and two
one-parameter families after three levels under `f_c<=4`.  At the fourth level,
leaf-voltage counts kill every state except two.  Their fixed coordinate blocks are
respectively `LRR` and `RRL`; every optional event in the same block is `R`, so
neither block can alternate.  The classification is algebraic, has no voltage,
period, or width cutoff, and was independently re-derived line by line.

The conclusion is boundary-local: one of the first four cuts above the bottom
rail has multiplicity at least five, and the reversed argument gives the same
statement within four levels of the top rail.  This is stronger than merely locating
an unspecified fat cut somewhere in the strip.

The complete proof is in
`research-notes/primitive_cap4_analytic_2026-08-20.md`.  The finite-window
regression

```text
python code/python/audit_primitive_cap4_frontier.py
```

checks voltage windows `3,5,10,20`, the exact symbolic depth-three families, and
zero depth-four states.  It is an audit of the algebraic proof, not the basis for
an unbounded claim.

This is a genuine all-width/all-period narrowing for both primitive `g=4` and
primitive `g=8`, but it is **not** `g>=12`: the branch with a fat cut `f_c>=5`
remains open, and nonprimitive `g=8` geometries are untouched.  Future work should
seek a contraction or unavoidable stable-order defect after the first fat cut;
extending another fixed cut cap will not by itself close the unrestricted problem.

## 20 August 2026: checker-pure `(2,-2)` growth eight is excluded

The cardinality-free form of the two-lane rank lemma gives a further analytic
all-period exclusion.  Let `O` be the eight excess-one translation classes of a
putative `d=(2,-2), g=8` highway.  If every member of `O` has one checkerboard
parity, then all of `O` lies on one of the two quotient vertex types.  If `o_r`
counts these classes in lane `r=x mod 2`, the signed residue theorem gives

```text
o_0+o_1=8,        o_0=o_1=2 (mod 4),
```

so `{o_0,o_1}={2,6}`.  The two-lane run identity is cardinality-free and yields

```text
K = 1 + E + L,
E + L = binom(o_0,2)+binom(o_1,2)=0            (mod 2),
```

hence `K=1`.  Exact stable alternation instead gives `K=#L`.  Writing `N=2M`,
heading reset supplies `M` horizontal moves, horizontal displacement two makes
`M` even, and `g=8` gives `#L=M-4`, hence `K=0`, a contradiction.  Quarter-turns
cover the full sign orbit of `(2,-2)`.

This theorem excludes only the **checker-pure** subfamily.  Mixed-checker wakes
at `(2,-2)` and all other unresolved growth-eight drift geometries remain open;
therefore this is not `g>=12`.  The proof and bounded algebra regression are

```text
research-notes/growth8_checker_pure_exclusion_2026-08-20.md
code/python/growth8_checker_pure_audit.py
```

## 20 August 2026: the fat-frontier monotonicity route is false

Do not assume that the number `p_c` of nonleaf frontier nodes is nondecreasing.
Exact alternating local frontiers exist with `p` dropping from two to one, and
the exact predecessors refute the tested three- and four-layer `p`-only
Hall/induction claims.
One exact three-level fragment has

```text
B=(0,2), V=(2,-2), deg=(3,3),
B'=(0,2,1,2,1,0), V'=(2,-1,0,-1,-1,-1), deg'=(1,0,1,0,0,0),
B''=(1,2), V''=(3,1), deg''=(2,0),
```

with stable words `(RL)^4`, `(RL)^4`, `(RL)^2` and `p=(2,2,1)`.  Richer-state or
longer-history Hall statements are not ruled out.

The surviving global datum is rooted ancestry.  For a frontier `(B_j,V_j)`, let

```text
r=1+# {j : B_(j+1) != B_j+V_j}.
```

Any predecessor has at least `r` nonleaf blocks.  A local drop can be continued
backward only by inserting gratuitous block splits and leaf separators; in the
longest checked exact branch the minimum extendible demands grow `3,6,10`, after
which the displayed branch terminates because two forced `L` events cannot be
separated.  This is branch-specific evidence, not a universal theorem.  The live
primitive target is to prove that every forward drop creates a backward defect
whose separator demand cannot reach the singleton root.  Until that global
propagation statement is proved, primitive-diagonal `g=4` remains open.

## 22 August 2026: computer-assisted cap-five obstruction

The boundary obstruction now advances one step beyond the analytic cap-four
theorem.  If `f_c` is the cut multiplicity above the normalized bottom rail,
every primitive-diagonal finite-support highway of growth four would satisfy

```text
max(f_1,f_2,f_3,f_4,f_5) >= 6.
```

Assume instead that the first five cuts are at most five.  The cap-four theorem
forces a first cut of size five at depth `2`, `3`, or `4`; depth one is excluded
by the level count.  The following row has five nodes and at most two nonleaves,
so at least three terminal voltages are fixed leaf voltages.  The root-voltage
equation leaves at most one free integer parameter.  Exhausting all cut prefixes,
ordered degree rows, terminal leaf placements, and exact affine order regimes
gives 1,320 cases.  Only nine exact source regimes survive the earlier rows, and
each fails even the relaxed test that its fixed leaf/endpoint word embed in the
required alternating terminal word.

Two separately written exact enumerators agree on all 1,320 cases, the same nine
regimes, and zero extensions.  The audit also checks the released hashes and
certificate:

```text
python code/python/primitive_g4_cap5_symbolic.py
python code/python/verify_primitive_g4_cap5_indep.py
python code/python/verify_primitive_g4_cap5_top.py
python code/python/audit_primitive_g4_cap5.py
```

The proof boundary and complete table are in
`research-notes/primitive_g4_cap5_symbolic_2026-08-22.md`; the machine-readable
record is `results/primitive_g4_cap5_certificate.json`.  A separate
sign-reversed top calculation, retaining the original longitudinal coordinate,
checks another 1,320 cases, leaves two exact source regimes, and has zero
extensions.  Thus the same threshold holds inward from the top without invoking
a reflection symmetry.  This is exact and period-unbounded, but computer-assisted.
It does not control a frontier
after it reaches six nodes and therefore does not prove `g>=12`.

The top conventions also yield an analytic local sharpening.  If the first
inward cut had two nodes, the depth-one stable word forces both child voltages
to be zero.  The two even-depth children are then nonleaves with fixed `L`
anchors at `x=-1` and `x=0`; the second endpoint at zero and the first start at
minus one are consecutive in stable order, so they form an unavoidable `LL`.
Hence the first inward cut below the top rail has multiplicity exactly three.
Writing the three child voltages in order, exact depth-one alternation gives the
two families

```text
B=(-1,-1,-1+r), V=(0,r,-r),
B=(-1,-1+r,-1), V=(r,-r,0),  r<=-1.
```

The next count law allows only `1,2,5,6,9,10` children.  The first two values
would require two even-depth leaf voltages `-1`, whereas either family contains
at most one.  For nine or ten children all three parents are nonleaves; the last
parent endpoint at zero and the first parent start at minus one are then
consecutive `L` anchors.  Hence the first two inward cuts are exactly `(3,5)` or
`(3,6)`.  In either case `r=-1`, the unique leaf is the first node, and the
current frontier is `B=(-1,-2,-1), V=(-1,1,0)`.  The proof note gives the complete
finite affine normal forms for the two nonleaf event-coordinate lists.  A
literal `(3,6)` two-row witness exists, so the six-branch cannot be removed by a
one-row argument.

The next odd row is nevertheless classified.  The eight `f_2=5` affine forms
have one state with the three required `+1` leaf voltages for `f_3=2,3`; its
fixed word is `RLRLLRR`, so both values fail.  The forty `f_2=6` forms give one
four-leaf state at `f_3=2` and five exact three-leaf branches at `f_3=5,6`.
Their fixed words are

```text
RLRLLRLR,
RLRLLRRRR, RRRRLLRLR, RLRRRLRLR, RLRLRRRLR, RLRRLRRLR.
```

Each has either a fixed `LL` or a required missing `L` in an empty integral
stable-order gap.  Consequently the analytic all-period top prefix is

```text
(3,5,m), m in {6,7,10,11,14,15},
or (3,6,m), m in {9,10,13,14,17,18}.
```

`code/python/audit_primitive_g4_top_prefix.py` checks all 8+40 affine forms,
solves the leaf equations over the integers, and performs exact gap matching
without a voltage bound.  Its checked summary is
`results/primitive_g4_top_prefix_certificate.json`.  This still does not
constrain the later fat frontier.

A second analytic lemma controls every global-maximum plateau.  For bottom-rooted
frontier sizes `n_d`, nonleaf counts `p_d`, and `M=max n_d`, put

```text
D_d=M-p_(d-1)-p_d
```

at a frontier with `n_d=M`.  This equals the number of outgoing leaves minus the
number of incoming parent blocks.  The level laws give

```text
4D_d=2M-n_(d-1)-n_(d+1)
     -tau_(d-1)(omega_(d-1)-omega_d).
```

Hence `D_d>=0`, and `D_d>=1` at a strict local maximum.  On a maximum plateau,
both boundary debts cannot vanish: that would use two distinct odd-depth wake
rows, while primitive growth four has only one.  Thus some boundary block
contains at least two outgoing leaves.  This is a proof-grade separator-debt
obligation, not an exclusion; an exact local `2,6,2` fragment realizes positive
debt.  The remaining target is to show that this debt cannot propagate through
a finite exact tree to both singleton rails.

## 22 August 2026: mixed-checker rank condition at `(2,-2)`

The two-lane permutation sign now covers arbitrary mixtures of the two checker
types.  With lane counts `q_r,c_r`, their common parity `p`, and `I` the parity of
the ordered mixed pairs with the `C` level below the `Q` level, finite-support
gadget decomposition gives

```text
E+L=sum_r [binom(q_r,2)+binom(c_r,2)]+I+p  (mod 2).
```

For `g=8`, P22 cancels the four binomial terms in pairs.  Exact P3 order and the
one-tour sign then force `I+p=1`.  Consequently the remaining `2--6` checker split
has even interlacing, while the `4--4` split has odd interlacing.

There is also an independent mod-four charge.  With `t=x+y`, `Q={t even}` and
lane `r=x mod 2`, the weight

```text
(-1)^(x+y)(floor(x/2)+floor(y/2))
```

is drift-periodic, has zero four-corner sum, and has potential monodromy `3`.
It forces

```text
sum_Q floor(t/2)-sum_C floor(t/2)-q_1 = 1  (mod 4).
```

In the normalized residue matrices the raw `Q-C` moment is therefore `3 mod 4`
for the `4--4` split and `0 mod 4` for the `6--2` split.  Boundary placements
satisfying both the moment and the rank condition still exist, so this is a
strict narrowing, not an exclusion.  See

```text
research-notes/growth8_mixed_checker_rank_2026-08-22.md
code/python/mixed_checker_rank_parity_audit.py
```

## 22 August 2026: growth-eight period 50 is excluded

A complete fixed-growth run of `PositiveGrowthResidueSearch` covers every
normalized length-12 prefix rank at `N=50`, `g=8`.  Eight disjoint shards report
15,488,130,188 nodes, 327,932,571 residue checks, 14,293,604 exact P3 checks, and
no hits.  No node cap or deficit pruning was used.

`code/python/aggregate_target_growth_shards.py` checks exact rank coverage,
prefix reconstruction, per-rank and per-shard sums, hit-list agreement, and raw
shard hashes.  Its checked summary is
`results/growth8_period50_exclusion.json`; the full statement and rerun commands
are in `research-notes/growth8_period50_exclusion_2026-08-22.md`.

This search relies on the proved residue theorem for pruning.  It closes only
the pair `(N,g)=(50,8)`.  It does not close a growth-eight drift family or give an
all-period lower bound.

## 22 August 2026: axis growth-eight residue structure

The exact-row clause of P22 sharpens both axis orbits.  At `(2,0)`, four occupied
rows each contain the opposite-checker residue pair, and `N=4 (mod 8)`; the
two-column rank identity independently gives the same period class.  At `(4,0)`,
every occupied row is checker-balanced and `N=0 (mod 8)`.  Both orbits remain
open.  The proof is in
`research-notes/growth8_axis_classification_2026-08-22.md`.

## 22 August 2026: full-rail `(4,-4)` exclusion (scope corrected 3 September)

The original text below assumes full rail occupancy without proving it.
Its conclusion is valid only for that subfamily, not the whole orbit.

At `d=(4,-4)`, extremal rigidity puts four singleton odd classes on each guard
rail.  Those eight classes exhaust a growth-eight wake.  The resulting four-lane
edge-parity flow is unique and contains every allowed interior block.  Its local
rank term is zero, and its edge inversion count is even.  Hence the one-tour sign
gives `K=1`.  Checker purity and the period congruence give `N=0 (mod 8)`, while
P3 gives `K=#L=(N-8)/2=0`, a contradiction.

This is an analytic all-period exclusion of the whole quarter-turn orbit.  See

```text
research-notes/growth8_extremal_m4_exclusion_2026-08-22.md
code/python/growth8_extremal_m4_rank_audit.py
results/growth8_extremal_m4_rank_audit.json
```

## 22 August 2026: growth-eight period 52 is excluded

The second fixed-growth run is complete.  At `N=52`, `g=8`, all 2,048 normalized
length-12 prefix ranks were covered exactly once in eight shards.  No node cap or
deficit pruning was used.  The combined search visited 38,465,607,042 nodes,
made 1,441,579,326 residue checks and 95,203,305 exact P3 checks, and found no
accepted word.

The aggregate was rebuilt from the archived shard records.  It reports exact
rank coverage, consistent per-rank sums, an empty hit list, and no audit problem:

```text
research-notes/growth8_period52_exclusion_2026-08-22.md
results/growth8_period52_exclusion.json
records/g8_p52_shards/
```

Together with the general computation through period 48 and the targeted
period-50 run, the first growth-eight period not yet excluded is now 54.  This
does not close any all-period drift case.

## 22 August 2026: rank parity at the saturated skew drifts

The two chiral orbits represented by `(2,4)` and `(2,-4)` now have exact
all-period moment and rank conditions.  After translating the unique P22 matrix, one doubled
residue fibre lies in the two-class lane and three doubled fibres lie in the
six-class lane.  If `T_0,T_1,T_3` are the two transverse levels in those three
majority fibres and `T_A` is the minority pair, put

```text
S_A=sum_(t in T_A)t/4,       S_j=sum_(t in T_j)(t-j)/4.
```

For `d=(2,4s)`, the extra drift-periodic four-corner weight gives

```text
S_A-S_0+S_1+S_3=-s  (mod 4),
```

while the rank sign gives

```text
sum_{i<j} #{(u,v) in T_i x T_j : u<v} = 1  (mod 2).
```

The quotient parity flow is unique.  Its four finite chains reduce the edge/local
rank sign to the displayed endpoint interlacing, in both chiralities separately.
The bounded audit checks 148 segment interactions, 1,446 additive-weight identities,
and 2,592 full boundary placements.  In either chirality 184 tested placements
satisfy both conditions, so this is a strict narrowing and not an exclusion.

```text
research-notes/growth8_skew_rank_parity_2026-08-22.md
code/python/growth8_skew_rank_parity_audit.py
results/growth8_skew_rank_parity_audit.json
```

## 23 August 2026: growth-eight period 54 is excluded

The resumed fixed-growth run at `N=54`, `g=8` completed all 64 rank shards.
Together they cover the 2,048 normalized length-12 prefixes exactly once.  The
run used no node cap and did not enable the optional deficit rule.  Its totals are

```text
nodes              99,180,610,230
residue checks       2,123,298,784
P3 checks              104,485,244
hits                             0
```

The aggregate was rebuilt from the copied archive rather than accepted from the
runner's working directory.  Prefix reconstruction, rank coverage, every counter
sum, both hit lists, and all 64 shard hashes pass.

```text
research-notes/growth8_period54_exclusion_2026-08-23.md
results/growth8_period54_exclusion.json
records/g8_p54_shards/
```

This raises the least possible growth-eight period to 56.  It is a finite
computer-assisted exclusion and does not remove another all-period drift orbit.

## 23 August 2026: growth-eight period 56 is excluded

The fixed-growth run at `N=56`, `g=8` completed all 256 rank shards. Together
they cover the 2,048 normalized length-12 prefixes exactly once. The run used no
node cap and did not enable the optional deficit rule. Its totals are

```text
nodes             246,883,217,080
residue checks       9,343,985,497
P3 checks               10,817,398
hits                              0
```

The aggregate was rebuilt from the copied archive rather than accepted from the
runner's working directory. Prefix reconstruction, rank coverage, every counter
sum, both hit lists, and all 256 shard hashes pass.

```text
research-notes/growth8_period56_exclusion_2026-08-23.md
results/growth8_period56_exclusion.json
records/g8_p56_shards/
```

This raises the least possible growth-eight period to 58. It is a finite
computer-assisted exclusion and does not remove another all-period drift orbit.

## 23 August 2026: additive boundary at `(3,-3)`

Scope correction, 3 September: the original paragraph below assumes full
rail occupancy. Its moment and period restrictions apply to that subfamily
only. They do not remove partial-rail period-58 candidates by this argument.

The forced `7+1` checker split at drift `(3,-3)` can be sharpened without a width
cutoff.  Normalize the guard rails to levels `1` and `W+1`.  P22 puts the remaining
horizontal and vertical odd classes in one lane at levels `h` and `v`, with
`k=(v-h)/3` odd.  The complete family of drift-periodic mod-four weights with zero
four-corner sum reduces on this boundary to

```text
k=W+1  (mod 4).
N=6    (mod 8).
N>=4W+12|k|+2.
```

One generator is `(-1)^(x+y)(floor(x/3)+floor(y/3))`; its potential monodromy is
one.  The full recurrence proof shows that no other weight in this additive family
adds a second condition. Transverse line parity supplies the period bound: the
`3|k|` cuts between the two extra classes have crossing number divisible by four.
Width four is removed, but normalized placements remain at every even width from
six onward. Since `k` is odd, every such placement has `N>=4W+14`. The three-lane
rank sign is compatible. The period residue comes from the orientation of the
forced `7+1` split: after phase zero is placed at an even-checker vertical arrival,
the vertical class is the sole even-checker odd class. Thus `A=1` in the
kinematic congruence. This removes `(3,-3)` from period 58 but does not close the
orbit.

The default audit checks 370 placements, the six generators of the `4^6` weight
family on each placement, and the direct parity flow on all 185 survivors:

```text
research-notes/growth8_m3_additive_boundary_2026-08-23.md
code/python/growth8_m3_boundary_audit.py
results/growth8_m3_boundary_audit.json
```

## 23 August 2026: complete additive condition at `(1,±3)`

For `d=(1,3s)`, the three P22 `y mod 3` weights and one quasi-periodic generator
span every drift-periodic mod-four weight with zero four-corner sum.  Writing
`j=y mod 3` and `n=x-s floor(y/3)`, the extra generator has monodromy `2+s` and
forces

```text
sum_O (-1)^(n+j)n = 2-s  (mod 4).
```

The quotient parity flow is unique as well.  Its four finite segments reduce the
edge/local sign to the total interlacing of the three residue fibres.  Since the
period congruence makes `#L` odd, P3 requires that interlacing sum to be even.

The result is all-period but not an exclusion.  A bounded additive count over
`n in [-5,5]` leaves 150,000 of 300,000 P22 placements in each chirality.  The
direct-flow rank audit checks a smaller complete window and leaves 824 of 1,944.

```text
research-notes/growth8_odd_skew_additive_2026-08-23.md
code/python/growth8_odd_skew_moment_audit.py
results/growth8_odd_skew_moment_audit.json
code/python/growth8_odd_skew_rank_parity_audit.py
results/growth8_odd_skew_rank_parity_audit.json
```

## 23 August 2026: primitive-diagonal growth-eight boundary

At drift `(1,-1)`, normalize the guard rails to levels `1` and `W+1` and write
`O` for the eight odd-class levels. The complete drift-periodic additive family
has one generator beyond P22, giving

```text
sum_(t in O) (-1)^t t = 3  (mod 4).
```

The one-lane quotient flow is unique. Pairing consecutive endpoints gives four
finite segments; each has self-sign one and every segment pair has cross-sign
zero. Thus `E+L=|O|/2=0`, which is compatible with P3 rather than contradictory.
The default audit checks the complete weight family, 238 direct finite flow
systems, and all 23,492 normalized P22 placements through width twenty. Exactly
11,746 placements survive the moment.

```text
research-notes/growth8_primitive_diagonal_boundary_2026-08-23.md
code/python/growth8_primitive_diagonal_boundary_audit.py
results/growth8_primitive_diagonal_boundary_audit.json
```

## 23 August 2026: coordinate-fibre visit law

The coordinate reversal identities have a finite-support mod-four consequence
that was not previously extracted. For drift `(a,b)`, use residues modulo a
nonzero coordinate component and exact coordinate lines when that component is
zero. If `nu_F` counts period events in one fibre and `Omega_F` counts the odd
translation classes there, P3 gives

```text
nu^x_F-Omega^x_F = 2*[a != 0]  (mod 4),
nu^y_F-Omega^y_F = 2*[b != 0]  (mod 4).
```

At growth eight this fixes the unsigned coordinate visit residues for all ten
drift types. In particular, `(3,-3)` has visit residues `2+0+0 mod 4` on each
axis; both axis cases acquire exact-row congruences; and every coordinate residue
at `(2,4)`, `(2,-4)`, and `(4,-4)` has visit count zero modulo four. The result
is not another orbit exclusion. All 185 `(3,-3)` additive placements through
width thirty admit the combined transverse, longitudinal, column, and row
congruence system, and the recorded width-ten, period-64 four-lane skeleton
remains feasible. A direct regression also checks all 10,702 heading-resetting
nonzero-drift words through period fourteen with no kinematic failure.

```text
research-notes/growth8_diagonal_coordinate_residues_2026-08-23.md
code/python/growth8_diagonal_coordinate_residue_audit.py
results/growth8_diagonal_coordinate_residue_audit.json
```

An axis-side conjecture was also tested and rejected before promotion. At drift
`(4,0)`, summing the stable-rank defects separately in the four `x mod 4` lanes
always gave two defective lanes at periods 16, 24, and 32 after imposing physical
cell alternation, binary class excess, and P22. At period 40 the exact macro search
found 52 strong candidates with zero lane defect. One is

```text
UUUuVvUUVvvvVuuVVVVv,
```

with `(U,u,V,v)=((1,1),(-1,-1),(1,-1),(-1,1))` in horizontal--vertical macro
coordinates. Its 40-turn trace has growth eight and drift `(4,0)`; every stable
class alternates, but seven classes begin with `L`. Thus the remaining obstruction
is the start condition itself, and the lane-defect parity must not be cited as an
all-period lemma.

The same macro search was then aimed at the other axis orbit, `(2,0)`. It kept
only paths with physical same-cell alternation, class excess in `{0,1}`, all
eight odd classes, and both the residue and exact-row clauses of P22. With both
possible first-turn orientations included, the strong-candidate counts at
periods `12,20,28,36,44` are

```text
0, 11, 212, 3,421, 51,896.
```

None has alternating stable words in every translation class. The period-44 run
was split into sixteen length-two macro prefixes and covered 316,568,701 search
nodes and 2,061,237 endpoint paths. This is a finite pattern, not an exclusion of
the `(2,0)` orbit. A narrower wake-only version is false: two period-44 candidates
make all eight odd-class words alternate and fail in one even class. A parity
search over 32 natural equality bins also fails; already at period 28, two
nonalternating candidates have zero aggregate bin vector. The surviving target
is therefore a genuinely global alternation obstruction, not a linear defect in
those bins.
