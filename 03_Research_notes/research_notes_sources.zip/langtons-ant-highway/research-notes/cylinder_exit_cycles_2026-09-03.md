# Exit cycles wind once, with an exact excursion decomposition

Let a finite-support periodic Langton trace have period `N` and nonzero drift
`d=(a,b)`.  Select the edge leaving the last stable occurrence of each visited
translation class.  Every directed cycle of this last-exit graph has voltage
exactly `+1`.

Moreover, a cycle of length `k` gives an exact decomposition of one period
into its `k` selected lattice edges and closed return excursions of lengths
`D_1,...,D_k`, where

```text
N = k + sum_i D_i,       D_i in 4 Z_(>=0).
```

In particular, every individual excursion is shorter than `N`.  This is
stronger than the positive-voltage inequality: it retains the actual motion
omitted between selected last visits.  It does not bound the wake carried by
the excursions or exclude growth eight.

## Chronological signs

Choose a representative cell `c_v` for each visited translation class.  Give
a phase occurrence at `c_v+n_i d` lifted time `i-N n_i`.  Write `T_v` for the
largest such time, and let the last selected edge have target `f(v)` and
voltage `lambda_v`, so

```text
c_v + selected step = c_(f(v)) + lambda_v d.
```

The arrival at its target occurs no later than that target's last visit.
Hence

```text
T_(f(v)) + N lambda_v >= T_v+1.
```

Summing around a directed cycle gives `N Lambda>=k>0`.  Its integer voltage
is therefore positive.  This is the last-exit inequality proved in
`odd_skew_excursions_and_domino_transfer_2026-08-31.md`; it does not require
the drift vector to be primitive in the lattice.

For comparison, let `F_v` be the first stable visit time and select the edge
leaving that visit.  Its target's first visit is no later than the arrival,
so

```text
F_(g(v)) + N lambda_v <= F_v+1.
```

A first-departure cycle consequently has `N Lambda<=k`.  Since it uses
distinct classes, `k` is at most the number of visited classes, which is at
most `N`.  Positive voltage would force equality throughout.  Every class
would then be a singleton, and P3 would make every turn right.  An all-right
heading-reset word closes after complete four-step squares and has zero
drift.  Thus a nonzero-drift trace has no positive first-departure cycle.

## Why a simple quotient cycle cannot wind twice

The quotient surface `R^2/Zd` is a cylinder, even when `d` is not primitive.
The lattice edges embed in it.  Two projected unit edges can meet away from
their endpoints only if they are the same projected edge: translation by
`d` preserves the integer lattice.

A functional-graph cycle has distinct quotient vertices.  Its realization
therefore has no self-intersection, unless it retraces an undirected edge.
Such retracing would be a two-edge backtrack.  In the present directed lattice
that is impossible: the incoming and outgoing axes at every cell are
perpendicular.  Here the checker/heading invariant matters: every visit to a
translation class has the same incoming axis, since heading reset makes the
drift preserve checker parity.  The selected edge and an earlier incoming
edge therefore remain perpendicular even when they belong to different
visits.  Thus every selected cycle is an embedded simple closed curve in the
cylinder.

Identify the cylinder with the punctured plane, using longitudinal position
as angle and the exponential of transverse position as radius.  The image
of an embedded cycle is a Jordan curve.  Its winding about the puncture is
zero if the puncture is outside, and otherwise is `+1` or `-1` according to
orientation.  The winding is precisely the cycle's edge voltage.  Therefore

```text
last-exit cycle:       Lambda=+1,
first-departure cycle: Lambda=0 or -1.
```

The previously proved orientation restriction still applies to the
zero-voltage first-departure cycles: their planar lifts are counterclockwise.
The winding statements do not imply that either functional graph has only
one cycle.  The standard period-104 trace has two last-exit cycles, as
recorded in the excursion note.

## Recovering a full period from a last-exit cycle

Choose a sufficiently late physical copy of the cycle, starting at the last
visit to a cell representing `v_0`.  Follow its selected edge to the next
physical cell.  The actual trace runs from this arrival to that same cell's
last visit before taking its selected edge.  This intervening segment is a
closed return excursion; it may have length zero.

Repeat at each successive cycle vertex.  Chronological extremality ensures
that each selected last visit occurs after the preceding selected edge, so
these segments concatenate in actual time.  Voltage `+1` puts the final
cell at the starting cell plus `d`.  Its last visit is exactly `N` steps
after the starting last visit.  The selected edges and intervening excursions
thus partition one period, proving

```text
N=k+D_1+...+D_k.
```

A closed quarter-turn walk alternates horizontal and vertical steps.  Zero
displacement makes the count on each axis even, so its length is divisible
by four.  This proves `D_i in 4 Z_(>=0)`.  If `r` selected edges do not land
directly at their target's last visit, it also gives

```text
N>=k+4r,       N=k mod 4.
```

The cycle itself alternates step axes and has displacement `d`.  Hence its
length obeys

```text
k >= 2 max(|a|,|b|).
```

For example, at drift `(1,-3)` every last-exit cycle has length at least six.

## The first-entry version

There is also a first-entry version of the decomposition.  At each first
visit select its physical predecessor, directing the selected edge backward.
If that predecessor is in class `p(v)` with reverse voltage `mu_v`, then

```text
F_(p(v))+N mu_v <= F_v-1.
```

Every reverse-first-entry cycle consequently has strictly negative voltage.
The cylinder argument makes it exactly `-1`.  Reverse the cycle's orientation
to obtain forward voltage `+1`.  Starting at a sufficiently future first
visit, the actual trace waits at each cycle source until the departure
feeding the next cycle vertex's first visit, then takes that selected edge.
These waits are closed excursions starting at first visits.  They give
another exact identity `N=k+sum_i D_i`, with `D_i in 4 Z_(>=0)`.

This graph is different from the first-departure graph: one selects edges
entering first visits, the other edges leaving them.  The first-entry waits
start at white, right-turn visits; the last-exit waits end at last visits.
Neither description fixes the initial colours of the other cells met by
an excursion.

### Exactly half the first-entry vertices have positive waits

For this forward first-entry cycle, its incoming edge at a physical vertex
`v` is the actual first arrival there. If the geometric corner at `v` is
R, that first visit immediately traverses the geometric outgoing edge.
Its target cannot have its selected first arrival later via the same edge:
the first departure from `v` has already reached that exact physical cell.
Thus the wait at an R corner is zero. At an L corner the geometric edge
is opposite to the actual first R departure, so the wait is positive.

Every embedded essential cycle on the flat translation cylinder has total
signed turning zero. One elementary proof takes a straight longitudinal
circle beyond its transverse range. The two disjoint circles bound a flat
annulus. Triangulate it; summing the triangle angles gives total boundary
exterior angle `2 pi chi=0`. The straight circle contributes zero, so the
polygonal cycle does too. There is no curvature singularity at the seam
because the identification is a translation.

Consequently a length-`k` first-entry cycle has exactly `k/2` L corners
and exactly `k/2` positive waits. Each positive wait has length at least
four. The period decomposition therefore yields the all-period bound

```text
N >= 3k >= 6 max(|a|,|b|).
```

This counts time, not signed black change. In particular, it does not
assert that a longer excursion adds four wake cells.

The turn-change argument in `first_entry_detour_charges_2026-09-04.md`
strengthens this to `N>=6 max(|a|,|b|)+2(|a|+|b|)`. That note also gives
the exact integer detour charges whose sum is `g/4`, and explains why
their positivity does not follow from local alternation and ray avoidance.

## The missing wake estimate

### Every positive last-exit wait reverses heading

Suppose the selected last departure from a physical cell `u` reaches a
cycle vertex `v` with incoming heading `h`. Let `D_v` be the wait from this
arrival to the last visit to `v`. If `D_v>0` and that last visit also had
heading `h`, its predecessor would again be the physical cell `u`.
That would visit `u` after its selected last departure, a contradiction.
The fixed incoming axis leaves only the opposite heading. Thus

```text
D_v=0: the incoming heading is unchanged,
D_v>0: the incoming heading is reversed.
```

This proof also covers the wrap edge of a lifted cycle: the final vertex
is the appropriate translated physical cell, not an unshifted representative.

Let `c_v` be the geometric turn of the cycle at `v`, with R equal to `+1`
and L to `-1`. The actual terminal turn is `s_v=2 omega_v-1`, since P3
ends an odd class with R and an even class with L. Both departures use the
same selected edge, so reversal of the incoming heading reverses the turn:

```text
D_v=0  iff  s_v=c_v,
D_v>0  iff  s_v=-c_v.
```

These equivalences retain information that the voltage inequalities alone
do not record. In particular, every positive last-exit excursion has turn
balance two modulo four.

### Diagonal cycle extrema and rail avoidance

Now normalize `d=(m,-m)` with `m>0`, and use transverse coordinate
`t=x+y`. Every minimum of a positive-voltage embedded essential cycle
has geometric port `SL`; every maximum has geometric port `ER`.
For a negative-voltage cycle, the corresponding ports are `WR` at every
minimum and `NL` at every maximum.

To see this, use the orientation-preserving cylinder coordinates
`(u,t)=(x-y,x+y)`, with `u` taken modulo `2m`. For a curve oriented with
voltage `+1`, the component extending to `t=-infinity` is on its right,
and the component extending to `t=+infinity` is on its left. This follows
equivalently by its signed crossing number with an arc from the lower end
of the cylinder to the upper end. The sides exchange for voltage `-1`.

At a minimum the only possible quarter-turn corners are `W->N` and
`S->E`. At the former corner, a sufficiently close point southwest of
the vertex is on its left but lies strictly below the whole curve. This
contradicts voltage `+1`, so its minimum must be `S->E`. At a maximum
the possible corners are `E->S` and `N->W`; the latter puts a nearby
northeast point on the right, although it is strictly above the curve.
This excludes it for voltage `+1`. Exchanging left and right gives the
negative-voltage statement. Choose each neighborhood disjoint from all
nonincident edges; other equal extrema do not affect the argument.

In particular, positive cycles have vertical-arrival minima and horizontal-
arrival maxima. Their transverse width is odd. Negative cycles have the
opposite types and also have odd width.

Combining the positive-cycle corners with the exact wait rule gives

```text
at a cycle minimum: D_v>0 iff omega_v=1,
at a cycle maximum: D_v>0 iff omega_v=0.
```

A positive wait at a wake minimum ends with actual port `NR`, so its final
arrival comes from one level below that minimum. A positive wait at a
non-wake maximum ends with actual port `WL`, so its final arrival comes
from one level above that maximum. Such excursions must leave the cycle's
transverse range on the indicated side.

These statements concern the cycle's extrema, not an assumed full trace
boundary. They imply unconditional rail restrictions. A positive last-exit
or forward first-entry cycle cannot meet the actual lower rail: its
horizontal singleton vertices cannot be positive-cycle minima. A negative
first-departure cycle cannot meet the actual upper rail. A zero-voltage
first-departure cycle is counterclockwise; its bounded planar interior is
on the left. The same southwest/northeast test shows that it cannot meet
either horizontal rail. Hence every first-departure cycle avoids the
upper rail. None of these conclusions fills an unvisited rail lane.

### What is still missing

The edge arriving along a selected cycle need not be the incoming edge of
the selected visit at its target.  A return excursion may intervene and
reverse the incoming heading.  Consequently, first-turn `R` or terminal-turn
parity does not determine the geometric turn of the cycle at that vertex.
Counting the curve's corners as wake cells would discard exactly the
excursions retained above.

A closure argument still needs to control these excursions using stable
visit order and the growth-eight wake budget.  The one-winding theorem
provides an exact decomposition for that argument, not the missing estimate.
