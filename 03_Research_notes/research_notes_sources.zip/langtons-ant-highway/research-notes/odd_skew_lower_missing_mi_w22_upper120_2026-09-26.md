# M-I at width 22 cannot have upper long band `120`

26 September 2026. For drift `(1,-3)`, the lower-missing M-I family first
appears at width 22. Its unique wake placement is

```text
O={0,1,4,6,10,14,20,22}.
```

This certificate excludes the upper fat `(1,2,3)` initial band
`(j,k,l)=(1,2,0)` for that placement. Combined with the existing width-22
`111` exclusion and the all-width `210` near-wake lemma, it leaves only the
upper short band at width 22. It does not settle the short band or wider M-I
placements.

The verifier uses the physical row coordinate `t=3x+y`. The lower cap is at
`t=0`, the upper cap at `t=22`, and their common center row is `t=11`.
Rotating upper headings by 180 degrees maps inward row `u` to physical row
`22-u` while preserving the turn and the chronological event order. It
enumerates lower prefixes through row 11 from the missing cap and upper
prefixes through inward row 10 from the upper `120` cap. Every row count
allowed by directional flow, binary wake excess and row parity is considered;
within each count, every right/left alternating word consistent with the
necessary finite-return adjacency is considered. A word is removed only for
a witnessed finite wrong first return or an infeasible lifted clock. The
lower clock uses integer `N>=6`. The upper clock uses real `N>=6`, an exact
rational relaxation that contains every integer-period case.

The lower frontier contains 302 prefixes and 302 distinct center words. An
earlier unfiltered upper run found 32,516 prefixes at inward row 10. A
necessary full-width integer count-flow model enforces the wake
pattern, all directional flows across rows 0 through 22, and one of the eight
count profiles of the 302 lower prefixes. Applying it before the large
row-ten word enumeration leaves 1,800 upper prefixes. The count model adds
no period or ordering constraint and cannot discard an actual orbit.

For each upper prefix, the verifier tries every rotated lower center word
whose port counts satisfy the upper row-eleven flow equations. There are
133,597 such pairs. A finite first-return path rejects 133,485; the exact
real upper clock rejects another 107. The five remaining pairs specify all
23 physical rows because their center words identify their exact lower
prefixes. In each full-width word system, every event has a successor, and
a finite path returns to its starting event with zero horizontal voltage.
The path would require its positive number of steps to equal zero in the
lifted clock. All five full integer clock systems are independently
infeasible. Therefore the upper `120` band is impossible at width 22.

Run `python code/python/verify_lower_missing_mi_w22_upper120.py` from the
repository root. It regenerates both cap frontiers, the full-width count
filter and all center joins, then writes
`results/lower_missing_mi_w22_upper120_checks_2026-09-26.json` with all five
complete zero-voltage return paths. The proof uses no period or row-length upper
bound and does not extrapolate repeated quotient vertices into physical
returns.

The standard-library checker
`code/python/check_lower_missing_mi_w22_upper120_witnesses.py` reads that
report, reconstructs ordinal successors from each complete row system, and
replays all five cycles. In each case it checks that the path returns to the
same event with zero voltage after a positive number of steps. Thus the final
obstruction can be checked without a solver.
