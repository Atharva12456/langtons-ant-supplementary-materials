# Five offset-eight words and a left turn at offset twelve

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Continue with the upper U branch of family A. The preceding
return arguments fix offsets five through seven and the final
events through offset eleven. This note reduces offset eight
to five explicit words and forces the last east arrival on
offset twelve to turn left. The U branch remains open.

## The second east arrival on eight turns left

Use the labels from
`odd_skew_upper_a_u_forced_tail_2026-09-14.md`. There
are six east arrivals `E1,...,E6` and five south departures
on eight. The following are already forced:

```text
E1=ER at south ordinal 2;
E3=EL;
J=WL at south ordinal 4;
E5=ER at south ordinal 5;
the consecutive final block J,E5,E6=EL.
```

If `E2=ER`, alternation between the consecutive east arrivals
`E1=ER,E2=ER` would require an intervening `WL`. This
would put `E2` at south ordinal at least four. But `E2`
precedes `J`, which is already the fourth south departure.
Thus `E2=EL`.

The first south departure is `WL`, immediately before the
first east arrival `E1=ER`. Since no east arrival precedes
it, the word begins exactly `WR,WL,ER`.

## The five words

Only the turn at `E4` remains to be chosen among the east
arrivals. If `E4=ER`, it is the third south departure.
Alternation fixes the complete ten-visit word

```text
A: WR,WL,ER,EL,WR,EL,ER,WL,ER,EL.
```

If `E4=EL`, the third south departure is another `WL`,
denoted `I`. Between `E1` and the final `J` there are
exactly the four left turns `E2,E3,E4,I`, with `E2,E3,E4`
in their fixed order. Every intervening right turn is `WR`.
The four positions for `I` therefore give exactly

```text
B0: WR,WL,ER,WL,WR,EL,WR,EL,WR,EL,WR,WL,ER,EL;
B1: WR,WL,ER,EL,WR,WL,WR,EL,WR,EL,WR,WL,ER,EL;
B2: WR,WL,ER,EL,WR,EL,WR,WL,WR,EL,WR,WL,ER,EL;
B3: WR,WL,ER,EL,WR,EL,WR,EL,WR,WL,WR,WL,ER,EL.
```

These fourteen-visit words and A are necessary alternatives,
not realized traces. They use only the stable turn order and
the already forced square through the last west departure
on seven. The subsequent return-order argument in
`odd_skew_upper_a_u_unique_eighth_word_2026-09-14.md`
excludes A and B1 through B3, leaving only B0.

There is one useful distinction at offset nine. In the four
B words, `E4=EL`; the eighth-step first return from `D5`
through `6:WL2,5:SR,2:WR,3:NR,6:ER,5:SL2,E4` cannot
have an `SR` source, because its consecutive target would
be `D6=NL`, whereas `D6=SR` is already forced. Hence
`D5=NL` in B0 through B3. Its incoming predecessor on
eight is the `WR` immediately before `E4`.

## Comparing the two upper clocks

The endings from the preceding note are

```text
9:  ...,D6=SR,D7=NL,D8=SR,SL;
10: ...,F6=ER,K=WL,X=WR,F7=EL;
11: ...,P_J=NL,NR,SL.
```

The final `NR` on eleven is supplied by `F7`. Let `H`
be the last east arrival on twelve; it is supplied by the
last `SL` on nine, whose incoming predecessor is `10:K`.

Write `tau` for stable lifted time in the upper inward
orientation. A south step followed by an east step has
voltage minus one, so its time increment is `2+N`, not
the lower-cap value `2-N`. The relevant identities are

```text
tau(F7) = tau(E5)+2+N,
tau(H)  = tau(K)+2+N.
```

The three consecutive square gaps on offset six give
`tau(6:EL2)=tau(6:WL3)+8`. Since `E6` and `F6` are
supplied by `6:WL3` and `6:EL2`, each by a two-step
path with the same voltage, this yields

```text
tau(F6)=tau(E6)+8.
```

Now `F6<K` and `E5<E6`. Consequently

```text
tau(H)-tau(F7) = tau(K)-tau(E5)
               > tau(E6)+8-tau(E5)
               > 8.                                (1)
```

No bound on a black lifetime is used here.

## The last east arrival on twelve is EL

If `H=ER`, its south step would reach eleven after its
last north arrival, which has time `tau(F7)+1`. By (1)
the arrival would be strictly later. The only event on
eleven after that north arrival is its final `SL`.
Thus `H` would be the last south departure on twelve
as well as its last east arrival.

An alternating word cannot have a left turn after such
an `ER`: an `EL` would be another east arrival, and a
`WL` another south departure. The word would end in
`ER`, making offset twelve wake. But the U branch has
`h=1` in family A, so every offset from seven through
fifteen is non-wake. This contradiction proves `H=EL`.

There is at most one south departure on twelve after `H`,
since it too would have to feed the unique final `SL`
on eleven. Because `H` is the last east arrival and twelve
is non-wake, the word on twelve therefore ends either
at `H=EL`, or with the block

```text
H=EL,WR,WL.
```

These two endings and the remaining offset-eight word B0
still require higher return arguments. They do not exclude
U, the upper two-`ER` branches of A, or family B.
