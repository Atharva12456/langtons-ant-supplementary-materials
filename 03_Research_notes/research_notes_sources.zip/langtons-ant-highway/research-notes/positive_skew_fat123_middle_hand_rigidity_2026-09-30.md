# Hand rigidity of the lower positive-skew fat-(1,2,3) middle branch

Assume finite-support periodic drift `(1,3)`, `t=3x-y`, lower cap zero, and

```
0: NR; 1: WR,WL; 2: NR,SL,NR;
3: WR,WL,ER,WL,WR,[WL]^(1-a), a=omega_3.
```

Let `b=omega_4`. Then the only possible fourth rows are

```
a=b=0: SR,SL,SR,SL;
a=0,b=1: SR,SL,SR,SL,NR;
a=b=1: SR,SL,SR.
```

This hand proof needs no growth restriction, P22 equation, width cutoff,
period congruence, or lifetime bound. It uses integer lifted times, N>0,
exact directed ordinal matching, and four-step/eight-step/twelve-step
physical first returns. The direction words are checked independently by
`work_positive_skew_caps_20260930/check_cap_normals.py`.

## Complete starting forms

Write `A=(NR,SL)`, `B=(NR,NL)`, `C=(SR,SL)`, and `Z=(NR)`.
The proved cap normal forms in
`work_positive_skew_caps_20260930/positive_skew_cap_normal_forms.md` give:

1. `A B C A^(1-a) Z^b`;
2. `C F_(2-a)(b)`, where F pairs NR with the L multiset
   `{NL, SL repeated 2-a times}` in any order, then appends `[NR]^b`;
3. two-SR words: `C C` when a=b=0, `C A SR` or `C C Z` when a=0,b=1,
   and `C SR` when a=b=1.

Cases 1 and 2 have exactly one SR and one NL on four. We exclude them
separately, then remove the unwanted two-SR case.

Use representatives `(0,-t)`, so E/W voltages are +1/-1 and vertical
voltages zero. All stable event times are integers. Put

```
v=tau(first 3:WR), w=tau(first 3:WL), so w>=v+1.
```

The first east arrival E1 on five is supplied by
`first 3:WR -> first 2:NR -> 5:E1`, giving

```
tau(5:E1)=v+2-N <= v+1.
```

## Case 1: A B C A^(1-a) Z^b

The fourth row starts `NR,SL,NR,NL,SR,SL`. Its NL and SR are its first
and second west departures, feeding `1:WR,WL`.

Let E2 be the second east arrival on five, supplied by `2:SL`. If E2
were EL, the path

```
4:SR -> 1:WL -> 2:SL -> 5:E2=EL -> 4:N arrival
                      W,S,E,N
```

would be a four-step physical first return on four. The next stable event
after that SR is SL, so a north-arrival endpoint is impossible. Thus E2=ER.

Let F1,F2,F3 be the first three north departures on five. They feed,
respectively, the two initial NR ports and the NL on four. F3 has the
forced return

```
F3 -> 4:NL -> 1:WR -> 0:NR -> 3:ER -> 4:SR
   -> 1:WL -> 2:SL -> 5:E2=ER,
```

whose directions are `NWNESWSE`. The displacement is zero and there is
no intermediate level-five event. Its endpoint is ER, so F3 is a left
turn: F3=EL. It immediately precedes E2 and must be E1, the only earlier
east arrival. In particular F2 precedes E1.

But F2 feeds the second NR on four, which follows the first SL there.
That SL is supplied by the first 3:WL at time w, so

```
tau(F2)>tau(first 4:SL)-1=w>=v+1,
tau(F2)>=v+2>v+2-N=tau(E1).
```

This contradicts F2 before E1. Therefore case 1 is impossible.

## Case 2: C F_(2-a)(b)

The fourth row begins SR,SL; its other north arrivals all occur after
this SL. Its first SR feeds `1:WR`, which then feeds zero NR and three ER.
The first 3:WL feeds that SR, so the four-step square gives

```
tau(3:ER)=w+4,
tau(first 4:SL)=w+5.
```

Every north departure on five feeds a later north arrival on four, hence
has time greater than w+4. In contrast

```
tau(5:E1)=v+2-N < w+4.
```

Thus E1 is ER and no WR precedes it. The fifth row starts with its first
ER and its first south departure.

The first west departure D1 on six feeds first 3:WR. Its forced square

```
D1 -> first 3:WR -> first 2:NR -> 5:E1=ER -> first 6:S arrival
```

has directions WNES. D1 cannot itself be that earlier south arrival, so it
is NL; its opposite-turn endpoint is SR, the second west departure D2.
No earlier NL or south arrival is available, and alternation forces six
to begin `NR,NL,SR`.

The second north departure U on seven feeds this first NL on six. The
twelve-step zero-displacement return with directions `NWNESWSWNESE` is

```
U -> 6:NL -> first 3:WR -> first 2:NR -> first 5:ER -> D2=6:SR
  -> first 3:WL -> first 4:SR -> 1:WR -> 0:NR -> 3:ER
  -> first 4:SL -> first 7:E arrival H1.
```

There is no intermediate level-seven event. U cannot be EL because H1
is the first east arrival. Thus U=WR, H1=EL, and H1 is the third north
departure on seven. The eight-step physical first return from D2, with
directions `WSWNESEN`, then forces the third north arrival on six to be
the next stable event after D2. It is NL, the third west departure D3.

The third west departure feeds the second 3:WL; its south step feeds
the third south arrival on four, which in this one-SR case is the second SL.
Therefore there is the four-step return

```
7:H1=EL -> D3=6:NL -> second 3:WL -> second 4:SL -> 7:Hj,
                          N,W,S,E.
```

It has zero displacement and no intermediate level-seven event. H1,Hj
would have to be consecutive stable visits. Yet between the first and
second SL on four there is at least one NR: every remaining L in F is
preceded by NR. Its east departure supplies an east arrival on seven
strictly between H1 and Hj. This is a skipped physical return. Case 2
is impossible.

## The unwanted two-SR word C A SR

This word is `SR,SL,NR,SL,SR` and is possible in the aggregate normal
form only when a=0,b=1. Let `q=tau(1:WL)`, `z=tau(last 3:WR)`, and
`h=tau(last 3:WL)`. The row-two order `NR,SL,NR` gives z>q, while
the row-three order gives h>z. Its last WL is the fourth south departure
on three and therefore feeds the final SR on four. That final SR is
the second west departure and feeds `1:WL`. Exact clock matching gives

```
q=h+1+1+N=h+2+N,
```

contradicting h>z>q and N>0. This excludes C A SR, leaving exactly the
three rows stated at the beginning.

## Independent finite check

`work_positive_skew_caps_20260930/verify_fat123_rigidity_csp.py`
independently checks every starting form,
using physical coordinates to generate only words compatible with forced
zero-copy next-visit constraints, then checking all integer N>=1 with Z3.
For k1 its complete stage counts are 18 -> 26 -> 212 -> 41, and all
forty-one surviving prefixes have exactly these three initial fourth rows.
The hand proof above establishes the initial rigidity independently of that
enumeration. The finite check retains every emitted physical rejection,
every rejected clock input, and all parent/count domains.
