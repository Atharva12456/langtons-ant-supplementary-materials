# Width 22 upper guard excluded for lower fat `(0,0,111)`

At growth eight and drift `(1,-3)`, the lower fat `(1,2,3)` band
`(omega_3,omega_4,j,k,l)=(0,0,1,1,1)` has two static width-22 upper-guard
wake placements after P22, rank and moment. The upper-guard early-wake
prefix lemma already excludes `{0,2,9,15,16,20,21,22}`. This certificate
excludes the other one,

```text
W=22,  O={0,2,10,12,18,20,21,22}.
```

Consequently this cap pair requires `W>=26`: width 20 is excluded by the
early-wake lemma, width 22 by its two parts, and the all-width static
classification has no width-24 placement. Wider placements and the full
drift orbit remain open. The first remaining static width is 26, with
three wake placements; this certificate does not test their stable words.

## Two-cap exclusion

The verifier grows lower words through row nine from the fixed lower band,
and upper-guard words through inward offset nine. There are 12 and 222
exact-integer-clock prefixes. A necessary full-width port-count model has
one variable for every row and port, enforces nonnegative counts, row parity,
the eight wake excesses, directional flow, and one of the three count
profiles among the 12 lower-nine prefixes. The lower cap is then extended
through row ten and the upper cap
through inward offset ten. Exact clocks yield 2,815 lower and 2,095 upper
prefixes. The full-width count model leaves 1,409 upper prefixes. A
necessary center-count lookahead then leaves 2,182 lower prefixes. Neither
filter can discard an actual orbit.

At the physical center row eleven, the upper prefixes allow 28 rotated port
count vectors. Enumerating all lower row-eleven count vectors, alternating
words, finite first returns and exact integer clocks leaves 3,395 lower
prefixes with 2,165 distinct center words. The lower row-eleven sweep checks
17,610 count options; 15,325 miss every upper center count, 115,185 of
141,699 generated adjacency words have wrong finite returns, and 23,119
more fail exact clocks. These figures leave 3,395 words.

Each upper inward-ten prefix is joined to every rotated lower center word
with the required upper row-eleven counts. There are 1,723,256 such
center-word pairs. An explicit finite wrong return rejects 1,722,896;
an exact real upper-clock relaxation rejects another 149. The remaining
center words identify 480 full-row combinations with the lower prefixes.
Twenty-five fail full-width ordinal edge balance. In each of the other
455 complete 23-row systems, a finite path returns to the same cell and
horizontal copy at the wrong next stable event. No complete word survives.

The lower clock uses integer `N>=max(6, represented event count)` with
`N=6 mod 8` and stable event gaps of at least four. Its cycle-based
implementation is an exact decision procedure for these difference
constraints, with no upper bound on `N`. The upper center clock is relaxed
to real `N>=6`, which only enlarges the candidate set. Every decisive
full-width rejection is a directly traced finite path; a quotient cycle is
never extrapolated into a physical return.

Run `python code/python/verify_lower_fat123_a0_b0_111_w22_guard.py` from
the repository root. It regenerates both caps, the count filter and every
center join without a checkpoint, then writes
`results/lower_fat123_a0_b0_111_w22_guard_checks_2026-09-27.json` with ten
complete sample word systems and paths. The separate standard-library
`code/python/check_lower_fat123_a0_b0_111_w22_guard_witnesses.py` replays
those ten paths from ordinal flow. The exhaustive verdict comes from the
first verifier; the sample checker independently checks the format and
physical meaning of its final obstructions.
