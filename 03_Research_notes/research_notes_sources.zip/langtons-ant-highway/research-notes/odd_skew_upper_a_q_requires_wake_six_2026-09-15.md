# Form Q requires a wake at six

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: in the remaining middle placement,
`E5=EL` is now forced. See
`odd_skew_upper_a_q_middle_right_exclusion_2026-09-15.md`.
The exclusion of `M_L0` in
`odd_skew_upper_a_q_ml0_exclusion_2026-09-15.md`
further leaves only `M_L1` in that placement.

At the upper cap of family A, form Q cannot have
`omega_6=0`. With `omega_6=1`, the third north arrival
on seven cannot precede its fourth west departure.
Only four words on seven remain, listed below.

Thus Q requires `h=1`, or `p=m-1`. The argument uses
stable order and same-cell first returns, without a
simulation or a bound on a black lifetime. It does not
exclude the whole Q form. Form P, family B, and the
other cap profiles in `(1,-3)` remain open.

## Fixed ports and the first north arrival on seven

The normal form is

```text
5: NR1,SL1,SR,NL,NR2,SL2,NR3,SL3;
6: WR1,WL1,ER1,EL,ER2,WL2,[WR2]^e,     e=omega_6.
```

Use `W1,...,W5` for the west departures on seven,
feeding `4:WR1,WL1,WL2,WR2,WR3`. Its north arrivals
are supplied by `6:WR1,EL,[WR2]^e` in that order.

The return through the first `WL` on four already
forces `W2=SR`, immediately followed by `W3=NL`;
the latter is the second north arrival on seven. See
`odd_skew_upper_a_two_er_normal_form_2026-09-15.md`.

The first west departure cannot be the first north
arrival `NL`: no earlier right turn would then be
available on seven. Hence `W1=SR`, and the first
north arrival is `NR`.

Let `E1,...,E6` be the east arrivals on eight, supplied
by `5:NR1,SL1,NR2,SL2,NR3,SL3`. The three-step path

```text
W1 -> 4:WR1 -> 5:NR1 -> 8:E1
```

forces `E1=ER`. A left turn would make the south
predecessor of `W1` an earlier east right turn, before
the first east arrival. Its south step therefore gives
a square from `W1=SR` to the following `SL`.

The first north arrival must precede the consecutive
pair `W2,W3`. These facts give two possible prefixes:

```text
A: W1=SR,SL,first NR,SL,W2=SR,W3=NL;
B: first NR,SL,W1=SR,SL,W2=SR,W3=NL.
```

In A, `E1=ER` is the second south departure on eight;
in B it is the third.

## W4 and W5 both turn right

If `W4=NL`, it must be the optional third north
arrival. No right turn could then occur between
`W3=NL` and `W4=NL`. Thus `W4=SR`.

There is a seven-step path

```text
W4 -> 4:WR2 -> 5:NL -> 2:WL -> 1:SL -> 4:EL
   -> 5:NR2 -> 8:E3.
```

If `E3=EL`, the south predecessor of `W4` on eight
has an eight-step first return to `E3`. It must be
`E2=ER`, immediately before it. But then

```text
5:SL1 -> 8:E2=ER -> 7:W4=SR -> 4:WR2 -> 5:NL
```

is a square with two left-turn endpoints. Hence
`E3=ER`, and its south step gives a first return
from `W4=SR` to the following `SL`.

The last west departure `W5` cannot be the remaining
north arrival `NL`, since no right turn would be
available after this `SL` and before `W5`. Therefore
`W5=SR`. If the third north arrival exists, it is `NR`.

For `e=0`, the suffix after either prefix A or B is

```text
W4=SR,SL,W5=SR,SL.
```

For `e=1`, the third north arrival `V=NR` has three
possible positions:

```text
before W4:       V=NR,SL,W4=SR,SL,W5=SR,SL;
between W4,W5:   W4=SR,SL,V=NR,SL,W5=SR,SL;
after W5:        W4=SR,SL,W5=SR,SL,V=NR,SL.
```

## The last east arrival on eight is EL

The relevant south ordinals are the same for prefixes
A and B:

| Case | E3=ER | W5 | Total south arrivals on seven |
|---|---:|---:|---:|
| `e=0` | 6 | 7 | 8 |
| `V` before `W4` | 7 | 8 | 9 |
| `V` between `W4,W5` | 6 | 8 | 9 |
| `V` after `W5` | 6 | 7 | 9 |

If `E5=EL`, the square through `W5,4:WR3,5:NR3`
forces its south predecessor on eight to be the
consecutive east arrival `E4=ER`, supplying `W5`.
In the first, second, and fourth rows this would put
the successive east right turns `E3,E4` at consecutive
south ordinals. A `WL` between them is required by
alternation, so those three rows instead have `E5=ER`.
It supplies the `SL` following `W5`.

In the first two rows `E5` is the last south departure;
hence `E6=EL`, immediately following it. In the fourth
row `E5` is the penultimate south departure. Taking
`E6=ER` would require both an intervening `WL` and
another south departure, so again `E6=EL`.

In the middle row, either `E5=ER` is the last south
departure, or `E4=ER,E5=EL` are consecutive with `E4`
at the penultimate south ordinal. In the latter case,
`E6=ER` would be both the last east arrival and last
south departure, forcing a wake on eight. Eight is
non-wake. Thus `E6=EL` in every row.

## The zero-wake band is impossible

The west departures `D1,...,D(3+e)` on nine feed

```text
6: WR1,WL1,WL2,[WR2]^e.
```

There is a square path from `D3` through
`6:WL2,5:SL3,E6=EL` to a north arrival on nine.
If `D3=NL`, its north predecessor on eight must be
`WR`, immediately before `E6`, by the corresponding
square return on eight.

In the zero-wake row the predecessor of `E6` is
instead `E5=ER`. Hence `D3=SR`. Its square return
would then have the consecutive target `NL`, producing
a fourth west departure on nine. There are only three
when `e=0`. This excludes the entire zero-wake band
of Q, for either prefix A or B.

## The third north arrival cannot precede W4

In the `V`-before-`W4` row, `E5=ER,E6=EL` are
again consecutive. The same argument forces
`D3=SR,D4=NL`, with `E6` supplying `D4`.

Let `F1,...,F7` be the east arrivals on ten. In this
row the optional north arrival `V`, supplied by the
last `WR` on six, supplies `F4`. If `F4=ER`, the path

```text
D4=NL -> 6:WR2 -> 7:V=NR -> 10:F4=ER -> south arrival on 9
```

would be a square first return with target `SR`, giving
another west departure after the last one. Thus `F4=EL`.

The south predecessor of `D3` on ten has the
eight-step first return

```text
south predecessor -> 9:D3=SR -> 6:WL2 -> 5:SL3 -> 8:E6=EL
                  -> 9:D4=NL -> 6:WR2 -> 7:V=NR -> 10:F4=EL.
```

That predecessor must therefore be `F3=ER`, immediately
before `F4`. In both prefixes A and B, `F3` is supplied
by the `SL` immediately before `W2` on seven. Thus

```text
7:SL before W2 -> 10:F3=ER -> 9:D3=SR -> 6:WL2 -> 5:SL3
               -> 8:E6=EL -> 9:D4=NL -> 6:WR2 -> 7:V=NR
```

is an eight-step first return. Its direction word is
`E S W S E N W N`. It skips `W2=SR,W3=NL` between
the displayed endpoints on seven. This is impossible.

## Remaining Q words

Only `e=1`, with `V` between `W4,W5` or after `W5`,
remains. The four complete words on seven are

```text
A, middle: SR,SL,NR,SL,SR,NL,SR,SL,NR,SL,SR,SL;
B, middle: NR,SL,SR,SL,SR,NL,SR,SL,NR,SL,SR,SL;
A, after:  SR,SL,NR,SL,SR,NL,SR,SL,SR,SL,NR,SL;
B, after:  NR,SL,SR,SL,SR,NL,SR,SL,SR,SL,NR,SL.
```

In every word `E6=EL`. In the after case `E5=ER`;
the middle case still permits either turn at `E5`.
These four words and their higher continuations are
not excluded here. Since Q now requires `h=1`, upper
offsets seven through fifteen are all non-wake.
