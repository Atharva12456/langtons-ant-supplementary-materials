# Upper-guard wake families above lower fat123 `(0,1,111)`

For drift `(1,-3)` and growth eight, normalize the lower transverse level
to zero and let the upper level be the even integer `W`. Assume the lower
fat `(1,2,3)` initial band is `(omega_3,omega_4,j,k,l)=(0,1,1,1,1)`
and the upper cap is a guard. P22, the rank parity and the moment condition
give the six families below. A stronger upper-guard hand lemma leaves
only the even-offset family with `i=0`, at every width and period.

## Complete arithmetic classification

The six fixed wakes are `{0,2,4,W-2,W-1,W}`. The other two have upper
inward offsets `u<v`, so the full wake set is

```text
O = {0,2,4,W-2,W-1,W,W-u,W-v}.
```

Write `W=6m+r`, where `r` is `0`, `2`, or `4`. Exactly the following
choices pass P22, even rank and moment `3 mod 4`:

| Offsets | Index bounds | `r=0` | `r=2` | `r=4` |
|---|---|---|---|---|
| `u=6i+4, v=6j+4` | `0<=i<j<=floor((W-9)/6)` | `m+i+j` odd | even | odd |
| `u=6i+1, v=6j+1` | `1<=i<j<=floor((W-6)/6)` | `m+i+j` even | odd | even |

An empty index range contributes no wake set. These are necessary wake
schedules; satisfying them does not construct a highway.

To prove completeness, split transverse levels by residue modulo three.
Among the fixed wakes, two residue fibres already have two even wakes.
The remaining fibre contains one even wake and the odd wake `W-1`.
P22 requires signed wake count `2 mod 4` in each fibre. Both free wakes
must therefore lie in this last fibre and have the same parity. In upper
offset coordinates this is `u,v = 1 mod 3`, giving precisely the two
rows of the table. The bounds say that both free wakes lie between
physical levels five and `W-3`.

The interlacing number is even automatically. Let `I_ab` count pairs
`x<y` with `x` in residue fibre `a` and `y` in fibre `b`, for `a<b`.
The four-wake fibre has one fixed endpoint below both free wakes and
one above them. Each two-wake fibre also has one wake on either side
of both free wakes. Ordering these fixed endpoints gives
`(I_01,I_02,I_12)=(2,4,4),(5,3,4),(5,4,1)` for `r=0,2,4`, respectively.
Their sums are `10,12,10`, independently of the free wakes' positions
and parity.

For the moment `M=sum_{t in O} (-1)^t floor(t/3)`, the six fixed wakes
contribute `2m+1`. The two extra even-level wakes give

```text
M = 2m - 2(i+j) + 1  (mod 4),  r=0 or 4;
M = 2m - 2(i+j) + 3  (mod 4),  r=2.
```

The two extra odd-level wakes give

```text
M = -2m + 2(i+j) + 3  (mod 4),  r=0 or 4;
M = -2m + 2(i+j) + 1  (mod 4),  r=2.
```

Setting `M=3 mod 4` yields the parity conditions in the table.

## An all-width exclusion

The [upper-guard hand certificate](odd_skew_upper_guard_hand_certificate_2026-09-24.md)
excludes a wake at inward offset seven after quiet offsets three through
six. The [extension](odd_skew_upper_guard_offsets_3_6_impossible_2026-09-26.md)
also excludes a non-wake offset seven. Together they prove that an upper
guard **must wake at least one of offsets three through six**. The proof
uses finite same-cell returns and one exact clock inequality, without a
width or period bound.

Every odd-offset family has its first extra wake at offset at least seven,
and every even-offset family with `i>=1` has its first extra wake at
offset at least ten. Their offsets three through six are quiet, so all
are excluded. Only the even-offset branch `i=0` remains:

```text
u=4, v=6j+4,  1<=j<=floor((W-9)/6),
O={0,2,4,W-2,W-1,W,W-4,W-(6j+4)}.
```

The table's moment parity is still required: `m+j` is odd for `r=0,4`
and even for `r=2`. These are necessary placements, not realized highways.

## Reproduction and scope

Run `python code/python/lower_fat123_a0_b1_111_upper_guard_schedules.py`.
The checker independently enumerates all wake pairs at every even width
from eight through 160 and compares them with the formulas. It checks
7,969 static placements, of which 456 have the earlier forbidden
offset-seven pattern. The stronger lemma removes 7,500 placements,
leaving 469 with `i=0` through width 160. Its result is
`results/lower_fat123_a0_b1_111_upper_guard_schedules_2026-09-24.json`.

The finite audit checks the formulas; the residue and moment argument
above establishes their all-width scope, and the hand lemma gives the
all-width exclusion. The cap pair remains open.
