# Partial rails at drift (4,-4): a relaxed family

Date: 2026-09-04.

Subsequent status: [the alternating-half-rail argument](m4_alternating_half_rail_exclusion_2026-09-06.md)
excludes the explicit family below using additional visit-order information. Its
compatibility with the stated rank, residue, and additive tests remains valid.
The final discussion records the gap before that later argument.

## Scope

This note gives an infinite family of **relaxed boundary and parity data, not P3 traces**. The family satisfies the coordinate-fibre wake congruences, the rank-sign obstruction, and every drift-periodic additive mod-four endpoint charge. The upper rail is only partially occupied. Consequently, the full-rail rank exclusion cannot be extended to the whole drift orbit using those conditions alone.

No legal chronological ordering, nonnegative integer edge flow, or actual period is constructed here. In particular, this does not establish existence of a growth-eight highway or close any remaining orbit. The distinction matters because extremal rigidity makes each *visited* rail class a singleton; it does not require every rail lane to be visited.

The rank formulas used below are those of the rank factorization in `paper/comprehensive_main.tex` and the conditional full-rail calculation in `growth8_extremal_m4_exclusion_2026-08-22.md`. The complete additive-weight equation is recorded in `growth12_research_2026-08-17.md`; the visit-residue law is in `growth8_diagonal_coordinate_residues_2026-08-23.md`. The calculations here are symbolic.

## The boundary

Put

\[
d=(4,-4),\qquad t=x+y,\qquad r=x\pmod4.
\]

Use the phase convention that even levels contain vertical-arrival classes, denoted \(Q\), and odd levels contain horizontal-arrival classes, denoted \(C\). Let \(D_{t,r}\in\{0,1\}\) be the wake indicator. First take \(W=4L\), with \(L\ge1\), and set

\[
\begin{aligned}
D_{1,r}&=1 &&(r=0,1,2,3),\\
D_{3,r}&=1 &&(r=0,2),\\
D_{W+1,r}&=1 &&(r=1,3),
\end{aligned}
\]

with all other entries zero. The final family will have \(L=2j+1\), \(j\ge1\), so that \(W=8j+4\).

There are eight horizontal wake classes and no vertical wake classes. The lower rail has four occupied lanes and the upper rail has two. Each residue of \(x\) occurs twice. For \(y=t-r\pmod4\), the lower rail contributes all four residues once, the two level-three classes contribute residues \(3,1\), and the upper rail contributes residues \(0,2\). Thus each residue of \(y\) also occurs twice. All these wakes have the horizontal checker sign, so every coordinate fibre has signed wake sum \(-2\equiv2\pmod4\), as required by the coordinate-fibre wake congruence.

## The finite edge-parity solution

All variables in this section lie in \(\mathbb F_2\). At an odd-level class \((j,r)\), write \(s_{j,r}\) and \(n_{j,r}\) for its south and north outgoing edge parities. At an even-level class \((t,r)\), write \(w_{t,r}\) and \(e_{t,r}\) for its west and east outgoing edge parities. Their targets are

\[
\begin{array}{c|c}
\text{edge}&\text{target}\\ \hline
S&(j-1,r)\\
N&(j+1,r)\\
W&(t-1,r-1)\\
E&(t+1,r+1).
\end{array}
\]

The zero vertical boundary gives

\[
w_{t,r}=e_{t,r}=a_{t,r},\qquad
n_{j,r}=b_{j,r},\qquad s_{j,r}=b_{j-2,r}.
\]

The two remaining boundary equations are

\[
b_{j,r}+b_{j-2,r}=D_{j,r},\qquad
a_{j-1,r-1}+a_{j+1,r+1}=D_{j,r}.
\tag{1}
\]

Vanishing below the strip determines the solution successively; vanishing above it can then be checked directly. Write

\[
\mathbf f=(1,1,1,1),\quad
\mathbf v=(1,0,1,0),\quad
\mathbf o=(0,1,0,1),\quad
n_* = W/2-1=2L-1.
\]

The solution is

\[
\begin{array}{c|c}
\text{levels}&\text{parity vector}\\ \hline
b_1&\mathbf f\\
b_3,b_5,\ldots,b_{W-1}&\mathbf o\\
a_2&\mathbf f\\
a_4,a_6,\ldots,a_W&\mathbf v.
\end{array}
\tag{2}
\]

All unlisted vectors vanish. There are \(n_*\) occurrences of each of the two repeated masks. Substitution into (1) verifies the lower boundary, level three, and the upper boundary separately. This is a finite parity flow; it is not an integer-flow or itinerary construction.

## The local rank correction

Let \(p_v\) be the sum, modulo two, of the positive incoming and positive outgoing edge parities at a class. Here positive means north on vertical edges and east on horizontal edges. In the present coordinates,

\[
p_{Q(t,r)}=b_{t-1,r}+a_{t,r},\qquad
p_{C(j,r)}=a_{j-1,r-1}+b_{j,r}.
\]

The local rank correction is

\[
\Lambda=\sum_Q p_v(D_v+1)+\sum_C D_v(p_v+1)\pmod2.
\tag{3}
\]

At level two, every \(Q\)-value of \(p\) is zero. At each even level from four through \(W\), every \(Q\)-value is one, contributing four to (3). At every occupied horizontal boundary class, \(p=1\); the other horizontal classes have \(D=0\). Therefore

\[
\Lambda=0.
\tag{4}
\]

The individual interior vertical corrections need not vanish; their sum does.

## The global edge inversions

Order source edge blocks lexicographically by level, then lane \(0,1,2,3\), then negative before positive. Use the corresponding order at targets, including the incoming port. Let \(E\) be the parity of the resulting edge-block permutation, weighted by the edge parities. An inversion can only involve equal source levels or source levels differing by one or two.

The adjacent-level contributions cancel in pairs. For each odd \(j\), the positive edges from \(C_j\) crossing the negative edges from \(Q_{j+1}\) contribute \(|b_j||a_{j+1}|\). The positive edges from \(Q_{j+1}\) crossing the negative edges from \(C_{j+2}\) contribute the same quantity. Here \(|\cdot|\) denotes the number of ones in a mask.

For the remaining horizontal-source terms,

\[
E_C=\sum_{j\text{ odd}}\left[
\binom{|b_j|}{2}+|b_j|
+\sum_{r<s}b_{j,r}b_{j-2,s}
\right]\pmod2.
\tag{5}
\]

The last sum is the same-level positive/negative crossing count. The first two terms count north edges from level \(j\) against south edges from level \(j+2\): their common target level has the reversed port order when the target lanes agree, so an inversion occurs for \(r\ge s\).

For vertical sources, put

\[
\rho_+(r)=r+1\pmod4,\qquad \rho_-(r)=r-1\pmod4,
\]

with values taken in \(\{0,1,2,3\}\). Then

\[
\begin{aligned}
E_Q=\sum_{t\text{ even}}\bigg[&
\binom{|a_t|}{2}
+a_{t,0}(|a_t|-a_{t,0})
+a_{t,3}(|a_t|-a_{t,3})\\
&+\sum_{r,s}a_{t,r}a_{t+2,s}
\mathbf1_{\rho_+(r)\ge\rho_-(s)}\bigg]\pmod2.
\end{aligned}
\tag{6}
\]

The binomial term is the same-level mixed-port count. The next two terms are the cyclic lane-order inversions: west edges wrap lane zero to lane three, and east edges wrap lane three to lane zero. The last term compares east edges from level \(t\) with west edges from level \(t+2\); equal target lanes again invert the two ports.

Equations (5) and (6) can be evaluated without a case search. In (5), the self-term for \(\mathbf f\) is \(6+4=10\), and the self-term for \(\mathbf o\) is \(1+2=3\). The \(\mathbf o,\mathbf f\) cross-term has two pairs, while each \(\mathbf o,\mathbf o\) cross-term has one. Thus

\[
E_C=n_*+(n_*-1)=1\pmod2.
\]

In (6), the self-term for \(\mathbf f\) is \(6+3+3=12\). The self-term for \(\mathbf v\) is \(1+1=2\). The separated-level \(\mathbf f\)-to-\(\mathbf v\) term has four pairs: one against target lane three and three against target lane one. A \(\mathbf v\)-to-\(\mathbf v\) term has three pairs. Consequently

\[
E_Q=n_*-1=0\pmod2,
\qquad E=E_C+E_Q=1.
\tag{7}
\]

For a pure-horizontal growth-eight trace the period congruence is \(N\equiv0\pmod8\), so the number of left turns would satisfy \(K=(N-8)/2\equiv0\pmod2\). The rank-sign condition is \(K\equiv1+E+\Lambda\). Equations (4) and (7) give precisely zero on its right-hand side. The rank condition therefore does not exclude this boundary family.

## Every additive mod-four charge

Let \(w_{r,t}\in\mathbb Z/4\mathbb Z\) be any drift-periodic zero-four-corner weight. In these coordinates its defining equation is

\[
w_{r,t}+w_{r+1,t+1}+w_{r,t+1}+w_{r+1,t+2}=0.
\tag{8}
\]

Write \(w_t=(w_{r,t})_r\), and let \((Pz)_r=z_{r+1}\). Equation (8) is

\[
w_t+(I+P)w_{t+1}+Pw_{t+2}=0.
\tag{9}
\]

The two initial vectors \(w_0,w_1\) are arbitrary, and (9) determines the weight in both directions because \(P\) is invertible. Thus the following calculation treats the whole additive family, not a selected list of test weights.

Put \(A_t=\sum_r w_{r,t}\) and \(S=A_0+A_1\). If \(z_t=(-1)^t w_t\), then

\[
z_{t+1}-z_t=P^{-t}(-w_1-w_0).
\]

Summing four consecutive differences gives \(z_{t+4}=z_t-S\mathbf f\). In particular, at odd levels,

\[
w_{t+4}=w_t+S\mathbf f.
\tag{10}
\]

Define the even- and odd-lane sums

\[
V_t=w_{0,t}+w_{2,t},\qquad O_t=w_{1,t}+w_{3,t}.
\]

Equation (10) yields \(O_{W+1}=O_1+2LS\). Directly from (9),

\[
w_3=(P^{-1}+P^{-2})w_0+(I+P^{-1}+P^{-2})w_1,
\]

so that

\[
V_3=A_0+2V_1+O_1.
\tag{11}
\]

For completeness, the north-heading potential monodromy along \(d\) is

\[
M_N=A_0-A_1.
\tag{12}
\]

One way to obtain (12) is to join \((r,-r)\) to \((r+1,-r-1)\) by an east step and a south step. The two right-turn cocycle equations, together with \(F_S=F_N-2w\) at the endpoint, give

\[
F_N(r+1,-r-1)-F_N(r,-r)
=-w(r,-r)-w(r+1,-r)+2w(r+1,-r-1).
\]

Summing over four successive lanes gives (12). This is a potential calculation along a lattice path, not a proposed ant itinerary.

The use of levels zero and one does not require the trace to visit level zero. Summing (9) over lanes shows that \(A_p-A_{p+1}=A_0-A_1\) at every even level \(p\). Thus (12) is also the north-heading monodromy at an actual even-level starting class.

The total wake weight is \(A_1+V_3+O_{W+1}\). Its additive endpoint defect is therefore

\[
\begin{aligned}
\sum_{D=1}w+M_N
&=A_0+V_3+O_1+2LS\\
&=2(A_0+V_1+O_1)+2LS\\
&=2(L+1)S\pmod4.
\end{aligned}
\tag{13}
\]

Since \(S\) is arbitrary, every additive charge vanishes exactly when \(L\) is odd. Taking \(L=2j+1\), \(j\ge1\), gives the asserted widths

\[
W=8j+4\in\{12,20,28,\ldots\}.
\]

## Coordinate-fibre visit residues

The local port congruences prescribe a class multiplicity \(m_v\), modulo four, by

\[
m_v\equiv D_v+2p_v\quad(Q),\qquad
m_v\equiv2p_v-D_v\quad(C).
\]

For this family, every horizontal wake has multiplicity residue one and every other horizontal class has residue zero. The vertical level-two classes have residue zero; every lane at each vertical level from four through \(W\) has residue two.

Each \(x\)-residue fibre, and likewise each \(y\)-residue fibre, consequently has total visit residue

\[
\nu_F\equiv2+2n_*=4L\equiv0\pmod4.
\]

Its unsigned wake count is \(\Omega_F=2\), so \(\nu_F-\Omega_F\equiv2\pmod4\), the required coordinate-fibre value for either nonzero drift component. Again, these are compatible multiplicity residues, not a realization by integer port counts.

## What remains

The family passes the rank-sign test, the complete additive mod-four endpoint test, and the stated coordinate-fibre tests. Any exclusion of these placements must use an additional condition, such as integer-flow realizability, stable port order, or physical chronology. The full-rail argument does not supply that condition for a partially occupied upper rail.
