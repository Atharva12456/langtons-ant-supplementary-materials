# Three two-ER forms at the upper cap of family A

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: form R is excluded at the upper cap
of family A in `odd_skew_upper_a_r_exclusion_2026-09-15.md`.
Only P and Q remain there. P still permits `e=0` or
`1`; Q now requires `e=1`, by
`odd_skew_upper_a_q_requires_wake_six_2026-09-15.md`.
The three-form classification below is the earlier local
reduction, which also applies without that upper-cap
exclusion's hypotheses.

The upper cap in family A now has exactly two `ER` ports
at offset six. Let `e=omega_6`. Its remaining possibilities
through offsets five and six are

| Form | Offset five | Offset six |
|---|---|---|
| P | `SR,SL,NR,NL,NR,SL,NR,SL` | `ER,EL,ER,WL,WR,WL,[WR]^e` |
| Q | `NR,SL,SR,NL,NR,SL,NR,SL` | `WR,WL,ER,EL,ER,WL,[WR]^e` |
| R | `NR,SL,SR,NL,NR,SL,NR,SL` | `ER,WL,ER,WL,WR,EL,[WR]^e` |

Both values `e=0,1` remain in each form, giving six
necessary local bands, not six realizations. In family A,
`e=1` means `h=1`, or `p=m-1`; `e=0` means `h>=2`.
These bands and family B remain open.

The reduction below uses only same-cell first returns. In
fact, the three-form statement holds at either `(1,2,2)`
cap with `omega_4=1,omega_5=0` and two `ER` ports at
offset six. It does not use the later non-wake band of
family A or a longitudinal time comparison.

## The square through offset five

The two-sided normal form gives

```text
4: WR,WL,ER,WL,WR,EL,WR
5 A: SR,SL,NR,NL,NR,SL,NR,SL
5 B: NR,SL,SR,NL,NR,SL,NR,SL.
```

With two `ER` ports, the complete count row on six is

```text
(ER,EL,WR,WL)=(2,1,1+e,2).
```

The south predecessor of `5:SR` has the square return
through `5:SR,2:WR,3:NR` to the second east arrival
on six. The source is the first south departure for word
A and the second for word B. Its source and target are
consecutive stable events with opposite turns.

For A, if the second east arrival is `EL`, the word
starts `ER,EL`. The remaining east right turn can occur
before both remaining `WL` ports, between them, or after
both. If the second east arrival is `ER`, its predecessor
is the first south departure `WL`, preceded by the first
east arrival `EL`. This forces the prefix
`WR,EL,WR,WL,ER` and uses both available `WR` ports,
so `e=1`.

For B, an `EL` at the second east arrival forces the
prefix `WR,WL,ER,EL`. If the second east arrival is
`ER`, its immediately preceding `WL` is the second south
departure. The first east arrival must also be `ER`:
an earlier `EL` and two earlier `WL` ports would require
three earlier `WR` ports, but at most two are available.
The prefix is therefore `ER,WL,ER`.

Alternation gives the following complete list before further
return restrictions:

| Name | Offset five | Offset six | Allowed e |
|---|---|---|---|
| P0 | A | `ER,EL,ER,WL,WR,WL,[WR]^e` | 0 or 1 |
| P1 | A | `ER,EL,WR,WL,ER,WL,[WR]^e` | 0 or 1 |
| P2 | A | `ER,EL,WR,WL,WR,WL,ER` | 1 |
| P3 | A | `WR,EL,WR,WL,ER,WL,ER` | 1 |
| Q0 | B | `WR,WL,ER,EL,ER,WL,[WR]^e` | 0 or 1 |
| Q1 | B | `WR,WL,ER,EL,WR,WL,ER` | 1 |
| Q2 | B | `ER,WL,ER,EL,WR,WL,[WR]^e` | 0 or 1 |
| Q3 | B | `ER,WL,ER,WL,WR,EL,[WR]^e` | 0 or 1 |

Counting the separate values of `e`, there are thirteen
initial combinations. The following returns exclude seven.

## The initial ER,EL pair excludes P1 and P2

Let `W1,...,W5` be the west departures on seven, feeding
the west arrivals `WR,WL,WL,WR,WR` on four. The fixed
path from `W2` starts

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> first east arrival on 6.
```

For P0, P1, and P2, it continues through
`5:SR,2:WR,3:NR` to the second east arrival `EL`, then
north. This twelve-step first return ends at the first
north arrival on seven. Thus its source is `W2=SR`
and its consecutive target is `W3=NL`.

The square

```text
6:EL -> 7:W3=NL -> 4:second WL -> 3:last SL
     -> third east arrival on 6
```

must consequently join consecutive stable events. It skips
`WR,WL` in P1 and two such pairs in P2. Both are
impossible. P0 is not excluded by this square.

## The same square excludes Q1

For Q0 and Q1, the first south departure on six is
`WL`; the first `ER` feeds `5:SR`. The return from
`W2` again ends at the second east arrival `EL`, but
this is now the second north departure on six.

If `W2=NL`, it would be the first north arrival on seven,
supplied by the initial `6:WR`. The eight-step first return

```text
6:first WR -> 7:W2=NL -> 4:first WL -> 3:SR -> 0:WR
           -> 1:NR -> 4:ER -> 3:first SL -> 6:first ER
```

would have two right-turn endpoints. Hence `W2=SR`,
with consecutive target `W3=NL`. The square from `6:EL`
through `W3,4:second WL,3:last SL` to the third east
arrival now skips `WR,WL` in Q1. This excludes Q1,
but not Q0.

## The first-EL word P3 is impossible

For P3, the return from `W2` ends at the first east
arrival `EL` on six, the second north arrival on seven.
If `W2=SR`, its target is `W3=NL`, and the same square
from this `EL` to the last `ER` on six skips intervening
stable visits. Thus `W2=NL`, the first north arrival on
seven. The earlier west departure is `W1=SR`, immediately
followed by `W2=NL`.

Label the east arrivals on eight by `Ei`. Since the word
on five is A, the three-step path from `W1` through
`4:first WR,5:first NR` ends at `E2`. It cannot turn
right: its south step would return from `W1=SR` to
`SL`, rather than its immediate successor `W2=NL`.
Hence `E2=EL`, with consecutive predecessor `E1=ER`.
They are the initial two stable events on eight, because
`E1` supplies the first south arrival `W1` on seven.

The four west arrivals on six in P3 are `WR,WR,WL,WL`.
Let their matching west departures on nine be `D1,...,D4`.
The third has the twelve-step first return

```text
D3 -> 6:first WL -> 5:SR -> 2:WR -> 3:NR -> 6:second ER
   -> 5:first SL -> 8:E1=ER -> 7:W1=SR -> 4:first WR
   -> 5:first NR -> 8:E2=EL -> first north arrival on 9.
```

Its source cannot be `NL` before the first north arrival.
Thus `D3=SR`, with consecutive target `D4=NL`. The
square

```text
8:E2=EL -> 9:D4=NL -> 6:second WL -> 5:second SL -> 8:E4
```

skips `E3` in east-arrival order. This excludes P3.

## The final EL excludes Q2

The left-return obstruction in
`odd_skew_upper_a_single_er_reduction_2026-09-14.md`
applies to word B whenever the last east arrival on six
is `EL`, regardless of the number of `ER` ports. It
forces `W3=NL` and an incoming `WR` immediately before
that last `EL` on six.

For completeness, an `SR` at `W3` would return to
`W4=NL`. The path from `W4` to `E3` then forces
`E3=EL`, with `E2=ER` supplying `W3`. The resulting
eight-step first return

```text
5:SL1 -> 8:E2=ER -> 7:W3=SR -> 4:second WL -> 3:last SL
      -> 6:last EL -> 7:W4=NL -> 4:second WR -> 5:NL
```

has two left-turn endpoints. Hence `W3=NL`; the square
through `4:second WL,3:last SL` forces the claimed
immediately preceding `WR` on six.

In Q2 the last `EL` is instead immediately preceded by
`ER`, so Q2 is impossible. Q3 has the required `WR`
predecessor and is not excluded by this argument.

Only P0, Q0, and Q3 remain. These are the forms P, Q,
and R in the statement. Their higher continuations still
require separate arguments.
