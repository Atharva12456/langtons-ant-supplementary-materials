# Family B has a forced lower level-nine word

22 September 2026. This is a local necessary condition, not an exclusion of Family B or the `(1,-3)` orbit.

In the September 13 Family B wake table,

```text
W=6m+4,
O={0,5,6,8,6p+2,6r+4,W-2,W},
2<=p<r<=m-1,  p+r odd.
```

Hence `6p+2>=14`, `6r+4>=22`, and `W-2>=26`, so `omega_9=0`. The lower cap has level six `ER,EL,ER` and two possible level-eight words, as proved in `odd_skew_fat122_three_visit_six_2026-09-12.md`:

```text
8A: ER,EL,WR,WL,WR,WL,WR,WL,ER
8B: WR,EL,WR,WL,ER,WL,WR,WL,ER.
```

Both level-eight words have exactly four north departures (`EL` once, `WR` three times) and no south arrivals. Level six has no east departures and no west arrivals. Directional balance into odd level nine therefore gives four `NR`, zero `NL`, zero `SR`, and four `SL` after its non-wake right/left balance. Alternating turns starting with right force the unique word

```text
9: NR,SL,NR,SL,NR,SL,NR,SL.
```

The checker `code/python/verify_family_b_level9_word.py` runs `p2_research.row_options` and exhaustive `stable_words` separately for both level-eight words and gets exactly one count row and this one word in each branch. It also checks that this extension satisfies the local physical first-return condition. At level ten, the same raw count enumeration finds 32 words per branch; this note makes no claim about their later continuation or global tour connectivity.
