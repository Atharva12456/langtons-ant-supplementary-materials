# The offset-eight words remaining for Q

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: suffixes `M_R0,M_R1` are excluded
for all four prefixes in
`odd_skew_upper_a_q_middle_right_exclusion_2026-09-15.md`.
The further exclusion of `M_L0` is in
`odd_skew_upper_a_q_ml0_exclusion_2026-09-15.md`.
The list below now leaves twelve formal words, using
only `M_L1,A_0,A_1` as suffixes.

The four offset-seven words left for Q determine a
finite list of full words on eight. There are four
possible prefixes through `E3=ER`. Each can be followed
by one of four suffixes in the middle placement, or
one of two suffixes in the after placement.

These are necessary words, not realizations. No whole
remaining Q word is excluded here. The split at `E5`
in the middle placement remains unresolved.

Use the notation of
`odd_skew_upper_a_q_requires_wake_six_2026-09-15.md`.
The north arrival `V=NR` on seven is supplied by the
last `WR` on six. Its placement is either between
`W4,W5` or after `W5`. The prefixes A and B refer
to the two orders before `W3=NL` on seven.

## The second west departure on nine

The west departures on nine feed

```text
D1 -> 6:WR1;
D2 -> 6:WL1;
D3 -> 6:WL2;
D4 -> 6:WR2.
```

The turn at `E2` determines the turn at `D2`:

```text
E2=ER  => D2=SR;
E2=EL  => D2=NL, supplied by WR immediately before E2.
```

For the first claim, suppose `D2=NL`. Its north
predecessor on eight has the square first return

```text
north predecessor -> 9:D2=NL -> 6:WL1 -> 5:SL1 -> 8:E2.
```

If `E2=ER`, that predecessor must be `EL`, immediately
before `E2`. It would be the first east arrival `E1`,
which is already `ER`. Hence `D2=SR`.

For the second claim, suppose `E2=EL,D2=SR`. The
square from `D2` through `6:WL1,5:SL1,E2` forces its
consecutive target to be `D3=NL`, supplied by `E2`.
Then

```text
8:E2=EL -> 9:D3=NL -> 6:WL2 -> 5:SL3 -> 8:E6=EL
```

is a square with two left-turn endpoints. Thus
`D2=NL`. Its incoming square on eight forces the
`WR` immediately before `E2`.

## Four prefixes through E3

The south ordinals on eight are fixed through `E3`:

```text
prefix A: E1=ER is second;  E3=ER is sixth;
prefix B: E1=ER is third;   E3=ER is sixth.
```

The fifth south departure, supplying `W4=SR`, is
`WL`, immediately before `E3=ER`. Its eight-step
first return through `W4,4:WR2,5:NL,2:WL,1:SL,4:EL,
5:NR2` also fixes that gap to eight.

If `E2=ER`, successive east right turns require a
`WL` between them. Prefix B would put `E2` no earlier
than the fifth south ordinal and `E3` no earlier than
the seventh. It is therefore impossible. In prefix A,
`E2=ER` must be the fourth south departure, giving
the first prefix below.

If `E2=EL`, its forced incoming `WR` rules out placing
it immediately after `E1=ER`. It cannot follow the fifth
south departure either, since that `WL` immediately
precedes `E3`. In A it can follow the third or fourth
south departure; in B only the fourth. Alternation gives
exactly four prefixes:

```text
A_R:  WR,WL,E1=ER,WL,E2=ER,WL,E3=ER;

A_L3: WR,WL,E1=ER,WL,WR,E2=EL,WR,WL,WR,WL,E3=ER;

A_L4: WR,WL,E1=ER,WL,WR,WL,WR,E2=EL,WR,WL,E3=ER;

B_L4: WR,WL,WR,WL,E1=ER,WL,WR,E2=EL,WR,WL,E3=ER.
```

In `A_R`, `D2=SR`; in the other three, `D2=NL`.

## Four suffixes for the middle placement

Here `E3=ER` is the sixth south departure, `W5` is
the eighth south arrival on seven, and there are nine
south departures on eight.

If `E5=ER`, it is the ninth and last south departure,
immediately followed by `E6=EL`. The eighth south
departure is `WL`, immediately before `E5`, by the
square through `W5,4:WR3,5:NR3`. Taking `E4=ER`
would exceed the nine south departures, so `E4=EL`.
It can occur before or after the seventh south departure,
but not after the eighth.

If `E5=EL`, its square forces the consecutive pair
`E4=ER,E5=EL`, with `E4` the eighth south departure.
The seventh is the `WL` between `E3` and `E4`.
The ninth is also `WL`, either before or after `E6=EL`.

Thus append one of the following suffixes after `E3`
in any of the four prefixes above. Subscripts on `WL`
give its south ordinal on eight.

```text
M_R0: E4=EL,WR,WL7,WR,WL8,E5=ER,E6=EL;
M_R1: WL7,WR,E4=EL,WR,WL8,E5=ER,E6=EL;

M_L0: WL7,E4=ER,E5=EL,WR,WL9,WR,E6=EL;
M_L1: WL7,E4=ER,E5=EL,WR,E6=EL,WR,WL9.
```

## Two suffixes for the after placement

Here `E3=ER` is the sixth south departure, `W5` is
the seventh south arrival, and `E5=ER` is the eighth
south departure. The seventh is a `WL` immediately
before `E5`. The port `E4` must be `EL`, before that
`WL`, so it immediately follows `E3`.

The remaining south departure is a `WL`, before or
after `E6=EL`. The two suffixes after `E3` are

```text
A_0: E4=EL,WR,WL7,E5=ER,WL9,WR,E6=EL;
A_1: E4=EL,WR,WL7,E5=ER,E6=EL,WR,WL9.
```

Every suffix has seven events. The full word on eight
therefore has fourteen visits when its prefix is `A_R`,
and eighteen for each of the other prefixes. There are
sixteen formal middle words and eight formal after words
before imposing further return restrictions.

## Consequences when E5 and E6 are consecutive

In `M_R0,M_R1,A_1`, the final east pair is the
consecutive pair `E5=ER,E6=EL`. The square at `D3`
therefore forces `D3=SR,D4=NL`, with `E6` supplying
`D4`: an `NL` at `D3` would require `WR` immediately
before `E6` instead.

Write `Fj` for the east arrival on ten supplied by
`V=NR`. Since `D4` is the last west departure, its
square through `6:WR2,V,Fj` rules out `Fj=ER`.
Thus `Fj=EL`. The south predecessor of `D3` on ten
then has an eight-step first return to `Fj`, forcing
the consecutive pair `F(j-1)=ER,Fj=EL`.

Consequently,

```text
M_R0 or M_R1: F4=ER,F5=EL are consecutive;
A_1:         F5=ER,F6=EL are consecutive.
```

The same conclusion holds in any other suffix if
`D3=SR`, because its square then gives `D4=NL`
supplied by `E6`. These conditions do not yet exclude
the remaining Q continuations.
