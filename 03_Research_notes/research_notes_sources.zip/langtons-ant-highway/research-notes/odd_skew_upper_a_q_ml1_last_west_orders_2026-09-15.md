# The last west-departure orders in Q, M_L1

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

In `M_L1`, the case `D4=SR` after the last north
arrival on nine is impossible. If `D4=SR`, it must
precede that north arrival. The alternative `D4=NL`
remains open.

The resulting endings on ten are restricted below.
In all remaining cases the ending on eleven is

```text
SR,SL,SR,NL,NR,SL.
```

This does not exclude the entire `M_L1` suffix or Q.

## Data and two square constraints

The suffix on eight is

```text
E3=ER,L7=WL,E4=ER,E5=EL,b=WR,E6=EL,c=WR,L9=WL.
```

The established turn `D3=NL` on nine is supplied
by `b`; its following `NR` is supplied by `E6`.
The final north arrival is supplied by `c`. Write
`Vc` for that arrival when it is `NR` rather than
the last west departure `D4=NL`.

The east arrivals `F4,F5,F6,F7` on ten are supplied
by the `SL` after `W4`, the middle north arrival,
the following `SL`, and the final `SL` on seven.
The first of those two later `SL` ports is supplied
by `L7`; the last by `L9`.

Two square constraints will be used repeatedly:

1. If `F6=EL`, it must have `WR` immediately before
   it on ten. To see this, let `P7` be the west
   departure on eleven feeding `L7`. An `SR` there
   would return to the next west departure `NL`,
   feeding `b`, and force a square from `L7` to `b`
   that skips `E4,E5`. Thus `P7=NL`. Its incoming
   square on ten forces the claimed `WR` predecessor.

2. If `F7=EL`, it must also have `WR` immediately
   before it on ten. The last west departure on
   eleven feeds `L9`; its square through the final
   `SL` on seven and `F7` cannot have an `SR` source,
   since that would give another west departure after
   the last one. Its `NL` source therefore has the
   required incoming `WR` predecessor on ten.

## A consequence of D4=SR and F5=EL

Whenever these two turns occur, the square through
`D4,6:WR2`, the middle north arrival on seven, and
`F5` forces the consecutive pair `F4=ER,F5=EL`.

The west departure on eleven feeding `L5`, the `WL`
immediately before `E3`, must then be `SR`: an `NL`
source would require `F3=EL` and a square on eight
that skips `E2`. Its sixteen-step first return through
`F4,D4,6:WR2` and `F5` forces the next west departure,
feeding `L7`, to be `NL`, supplied by `F5`. The square
through `L7` and the `SL` after the middle north
arrival consequently forces `F6=ER`.

These are the same paths used in the last section of
`odd_skew_upper_a_q_middle_third_west_2026-09-15.md`;
none depends on the position of the final `c=WR`.

## D4=SR cannot follow Vc

Suppose the ending on nine is

```text
...,D3=NL,NR from E6,SL,Vc=NR,SL,D4=SR,SL.
```

If `F5=ER`, its square from `D4` supplies the final
`SL` on nine, making `F5` the last south departure
on ten. Thus `F6=EL` immediately follows `F5=ER`.
This contradicts square constraint 1.

If `F5=EL`, the preceding argument forces
`F4=ER,F5=EL,F6=ER`. Here `F4` supplies `D4`, the
penultimate south arrival on nine, so `F6` is the
last south departure on ten. The final east arrival
is `F7=EL`, immediately after `F6=ER`, contradicting
square constraint 2.

Both turns at `F5` are impossible. Hence a right-turn
`D4` must precede `Vc`.

## Two endings on ten when D4=SR precedes Vc

The ending on nine is now

```text
...,D3=NL,NR from E6,SL,D4=SR,SL,Vc=NR,SL.           (1)
```

First suppose `F5=ER`. It supplies the `SL` immediately
after `D4`, so it is the penultimate south departure
on ten. Another east right turn at `F6` would require
an intervening `WL`, exceeding the single remaining
south departure. Thus `F6=EL`. A right turn at `F7`
would be both the last east arrival and last south
departure, forcing a wake on ten. Hence `F7=EL`.

Constraint 1 requires a `WR` before `F6`. The required
left turn between `F5=ER` and that `WR` must be the
last south departure `Z=WL`. Alternation fixes

```text
10: ...,F5=ER,Z=WL,WR,F6=EL,WR,F7=EL.               (2)
```

Now suppose `F5=EL`. Then `F4=ER,F5=EL,F6=ER` are
forced. The first of these supplies `D4`, the third-last
south arrival on nine. If `F6` were the last south
departure on ten, it would immediately precede `F7=EL`,
contradicting constraint 2. Thus `F6` is the penultimate
south departure, and the last is `Z=WL` before `F7`.
The resulting ending is

```text
10: ...,F4=ER,F5=EL,F6=ER,Z=WL,WR,F7=EL.             (3)
```

In (2), `F5<c<Z` in lifted time. In (3), `F6<c<Z`.
These orders follow from the consecutive `SL,Vc,SL`
at the end of (1), by their incoming vertical steps.

## The D4=NL alternative

If `D4=NL`, it is supplied by `c`, and nine ends

```text
...,NR from E5,D3=NL,NR from E6,D4=NL.
```

Its last south arrival occurs before the north arrival
from `E5`. Thus the last south departure on ten occurs
before `E5` in lifted time.

The fixed lower paths give `F4>E5`. For completeness,
let `J` be `6:ER2` and let
`g=tau(7:W4)-tau(7:W3)>0`. The square from `6:EL`
to `J`, followed by the seven-step path from `W4`
to `E3`, gives

```text
tau(E3) = tau(J) + g + 4.
```

The two-step path from `J` to `E4`, and the square
from `E4=ER` to `E5=EL`, give

```text
tau(E5) = tau(J) + N + 6.
```

Since `tau(F4)=tau(E3)+N+2`, it follows that
`tau(F4)-tau(E5)=g>0`.

All of `F4,F5,F6,F7` consequently occur after the
last south departure on ten and must be `EL`.
Their ending is

```text
10: ...,F4=EL,WR,F5=EL,WR,F6=EL,WR,F7=EL.           (4)
```

## A common ending on eleven

Let `Pb,Pc,PL` be the last three west departures on
eleven, feeding `8:b=WR,c=WR,L9=WL` in order.
In every remaining case `F7=EL`, so the last-square
constraint gives `PL=NL`, supplied by the `WR`
immediately before `F7`. Its target is the final `NR`
on eleven, supplied by `F7`.

In (2) and (4), `F6=EL`. Both `Pb` and `Pc` occur
after its north arrival on eleven: for example,

```text
tau(Pb) - [tau(F6)+1] = tau(b)-tau(L7)-4 >= 8,
```

because `L7,E4,E5,b` have at least three four-step
gaps. The only north departures after `F6` are the
last `WR` and `F7`, already assigned to `PL` and
its following `NR`. Hence `Pb=Pc=SR`.

In (3), the west departure feeding `L7` is `NL`,
supplied by `F5`. Both `Pb,Pc` occur after it in
west-arrival order. Again the only later north
departures on ten are the last `WR` and `F7`, so
both must be `SR`.

Alternation now gives the same ending in all cases:

```text
11: ...,Pb=SR,SL,Pc=SR,PL=NL,NR,SL.
```

This common ending leaves the `D4=NL` case and
the two possibilities (2), (3) to be handled. The
whole middle suffix remains open.
