# Complete exclusion of the lower-guard / upper-missing orientation for drift `(1,-3)`

At growth eight, the surviving guard/missing orientation was previously reduced to two wake-placement families:

```text
Family I:  W=6m,   a=6p+2, b=6q+1, 1<=p<q<=m-2.
Family II: W=6m+2, a=6p+1, b=6q,   1<=p<q<=m-1.
```

Both families are impossible at every period. The proof is entirely from the upper missing cap using exact stable chronology.

## Universal upper-cap input

Use inward coordinate `u=W-t` from the upper missing cap and rotate all heading labels by 180 degrees. The fixed missing-cap rows are

```text
0: WR
1: NR
2: empty
3: SR,SL
4: WR,WL,ER.
```

Every extension below is checked by exact order-preserving edge matching and the same-cell successor rule: the first physical return to a class copy must land at the next stabilized visit.

If offsets 5 through 12 are all non-wake, direct stable-word enumeration gives

```text
u     tried stable words     exact survivors
5              1                    1
6              2                    2
7             38                    3
8             57                    2
9             92                    8
10          3326                    4
11          1896                    3
12          1156                    0
```

Thus an upper missing cap cannot have all offsets 5,...,12 non-wake.

## Family II

Here

```text
W=6m+2,
u_b=W-b=6(m-q)+2,
u_a=W-a=6(m-p)+1,
u_b<u_a.
```

If `q<=m-2`, then `u_b>=14` and `u_a>=19`, so offsets 5,...,12 are non-wake. The universal table excludes the case.

If `q=m-1`, then `u_b=8` and `u_a>=13`. Exact propagation with wake schedule

```text
5,6,7 non-wake; 8 wake; 9,10,11,12 non-wake
```

gives survivor counts

```text
1,2,3,2,12,16,16,5.
```

At offset 13, both possible parities are impossible: wake if `u_a=13`, non-wake if `u_a>13`. A necessary-return transfer solver gives zero rows in either case. A standalone direct C++ enumerator independently exhausts all raw stable words and finds zero survivors for both parities.

Therefore Family II is impossible.

## Family I

Here

```text
W=6m,
u_b=W-b=6(m-q)-1,
u_a=W-a=6(m-p)-2,
u_b<u_a.
```

If `q<=m-3`, then `u_b>=17` and `u_a>=22`, so offsets 5,...,12 are all non-wake. The universal table excludes the case.

If `q=m-2`, then `u_b=11`. Since `p<q`, `u_a>=16`, so offset 12 is non-wake. Direct exact enumeration with wake schedule

```text
5,6,7,8,9,10 non-wake; 11 wake; 12 non-wake
```

gives

```text
u      5   6   7   8   9   10   11   12
surv   1   2   3   2   8    4    1    0
```

The direct word counts at the last two steps are 1584 candidates at wake offset 11, leaving one exact state, then only 8 candidates at non-wake offset 12, leaving zero.

Therefore Family I is impossible.

## Theorem

No growth-eight periodic trace with drift `(1,-3)` can have a lower guard cap and an upper missing cap.

Combined with the earlier all-period exclusions of missing/missing, missing/guard, and guard/guard, every remaining `(1,-3)` growth-eight trace must involve at least one fat cap profile `(1,2,2)` or `(1,2,3)`.

This does not yet close the drift orbit because the fat-cap cases remain open.
