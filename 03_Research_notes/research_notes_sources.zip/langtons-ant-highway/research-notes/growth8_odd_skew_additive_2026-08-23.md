# Additive and rank conditions at drift `(1,±3)`

## Statement

Write the drift as `d=(1,3s)`, where `s` is `1` or `-1`, and translate the
configuration so that the period-start cell has even checker parity.  For an odd
translation class with base `(x,y)`, put

```text
j = y mod 3,       n = x-s floor(y/3).
```

Both quantities are constant under translation by `d`, apart from the fixed
choice of the residue representative `j`.  The checker sign is
`(-1)^(n+j)`.  Every finite-support growth-eight highway in either orbit must
satisfy

```text
sum_O (-1)^(n+j)n = 2-s  (mod 4).                       (1)
```

Thus the right side is `1` for `(1,3)` and `3` for `(1,-3)`.  This moment is
independent of the three P22 equations in the `y mod 3` residues.  Together,
those four equations exhaust the drift-periodic additive mod-four weights with
zero four-corner sum.

There is also a lifted-rank condition.  For each residue `j`, let `U_j` be the
set of its four or two longitudinal coordinates, ordered as follows:

```text
d=(1,3):       U_j={n},
d=(1,-3):      U_j={3n+j}.
```

For `i<j`, put

```text
I_ij=#{(u,v) in U_i x U_j : u<v}  (mod 2).
```

Every highway in either orbit must satisfy

```text
I_01+I_02+I_12=0  (mod 2).                               (2)
```

Conditions (1)--(2) narrow both orbits but do not exclude either one.

## The remaining generator

If `w` is such a weight, write

```text
w(x,y)=(-1)^(x+y) f(x,y).
```

The four-corner equation says that the mixed difference of `f` vanishes, so
`f(x,y)=A(x)+B(y)`.  Drift periodicity then gives a constant `c` with

```text
A(x+1)-A(x)=c,       B(y+3s)-B(y)=-c.
```

After absorbing one constant into `B`, every solution has the form

```text
f(x,y)=c[x-s floor(y/3)]+beta_(y mod 3),                 (3)
```

where `c,beta_0,beta_1,beta_2` are arbitrary modulo four.  The three `beta`
generators are exactly the signed residue charges already used in P22.  The only
new generator is therefore

```text
w_s(x,y)=(-1)^(x+y)[x-s floor(y/3)].                    (4)
```

It is periodic under `(x,y)->(x+1,y+3s)`, and its four-corner sum is zero.
Integrating the north-heading potential along two northeast diagonals and one
reversed southeast diagonal for `s=1`, or along the reversed path for `s=-1`,
gives monodromy

```text
2+s  (mod 4).
```

Charge conservation is consequently

```text
sum_O w_s + 2+s = 0  (mod 4),
```

which is (1).  A residue generator with coefficient `beta_j` has monodromy
`2 beta_j`; its endpoint equation is the P22 signed sum in residue `j`.  This
proves the completeness assertion following (1).

## The rank sign

Use the invariant transverse coordinate `t=3x-sy`.  At an even quotient vertex
the outgoing blocks are `W,E`, with targets `t-3,t+3`.  At an odd vertex they are
`S,N`, with targets `t+s,t-s`.  Reducing all block multiplicities modulo two,
the incoming and outgoing sums at a vertex both equal its odd-class indicator.

This finite flow is unique.  A nonzero zero-boundary flow with a least source
level would contain the block pointing below that level; the zero incoming sum at
its target would require a second block from a still lower source.

P22 gives an even number of endpoints in each `y mod 3` fibre.  Pair consecutive
endpoints in each fibre.  The unique flow is the symmetric difference of the four
resulting finite segments.  Comparing source and target port orders gives a short
interaction table:

- at `(1,3)`, every segment has self-sign zero;
- at `(1,-3)`, every segment has self-sign one, and the four self-signs cancel;
- two segments in the same residue fibre have zero cross term; and
- two segments in different fibres contribute the interlacing of their endpoint
  pairs in the ordering used to define `U_j`.

Summing the table gives

```text
E+L=I_01+I_02+I_12.                                    (5)
```

The checker count is odd in these two drift orbits, so the period congruence has
`N=2` or `6 (mod 8)`.  Hence `#L=(N-8)/2` is odd.  Exact P3 alternation gives
`K=#L=1`, while the one-tour port factorization is `K=1+E+L`.  Therefore
`E+L=0`, proving (2).

## Compatibility

P22 forces the unsigned counts in the three `y` residues to be a permutation of
`4,2,2`.  The two-class residues have a common checker sign, while the four-class
residue has a `3+1` checker split.  These conditions leave unbounded freedom in
the longitudinal integers `n`.

The additive audit takes distinct `n` values from `[-5,5]`.  For each chirality it
finds 300,000 P22 configurations and 150,000 satisfying (1), split evenly among
the three possible positions of the four-class residue.  The exact half is a
useful check that the moment is independent, but the surviving 150,000 placements
make clear that it is not an exclusion.  A separate direct-flow audit on
`n in [-3,3]` checks all 1,944 additive survivors; 824 also satisfy (2) in each
chirality.

## Audit

```text
python code/python/growth8_odd_skew_moment_audit.py \
  --output results/growth8_odd_skew_moment_audit.json
```

The program checks all 256 choices of the four coefficients in (3), their
four-corner sums, drift periodicity, and potential monodromy in both chiralities.
It then performs the bounded endpoint count above.  The output reports
`all_checks_passed=true`.

The lifted-rank regression is

```text
python code/python/growth8_odd_skew_rank_parity_audit.py \
  --output results/growth8_odd_skew_rank_parity_audit.json
```

It checks 420 segment self/cross interactions in each chirality, solves every
bounded parity flow directly, verifies uniqueness, and compares all 3,888 direct
signs with (5).

```text
growth8_odd_skew_moment_audit.py
a646c006962206d0b2f2292f4ac623e1d785a475931465b47c065c4ea922cd22

growth8_odd_skew_moment_audit.json
41af3e8d851150cf2fa7c520aafdfe79d6cdb93ab04c96bb0f1d9fdea6dea364

growth8_odd_skew_rank_parity_audit.py
8f089ffce4281679ef1578b327dde930097b76a776f92b27037e67a2bd4b9b31

growth8_odd_skew_rank_parity_audit.json
d0661aa367d11bdff6693fd63f310a3a20f2d3a1258f8e7e27c37d43927e6f92
```
