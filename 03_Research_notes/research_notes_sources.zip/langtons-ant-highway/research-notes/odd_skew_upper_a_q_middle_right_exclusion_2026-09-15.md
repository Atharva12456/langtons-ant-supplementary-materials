# The middle placement in Q requires E5=EL

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

In the middle placement of Q, the fifth east arrival
on eight cannot be `ER`. This excludes both suffixes
`M_R0,M_R1` for all four prefixes in
`odd_skew_upper_a_q_eighth_word_forms_2026-09-15.md`.

The middle placement must therefore have the consecutive
pair `E4=ER,E5=EL`. Its two remaining suffixes and both
after-placement suffixes remain open. There are now
sixteen formal words on eight for Q, not twenty-four.
This does not exclude Q or the `(1,-3)` orbit.

## Consequences of E5=ER in the middle placement

Assume this turn for a contradiction. The word on eight
has one of the following endings, including `E3`:

```text
M_R0: E3=ER,E4=EL,b=WR,L7=WL,c=WR,L8=WL,E5=ER,E6=EL;
M_R1: E3=ER,L7=WL,b=WR,E4=EL,c=WR,L8=WL,E5=ER,E6=EL.
```

Here `Li` denotes the `WL` at south ordinal `i` on
eight. In both endings, `L5=WL` immediately precedes
`E3=ER`. It supplies `W4=SR` on seven.

The consecutive pair `E5=ER,E6=EL` forces
`D3=SR,D4=NL` on nine, with `E6` supplying `D4`.
The middle north arrival `V=NR` on seven supplies
`F5=EL` on ten, and the adjacent predecessor is
`F4=ER`, supplying `D3`.

The last north arrival and the last west departure on
nine are both `D4=NL`. No right turn can occur after
it, so the word ends there. Its immediate predecessor
`D3=SR` is consequently the last south arrival. Thus
`F4=ER` is the last south departure on ten. All later
east arrivals turn left, fixing the ending

```text
10: ...,F4=ER,F5=EL,WR,F6=EL,WR,F7=EL.              (1)
```

The port `F6` is supplied by the `SL` after `V` on
seven; that `SL` is supplied by `8:L7=WL`.

## The west departure feeding L5 is SR

Let `P` be the west departure on eleven feeding `L5`.
There is an eleven-step path

```text
P -> 8:L5=WL -> 7:W4=SR -> 4:WR2 -> 5:NL -> 2:WL
  -> 1:SL -> 4:EL -> 5:NR2 -> 8:E3=ER
  -> 7:SL after W4 -> 10:F4=ER.
```

If `P=NL`, starting at its north predecessor on ten
gives a twelve-step first return to `F4=ER`. The
predecessor must be `F3=EL`, immediately before `F4`.

Let `Z` be the south departure on eight supplying the
`SL` before `W2` on seven, and hence `F3`. In prefix
A, `Z` is the third south departure `WL`; in prefix B,
it is `E1=ER`. In every prefix under consideration,

```text
Z < E2 < L5
```

on eight. But the forced path

```text
8:Z -> 7:SL before W2 -> 10:F3=EL -> 11:P=NL -> 8:L5
```

is a square first return. It skips `E2`. Therefore
`P=SR`.

Extend the eleven-step path above through

```text
F4=ER -> 9:D3=SR -> 6:WL2 -> 5:SL3 -> 8:E6=EL
      -> 9:D4=NL -> 6:WR2 -> 7:V=NR -> 10:F5=EL
      -> north arrival on eleven.
```

This is a twenty-step first return from `P`. There is
no intervening visit to offset eleven. Its endpoint
must be `NL`, the next west departure after `P`.
Write this next departure as `P+`. It is supplied by
`F5=EL`.

## M_R1 gives a left/left square

In `M_R1`, the next west arrival on eight after `L5`
is `L7=WL`. Thus `P+` feeds `L7`, and

```text
10:F5=EL -> 11:P+=NL -> 8:L7=WL -> 7:SL after V -> 10:F6=EL
```

is a square first return with two left-turn endpoints.
This excludes `M_R1` for every prefix.

## M_R0 forces a left turn on twelve

In `M_R0`, the next three west arrivals after `L5`
are `b=WR,L7=WL,c=WR`. Let their predecessors on
eleven be `Pb=P+`, `PL`, and `Pc`, respectively.
We already have `Pb=NL`, supplied by `F5=EL`.

The north arrivals on nine supplied by `E4,b,c` are
all `NR`. Indeed, `D1,D2` precede `E4`: the fixed
three-step path from `D2` to `E2` has zero voltage,
so `tau(D2)=tau(E2)-3`. The remaining west departures
are `D3=SR,D4=NL`, and `D4` is supplied by `E6`,
after all three of these north arrivals.

Let `Gb,Gc` be the east arrivals on twelve supplied
by the north arrivals from `b,c`. Suppose `Gb=ER`.
The square through `Pb,b` and the north arrival on
nine returns from `Pb=NL` to `PL=SR`. Its next square
through `L7`, the `SL` after `V`, and `F6=EL` then
returns to `Pc=NL`.

Consequently

```text
12:Gb=ER -> 11:PL=SR -> 8:L7=WL -> 7:SL after V -> 10:F6=EL
         -> 11:Pc=NL -> 8:c=WR -> 9:north arrival from c -> 12:Gc
```

is an eight-step first return. There is at least one
east arrival between `Gb` and `Gc`, supplied by the
`SL` between the north arrivals from `b,c` on nine.
The return skips it. Hence `Gb=EL`.

## The resulting time order is impossible

Start at the south predecessor `H` of `P=SR` on
twelve. Follow the twenty-step return from `P` to
`Pb=NL`, and then the three steps through
`8:b=WR,9:north arrival from b,Gb=EL`. This is a
twenty-four-step first return to twelve. It forces
`H=ER`, immediately before `Gb=EL`.

On nine, the two consecutive north arrivals supplied
by `E4` and `b` are both `NR`, with a single `SL`
between them. Thus the east arrival immediately before
`Gb`, namely `H`, is supplied by that `SL`. Let `S`
be its south predecessor on ten.

The incoming vertical steps give

```text
tau(S) > tau(E4).                                   (2)
```

But there is now the four-step, zero-voltage path

```text
10:S -> 9:that SL -> 12:H=ER -> 11:P=SR -> 8:L5=WL.
```

Therefore

```text
tau(L5) = tau(S) + 4 > tau(E4).
```

This contradicts `L5<E3<E4` on eight. Hence `M_R0`
is also impossible for every prefix.

Both right-turn suffixes in the middle placement are
excluded. Q's remaining middle words use `M_L0` or
`M_L1`, and its after words use `A_0` or `A_1`.
