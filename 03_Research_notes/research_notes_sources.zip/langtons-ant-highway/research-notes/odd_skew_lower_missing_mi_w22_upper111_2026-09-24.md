# M-I at width 22 cannot have upper long band `111`

24 September 2026. For drift `(1,-3)`, the lower-missing M-I family has
minimum width 22. Its unique wake placement at that width is

```text
O={0,1,4,6,10,14,20,22}.
```

This note excludes the upper fat `(1,2,3)` initial long band
`(j,k,l)=(1,1,1)` for that placement. It does not exclude width 22 with
the short or `120` upper band, nor M-I at larger widths. The upper `210`
band is already excluded throughout M-I by the near-wake lemma.

Use physical transverse coordinate `t=3x+y` from the lower cap. The
center row is `t=11`, also inward offset eleven from the upper cap.
Rotating upper heading labels by 180 degrees preserves the turns and
the chronological order of events in each stable word.

The verifier enumerates every lower prefix through level eleven and
every upper-`111` prefix through inward offset ten. Each row count comes
from directional flow and binary wake excess; every alternating word
consistent with necessary finite-return adjacency is considered. A
prefix is removed only for a witnessed wrong finite first return or an
infeasible lifted clock. The lower clocks use integer `N>=6`; the upper
clocks use the larger domain of real `N>=6`, solved with exact rational
arithmetic. Thus the upper frontier contains every integer-period case.
There is no period or row-length upper bound and no extrapolation from
repeated quotient vertices to physical returns.

The lower survivor counts at levels three through eleven are
`1,1,1,3,4,2,9,20,302`. The upper counts at offsets five through ten
are `6,28,20,10,7,104`. The 302 lower prefixes have 302 distinct center
words. After the heading rotation, only **6,948 pairs** of a lower
center word and an upper depth-ten prefix satisfy the upper row-eleven
count equations. Every one has a witnessed finite first return to an
event other than the required next stable event. Consequently none can
describe the common physical center row.

Run `python code/python/verify_lower_missing_mi_w22_upper111.py` from the
repository root. It regenerates both frontiers, checks all 6,948 joins,
and writes `results/lower_missing_mi_w22_upper111_checks_2026-09-24.json`.
The result includes a sample complete path with cumulative voltage.
An earlier independent full-upper-row enumeration also found no shared
center word among 302 lower and 3,150 upper center words; the shorter
direct join avoids generating upper words that cannot match the lower cap.
