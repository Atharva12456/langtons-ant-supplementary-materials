# All-period exclusion of the `a=7` guard/missing branch at drift `(1,-3)`

Later result (9 September 2026): [the complete guard/missing exclusion](odd_skew_guard_missing_complete_exclusion_2026-09-09.md) closes both lower-guard / upper-missing families. The remaining-family statements below describe the earlier stage; the full drift orbit remains open.

## Statement

Consider a finite-support periodic Langton trace of growth eight in the odd-skew drift orbit represented by `d=(1,-3)`. Normalize the transverse coordinate so a lower guard cap is at levels `0,1,2` and an upper missing cap is at the far end.

The previously proved guard/missing classification leaves Family II

```text
W=6m+2,
a=6p+1,
b=6q,
1<=p<q<=m-1,
m+p+q even,
```

with wake set

```text
O={0,1,2,a,b,W-4,W-1,W}.
```

The subfamily `p=1`, equivalently `a=7`, is impossible at every period and every width.

Consequently Family II has `p>=2`. Its old lower width bound `W>=20` improves to `W>=32`: with `p>=2`, the first arithmetic possibility is `m=5,p=2,q=3`.

## Local reduction

For `p=1`, `b=6q>=12` and `W>=20`, so the wake pattern on levels zero through nine is exactly

```text
1,1,1,0,0,0,0,1,0,0.
```

The existing lower-guard return argument fixes the first five stable rows to

```text
0: WR
1: NR
2: WR
3: SR,SL,NR,SL
4: WR,WL,ER,WL
```

where even transverse levels have horizontal arrivals and odd levels have vertical arrivals.

From here there are no width or period parameters left in the local problem. For each next level, directed edge matching with the already fixed outer levels determines a finite list of port-count rows. P3 requires the stable class word to alternate `R,L,R,L,...` beginning with `R`. Parallel unit edges match in this stable order.

Whenever the resulting deterministic successor path returns to the same physical cell, the endpoint must be the immediately next event in that cell's stable word. A return to an earlier stable event or one that skips an intervening stable event is impossible, since the traced path contains every ant step between its endpoints.

## Exact finite certificate

The accompanying audit `verify_odd_skew_guard_missing_a7.py` exhausts only these exact local possibilities. It contains no period cutoff, width cutoff, or visit-count cutoff.

Layer counts are:

```text
through level 5 (even):       2 survivors
through level 6 (even):      11 survivors
force level 7 wake:           1 survivor
force level 8 even:           2 survivors
force level 9 even:           0 survivors
```

After level seven, the unique surviving stable rows are

```text
5: SR,SL,NR,SL
6: WR,EL,WR,WL,ER,WL,WR,EL
7: SR,NL,NR,SL,NR,NL,NR
```

At even level eight exactly two stable words survive:

```text
ER,EL,WR,EL,WR,WL
ER,EL,WR,WL,WR,EL
```

For either level-eight word, an even level nine has one of the four port-count rows

```text
(NR,NL,SR,SL) =
(4,0,5,9),
(3,1,4,6),
(2,2,3,3),
(1,3,2,0).
```

Across both level-eight states these rows have exactly 948 alternating stable words. Every one is rejected by an exact same-cell return of length 4, 8, or 12 that either returns backward in stable order or skips at least one required visit. No longer excursion is used.

Therefore a lower guard cannot have its first additional wake at level seven while levels eight and nine are even. The `a=7` Family-II branch has exactly that local pattern, so it is excluded for all widths and periods.

## Scope

This closes an infinite parameter subfamily, not the entire `(1,-3)` drift orbit. Family I (`W=6m`, first extra wake `a=6p+2`) remains open, and Family II remains open for `p>=2`. The fat cap profiles `(1,2,2)` and `(1,2,3)` also remain outside this argument.
