# Growth-twelve research log — 17 August 2026

Subsequent status: the unrestricted primitive-diagonal growth-four case is
excluded by the analytic reduction and computer-assisted affine classification
in [the top-boundary note](primitive_g4_cap5_symbolic_2026-08-22.md). The
growth-eight cases remain open. The entries below preserve the earlier
checkpoint and its intermediate questions.

## Active objective and status

The target is the universal periodic statement `g>=12`: every positive-growth
finite-support periodic highway, of any nonzero drift geometry, should gain at least
12 black cells per period.  Since the even-winding theorem gives
`g in 4*Z_{>0}`, it is enough to exclude `g=4` and `g=8`.

**Current status: open.**  The accepted diagonal theorem `W>=10` is an input, not a
solution.  It does not apply to axis or other non-diagonal drift.

## Known barrier

The residue theorem restricts every growth-four drift to

```text
(+/-1,+/-1), (+/-2,0), (0,+/-2), (+/-2,+/-2),
```

but explicit heading-reset tours realize every skeleton while satisfying all
one-period alternation and signed-residue tests.  They fail only the stabilized
cross-period P3 order.  Therefore no incidence-only strengthening is being reused.

## New final-wake block route for diagonal drift

For normalized diagonal drift `d=(m,-m)`, translation preserves `t=x+y` and shifts
the longitudinal coordinate by `m`.  After the ant's final exit from an untouched
far-ahead block, the settled black mask must therefore be periodic under
`x -> x+m`.  Its number of black cells in one `m`-column domain is exactly `g`, the
number of odd translation classes.

For `g<=8`, the residue bound gives `m<=4`.  Thus a relaxed block confined
to the full eleven-line strip of an exact `W=10` highway can be filtered by the
necessary conditions:

1. the final mask repeats with period `m` across at least two domains; and
2. its fundamental-domain weight is `g in {4,8}`.

`code/python/explore_width10_low_growth.py` performs this classification while
retaining the accepted once-entry restriction on extremal cells and allowing every
same-side exterior return.  This is presently a research diagnostic.  Even a
complete zero result would exclude only diagonal low-growth highways of transverse
width exactly ten.  Wider diagonal highways and all non-diagonal cases remain
outside this model.

### Forward/reverse status (bounded evidence only)

The forward boundary search remains incomplete at every useful four- or
eight-column cap.  A separately written reverse search,
`code/python/explore_width10_g4_reverse.py`, starts from the sparse periodic
growth-four terminal masks and exactly undoes each ant turn.  A 100,000-segment
involution audit found no mismatch with the forward dynamics.  The proved
extremal, positive-even-fibre, and signed-residue filters leave 20 period-one and
61 period-two masks at `W=10` before the stronger additive filter below.

At two columns the forward and reverse searches both reach filtered period-one
growth-four masks, so the machinery has a positive local control.  At four columns
the reverse search reached 5,000,005 states with 2,808,260 still queued and no hit;
the forward search reached a 50,000,000-state cap and its two period-two
growth-four terminal events both failed the proved wake filters.  Neither run is
complete, so neither is an exclusion.  The same forward run already contains three
filtered growth-eight period-two terminals.  The local four-column relaxation
therefore cannot by itself exclude growth eight.

At eight columns the first filtered `g=12,m=2` mask is exactly the settled standard
period-104 wake, independently reconstructed from its twelve strand bases.  This is
a positive control, not evidence for uniqueness.

## Full diagonal additive-weight audit

The complete local mod-four charge criterion gives more diagonal weights than the
subfamily used in P22.  For `d=(m,-m)`, put `r=x mod m` and `t=x+y`.  Every
drift-periodic weight obeys

```text
w[r,t] + w[r+1,t+1] + w[r,t+1] + w[r+1,t+2] = 0 (mod 4),
```

so two consecutive transverse rows determine the whole weight.  If
`A_t=sum_r w[r,t]`, the potential monodromy along the drift is
`A_t-A_(t+1)`.  Widget cancellation therefore gives the necessary wake equation

```text
sum_i w[x_i mod m, x_i+y_i] + A_p - A_(p+1) = 0 (mod 4),
```

where `p` is the transverse coordinate of the period-start ant.

`code/python/full_additive_wake_audit.py` enumerates all 16 weights for `m=1` and
all 256 for `m=2`.  All equations hold on the primitive-diagonal growth-four
near-model, the even-diagonal growth-four near-model, and the standard highway.
Thus these weights do **not** close growth four.  They do sharpen the even-diagonal
wake arithmetic: after shifting the common wake parity so its minimum transverse
line is zero, the four wake labels must satisfy

```text
sum_i (t_i/2) = 3 (mod 4),
```

which lifts the older `sum_i t_i = 2 (mod 4)` condition to a mod-eight condition.
At exact `W=10` it reduces the period-two target masks from 61 to 14; the analogous
primitive case reduces 20 to 10.  Valid static masks persist at every tested even
width, so this is a new pruning invariant rather than an all-width contradiction.

## Tait-connectivity route: ruled out

A second attempted shortcut was to connect growth to transverse span through the
Tait graph of the settled wake.  It does not work.  The endpoint decomposition

```text
B_(n+1)-B_n = (S+n*d) + (A+(n+1)*d) - (A+n*d)
```

does not make the emitted strand representatives `S+n*d` a connected graph: the
moving widget can supply bridges which the negative widget term then deletes, and
individual strand representatives can be shifted by multiples of `d` without
changing the highway.  Even the canonical twelve-strand base set of the standard
highway is a four-component Tait forest, although a different, dynamically aligned
set of twelve edges is shed as a tree.

There are two independent sharp obstructions.  First, the exact-width-ten relaxed
dynamics reaches a period-one growth-four mask with base rows `{0,1,2,10}`; it
satisfies P22 and every additive mod-four wake equation, but its upper strand is a
different Tait component from the three lower strands.  Thus literal local
chronology plus both extrema does not force settled top-to-bottom connectivity.
Second, even if such connectivity were assumed, a Tait edge on an odd transverse
level advances the Tait-vertex transverse coordinate by two.  Connectivity would
therefore imply only `g >= W/2 + 2`, not `g >= W + 2`.  An eight-edge Tait tree
spanning `W=10` satisfies the growth, P22, and full additive moment conditions.

Consequently neither settled-wake connectivity nor a component-diameter bound can
prove `g>=12`.  Any viable next argument must retain the actual lifted-time P3
adjacency (or an equivalent cross-period chronological invariant); connectivity of
an arbitrarily chosen endpoint representative set is not invariant data.

## Bounded nonlinear local-invariant audit

`code/python/local_pair_invariant_audit.py` tests whether the missing obstruction is
a small pair-correlation charge.  The first ansatz contains the global black count,
all black-pair counts with canonical displacement in `[-2,2]^2`, and a heading
correction with every algebraic-normal-form monomial of degree at most two in the
ant's `3x3` black neighbourhood.  A second search permits every coefficient to
depend on `(x mod 2,y mod 2)`, the most immediate coordinate-periodic refinement for
the axis `d=(2,0)` case.  Both expand every one-step identity exactly as a
multilinear Boolean polynomial, over `Z/2` and `Z/4`; no random states or finite
spatial box are used.

The exact linear/module audit has 197 unknown coefficients and reports only the
known constant and black-count/heading charges.  The 788-coefficient period-two
extension likewise has no solution with a nonzero pair coefficient over either
ring.  This closes one finite radius/degree/coordinate-period ansatz only.  It is
**not** a classification of arbitrary-range, higher-degree, or aperiodically
weighted invariants, and it supplies no growth exclusion.

## Axis growth four: exact transition-system boundary

Normalize the saturated axis case to `d=(2,0)`.  P22 fixes its four odd classes
to

```text
(0,y0), (1,y0), (0,y1), (1,y1),     y1-y0 positive and even.
```

There is a useful proved mod-two normal form on the two-column quotient cylinder.
At every class, each ant visit uses one horizontal and one vertical incident edge,
so the boundary of each of the horizontal and vertical edge-parity chains is the
set of four odd classes.  The cylinder's vertical graph is a line in each residue;
therefore every vertical edge strictly between `y0` and `y1` occurs oddly in each
residue, and every other vertical edge occurs evenly.  On a non-wake row the two
parallel horizontal edge types have equal parity; on either wake row they have
opposite parity.  The sum of the wrap-edge parities is one because the lifted trace
has winding one.  Thus the quotient contains forced vertical wake intervals and
wake-row horizontal defects, plus an unbounded collection of optional horizontal
two-edge winding cycles.  Those optional cycles can themselves carry nonzero
quotient voltage, so the normal form does not select a unique winding component.
This is a structural reduction, not an exclusion.

`code/python/axis_g4_transition_audit.py` made the former sharp obstruction literal.  It
builds two square-lattice successor circuits with total voltage one and total turn
excess four.  With phases `0,...,7`, every translation class is in exact lifted-time
P3 order: two middle classes have word `RL`, and the four wake classes are singleton
`R`.  Cross-splicing the two circuits into the one-circuit word `RLRRLRRR` creates
exactly one P3 defect.  This isolated the single-tour issue that the rank-parity
theorem below now resolves without bounding the number of zero-voltage components.

The naive parity version is false.  The zero-voltage circuit `RRRRLLLL` is P3-valid
relative to the external drift `(2,0)`, has only even classes, and can be translated
to unused rows.  Appending it produces a P3-compatible three-circuit system with the
same growth and voltage.  Hence neither the parity nor the raw number of successor
circuits is controlled.  None of these multi-circuit objects is a periodic highway.

## Axis growth four: proved all-period exclusion

The missing single-tour constraint has now been obtained as a permutation-sign
identity.  This is an **analytic theorem**, not a bounded search and not a
computer-assisted premise.

Normalize an axis-growth-four candidate to drift `d=(2,0)`, translate its period
start to the origin, and choose a phase whose arrival heading is vertical.  Write
`N=2M`.  In each quotient class `(x mod 2,y)`, order the event phases by decreasing
`x`, then increasing phase; this is exactly the stabilized P3 order.  If `r_i` is
the zero-based rank of event `i`, define

```text
K = sum(r_i : turn i is L)  (mod 2).
```

For **every** heading-reset one-tour word with endpoint `(2,0)`, independent of its
growth or of P3,

```text
K = 1 + N/4  (mod 2).                         (A)
```

Pair the moves into `M` horizontal-then-vertical macros.  The quotient has a
vertical-arrival vertex `Q_y` and a horizontal-arrival vertex `C_y` on every used
row.  At a vertex, sort occurrences by stable rank and let `a_r,b_r` be the positive
incoming/outgoing port bits.  If `I(a)` counts inversions `1...0`, then

```text
I(a) = A(n-1) + sum(r a_r) + binom(A,2)  (mod 2).
```

At `Q`, an `L` turn means `a!=b`; at `C` it means `a=b`.  Summing the resulting local
identities cancels every directed-edge binomial twice and cancels the linear terms
by vertical cut balance.  Thus

```text
K = sum_v (I(a_v)+I(b_v)) + sum_y binom(h_y,2),
```

where `h_y` is the horizontal multiplicity on row `y`.  Port-sorting factors the
one-cycle phase successor into the local permutations and an edge-block
permutation of parity `E`, so `sum_v(I(a_v)+I(b_v))+E=1`.  If `n_y` counts north
steps from row `y`, closed vertical flow gives

```text
h_y=n_{y-1}+n_y,
E=sum_y n_y + sum_y n_y n_{y+1},
sum_y binom(h_y,2)=sum_y n_y n_{y+1},
M=2 sum_y n_y.
```

Equation (A) follows.  Stable order is preserved inside every directed edge block:
with level `ell=(x-(x mod 2))/2` and key `tau=i-N*ell`, successor along a fixed
quotient edge adds a constant, including at the cyclic period seam.

For a P3-valid word every class is `R,L,R,L,...` in stable order, so every `L` has
odd rank and `K=#L (mod 2)`.  The residue theorem makes an axis `g=4` skeleton
occupy two rows, each with one class in each `x` residue; hence exactly two odd
classes have even checker parity.  If `u_j` is the horizontal macro step and `v_j`
its incoming vertical sign, the even-phase turn sign is `u_j v_j`, and

```text
M + 2 + 0 + 2
  = sum_j (1+u_j+v_j+u_j v_j)
  = sum_j (1+u_j)(1+v_j) = 0  (mod 4).
```

Therefore `N=2M` is divisible by eight.  P3 gives `K=#L=(N-4)/2=0 (mod 2)`, while
(A) gives `K=1`, a contradiction.  Quarter-turn rotations cover all axis directions.

`code/python/axis_rank_parity_audit.py` is a bounded regression for the proof
factorization, not a proof oracle. It checks all endpoint words through period 16.

**Promoted result:** no finite-support periodic highway of growth four has axis
drift, at any period.

## Even-diagonal growth four: proved all-period exclusion

The same lifted-rank sign has a two-lane form that closes the even-diagonal family
analytically.  At `g=4`, the density bound reduces an even diagonal drift to
`d=(2,-2)` up to quarter-turn rotation.  Put

```text
t=x+y,  r=x mod 2,  ell=(x-r)/2,  tau=i-N*ell.
```

The translation classes are `(t,r)`, ordered by increasing `tau`.  Choose a
vertical-arrival phase at the origin, so vertical-arrival classes `Q` have even
`t` and horizontal-arrival classes `C` have odd `t`.  Define `K` as the sum modulo
two of the stable ranks of all `L` events.

At a class of multiplicity `m`, let `A,B` be its positive incoming/outgoing port
counts and `p=A+B mod 2`.  Positive means north/east at `Q` and east/north at `C`.
If `D=#R-#L`, P3 gives `D in {0,1}`.  The binary inversion identity from the axis
proof gives the following local correction after directed-edge binomials cancel:

```text
Q: p(D+1),       because D = m-2p (mod 4),
C: D(p+1),       because D = 2p-m (mod 4).
```

Let `E` be the edge-block permutation sign when blocks are ordered by
`(t,r,port)`, negative before positive.  Directed-edge blocks preserve `tau`
order, including the period seam, and the phase successor is one even cycle.  Thus

```text
K = 1 + E + L  (mod 2),
```

where `L` is the total local correction.

Write `w,e,s,n` for directed-block multiplicity parities.  Flow is

```text
w[t,r]+e[t,r] = s[t+1,r]+n[t-1,r]                 (Q, t even),
s[j,r]+n[j,r] = w[j+1,1-r]+e[j-1,1-r]             (C, j odd).
```

The residue theorem gives one of the two doubled perfect-matching matrices at
`g=4`.  Hence all four excess-one classes `O` have one checker parity, and each
lane contains two of them.  The needed two-lane lemma is

```text
E+L = sum_r binom(o_r,2)  (mod 2),
```

where `o_r` counts `O` in lane `r`.  It has a direct finite-support proof.

If `O` lies on `C`, every `Q` multiplicity is even.  Hence `w=e=:a` and
`s[j,r]=n[j-2,r]`; the two flow equations and finite support give
`a[t,r]=n[t-1,1-r]`.  Therefore `p=D` at `C`, while the two `Q` corrections on
each level cancel, so `L=0`.  Every bit `n[j,r]=1` contributes the four-edge
parity gadget

```text
G_C(j,r)={N[j,r],S[j+2,r],W[j+1,1-r],E[j+1,1-r]}.
```

Its source order `[N,W,E,S]` and target order `[W,S,N,E]` have odd relative sign.
Two gadgets have odd cross-inversion parity exactly when they are adjacent in the
same lane.  Thus

```text
E = sum n[j,r] + sum n[j,r]n[j+2,r].
```

In each lane this is the number of runs of ones modulo two.  If there are `k_r`
runs, their boundary has `o_r=2k_r` vertices, and
`k_r=binom(o_r,2) mod 2`.  If `O` lies on `Q`, the symmetric reduction uses
`s=n=:b`, `e[t,r]=b[t+1,r]`, and gadgets

```text
G_Q(j,r)={S[j,r],N[j,r],E[j-1,r],W[j+1,r]}.
```

Their source/target orders are `[E,S,N,W]` and `[S,W,E,N]`, with the same
self/cross table.  This proves the lemma in both cases.

For the doubled matching, `o_0=o_1=2`, so `E+L=0` and the one-tour sign gives
`K=1`.  P3 instead makes every `L` rank odd, hence `K=#L`.  Writing `N=2M`, the
horizontal displacement two forces `M` even; since `g=4`,

```text
#L=(N-4)/2=M-2=0 (mod 2).
```

Contradiction.  Quarter-turn rotations cover all even-diagonal signs.

`code/python/even_diagonal_rank_parity_audit.py` checks the local mod-four truth
tables, both gadget permutations, the complete nearby gadget cross table, and all
two-lane finite binary chains through a configurable length.  It is explicitly
labelled bounded evidence, not a proof oracle; the theorem is the displayed
finite-support argument.

**Promoted result:** no finite-support periodic highway of growth four has
even-diagonal drift, at any period. **Open at this checkpoint:** primitive-diagonal
growth four and all growth-eight cases. The later top-boundary result closes the
growth-four case; the target `g>=12` remains open.
