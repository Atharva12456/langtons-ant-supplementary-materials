# The second width-eighteen placement is impossible for the last lower fat band

27 September 2026. At growth eight and drift `(1,-3)`, take the lower
fat `(1,2,3)` band `(omega_3,omega_4,j,k,l)=(1,1,1,1,0)` and an upper
fat `(1,2,3)` cap. The P22, rank, and moment classification has exactly
two width-eighteen wake placements. The preceding A(1,1) center-count
proof excludes `{0,2,3,4,6,8,16,18}`. This note excludes the other,

```text
W=18, A(2,2): O={0,2,3,4,12,14,16,18}.
```

The checker regenerates the lower frontier from its fixed rows zero
through four to center row nine. It separately regenerates the upper
fat frontier in half-turned inward coordinates from fixed rows zero
through two to inward row seven. Every added word obeys alternation,
directional flow, the prescribed wake, the finite first-return checks,
and the lifted integer-clock relaxation. The clock has unbounded
`N>=max(6, represented event count)` and visit spacing at least four;
it does **not** impose `N≡6 (mod 8)`. Dropping that congruence enlarges
the frontiers. The upper half has the opposite voltage sign after the
half-turn. No period, row-length, or black-lifetime cutoff is used.

The lower survivor counts on rows five through nine are
`8,10,10,25,4`. The upper counts on inward rows three through seven
are `4,8,60,471,3119`. The four lower center rows have two port
signatures `(NR,NL,SR,SL)`: `(4,2,2,4)` twice and `(6,0,0,6)` twice.

Before constructing upper inward row eight, the verifier checks all
its flow/wake count options against lower center counts and two
physical edges crossing the cap cut: lower row seven east to physical
row ten, and physical row eleven west to lower row eight. It checks
every lower state of a matching center signature. The next upper
count row is computed from a count-only placeholder for row eight;
this only enlarges the set of eligible count options. Exactly 954
upper row-eight count options remain. They generate 5,480 adjacency
words, of which 3,810 have finite wrong returns and 1,337 fail the
relaxed clock. Thus 333 upper row-eight words survive.

Those 333 words give 333 eligible upper center count options and
1,698 adjacency words. After the half-turn, 62 center-word joins
match a lower row-nine word. For each join, the verifier assembles all
nineteen physical rows and checks the outgoing and incoming count on
**every directed edge**. All 62 balance. Each has an explicitly
replayed, finite, zero-voltage first return to the same physical cell at a
wrong stable-event position. A return to the same index is a
positive-length zero-voltage closed walk: summing the lifted clock
equalities around it gives `0=L>0`. The other wrong positions violate
the required next stable visit. Of the 62 canonical witnesses, 49
return to the same index, 11 to an earlier index, and two skip the next
visit. The longest path is 120 steps. The 62 complete words are
therefore impossible for every period.

`code/python/verify_lower_fat123_a1_b1_110_w18_A22.py` regenerates
the frontiers and join from fixed cap words; it reads no scratch
checkpoint. Its result is
`results/lower_fat123_a1_b1_110_w18_A22_checks_2026-09-27.json`,
which includes each complete word and its finite path. The separate
`code/python/verify_w18_a22_finite_returns_independent.py` checker
replays all 62 paths using only the Python standard library. It
independently rebuilds ordinal successors, checks full directional
balance and physical coordinates at each step, and verifies that no
earlier same-cell return occurs. It makes no quotient-cycle inference.

Together with the A(1,1) exclusion and the earlier width-twelve and
width-sixteen exclusions, this gives the necessary bound `W>=20` for
this lower band with an upper fat cap. It does not close the full
drift `(1,-3)` orbit.
