# Upper fat quiet-three/four, wake-five requires wake-six or seven

For literal drift `(1,3)`, an upper F123 cap cannot have quiet inward
offsets three and four, wake five, and quiet six and seven. Both choices
of the wake bit at eight are impossible. This local exclusion holds for
every growth, width and positive integer period. At growth eight it
excludes the entire lower-thin `110` / upper-F123 wake-five cap family.
The whole orbit and the other caps of lower `110` remain **open**.

## Exact local domain and independent exclusion

Use the orientation-preserving half-turn at the upper extremum. The
initial words are `0:NR`, `1:WR,WL`, `2:NR,SL,NR`. Turns R/L are preserved;
inward edge clocks have shifts `1+N` for E, `1-N` for W, and one for N/S.
The period variable is integer `N>=1`, unbounded above. Stable order is
strict. No growth, P22, period residue or gap-four restriction is used.

At each new offset the directed ordinal flow determines a finite exact
port-count domain by nonnegativity. If the offset is odd, with A east
departures three rows earlier and D north arrivals one row earlier,

```
ER=A-e, EL=e, WR=D-e, WL=A+D-3e-omega.
```

At an even offset, with B south departures one row earlier and C west
arrivals three rows earlier,

```
SR=s, SL=B-s, NL=C-s, NR=omega+B+C-3s.
```

Every nonnegative integer vector is considered. All R-first alternating
multiset words are covered by a necessary first-return adjacency
generator. It prunes only zero-copy physical returns: such a return
must be the next event at that physical cell and must reverse the turn.
A quotient return at nonzero copy coordinate is not adjacency. Remaining
words are rejected by an explicit wrong physical first return or an
inconsistent unbounded integer clock.

| New offset | Wake bit | Count vectors | Raw alternating words | Emitted candidates | Survivors |
|---|---:|---:|---:|---:|---:|
| 3 | 0 | 2 | 4 | 4 | 4 |
| 4 | 0 | 10 | 97 | 10 | 9 |
| 5 | 1 | 25 | 625 | 31 | 25 |
| 6 | 0 | 94 | 25,022 | 138 | 34 |
| 7 | 0 | 160 | 341,856 | 36 | 6 |
| 8 | 0 | 30 | 75,654 | 24 | 0 |
| 8 | 1 | 30 | 90,240 | 27 | 0 |

The independent audit imports neither the frontier nor the fast-clock
engine. It rederives all 351 count vectors and the total of 533,498 raw
words, regenerates every emitted candidate using a separately written
nonmemoized geometric generator, replays all 158 physical rejections,
and reconstructs all 34 rejected clocks directly in Z3. All checks pass.
All 51 terminal candidates fail physical first returns; their return
direction words are NESW (20), SWNE (24), or SWNWSENE (seven). Both
terminal bits were independently generated and no resource cap was
reached. Thus the terminal empty domains are exhaustive exclusions.

A separate [terminal hand reduction](../work_positive_skew_upperfat_wake5_hand_20261002/hand_reduction.md)
now eliminates the same six prefixes without enumerating row-eight words.
It uses 18 zero-copy return adjacencies and seven conditional wrong
first-return paths; an independently written compass/ordinal checker
verifies every path. The finite reduction through seven remains
computer-assisted. Fresh code also regenerates the original domains and
checks all 158 physical and 34 clock rejections.

Reproduce from the project root:

```text
python work_positive_skew_upperF123_wake5_20261001/probe.py
python work_positive_skew_upperF123_wake5_20261001/audit_all8.py
python work_positive_skew_upperF123_wake5_20261001/verify_thin110_endpoints.py
```

The probe's default terminal choice is quiet eight; the independent
audit explicitly enumerates **both** terminal bits. The probe also has
an `--allquiet` exploratory mode, whose separate incomplete extension
does not enter this proof.

## All-width growth-eight consequence for lower thin 110

Lower thin `110` has fixed wakes `{0,4,5,6}`. The upper F123 cap in this
subfamily has wakes `{0,2,5}` through seven, fixing `W-5,W-2,W` and
leaving one residual wake. The previous complete width-sixteen exclusion
gives `W>=18`, so the lower and upper seven-offset bands are disjoint.

Write fibre `j=-t mod3`, sign `(-1)^t`, and longitudinal coordinate
`n=ceil(t/3)`. P22 at growth eight requires fibre sizes 4,2,2: the
four-wake fibre has a 3+1 sign split, and each smaller fibre has two
wakes with the same sign. Lower fixed wakes supply two positive
fibre-zero wakes, one positive fibre-two wake and one negative
fibre-one wake. Width zero modulo six forces both fibres zero and two
to have at least three fixed wakes, requiring two four-wake fibres.
At width two, fibre zero already has a valid four-wake 3+1 split, but
fibre one has two wakes of opposite signs. That pair has signed sum
zero and needs at least two additional wakes to reach two modulo four;
only one residual wake is available. Both widths are impossible.

Hence `W=6m+4`. Lower wakes zero/six already fill positive fibre zero;
upper W completes positive fibre two alongside lower four. The three
fixed fibre-one wakes are `5,W-5,W-2`, with two negative signs and one
positive, so the one residual must be negative in fibre one:

```
O={0,4,5,6,6p+5,W-5,W-2,W},
1<=p<=m-3,  m-p odd.
```

The fixed signed moment is `2m+5`; the residual subtracts `2p+2`.
Moment one modulo four therefore requires odd `m-p`. The seven fixed
wakes have eleven increasing-fibre pairs; the residual adds three,
giving even rank fourteen. Its interval initially gives `1<=p<=m-2`,
and the odd parity sharpens the upper bound to `m-3`. The initial bound
does not assume quiet upper six/seven: `p<=m-1` follows from `6p+5<=W`,
and equality `p=m-1` duplicates the fixed wake `W-5`. Conversely these
bounds and parity satisfy all of these arithmetic conditions; they do
not establish a physical trajectory.

The only residual upper distance is `6(m-p)-1`, hence at least seventeen
and equal to seventeen modulo twelve. In particular upper offsets six
and seven are quiet, contradicting the local theorem. The minimum
arithmetic example is width 28 with wakes `{0,4,5,6,11,23,26,28}`.

An independent original-coordinate check exhausts every unused residual
from lower level eight through W at each even width 18 through 150,
including possible upper six/seven, and finds exactly the displayed 121 endpoint
sets, all with upper offsets six through sixteen quiet. The all-width
scope follows from the sign, rank and moment derivation, rather than
the finite regression. Only this cap family is closed.
