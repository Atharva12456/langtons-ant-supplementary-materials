# The last width-18 placement above lower fat123 `(0,1,111)` is impossible

24 September 2026. For drift `(1,-3)`, growth eight and lower fat-cap
band `(omega_3,omega_4,j,k,l)=(0,1,1,1,1)`, the remaining width-18 wake
placement is

```text
B = {0,2,4,7,8,10,16,18}.
```

Its upper cap is fat `(1,2,3)`. A complete join of both cap frontiers
excludes B at every period. Combined with the previous width-through-16
exclusion and the three other width-18 exclusions (A, D and upper guard),
this proves the necessary bound **`W>=20`** for this lower band.
It does not exclude larger widths or the full drift orbit.

## Count constraints and complete frontiers

For each physical row `t=0,...,18` and arrival/turn port `p`, let
`c[t,p]` be its nonnegative integer multiplicity. Horizontal arrivals
occur only on even rows and vertical arrivals only on odd rows. The
right-minus-left excess is one on B and zero elsewhere. For each
heading `h`, arrivals on row `t` equal departures with that heading
on row `t-SHIFT[h]`; counts outside the strip are zero. Fix the known
lower rows zero through four and upper cap rows zero through two,
with the upper headings rotated by a half-turn.

These are necessary conditions on every full highway. At each frontier
extension the checker rejects a row-count choice only if it has no
completion to this integer count system. It then enumerates all
alternating words compatible with necessary finite-return adjacency.
Words are rejected only by a witnessed wrong finite first return or
an infeasible exact integer lifted clock. The clock has
`N>=max(6,number of represented events)` and `N=6 mod 8`, with no upper
bound on N. There is no arbitrary row-length cutoff.

The surviving lower frontier counts at levels five through eight are
`8,20,40,31`. The upper counts at inward offsets three through eight
are `4,7,41,130,191,3821`. The upper seed includes all possible initial
bands; none is assumed away.

## Joining without filling the center row

Rotate upper headings by 180 degrees, preserving chronological order.
The lower frontier occupies physical rows zero through eight; the
upper frontier occupies rows ten through eighteen. Row nine is still
unassigned. Any common extension must satisfy three conditions:

1. East departures on row seven equal east arrivals on row ten.
2. West departures on row eleven equal west arrivals on row eight.
3. The two induced port-count vectors on center row nine agree.

Exactly 3,520 pairs satisfy these conditions, in two count groups of
56 and 3,464 pairs. For each pair, ordinal matching of represented
ports determines partial successor paths. Every pair has a finite
path returning to the same physical cell at an event other than its
required next stable event. These paths use only assigned rows;
no choice of center-row word can repair them.

The exclusion uses actual cumulative-voltage-zero returns. A repeated
quotient vertex alone is not treated as a physical return. An independent
implementation of ordinal matching and direct flow matching reproduces
the 3,520 pairs and contradictions: 3,516 pairs already have a four-step
return contradiction, and the other four have an eight-step one.

## Reproduction

Run `python code/python/verify_lower_fat123_a0_b1_111_width18_b.py`.
It regenerates the necessary full-strip count system, both frontiers
and all joins, and writes
`results/lower_fat123_a0_b1_111_width18_b_checks_2026-09-24.json`.
The result records per-row rejection counts and a complete sample
return path with cumulative voltage. The independent audit is retained
locally as `work_a0_111_next/audit_w18_b_join.py` and
`work_a0_111_next/w18_b_join_audit.json`; the canonical verifier does
not depend on those exploratory files.
