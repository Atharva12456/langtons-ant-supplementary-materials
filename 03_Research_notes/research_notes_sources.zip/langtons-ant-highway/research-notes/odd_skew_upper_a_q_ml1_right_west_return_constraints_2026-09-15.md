# Return constraints when D4=SR in Q, M_L1

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

In the remaining right-turn case for `D4`, three late
east arrivals on twelve must turn left. If `F5=ER`,
the earlier turn `F4=ER` is also forced, and ten has
the consecutive triple `F4=ER,WL,F5=ER` with both
gaps equal to four. If `F5=EL`, the west departure
on thirteen feeding ten's last south departure is `NL`.

Neither entire `F5` branch is excluded here. The
`D4=NL` alternative and the rest of Q remain open.

## Notation

Use
`odd_skew_upper_a_q_ml1_last_west_orders_2026-09-15.md`.
The relevant ending on nine is

```text
NR from E5,D3=NL,NR from E6,SL0,D4=SR,SL1,NR from c,SL2.
```

Call the six corresponding east arrivals on twelve
`A,B,C,D,E,F`, in that order. Thus `C` is supplied
by `SL0`, `D` by `SL1`, and `F` by the final `SL2`.
The ending on eleven is

```text
Pb=SR,SLm,Pc=SR,PL=NL,NR,SL.
```

The west targets of `Pb,Pc,PL` on eight are
`b=WR,c=WR,L9=WL`. The port `PL` is supplied by
the final `WR` on ten, and the following `NR` by
`F7=EL`.

## The fixed east turns on twelve

The three-step path from `Pc` through `c` and its
north arrival on nine ends at `E`. A right turn
would return from `Pc=SR` to `SL`, contrary to its
immediate successor `PL=NL`. Hence `E=EL`.

The south predecessor of `Pc` on twelve has a square
first return to `E=EL`. It is therefore the preceding
east arrival `D=ER`, immediately before `E`, and it
supplies `Pc`.

This is the penultimate south departure on twelve.
Only one south departure remains, supplying the final
`SL` on eleven. If the last east arrival `F` were
`ER`, it would also be the last south departure,
forcing a wake on twelve. Thus `F=EL`.

The turn at `C` must also be left. The seven-step
path from `Pb` through

```text
8:b=WR,9:D3=NL,6:WL2,5:SL3,8:E6=EL,9:NR from E6,12:B
```

has the following alternatives. If `B=ER`, its south
step supplies `SLm`, the only south arrival between
`Pb` and `Pc`. Then `C=ER` would add a further south
arrival before `D=ER`, which supplies `Pc`.

If `B=EL`, the incoming first return on twelve forces
the consecutive pair `A=ER,B=EL`, with `A` supplying
`Pb`. A right turn at `C` would then have to supply
`SLm`. But `C,D` would be consecutive east right
turns supplying consecutive south arrivals, leaving
no possible `WL` between them. Both alternatives
exclude `C=ER`.

We have therefore proved

```text
C=EL, D=ER, E=EL, F=EL,
```

with `D,E` consecutive stable events. The last south
departure on twelve is a `WL`, either before or
after `F`.

## F5=ER forces F4=ER

In this branch the ending on ten is

```text
...,U=WL,F5=ER,Z=WL,Y=WR,F6=EL,X=WR,F7=EL.
```

Here `U` supplies `D4`, and `Z` is the last south
departure, supplying `SL2` on nine. The pair `U,F5`
is consecutive with gap four, by the square through
`D4,6:WR2` and the middle north arrival on seven.

Let `Ru` be the west departure on thirteen feeding
`U`. Its next west departure `Rz` feeds `Z`. There
is a twelve-step first return

```text
Ru -> 10:U -> 9:D4 -> 6:WR2 -> 7:middle NR -> 10:F5=ER
   -> 9:SL1 -> 12:D=ER -> 11:Pc=SR -> 8:c=WR
   -> 9:NR from c -> 12:E=EL -> north arrival on thirteen.
```

If `Ru=SR`, its target is `Rz=NL`, supplied by
`E=EL`. Then

```text
12:E=EL -> 13:Rz=NL -> 10:Z=WL -> 9:SL2 -> 12:F=EL
```

is a square with two left-turn endpoints. Therefore
`Ru=NL`.

Starting at the north predecessor of `Ru` on twelve
gives an eight-step first return to `D=ER`. That
predecessor must be `C=EL`, immediately before `D`.
Consequently

```text
9:SL0 -> 12:C=EL -> 13:Ru=NL -> 10:U=WL -> 9:D4=SR
```

is a square first return. Let `T` be the south
predecessor of `SL0` on ten. The incoming vertical
steps give `tau(U)-tau(T)=4`. Hence `T` and `U`
are consecutive stable events with opposite turns.
Since `U=WL`, the south departure `T` must be `ER`.

The following event after `U` is `F5=ER`, so `T`
is the preceding east arrival `F4=ER`. We obtain

```text
10: ...,F4=ER,U=WL,F5=ER,Z=WL,Y=WR,F6=EL,X=WR,F7=EL;
tau(U)-tau(F4)=4;
tau(F5)-tau(U)=4.
```

In this branch, `C=EL,D=ER,E=EL` are also three
consecutive stable events on twelve.

## F5=EL forces a left west departure on thirteen

The other branch has

```text
10: ...,F4=ER,F5=EL,F6=ER,Z=WL,X=WR,F7=EL.
```

Let `Rz,Rx` be the last two west departures on
thirteen, feeding `Z,X` respectively. Suppose
`Rz=SR`. Its square through `Z,SL2,F=EL` forces
the consecutive target `Rx=NL`, supplied by `F`.

Let `J` be the east arrival on fourteen supplied by
the penultimate east departure on eleven, namely
the final `NR` from `F7`. The path

```text
Rx -> 10:X=WR -> 11:PL=NL -> 8:L9=WL -> 7:final SL
   -> 10:F7=EL -> 11:final NR -> 14:J
```

has seven steps. If `J=ER`, it would return from
the last west departure `Rx=NL` to another west
departure `SR`. Thus `J=EL`.

Starting at the south predecessor of `Rz` on fourteen,
follow its square to `Rx` and then this seven-step
path. The twelve-step first return to `J=EL` forces
its immediately preceding east arrival `J0=ER` to
supply `Rz`. The source of `J0` is `SLm` on eleven:
the events between `SLm` and the final `NR` are the
west departures `Pc,PL`.

This gives the eight-step first return

```text
11:SLm -> 14:J0=ER -> 13:Rz=SR -> 10:Z=WL -> 9:SL2
       -> 12:F=EL -> 13:Rx=NL -> 10:X=WR -> 11:PL=NL.
```

Its direction word is `E S W S E N W N`. Both
endpoints turn left. Hence `Rz=SR` is impossible.

Therefore `Rz=NL`. Its incoming square on twelve
forces `WR` immediately before `F=EL`; the following
north arrival on thirteen, supplied by `F`, is `NR`.
This fixes another west turn but does not exclude
the entire branch.
