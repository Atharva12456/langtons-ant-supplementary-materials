# Growth-eight case ledger

The continuations are dated checkpoints. Later entries supersede earlier
open-case statements; the latest positive-skew continuation is dated 4 October
2026. The earlier ledger below retains the chronology of the intermediate
reductions. No whole growth-eight drift orbit is closed.

## Continuation: 21 September 2026

The upper `(1,2,2)` fat-cap profile at drift `(1,-3)` is now excluded at every period. The new hand proof uses the existing two-sided normal form: offset-five word B forces a same-cell first return with the wrong immediate successor; word A at the upper cap would require `0>=N+18`. It uses no period cutoff or bound on black lifetimes. See [odd_skew_upper_fat122_exclusion_2026-09-21.md](odd_skew_upper_fat122_exclusion_2026-09-21.md).

Consequently family A in the September 13 wake-family table is closed, including all its P, Q, R and single-ER continuations. The sole remaining recorded family with a lower `(1,2,2)` cap is B, with an upper `(1,2,3)` cap. Other lower-cap profiles remain separate; the entire `(1,-3)` drift orbit is still open. The historical progress entries below retain their original sequence and are superseded by this paragraph where they say family A or its continuations remain open.

The accompanying `verify_upper_fat122_exclusion.py` checks six explicit closed-walk certificates, their half-turns, and the exact integer clock sum. These are checks of the displayed proof certificates, not an end-to-end Lean formalization.

A further hand proof now removes the three `k=0` initial long-row bands at an upper `(1,2,3)` cap with non-wake inward levels three and four. The only possible initial bands are the short row `3:NR,NL`, or the long-row triples `(j,k,l)=(1,1,1),(1,2,0),(2,1,0)`. Family B satisfies these hypotheses. The excluded triples are `(1,0,2),(2,0,1),(3,0,0)`; the first two give upper-clock contradictions, and the third gives incompatible first returns. No wake assumption at level five or deeper, period cutoff, or lifetime bound is used. See [odd_skew_upper_fat123_four_band_reduction_2026-09-21.md](odd_skew_upper_fat123_four_band_reduction_2026-09-21.md). Its checker verifies fifteen closed first-return paths, one translated path, and the exact clock sums `N+10` and `N-2`, the latter positive for `N>=6`. All four retained initial bands remain unresolved. This narrows family B without closing it or the full drift orbit.

## Continuation: 22 September 2026

Nine lower `(1,2,3)` initial bands are now excluded at every period; see the [combined prefix note](https://drive.google.com/file/d/1mfU0G9CA4g_AQ5sOMl6ni3LIZSCIonUR/view?usp=drivesdk), the separate notes for the [(1,0,2)](https://drive.google.com/file/d/1bZqZeOF4G8RBfFNCvwofZAnTFb7RH66G/view?usp=drivesdk), [(2,0,1)](https://drive.google.com/file/d/1LoaIRb_B3yTyx9DepJwZWnY8CijTNWA9/view?usp=drivesdk), and [(1,1,0)](https://drive.google.com/file/d/1yMnf8752AZVl3OIltWVAm-bisxwpJeWh/view?usp=drivesdk) exclusions, and their exact checkers. With `omega_3=0`, the `(j,k,l)=(1,0,2)` and `(2,0,1)` bands are impossible for either value of `omega_4`. With `omega_3=1`, the entire `(2,0,0)` and `(1,0,1)` bands are impossible for either value of `omega_4`, and `(1,1,0)` is impossible when `omega_4=0`. These remove nine of the twelve lower `(1,2,3)` initial bands in the September 12 normal form. The three remaining bands are `(1,1,1)` with `omega_3=0` and either `omega_4`, plus `(1,1,0)` with `omega_3=omega_4=1`.

At an upper `(1,2,3)` cap with the Family B non-wake offsets five, seven and eight, the retained `(j,k,l)=(2,1,0)` band requires offset six to be wake. In the Family B parameterization this means `r=m-1` (and hence `p+m` even). [Exact upper-prefix checking](https://drive.google.com/file/d/1_yk0wDnHvqU6iMipjClnuYBOtHfwaf70/view?usp=drivesdk) leaves 6,574 integer-clock-feasible prefixes through row ten in this wake-six band; the short band and the `(1,1,1)` and `(1,2,0)` bands also retain checked prefixes. At the lower end of Family B, [level nine is uniquely `(NR,SL)^4`](https://drive.google.com/file/d/1lTHvbL2tO77LIbpUmhiSomBXmmASbkoH/view?usp=drivesdk) for either surviving level-eight word; [exact clocks leave eight or seventeen row-ten words](https://drive.google.com/file/d/1QRIj2VcfNrZtDUEhFqokk_QKEfK_RGE5/view?usp=drivesdk). The three open lower `(1,2,3)` bands have [two `(1,1,1)` prefix frontiers](https://drive.google.com/file/d/1G3oo8l7FQ4fsxYN3iOF5TKxykwBTY4px/view?usp=drivesdk) and [one wake-three level-ten restriction](https://drive.google.com/file/d/1LEC5u2iTryEcVETVk_vs4azwPZLLQDOw/view?usp=drivesdk), each with surviving local prefixes. Other lower-cap profiles remain separate; the full `(1,-3)` orbit is not closed.

## Continuation: 23 September 2026

The `(j,k,l)=(1,0,2)` exclusion for both values of `omega_4` has been reproduced independently of the 22 September checker. `odd_skew_lower_fat123_a0_102_exclusion_2026-09-22.md` and `code/python/verify_lower_fat123_a0_102_exclusion.py` enumerate without any P22 restriction or cycle extrapolation. Both bands still die at level nine (survivors `4,42,60,452,0` and `4,57,294,3112,0`). A Java explorer with an exact parametric clock (`code/java/StableWordFrontier.java`) and a raw-word reimplementation give the same counts; the latter exhausts about `7.5*10^11` alternating words at level nine.

A new lemma: an upper missing cap whose offsets `5-9,11,12` are non-wake is impossible at every period, with offset ten of either parity. The upper frontier is `2,1,1,2,3,2,5,4,6,0` at offsets three through twelve, and no P22 condition is used. P22 and the rank parity force exactly this schedule when the lower band is `(0,1,1,1,1)`, so **that band has no upper missing cap**. See `odd_skew_upper_missing_quiet_band_2026-09-23.md` and `code/python/verify_upper_missing_quiet_5_12_lemma.py`. The same note records a compression lemma: shifting all wakes above an empty twelve-level gap preserves P22, the rank parity and the moment modulo four. Schedule lists through width `2D+130` are therefore complete for prefixes of depth `D`.

The two cap pairs with a non-fat lower cap and an upper `(1,2,3)` cap are now classified by P22, rank and moment. Lower missing gives families M-I (`W=6m+4`, wakes `{0,1,4,6,6i+4,6k+2,6m+2,6m+4}`, `1<=i<k<=m-1`, `i+k` odd) and M-II (`W=6m+2`, wakes `{0,1,4,7,6k+2,6j+1,6m,6m+2}`, `1<=k<j<=m-1`, `j-k` even); width `0 mod 6` is impossible. Lower guard gives eight families A1, A2, B0-B3, C1, C2. See `lower_missing_upper_fat123_wake_families_2026-09-22.md` and `lower_guard_upper_fat123_wake_families_2026-09-22.md`. P22, rank and moment also force the upper cap of the lower band `(1,1,1,1,0)` to be `(1,2,3)`.

A stronger lemma: **every missing cap, lower or upper, has a wake at inward offset six**. With offset six non-wake and every other offset free, the lower frontier dies at level ten and the upper one at offset twelve, using no P22 condition. See `odd_skew_missing_cap_offset6_2026-09-23.md` and `code/python/verify_missing_cap_offset6_lemma.py`. **Family M-II is therefore impossible**, since level six is non-wake there. For the band `(0,0,1,1,1)` with an upper missing cap, only the upper schedules `{0,1,4,6}` and `{0,1,4,6,10}` through offset fourteen survive; explicit runs kill the other sixteen by offset twelve.

**Hand proofs (23 September, later).** The missing-cap lemmas and the `(1,0,2)` exclusion now have conceptual proofs that do not rest on enumeration.

- `odd_skew_missing_cap_offsets_five_six_2026-09-23.md` proves that every missing cap, lower or upper, has offset five non-wake and offset six wake. The upper-cap statement for offset five is new. The proof uses first returns and two lemmas: a square lemma, and a "two-west" Lemma M that forbids a row once `N_2` is forced right after `W_2`. The clock enters only through one strict inequality at each cap.
- `odd_skew_lower_fat123_a0_102_hand_proof_2026-09-23.md` proves that both `(1,0,2)` bands are impossible. It uses only alternation, ordinal matching and first returns, with no clock. Short closed walks force rows five through eight. A twelve-step return then makes every row-nine word contradictory.

Their walk and word certificates are `code/python/verify_missing_cap_hand_*.py`, `verify_missing_cap_lemma_m.py` and `verify_lower_fat123_a0_102_hand_walks.py`. Consequently the exclusion of family M-II and of the upper missing cap for band `(0,1,1,1,1)` are hand-proved as well.

## Continuation: 24 September 2026

The upper fat `(1,2,3)` initial `210` band requires a wake at inward offset
five or six. If both are non-wake, exact finite-return and lifted-clock
frontiers eliminate wake-seven at offset seven and both choices at offset
eight, at every period. See [the near-wake note](https://drive.google.com/file/d/1mqGUbyKRnBkpw7SHLoS6uCcMnGJs1UrO/view?usp=drivesdk) and its standalone checker. In lower-missing M-I, upper offsets five and six are both non-wake, so its upper `210` band is impossible. The short, `111`, and `120` upper bands remain.

One of Family B's 25 lower row-ten words has no row-eleven continuation:
`ER EL WR WL WR WL WR WL` after row-eight B. A forced twelve-step,
zero-voltage first return from the sixth west departure on row eleven to its
first north arrival contradicts alternation in every possible count row.
The other 24 words retain exact-clock prefixes. See [the row-ten word
exclusion](https://drive.google.com/file/d/1Pr0_oqlGXC0fuK1QMtexZvIGwbNR1PAb/view?usp=drivesdk).
Across those remaining prefixes, [the lower row-twelve
restriction](https://drive.google.com/file/d/1u4Se35sf5lp4Kui8tQdmL_lcGCxRAHqb/view?usp=drivesdk)
requires at least one `ER` event. For every possible row-eleven prefix,
assuming zero `ER` makes an explicit four-step first return
`12:WL -> 11:SR -> 8:WR -> 9:NR -> 12:EL` force two consecutive
left turns. The checker verifies this path for all 1,150 row-eleven
adjacency prefixes and independently regenerates the 25 row-ten
candidates. The result needs no period or width cutoff. It does not
close Family B.

If Family B row twelve has exactly one `ER`, [a self-contained exact
frontier](https://drive.google.com/file/d/1PCdQeTFBSsCqEKyECAfBQT3n3DaYfRa7/view?usp=drivesdk)
leaves 21 necessary prefixes, all with row-twelve counts
`(ER,EL,WR,WL)=(1,7,9,3)`. They follow only four of the 24 retained
row-ten words. The verifier regenerates all 565 clock-feasible row-eleven
prefixes; at row twelve it checks 532 adjacency words, rejects 272 by
finite wrong returns and 239 by exact integer clocks. Other positive
`ER` counts are separate, and Family B remains open.

The 21 one-`ER` row-twelve prefixes [all have a necessary non-wake
row-thirteen extension](https://drive.google.com/file/d/1X7m7jU0zUGM5yFS-m_ijix0mTTx1i0Un/view?usp=drivesdk).
An exact unbounded integer-clock witness search checks 473 candidate
words and records one extension for each prefix. This rules out a quick
row-thirteen local exclusion in that branch; it does not establish a
highway, and the `ER>=2` row-twelve branch remains separate.

For the lower fat `(1,2,3)` band `(1,1,1,1,0)`, [the all-width wake-family
classification](https://drive.google.com/file/d/1hRowND4nJ_QMMs08Cki1Fw1GQV0za6EI/view?usp=drivesdk)
leaves four parameter families with an upper fat cap. Its width-twelve join
fails by center-row length, so `W>=16`. The upper `210` band survives the
near-wake rule only in the width-`0 mod 6` A edge family. The global wake
coupling removes ten of 104 lower level-nine prefixes; 94 remain.

For the lower fat band `(0,1,1,1,1)`, [two-cap exact frontier
checks](https://drive.google.com/file/d/128TVJGo0RowLD5iBfQlDzKEsk2rZIxHY/view?usp=drivesdk)
exclude all widths through sixteen, giving the necessary bound `W>=18`.
At width eighteen, P22, rank and moment leave four endpoint wake
placements; one fat-upper placement, `{0,2,4,12,14,15,16,18}`, has
disjoint lower and rotated-upper center-row port patterns and is also
excluded. The unique guard-upper placement
`{0,2,4,5,11,16,17,18}` is [excluded by an upper-cap first-return
frontier](https://drive.google.com/file/d/1VHCUx3kRku5yYJgykEAEqUIt2dOqXSRN/view?usp=drivesdk)
that dies at inward offset seven. Fat-upper placement A,
`{0,2,4,6,8,15,16,18}`, is [excluded by its center-row north-arrival
count](https://drive.google.com/file/d/1TBaTy4pFfcQJan7KqMCcO66ROp-7ncwT/view?usp=drivesdk):
the lower frontier requires 11 or 15 arrivals, while the upper frontier
requires exactly 3. The last fat-upper placement B,
`{0,2,4,7,8,10,16,18}`, is also [excluded by a two-cap
join](https://drive.google.com/file/d/1Yy5-XBpZX721pyTniG_Z25gSDOCQP0qn/view?usp=drivesdk):
all 3,520 compatible depth-eight pairs have a witnessed wrong finite
first return before the center row is filled. An independent ordinal-flow
audit reproduces the pairs and contradictions. Thus **all width-eighteen
placements are excluded and `W>=20`** for this lower band. These checks
impose no period cutoff; larger widths remain open.

For the lower fat band `(0,0,1,1,1)` with an upper missing cap,
[P22, rank, moment and the missing-cap offset theorem](https://drive.google.com/file/d/1sshbEJqo670iEmb6o1olPxGxsXQ0Tf9s/view?usp=drivesdk)
leave exactly `W=6m+4` and wakes
`{0,2,6i+2,6j,W-6,W-4,W-1,W}` with `1<=i<j<=m-1` and `i+j`
even. Thus `W>=28`. This is an all-width necessary family, with
surviving wake sets and no stable-word exclusion yet.

An [upper-guard hand lemma](https://drive.google.com/file/d/1a5R7alNlckbtMRDtDnH2EhOVaZW_a2__/view?usp=drivesdk)
excludes wake at inward offset seven after quiet offsets three through
six. The [extended hand proof](https://drive.google.com/file/d/1NRR2rj5_3D3dZkCGmvfNnEHiiYgkF3T3/view?usp=drivesdk)
also excludes non-wake offset seven: 686 exact alternating words leave
only five adjacency-compatible candidates, all with explicit wrong
finite first returns. Thus an upper guard must wake at least one of
offsets three through six. One exact clock identity is needed at row
five; the standard-library certificates use no solver. This lemma needs
no P22, rank, moment, width or period bound. Of the six minimum-width
(`W=20`) guard placements above lower band `(0,0,1,1,1)`, the earlier
wake-seven part excludes three and the stronger lemma excludes a fourth,
`{0,2,7,8,11,18,19,20}`. Two remain at that width; see the
[static corollary](https://drive.google.com/file/d/15Hndl63paAeZ4gF86ytr3k5VPCyfOc8s/view?usp=drivesdk)
and the extended hand proof.

For lower fat band `(0,0,1,1,1)` with an upper guard, the [complete
all-width static classification](https://drive.google.com/file/d/1B_struDCAvKFRDcc5xk1_9I_LiGF4mFz/view?usp=drivesdk)
uses P22, rank, moment and the guard near-wake lemma. Exactly nine
indexed wake families remain. Its finite audit matches the formulas
through width 160, with 11,478 static placements; the algebra gives
the all-width scope. The minimum width is twenty, with precisely the
two placements above. This static classification alone does not exclude
their stable words; the later prefix proof below does.

For lower fat band `(0,1,1,1,1)` and an upper guard, [all-width P22,
rank and moment algebra](https://drive.google.com/file/d/1jT4qX6Q6sKYcr-4J6sW59GNjrM4iKew4/view?usp=drivesdk)
leaves six indexed wake families. The two extra wakes have upper inward
offsets either `(6i+4,6j+4)` or `(6i+1,6j+1)`, with the parity of
`m+i+j` fixed by `W=6m+r`. The stronger guard lemma excludes every
odd-offset family and every even-offset family with `i>=1`. Only even
`i=0` remains: inward wakes four and `6j+4`, `j>=1`, with the moment
parity still required. This cap pair remains open.

At the minimum M-I width `W=22`, the unique wake set is
`{0,1,4,6,10,14,20,22}`. Its upper long `111` band is now
[excluded by a two-cap join](https://drive.google.com/file/d/1xVbCczz0H4Xg4hOI_Abz12_kGCKj1E5K/view?usp=drivesdk):
all 6,948 count-compatible pairs of 302 lower center words and 104 upper
depth-ten prefixes have witnessed wrong finite first returns. Its upper
`120` band is also [excluded by a full-width
join](https://drive.google.com/file/d/1schnV0sFbm66PBuBEZe1sedTNVzwQj8q/view?usp=drivesdk).
The count-filtered upper frontier has 1,800 depth-ten prefixes. Among
133,597 center-count pairs, 133,485 have wrong finite returns and 107
fail relaxed upper clocks. Each of the last five complete row systems
has a replayable twelve-step zero-voltage cycle, checked independently
without a solver. The last width-22 upper short band is now [excluded by
an exhaustive two-cap join](https://drive.google.com/file/d/17fiKl8r5p_d4eW2DOZHAx3ZYqATzJPkk/view?usp=drivesdk).
It leaves 24,240 upper depth-ten prefixes and 1,868,917 center-word
pairs; 1,865,618 have wrong finite returns, 3,141 fail a relaxed upper
clock, and each of the remaining 158 complete row systems has an
independently replayed wrong finite return. Thus M-I requires `W>=28`;
its upper short, `111`, and `120` bands remain open at larger widths.
No period cutoff is imposed.

Three more [upper-guard early-wake prefix
exclusions](https://drive.google.com/file/d/1OcmCPHokRudyLIjnbWGaM1NmwAWkrhT0/view?usp=drivesdk)
now hold at every period. With upper guard rows `0:WR,1:NR,2:WR`, the
patterns `(wake3,quiet4)`, `(quiet3,4,wake5,quiet6,7)`, and
`(quiet3,4,5,wake6,7)` all have empty finite frontiers. Direct raw-word
enumeration gives, respectively, 8, 376, and 992 witnessed wrong first
returns on their terminal rows; the third pattern also uses one explicit
row-five clock identity `2-N>=5`. The first two remove entire all-width
`r2_fibre2_odd_top` and `r2_fibre0_odd_top` families for lower fat band
`(0,0,1,1,1)` with an upper guard. The third removes the
`r4_odd_pair_singleton_near` subfamily with its top odd wake at `W-7`.
Thus the two remaining `W=20` placements are excluded, so that cap pair
requires `W>=22`; of its two static `W=22` placements, only
`{0,2,10,12,18,20,21,22}` survives these local checks. Seven classified
parameter families still have unresolved placements at larger widths.

For the last lower fat `(1,2,3)` band `(1,1,1,1,0)`, a [two-cap width-sixteen
join](https://drive.google.com/file/d/1lSx7-6sLMGRjDoxC5A4L3KnG7_18gZER/view?usp=drivesdk)
excludes its unique `W=16` placement `{0,2,3,4,6,12,14,16}`. Exact
integer-clock frontiers leave 45 lower center prefixes and 1,263 rotated
upper prefixes. Of 2,880 center-count pairs, 2,440 fail a cross-cut
directional count and all 440 balanced pairs have an explicit wrong finite
first return. Together with the earlier `W=12` join, this band now
requires `W>=18`; wider placements remain open.

At `W=18`, the A(1,1) placement `{0,2,3,4,6,8,16,18}` is
[excluded by center-row count
incompatibility](https://drive.google.com/file/d/1amzPL8wb4A8d0k4ldogAgL0cvPpH4_yx/view?usp=drivesdk).
The lower frontier has 48 center states with four count signatures.
The upper frontier has 191 inward-seven states; all 965 possible
inward-eight count options lead to 6,296 inward-nine count options,
none matching a rotated lower signature. Upper row-eight and row-nine
word constraints are omitted in this screen, making it a sound
superset. The other `W=18` placement A(2,2),
`{0,2,3,4,12,14,16,18}`, is also [excluded by an exact two-cap
join](https://drive.google.com/file/d/1PA-n9i3XGMTFSzXAatJLko9vWX25WRcu/view?usp=drivesdk).
The verifier regenerates both cap frontiers from fixed seeds and joins
62 full nineteen-row systems. All 62 balance every directed-edge count
and have an explicit finite wrong first return; a separate
standard-library checker replays every path. With both `W=18`
placements excluded, this cap pair requires `W>=20`. The unique
static `W=20` wake placement is `{0,2,3,4,6,16,18,20}` and remains open.

For lower fat `(0,1,1,1,1)` with an upper guard, the unique static
`W=20` placement `{0,2,4,10,16,18,19,20}` is also
[excluded](https://drive.google.com/file/d/1iVIqAXErMCjiy2GOrULzewOTfWu2uOab/view?usp=drivesdk).
The exact two-cap frontiers yield 76 lower and 124 upper prefixes. A
full-strip count model leaves 31 compatible count-signature pairs, each
with exactly one possible middle-row count pattern. Across 8,254 cap
word pairs, finite-return checking leaves 1,890 row-nine and 7,331
row-ten words. Row eleven has just one adjacency word; its complete
21-row system contains a replayed 56-step zero-voltage wrong return to
row-zero event zero. A separate standard-library checker validates the
word system and path. This guard-cap pair now needs `W>=22`; the same
lower band with a fat upper cap still has open `W=20` placements.

The remaining lower fat `(0,0,1,1,1)` / upper-guard width-22 placement
`{0,2,10,12,18,20,21,22}` is now [excluded by an exact two-cap
join](https://drive.google.com/file/d/1bb2-b6HH45VsDqBFWeSdgkBsIRvjYCTK/view?usp=drivesdk).
The verifier regenerates 2,182 lower and 1,409 upper count-compatible
depth-ten prefixes, then 3,395 lower center prefixes. Of 1,723,256
center-word pairs, 1,722,896 have explicit wrong finite returns and 149
fail a relaxed upper clock. After 25 full-width count rejections, all
455 complete 23-row systems have wrong finite returns. Ten stored paths
pass a separate ordinal-flow replay. The earlier upper-guard prefix
lemma excludes the other width-22 placement and both width-20
placements. There is no static width-24 placement, so this cap pair
requires `W>=26`; its wider schedules remain open.

Open cases in the `(1,-3)` orbit after this continuation:

| Lower cap | Upper cap | Status |
|---|---|---|
| `(1,2,3)` band `(0,0,1,1,1)` | M, G, `(1,2,3)` | open; upper M requires `W>=28` and one wake family; upper G requires `W>=26`, with three static placements at that width |
| `(1,2,3)` band `(0,1,1,1,1)` | G, `(1,2,3)` | open; whole band `W>=20`; guard pair `W>=22`, only even-offset `i=0` family remains |
| `(1,2,3)` band `(1,1,1,1,0)` | `(1,2,3)` only | open; `W>=20`, unique `W=20` static placement `{0,2,3,4,6,16,18,20}`; upper `210` only in A edge |
| `(1,2,2)` family B | `(1,2,3)` | open; 24 lower row-ten words remain, row twelve needs `ER`; all 21 necessary `ER=1` prefixes continue to row thirteen, and `ER>=2` remains open |
| missing, family M-I | `(1,2,3)` | open; `W>=28`; upper `210` excluded throughout, all three other bands excluded at `W=22`; M-II excluded |
| guard, eight families | `(1,2,3)` | open |

Level-by-level search from either cap explodes in each open case. Rows can grow without any known bound, because fully free ports (`WR` at even levels, `SL` at odd levels) stay unconstrained until later rows are built. The whole `(1,-3)` orbit is not closed.

## Continuation: 30 September 2026 — literal positive skew (1,3)

The new [positive-skew cap reduction](positive_skew_cap_reduction_2026-09-30.md)
works directly at drift `(1,3)` with transverse coordinate `t=3x-y`.
It does not transfer the `(1,-3)` cap lemmas by reflection. At every positive
period and width, the missing `(1,1,0)` profile is impossible at either cap,
and the guard `(1,1,1)` profile is impossible at the lower cap. These have
hand proofs using ordinal directed-edge matching, physical first returns,
and, for the lower guard, one lifted-clock inequality using only `N>0`.
The upper guard remains open: reversing the drift changes that inequality.

The lower `(1,2,2)` cap has a rigid prefix through level seven, independently
of the eight-wake budget and P22. In particular `omega_3=0`, `omega_4=1`,
with rows three and four `WR,WL,ER,WL` and `SR,SL,SR`. The full eight
templates are given in the note. This rigidity is computer-assisted: a
complete raw alternating-word verifier with unbounded integer `N>0` and
strict row order leaves `4,14,15,48,8` states at levels three through seven.
It uses no width, lifetime or period cutoff, period congruence, four-step
gap, or P22 filter. The independent verifier
`code/python/verify_positive_skew_cap_reduction.py` was freshly run to PASS;
its missing and lower-guard frontiers end in zero states. The result is
`results/positive_skew_cap_reduction_missing_guard_thin_audit.json`.

At a lower `(1,2,3)` cap, the third-level short word `WR,EL`, and both long
words with ER after the second WR, contradict `N>0` by direct integer-clock
arguments. A complete finite-domain check then excludes ER-first words
through level seven without P22, a growth budget or a bound on N. A separate
physical-coordinate word generator and Z3 clock independently reproduce
all domains and rejections. Only the ER-between-WR word remains, with
three possible row-four bands: `SR,SL,SR,SL` when `(omega_3,omega_4)=(0,0)`,
that word followed by NR when the bits are `(0,1)`, and `SR,SL,SR` when
the bits are `(1,1)`. The independent check retains 41 necessary local
prefixes through level seven and was freshly rerun successfully.

The three row-four bands of the middle lower-fat word now also have a
separate [hand proof](positive_skew_fat123_middle_hand_rigidity_2026-09-30.md)
from exact timing and physical first returns, audited independently of the
finite search. The ER-first branch exclusion remains computer-assisted.

At growth eight, the last `(omega_3,omega_4)=(1,1)` lower-fat band cannot
meet an upper guard. A new hand argument exhausts the three even width
residues: P22 makes `W=0,2 mod6` impossible with the one remaining wake;
at `W=4 mod6` that wake cannot repair the fixed odd rank. This closes
that entire cap pair at all widths and periods, not the lower band with
other upper caps or the whole orbit.

Both lower fat profiles retain necessary local continuations. The remaining
cap pairs are lower `(1,2,2)` or `(1,2,3)` against upper guard, `(1,2,2)`,
or `(1,2,3)`. **The whole `(1,3)` drift orbit remains open.** These results
do not close the separate `(1,-3)` orbit or assert existence of any candidate.

The [positive-skew two-cap count and word join](positive_skew_width16_exclusion_2026-09-30.md)
now excludes all transverse widths through sixteen, so every remaining
growth-eight candidate has `W>=18`. Counts are unbounded nonnegative
integers, and no upper bound on period or lifetimes is imposed. The
complete prefix-count model is unsatisfiable for even `W=2..14`.
At `W=16`, 6,604 cap count-signature pairs leave exactly three full-strip
count structures. Their 38 cap-word pairs all have explicit wrong physical
first returns before reaching the central row. Independent geometric count
and physical-word implementations reproduce all counts and exclusions.
The width lower bound does not exclude the larger-width families.

Two further all-width hand exclusions follow from P22 and rank. Lower
`(1,2,3)` band C (wake three/four) cannot meet an upper `(1,2,3)` cap with
wake inward offset three. Lower band B (quiet three, wake four) cannot
meet an upper `(1,2,3)` cap with quiet offset three and wake offset four.
The first gives a fibre-sign or parity contradiction with the one remaining
wake; the second leaves a fixed odd rank that the two forced same-fibre
residual wakes cannot change. The complete modulo-twelve regression checks
all unbounded residue shadows and passes. See sections 10--11 of the cap
reduction note. Band C also has quiet lower levels five and seven by P22.

The remaining positive-skew families are lower thin, or lower fat bands
A/B/C, against the upper possibilities in that note. Every remaining
family retains unbounded arithmetic shadows. Exact continuation checks
retain 25,278 lower-thin prefixes through level nine and 1,453 upper-guard
prefixes through inward offset nine after all-width arithmetic schedule
restriction. All 5,552 emitted upper-schedule rejection certificates were
independently replayed. These local survivor domains do not establish
highways and do not close `(1,3)`.

Lower fat band C with an upper `(1,2,3)` cap also requires quiet lower
level eight. Assuming wake eight, P22 eliminates `W=2,4 mod6`; for
`W=0 mod6`, rank forces the only residual wake to be level six, but its
moment is three instead of one. The hand proof and complete residue-order
regression are section 12 of the cap reduction note. Of 225 complete local
band-C prefixes through eight, this removes the 118 wake-eight prefixes
from that cap pair; 107 quiet-eight prefixes remain. The upper `(1,2,2)`
case is separate.

The remaining lower band-C / upper `(1,2,3)` cap pair has a complete
[seven-family endpoint classification](positive_skew_fatC_fat123_wake_families_2026-09-30.md).
With quiet upper offset four, its two residual wakes are one of four
two-parameter families; with wake offset four, its one residual wake
belongs to one of three one-parameter families, with the width parameter
and parity included. The hand derivation exhausts fibre/sign possibilities,
rank and the moment. A direct-coordinate audit matches every accepted
placement through width 120 and all 23 independent unbounded examples.
Each family has arbitrarily large endpoint realizations; chronological
realizability and exclusion remain separate.

## Continuation: 1 October 2026 — smaller positive-skew obstructions

The [lower-fat ER-first exclusion](positive_skew_fat123_er_first_hand_exclusion_2026-10-01.md)
now has a hand proof at every growth, width and positive period. Ten
zero-voltage physical returns force prefixes on rows five and six,
then four east-arrival turns on seven. Both turns at the third east
arrival on five contradict physical next-visit order or directed
arrival ordinals. The twelve-step EL contradiction passes through a
different copy of row four at step six; its first physical return is
step twelve. A small fresh path/alternation checker and independent
structural audit verify the proof. The prior large finite-domain
certificate remains a separate regression.

The [band-C wake reduction](positive_skew_bandC_schedule_reduction_2026-10-01.md)
uses the fact that growth-eight P22 admits no two disjoint opposite-sign
pairs. Band C has exactly two full fibre sign patterns. Its upper
offset three is quiet with either remaining upper cap. Upper offset
five is also quiet, using a small independently replayed local lemma
for upper `(1,2,2)`. With upper `(1,2,3)`, only four extra wake schedules
through offset nine remain: `{}`, `{4}`, `{4,8}`, `{7}`. The saved
complete upper domain through seven shrinks conditionally from 13,707
to 1,892 prefixes; the reduced domain and source hash are saved in
`results/positive_skew_bandC_upperF123_depth7_pruned_2026-10-01.json`.

For [lower thin bits111 / upper (1,2,2)](positive_skew_tight_thin_reductions_2026-10-01.md),
the exact endpoint family has `W=6m+4`, residual wakes `6q-2,6p-1`,
`2<=q<=p<=m`, and even `m+p+q`. The whole unbounded subfamily
`q<p=m` is now excluded. It forces an isolated upper offset-five wake,
but quiet offsets three/four and wake five require wake six by the
small local lemma. Surviving parameters have `p<=m-1`, or `q=p=m`
with even `m>=4`. Root freshly reran the compact formula audit and
independently replayed all 1,374 physical and two clock rejections.

The [upper-guard local proof](positive_skew_upper_guard_small_hand_obstructions_2026-10-01.md)
also replaces a larger schedule search for the lower-thin / upper-G
pair: the four arithmetic schedules containing upper offset three or
five are excluded by small hand arguments through seven. A fresh
standard-library raw checker examines 574 extensions, and root
separately replays all 566 physical rejections and the single `2+N`
clock contradiction. This arithmetic consequence is restricted to
that lower cap; upper G remains possible in other unresolved branches.

These results restrict entire unbounded subfamilies and shorten
subsequent searches. They do not bound the remaining widths, join the
bulk chronological histories, construct a highway, or close `(1,3)`.
**The whole positive-skew growth-eight orbit remains open.**

## Further continuation: 1 October 2026 — the entire thin111 member is excluded

The [lower-thin rigidity theorem](positive_skew_lower_thin_hand_rigidity_2026-10-01.md)
now has a full hand proof at every growth, width and positive period.
It exhausts the third/fourth-row forms, uses zero-voltage physical
first returns and two inequalities with N>0 in the lower clock, and
forces all eight c/e/f templates through seven. Root's structural
review, a separate adversarial audit and the fresh fifteen-walk,
eight-template, thirty-two-ordinal-path checker found no gap.
The older large finite certificate remains a regression.

At growth eight the [entire lower-thin 111 wake member](positive_skew_lower_thin_111_exclusion_2026-10-01.md)
is now excluded for every upper cap, width and period. Its fixed signs
force uniform positive fibre zero, uniform negative fibre one, and
the mixed four-class fibre two. The upper extremum has `W=4 mod6`;
upper G and F123 then violate those fixed fibre signs. Upper F122
leaves exactly the family `W=6m+4`, residual wakes `6q-2,6p-1`,
`2<=q<=p<=m`, and even `m+p+q`. Every such shadow has quiet upper
offsets three, four, seven and eight. Offsets five and six wake
exactly when `p=m` and `q=m`, respectively.

The previous isolated-five lemma eliminates `q<p=m`. New weak local
lemmas eliminate both remaining parameter branches: upper F122
quiet offsets three through seven force wake eight, and upper F122
with quiet three/four and wake five/six also forces wake eight.
Each is a complete finite raw-word domain with unbounded `N>=1`,
strict order, no P22/growth/gap-four/period-residue filters,
and no exploratory frontier imports. Root independently replayed
all 10,336 physical-return rejections and eight clock UNSAT systems,
and separately rejected all 2,540 terminal row-eight raw words.

This argument does not depend on the previous width-sixteen exclusion:
eight wakes plus quiet lower levels one/two/three give `W>=10`, and
the exact residual bounds give `W>=16`. The saturated arithmetic
`W=16` case is covered
by the same quiet-eight obstruction. Thus no small-width exception
or coordinate cutoff remains in the 111 exclusion.

All 179 lower-thin 111 prefixes among the 25,278 saved complete
depth-nine prefixes are removed. The 25,099 remaining necessary
prefixes, source hash and theorem reference are saved in
`results/positive_skew_lower_thin_depth9_without111_2026-10-01.json`.
Seven lower-thin wake templates and the fat bands remain unresolved;
the whole `(1,3)` growth-eight orbit remains **open**.

## Further continuation: 1 October 2026 — upper-six obstruction and tighter remaining thin families

A new checked local obstruction excludes an upper F122 cap with quiet
offsets three/four/five, wake six, and quiet seven through twelve.
Its complete weak-clock necessary domain has 43 prefixes through
eleven and none through twelve. Root independently regenerated every
emitted candidate, recomputed all count-vector domains/raw-word totals,
replayed all 18,561 physical first-return rejections and verified all
10,933 rejected unbounded integer-clock systems. The argument has no
growth assumption or visit/width/period ceiling; the upper clock uses
`+N`, `N>=1`, and strict stable order only.

Combined with P22, rank and moment, this proves that lower band C
with upper F122, quiet upper four and wake upper six must also have
wake upper eight. The remaining endpoint shadow is exactly
`W=6m`, `O={0,2,3,4,6p+2,W-8,W-6,W}`, `m>=4`,
`1<=p<=m-3`, and odd `m+p`. The next residual upper distance is
sixteen modulo twelve, at least sixteen; all upper offsets nine
through fifteen are quiet. See the
[local obstruction and arithmetic proof](positive_skew_bandC_upper6_wake8_reduction_2026-10-01.md).
This excludes the quiet-eight branch, not the whole cap pair.

The [remaining-thin upper reductions](positive_skew_remaining_thin_upper_reductions_2026-10-01.md)
also show that upper F122 quiet three/four with wake five allows
only lower bits 000 or 010, with `W=2 mod6`; its forced wake six/eight
and quiet seven exclude every lower member having wake five or seven
under that upper schedule. Two exact compact endpoint families remain.
For upper quiet three through seven, forced wake eight gives five
exact endpoint families for lower 011/101/110. The complete unbounded
residue DP for all seven remaining lower members has 6,264 accepted
arithmetic residue templates after these local restrictions, versus
20,676 before. These are residue words, not periods or trajectories.
The independent original-coordinate audit checked 1,504,375 candidate
sets at widths ten through 180 and matched every compact formula.

A still stronger [upper-F122 obstruction](positive_skew_upper_thin_quiet34_requires_quiet5_2026-10-01.md)
now says that quiet upper three and four require quiet upper five,
at every growth, width and positive period. The unique wake-five/six
prefix through seven fails at eight for both possible wake bits:
the same SWNE physical first return skips an intervening stable event.
The new exhaustive terminal check rejects all 170 quiet-eight and
202 wake-eight raw words and independently replays every return.
The first-seven-row classification remains computer-assisted;
the terminal obstruction has a hand proof. This excludes both of
the just-classified lower-thin 000/010 upper-wake56 families. The
6,264 residue-template count above describes the intermediate stage;
six additional residue templates for that upper schedule are now removed.

Another complete raw [upper-F122 lemma](positive_skew_upper_thin_quiet6_requires_quiet7_2026-10-01.md)
excludes quiet three through six with wake seven, for either bit eight,
at every growth/width/positive period. The independent generator
exhausts 6,286 words, geometrically replays all 6,255 physical rejects,
and rederives six rejected weak integer-clock systems. Combining it
with band-C fibre signs excludes the **entire C/F122 upper-wake-seven
branch**. C/F122 now has quiet upper seven, and quiet upper four
always requires wake eight. Its quiet-four/quiet-six shadows are four
exact unbounded endpoint families; the quiet-four/wake-six shadow is
the single family above. None is asserted physically realizable.

Applying both stronger local lemmas to the complete remaining-thin
residue DP leaves 5,222 necessary arithmetic residue templates. The
new report, preserving the intermediate report, is
`results/positive_skew_remaining_thin_upperF122_residues_2026-10-01.json`.
Its per-lower-bit counts are 4,238 / 252 / 342 / 10 / 338 / 14 / 28
for 000 / 001 / 010 / 011 / 100 / 101 / 110. The just-excluded
quiet-six/wake-seven cap removes a further 1,036 residue templates.
These counts measure the exact finite residue alphabet, not a
percentage of the full orbit or a number of hypothetical highways.

For band C/upper F123, the empty extra-wake schedule narrows from
112 upper prefixes at seven to 36 at eight and 28 at nine. Independent
non-frontier code regenerated all 2,187 emitted candidates, replayed
2,123 physical rejections and verified the survivors' upper clocks.
The extra-wake-seven schedule has complete survivor counts
17,5,12,78 through eight/nine/ten/eleven; twelve remains incomplete
and has a saved feasible necessary sample, so no exclusion follows.
The separate lower negative-wake-nine domain retains 966 prefixes;
all 194 physical and 2,331 clock rejections were independently checked,
but its quiet-ten extension is explicitly incomplete.

Seven lower-thin members, lower fat bands A/B/C and arbitrary-width
coupled chronology remain unresolved. The full `(1,3)` growth-eight
orbit remains **open**.

## Further continuation: 1 October 2026 — thin101/110 upper-six cap families closed

The [new all-width exclusion](positive_skew_thin101_110_upper6_exclusion_2026-10-01.md)
removes lower-thin bits 101 and 110 against upper F122 whose wake
offsets through eight are exactly `{0,6}`. P22, rank and moment leave
three exact endpoint families. The previous quiet-twelve upper-six
obstruction forces nearby upper wakes eleven (101), nine (110 at
width four modulo six), or ten with either choice at twelve (110 at
width two modulo six). Every resulting local schedule is now excluded
by a complete weak-clock domain through twelve.

Four independent audits recomputed all exact count-vector/raw-word
domains, regenerated every emitted candidate without the frontier
engine, geometrically replayed all 83,376 physical rejections and
independently proved all 51,064 integer-clock contradictions.
Z3 checks of all 735 distinct clock signatures passed. The clocks
use the upper sign `+N`, integer `N>=1` unbounded above, and strict
stable order only. The growth-eight consequence is therefore not a
bounded period or visit search. All four terminal domains were
completed; the initial unsaturated time-limited stage was explicitly
incomplete and was superseded by a complete run.

The current remaining-thin/F122 arithmetic residue package has
5,210 templates after deleting these twelve templates. The report is
`results/positive_skew_remaining_thin_upperF122_residues_2026-10-01_d.json`.
Lower101 retains ten and lower110 twenty arithmetic residue templates
against their other F122 schedules; their F123 cap families remain
open. Upper G was already excluded for both by the all-width endpoint
classification. Neither whole lower member nor the whole `(1,3)`
orbit is claimed closed. Seven lower-thin members and the remaining
fat-band cap pairs still require coupled chronology at arbitrary width.

## Further continuation: 1 October 2026 — thin110 upper-fat wake-five family closed

The [upper-F123 local exclusion](positive_skew_upper_fat_quiet34_wake5_exclusion_2026-10-01.md)
proves that quiet offsets three/four and wake five require wake six or
seven. Both choices at eight were exhaustively checked with integer
`N>=1` unbounded above, upper-clock sign `+N`, and strict stable order.
The independent audit regenerated every emitted candidate, rederived
351 exact count vectors and 533,498 raw words, replayed all 158 physical
rejections and proved all 34 rejected clocks in Z3. All checks passed.

For lower-thin110 at growth eight, P22, moment and rank force
`W=6m+4` and wake set `{0,4,5,6,6p+5,W-5,W-2,W}` with
`1<=p<=m-3` and odd `m-p`. Its only residual upper wake is at distance
`6(m-p)-1>=17`, forcing offsets six/seven quiet and contradicting the
local theorem. This excludes the whole cap family for every width and
period. Lower110 against its other caps and the whole `(1,3)` orbit
remain open. The separate all-quiet upper-fat and upper-thin wakes-four/six
explorations have incomplete deeper stages and provide no exclusions.

## Further continuation: 2 October 2026 — another generic upper-thin exclusion

The [upper-F122 wakes-three/four theorem](positive_skew_upper_thin_wake34_quiet567_exclusion_2026-10-02.md)
excludes quiet offsets five/six/seven for both choices at eight and nine.
The independent all-raw implementation covers 66 count vectors and
5,025 alternating words, with 5,006 physical rejects and one direct
unbounded integer-clock contradiction. At eight, the unique prefixes
for its two bits differ only by a final NR. The terminal hand argument
uses two verified zero-copy returns: north departure three is followed
by east arrival one, and north departure four by east arrival four.
These force adjacent first/fourth east arrivals, skipping two ordinal
arrivals, which is impossible. Initial prefix completeness remains
computer-assisted; the terminal argument enumerates no row-nine words.

For lower-thin110 at growth eight, upper wakes three/four force
`W=6m+2`, residual `6r+5`, `1<=r<=m-2`, and even `m-r`. Its upper
distance is `9+12h`, so upper five through eight are quiet and the
whole all-width cap family is excluded. The generic theorem also
applies to every other lower cap. It removes another 96 thin/F122
arithmetic residue templates, leaving 5,114. A separate global upper
depth-seven filter retains 14,399 of the original 14,412 necessary
prefixes after the four proved generic wake-pattern exclusions.

The [width-eighteen joined proof](positive_skew_thin101_width18_exclusion_2026-10-02.md)
excludes the whole lower-thin101 member at that width. The freshly
audited weak upper seed has 99 prefixes; all 567 joining count vectors
are accounted for, and all 427 emitted words fail by 424 physical
returns or three independently reconstructed original-gauge clocks.
No visit or period ceiling is imposed. Arbitrary widths remain open.

Aggregate counts alone cannot close the saturated thin101/F123
wake-seven/eight family: a separately verified quiet six-row pump
preserves its count state and zero net displacement, producing
counts-only models at every `W=6m>=24`. The saved
`work_positive_skew_thin101_coupling_hand_20261002/coupling_findings.md`
records the exact bridge displacement requirements and the pump.
This is evidence that ordinal/physical/clock coupling is needed, not
a highway construction. The entire `(1,3)` orbit remains **open**.

For the remaining lower011/F123 wake-six family, the
[completed upper-fat rigidity calculation](positive_skew_upper_fat_wake6_rigidity_2026-10-02.md)
reduces all early words through seven to three under the forced quiet
schedule through ten. Its 415 necessary continuations were independently
regenerated; 46,862 physical and 32,929 clock rejections were verified,
with 668 distinct clock signatures checked by Z3. Quiet eleven remains
incomplete and nonempty, so that family is not excluded. All 415 also
pass an independently checked shared event-count period floor; the small
earlier period witnesses are not upper bounds. The full orbit remains open.

## Further continuation: 3 October 2026 — quiet-bridge chronology

The [quiet-bridge note](positive_skew_quiet_bridge_chronology_2026-10-03.md)
proves a new hand restriction after lower-thin101, conditioned on row
eight `SR SL` and quiet nine/eleven. Three physical `WNES` returns
force `SR10` to be three or four, for either bit at ten. Its horizontal
transfer is therefore `8+omega10` or `4+omega10`. This excludes the
previously exhibited count pump, whose row-ten choice was five. The
aggregate count pump was valid count data; it fails stable chronology.
At width 24, exact two-cap cut counts and displacement additionally
exclude this row-eight variant in the saturated upper-F123 wakes-seven/
eight family. A further complete independently audited fixed-period join
excludes all other quiet row-eight words at that same width, with no
survivors after row twelve. Thus the saturated thin101/F123 wakes-seven/
eight cap family is closed at width 24, and its remaining possible widths
are at least 30. Other cap families and arbitrary widths remain open.

The lower-thin110 / upper-F122 wakes-four/seven quiet band has been
independently checked through upper row twelve with the necessary
shared-period floor `N>=max(62,assigned upper events+34)`, `N=2 mod4`,
and gap four. All 262 count vectors and 38,960 emitted candidates were
regenerated: 12,377 physical rejects, 24,507 clock rejects, and 2,076
necessary survivors. Every survivor passed an original-variable Z3
clock check. Quiet thirteen remains incomplete; this family is open.

Two independently proved earlier checks use translated excursion order
and wrong physical returns through one new-row visit. Together they
reduce the completed row-twelve emissions to 18,470 while retaining all
2,076 survivors. They improve the exact continuation without imposing
a period or visit ceiling. The width-22 lower011 join also has an audited
count domain and complete row-eight join, but its later stages are still
in progress. The entire literal `(1,3)` growth-eight orbit and all ten
drift orbits remain **OPEN**; no arithmetic completion count changed.

## Further continuation: 4 October 2026 — width-22 thin011 join excluded

The [complete finite join](positive_skew_thin011_width22_exclusion_2026-10-04.md)
excludes lower-thin011 / upper-F123 wake six at width 22, with wake set
`{0,4,6,7,8,16,20,22}`. Independent checks cover all 1,518 parents,
617,021 emitted row-nine words, 135,293 reached row-ten words, 234,821
finite existence domains, and 113,976 imported or new clock rejections.
Exact full counts determine periods 210, 226, or 242, with no arbitrary
period or visit ceiling. The sole terminal clock rejection has two
independent hand contradictions valid for every period. Fresh root hash
checks bind both complete audits to the final sources.

This supersedes the preceding entry's statement that the later width-22
stages are still in progress. The cap family's remaining possible widths
start at 28. Arbitrary widths, other cap families, the full literal `(1,3)`
orbit, and all ten drift orbits remain **OPEN**. The arithmetic template
counts have not changed, and the paper artifacts are unchanged.

## Earlier ledger and chronological record

This note fixes the finite case split before any further all-period argument is
attempted.  It uses only heading reset, the strand-density bound, the signed
mod-four residue theorem, and the kinematic period congruence.  Chronology, line
parity, and the lifted-rank conditions can only remove rows from this ledger.

Scope correction, 3 September 2026: no whole drift orbit is currently certified
closed here. The earlier `(4,-4)` closure assumed full occupancy of both rails,
which extremal singleton visits do not establish. That proof excludes the
full-rail subfamily. The `(3,-3)` six-rail refinements have the same extra
hypothesis; see `rail_occupancy_scope_audit_2026-09-03.md`.

The 4 September first-entry argument gives the uniform period bound
`N>=6 max(|a|,|b|)+2(|a|+|b|)`. At diagonal drift `(m,-m)`, growth eight
requires `N>=10m+4`; for `m=4`, the period congruence strengthens this to
`N>=48`. The argument also identifies exact integer detour charges summing
to two. Four-step waits have charge one and eight-step waits have charge
zero. See `first_entry_detour_charges_2026-09-04.md`. These lower bounds
do not close an orbit or replace the existing finite-period records.

There is now an explicit infinite family of partial-rail `(4,-4)` boundary
placements passing the rank sign and every drift-periodic additive mod-four
endpoint charge. It is relaxed data, not a family of ant traces. See
`growth8_m4_partial_rail_obstruction_2026-09-04.md`; an exclusion must use
conditions beyond those tests.

The mixed `4+4` arrival-axis split at `(4,-4)` is excluded by the four-lane
rank sign. The remaining branch is pure-horizontal `8+0`. Its complete
additive endpoint condition is the single labelled-height congruence in
`growth8_m4_pure_additive_normal_form_2026-09-04.md`. These are all-period
reductions, but the pure branch and hence the whole orbit remain open.

## Drift orbits

Write the drift as `d=(a,b)`.  A heading-reset period has even length, so
`a+b` is even and `a,b` have the same parity.  At growth eight the density
bound gives

```text
max(|a|,|b|) <= 4.
```

There are 40 nonzero vectors satisfying these two conditions.  Quarter turns,
which are symmetries of Langton's rule, divide them into ten orbits.  One choice
of representatives is

```text
(1,-1)   (2,0)    (2,-2)   (1,3)    (1,-3)
(3,-3)   (4,0)    (2,4)    (2,-4)   (4,-4).
```

Reflections are not used: they reverse the chirality of the rule and do not
identify two cases in this problem.

## Coarse residue data

Let `A` be the number of the eight odd translation classes whose strand bases
have even checkerboard parity.  For every nonzero coordinate of the drift, P22
requires the signed sum in each coordinate residue to be `2 (mod 4)`.  The
resulting possibilities are:

| drift representative | unsigned counts in the `x` residues | unsigned counts in the `y` residues | possible `A` | possible `N mod 8` |
|---|---|---|---|---|
| `(1,-1)` | `8` | `8` | `1,3,5,7` | `2,6` |
| `(2,0)` | `2+6` or `4+4` | — | `0,2,4,6,8` | `0,4` |
| `(2,-2)` | `2+6` or `4+4` on both axes | same | `0,2,4,6,8` | `0,4` |
| `(1,3)` | `8` | a permutation of `4+2+2` | `1,3,5,7` | `2,6` |
| `(1,-3)` | `8` | a permutation of `4+2+2` | `1,3,5,7` | `2,6` |
| `(3,-3)` | a permutation of `4+2+2` | a permutation of `4+2+2` | `1,3,5,7` | `2,6` |
| `(4,0)` | `2+2+2+2` | — | `0,2,4,6,8` | `0,4` |
| `(2,4)` | `2+6` | `2+2+2+2` | `2,6` | `0` |
| `(2,-4)` | `2+6` | `2+2+2+2` | `2,6` | `0` |
| `(4,-4)` | `2+2+2+2` | `2+2+2+2` | `0,4,8` | `0` |

Rows and residue labels may of course be permuted by translating the coordinate
origin.  The table records only margins, not the unbounded transverse positions
of the translation classes.

The final column follows from the already proved congruence

```text
N/2 + a + b + A = 0  (mod 4).
```

For example, every odd-coordinate orbit can occur only at period `2` or `6`
modulo eight, while the three density-saturated magnitude-four cases with two
nonzero coordinates can occur only at period zero modulo eight.

The table deliberately stops at the coarse arithmetic layer.  Restoring P3 and
the exact-row part of P22 sharpens both axis rows.  At `(2,0)` there are exactly
four wake-bearing rows, each containing both residues, and `N=4 (mod 8)`.  At `(4,0)`
every occupied row is checker-balanced and `N=0 (mod 8)`.  The proofs are in
`growth8_axis_classification_2026-08-22.md`.

At `(2,0)`, exit-cycle chronology now reduces every last-exit cycle to four
vertices on two adjacent rows, with directions `E,N,E,S`; every first-departure
cycle has directions `W,N,W,S`.  A complete period is the last-exit cycle plus
four actual closed return excursions.  Their wake contribution is not yet
bounded strongly enough to exclude growth eight.  See
`axis_two_exit_cycles_2026-09-03.md` and `cylinder_exit_cycles_2026-09-03.md`.

For a normalized diagonal drift `(m,-m)`, extremal rigidity supplies a second
refinement.  If `alpha,beta` count odd classes on horizontal- and vertical-arrival
levels, then

```text
alpha+beta=8,       alpha=beta=m (mod 2),       alpha>=2.
```

Each rail contains at least one visited singleton, giving the last inequality.
Full occupancy of all `m` lanes has not been proved. Combining the displayed
conditions with the coarse P22 checker counts leaves the ordered splits

```text
m=1: (3,5), (5,3), (7,1)
m=2: (2,6), (4,4), (6,2), (8,0)
m=3: (3,5), (5,3), (7,1)
m=4: (4,4), (8,0).
```

For `m=2`, the `(8,0)` line is the checker-pure subfamily already excluded,
leaving the three mixed lines. The rank argument below excludes only the
full-rail part of the `m=4` row.

The following `(3,-3)` refinement assumes both rails are full. Their six
horizontal singleton classes and the wake-type parity law then force the
`7+1` checker split. Partial-rail candidates are not covered by this refinement.

The orientation of the `7+1` split is fixed. Choose phase zero at a vertical
arrival and translate that cell to the origin. Even transverse levels are then
even-checker and vertical-arrival. The six rail classes and the remaining
horizontal class lie on odd levels, while the one vertical class lies on an even
level. Hence `A=1`, and the period congruence sharpens the `(3,-3)` row to

```text
N=6  (mod 8).
```

This full-rail subfamily cannot contribute a period-58 candidate. The whole
orbit still has both coarse period classes, two and six modulo eight.

The `(3,-3)` placement is sharper than its checker split.  The two rails already
put two horizontal odd classes in every `x mod 3` residue.  The remaining
horizontal class and the one vertical class have opposite checker signs, so P22
forces them into the same `x` residue.  Applying the `y mod 3` clause puts them in
the same `y` residue as well.  If their levels are `h` and `v`, this says

```text
r_h=r_v,       h=v  (mod 3).
```

The three-lane rank sign is compatible with these conditions; it does not remove
the row.

The full additive mod-four family does give one more restriction.  Normalize the
rail levels to `1` and `W+1`, put the two extra classes in lane zero, and set
`k=(v-h)/3`.  Then

```text
k=W+1  (mod 4).
N>=4W+12|k|+2.
```

This rules out transverse width four but not the drift orbit: compatible
placements exist at every even width from six onward. Since `k` is odd, the
period bound is at least `4W+14`. The derivation and audit are in
`growth8_m3_additive_boundary_2026-08-23.md` and
`../code/python/growth8_m3_boundary_audit.py`.

The two odd skew rows also have one additive condition beyond P22.  For
`d=(1,3s)`, set `j=y mod 3` and `n=x-s floor(y/3)` on each odd class.  After
normalizing the period-start checker parity, every candidate satisfies

```text
sum_O (-1)^(n+j)n = 2-s  (mod 4).
```

Together with the three `y mod 3` residue equations, this exhausts the
drift-periodic zero-four-corner weights for these two orbits.  Static placements
still survive in both chiralities.  Their unique quotient parity flows also give
an even-interlacing condition among the three residue fibres.  In the first full
bounded window, 824 of 1,944 additive survivors meet it in each chirality.  See
`growth8_odd_skew_additive_2026-08-23.md`.

There is also a chronological cap restriction for `(1,-3)`.  Normalize a lower
missing-level cap to multiplicities `(1,1,0)` on levels zero through two.  Its
proved wake levels are `0,1,4`.  Exact same-cell returns, together with P22,
now force

```text
omega_6+omega_7 >= 1.
```

Thus this cap contributes at least four wake classes among levels zero through
seven.  The proof uses order-preserving edge matching, not a bounded search;
see `odd_skew_excursions_and_domino_transfer_2026-08-31.md`.  An upper guard
would make both levels six and seven non-wake by P22 and the rank theorem, so
the lower-missing/upper-guard cap pair is excluded at every period.  The direct
proof, including hand proofs of the missing/missing and guard/guard boundary
exclusions, is in `odd_skew_missing_guard_exclusion_2026-09-03.md`.  The reverse
guard/missing orientation was reduced to two necessary wake families in
`odd_skew_guard_missing_families_2026-09-03.md`. The September 9 record
`odd_skew_guard_missing_complete_exclusion_2026-09-09.md` excludes both
families by finite exact local chronology checks without a period or width
cutoff. Thus every remaining candidate has a fat cap, with profile
`(1,2,2)` or `(1,2,3)`, at one or both ends.

The hand argument in `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`
restricts a lower fat cap to fourteen possible five-level stable bands:
two with profile `(1,2,2)` and twelve with profile `(1,2,3)`. In the former,
level three is non-wake and the next two rows are

```text
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,[WR]^omega_4.
```

This two-band restriction also holds at an upper `(1,2,2)` cap after a
half-turn of the heading labels. Every lower `(1,2,2)` band requires the
black lifetime on level two to be at least `N+14`; eight of the twelve
lower `(1,2,3)` bands also require a lifetime longer than one period.
These are all-period necessary conditions. No general upper bound on
those lifetimes has been proved, and the drift orbit remains open.

There is a further all-period exclusion inside the lower `(1,2,2)` branch.
If levels four, five, and six are non-wake, a four-visit level six is
impossible: exact returns force a skipped stable visit by level nine,
regardless of the subsequent wake indicators. The remaining eight-visit
level-six row has only four possible stable orders. The hand proof and
the four orders are in `odd_skew_fat122_even_band_2026-09-12.md`.

For a lower `(1,2,3)` cap with a wake on level three, P22 gives a separate
global exclusion: the upper cap cannot be missing, and upper offset three
must be non-wake. All lower levels `5 mod 6`, including level five, must
also be non-wake. The pair argument is included in the normal-form note.

The even-band reduction has since been completed at the next inward
returns: every lower `(1,2,2)` cap must satisfy `omega_4+omega_5>=1`.
When both levels are non-wake, all eight-visit level-six orders fail
exact returns. The remaining five-visit wake row leads to a forced
six-step path of displacement `(1,-3)` between stable events in the
wrong order for `N>=6`. The proof is
`odd_skew_fat122_early_wake_2026-09-12.md`.

For the early wake pattern `(omega_4,omega_5)=(0,1)`, the level-six row
with two `ER` ports forces the wakes `0,5,6,8` and no other wake through
level eight. P22 then excludes both a missing and a guard upper cap;
the upper cap must be fat. An upper `(1,2,3)` cap in this subfamily
requires `W=4 mod 6`. See
`odd_skew_fat122_three_visit_six_2026-09-12.md` for the direct return proof.

The two-sided return argument in
`odd_skew_fat122_two_sided_wake_2026-09-13.md` proves the weaker but
orientation-independent bound `omega_4+omega_5+omega_6>=1` at either
`(1,2,2)` cap. Combining it with P22, rank interlacing, and the additive
moment reduces the lower `0,5,6,8` branch to three necessary wake
families. Their upper caps are respectively `(1,2,2)`, `(1,2,3)`, and
`(1,2,2)`, with a forced upper wake at offset four, two, and five.
Their minimum widths are `26`, `28`, and `22`. In the last family,
upper offset six cannot be the three-visit row: it has six or seven
visits according to its wake indicator. The parameter families and
proof are in `odd_skew_fat122_three_visit_wake_families_2026-09-13.md`.
The subsequent theorem in `odd_skew_fat122_rigid_five_wake_2026-09-13.md`
excludes the six- and seven-visit offset-six rows whenever offsets four
and five have wake indicators `(0,1)`, at either cap. Thus the
three-visit row and the wake pattern `0,5,6,8` are forced throughout
this branch. Applying the theorem at the upper cap excludes family C,
whose wake placement forbids upper offset eight. Families A and B
remain open. Together with the lower early-wake bound, they now cover
every lower `(1,2,2)` cap with level four non-wake. This does not close
the drift orbit or the fat-cap branches with level four wake.

For `omega_4=1` at a `(1,2,2)` cap, the single-`ER` offset-six row
has only words T and U when `omega_5=0`, or word V when `omega_5=1`.
Zero-displacement returns exclude the other prefix groups at either
cap. A lifted-time comparison between the third and fourth east
arrivals on offset eight excludes all these words at the lower cap.
Together with the earlier wake-five result, this proves that every
lower `(1,2,2)` cap has exactly two `ER` ports on offset six. Its
full count row is `(2,1,b-c+e,1+b-c)`, where
`(b,c,e)=(omega_4,omega_5,omega_6)`. The proof is in
`odd_skew_fat122_four_wake_single_er_2026-09-13.md`; no wake
assumptions beyond offset six are used. The sparse two-`ER` lower
continuations and the upper single-`ER` words remain open.
The same delayed-departure comparison also forces the last east
arrival on lower offset six to be `ER`: its east-arrival subsequence
is `ER,EL,ER` or `EL,ER,ER`.

The later reduction in `odd_skew_fat122_five_lower_bands_2026-09-13.md`
forces the last `ER` to be the second south departure on level six.
Consequently every lower `(1,2,2)` cap uses the level-five word starting
`SR,SL`, and its level-six word starts `ER,EL,ER`, with both stable
gaps exactly four. The remaining west-arrival tail is determined by
`(b,c,e)`. This leaves five necessary bands through level six: one for
`(b,c,e)=(0,1,1)`, and two choices of `e` for each of `(b,c)=(1,0)`
and `(1,1)`. When `b=1`, the fourth west departure on level seven is
`SR` followed immediately by `SL`. These are lower-cap restrictions;
the sparse continuations and the rest of the drift orbit remain open.

The four-visit band `(b,c,e)=(1,1,0)` is subsequently excluded in
`odd_skew_fat122_adjacent_wakes_force_six_2026-09-13.md`. Its single
west departure on level nine cannot satisfy the return order for
either turn at the last east arrival on level eight. Thus lower
wakes at both levels four and five force a wake at six, leaving
four necessary bands through level six. The exclusion uses no
conditions on the later wakes or on the period.

For the remaining lower bands with `b=1`, level seven has west
departure sequence `SR,SR,NL,SR,SR`. Its first six stable events
are `SR,SL,SR,NL,SR,SL`; the remaining `k=1-c+e` north right turns
are split before and after the last west departure. When
`(c,e)=(0,1)`, both cannot precede it. When `(c,e)=(1,1)` and the
single north right turn precedes it, levels seven and eight are
forced non-wake and wake respectively, and level eight has only
two possible fifteen-visit words. The all-period proofs are in
`odd_skew_fat122_seventh_level_2026-09-13.md`. These continuations
are still open.

The band `(b,c,e)=(1,0,0)` is excluded in
`odd_skew_fat122_four_only_forces_six_2026-09-13.md`. Both possible
orders of the remaining north arrival on level seven lead to
return contradictions, the longer argument ending at level eleven.
Together with the adjacent-wake exclusion, this forces `omega_6=1`
at every lower `(1,2,2)` cap. The remaining early triples are
`(0,1,1)`, `(1,0,1)`, and `(1,1,1)`; those continuations and the
rest of the drift orbit remain open.

For `(b,c,e)=(1,0,1)`,
`odd_skew_fat122_four_six_wake_order_2026-09-14.md` excludes
the level-seven order with one remaining north right turn on
each side of the last west departure. Both north right turns
must follow it. The surviving level-eight tail, from its third
east arrival, is

```text
ER,EL,WR,WL,ER,EL,WR,WL,(WR,WL)^(1-f),[WR]^g,
f=omega_7, g=omega_8.
```

The same hand-return argument forces `f=0` or `(f,g)=(1,1)`.
It excludes the alternative tail with the eighth south departure
before the last east arrival, but does not close this wake band.
The other early triples and the rest of the orbit remain open.

The surviving tail is subsequently excluded in
`odd_skew_fat122_four_six_band_exclusion_2026-09-14.md`.
A sixteen-step first return fixes the required west departure
on level eleven; this forces a twelve-step first return on
level eight with two right-turn endpoints. Thus the whole
lower band `(b,c,e)=(1,0,1)` is impossible. Every lower
`(1,2,2)` cap now has `omega_5=omega_6=1`, leaving only
the early triples `(0,1,1)` and `(1,1,1)`. These and the
other cap profiles remain open in the `(1,-3)` orbit.

The band `(b,c,e)=(1,1,1)` is also excluded, in
`odd_skew_fat122_adjacent_wake_band_exclusion_2026-09-14.md`.
The north-right-before-last-west order contradicts two lifted
clocks; the north-right-after-last-west order forces a third
west departure on level nine, where only two exist. Therefore
every lower `(1,2,2)` cap has the rigid early triple
`(omega_4,omega_5,omega_6)=(0,1,1)`. Its two previously
recorded wake families A and B are the only remaining cases
with this lower cap. They and the other cap profiles remain
open; the full `(1,-3)` orbit is not excluded.

The upper single-`ER` part of family A is reduced further in
`odd_skew_upper_a_single_er_reduction_2026-09-14.md`. A
zero-displacement left/left return excludes words T and V at
either `(1,2,2)` cap. Under family A's non-wake conditions at
upper offsets seven and eight, word U requires a wake at offset
six (`p=m-1`) and the fixed offset-seven word

```text
SR,SL,NR,NL,NR,SL,NR,NL,NR,NL,SR,SL.
```

The remaining U order and the upper two-`ER` branches are not
excluded. Family B and the other cap profiles also remain open.

For that last U order,
`odd_skew_upper_a_u_forced_tail_2026-09-14.md` excludes a
left turn at the fifth east arrival on offset eight and forces
the endings `ER,EL` on eight, `SR,NL,SR,SL` on nine,
`ER,WL,WR,EL` on ten, and `NL,NR,SL` on eleven. The final
four visits on six have successive gaps exactly four. These
are additional first-return restrictions, not an exclusion of
U or of family A.

`odd_skew_upper_a_u_eighth_words_2026-09-14.md` further
forces the second east arrival on eight to be `EL`, leaving
one ten-visit word and four fourteen-visit words there. In
the fourteen-visit alternatives, the fifth west departure on
nine is `NL`. A comparison of two upper-orientation clocks
forces the last east arrival `H` on twelve to be `EL`; twelve
ends at `H`, or with `H=EL,WR,WL`. These restrictions still
leave the U branch open.

The five offset-eight possibilities reduce to B0 alone in
`odd_skew_upper_a_u_unique_eighth_word_2026-09-14.md`:

```text
WR,WL,ER,WL,WR,EL,WR,EL,WR,EL,WR,WL,ER,EL.
```

The third south departure must precede the third east
arrival, excluding A, B2, and B3. A first-north-arrival
obstruction excludes B1. The remaining B0 word requires
`D1=SR,D2=NL` on nine; its middle departures and the
higher continuation remain open. This does not close U,
family A, or the whole orbit.

The remaining B0 word is excluded in
`odd_skew_upper_a_single_er_exclusion_2026-09-14.md`.
The three possible initial words on ten either force a
skipped return through the first west departures on eleven,
or force the first event on eight to be later than an event
on six which it must precede. This closes the entire upper
single-`ER` branch of family A. Its upper offset six must
now have two `ER` ports. The two-`ER` branches of A,
family B, and the other cap profiles in `(1,-3)` remain open.

The remaining two-`ER` words for family A are reduced in
`odd_skew_upper_a_two_er_normal_form_2026-09-15.md`.
Only the following three pairings through offsets five and
six survive the square-return constraints:

```text
5 A: SR,SL,NR,NL,NR,SL,NR,SL
6 P: ER,EL,ER,WL,WR,WL,[WR]^e;

5 B: NR,SL,SR,NL,NR,SL,NR,SL
6 Q: WR,WL,ER,EL,ER,WL,[WR]^e;
6 R: ER,WL,ER,WL,WR,EL,[WR]^e.
```

Here `e=omega_6` is still zero or one in each form. The
hand derivation excludes seven of thirteen initial local
combinations, leaving these six necessary bands. None of
the three forms, family B, or the full orbit is excluded
by this reduction.

Form R is narrowed in
`odd_skew_upper_a_r_requires_wake_six_2026-09-15.md`:
its `e=0` band is impossible, so R requires `h=1`
and `p=m-1`. With `e=1`, only the following two
offset-seven orders survive:

```text
M: SR,SL,SR,NL,NR,SL,SR,SL,NR,SL,SR,SL;
N: SR,SL,SR,NL,NR,NL,SR,SL.
```

The same note fixes the tail on eight in M and its full
fourteen-visit word in N. Those continuations and both
values of `e` in P and Q remain open. This removes one
complete local band, not form R or the whole orbit.

The M continuation of form R is excluded in
`odd_skew_upper_a_r_middle_exclusion_2026-09-15.md`.
A left/left first return forces the second east arrival
on ten to turn right; in M its resulting square skips
two intervening east arrivals. Only N remains for R.
For N, the eighteen-visit word on nine is fixed, ten
ends `WL,ER,WL,WR,EL`, and eleven ends `NL,NR,SL`.
The last east arrival on twelve is `EL`. These are
further restrictions, not an exclusion of N, P, Q,
family B, or the whole orbit.

The first east arrival on ten is narrowed in
`odd_skew_upper_a_n_first_east_reduction_2026-09-15.md`.
An equal-voltage comparison gives
`tau(S3)-tau(F1)>=16`, where `S3` is the third south
departure on ten. Thus `F1=ER` can only be the first
or second south departure; `F1=EL` can have only zero,
one, or two south departures before it. This leaves
five words on ten, excluding eight of thirteen initial
placements within N. The left-turn word L0, with no
earlier south departure, is then excluded: a forced
square gives `tau(E2)-tau(F1)=12`, while the required
visit order gives a lower bound of twenty. This leaves
four words, R1, R2, L1, and L2. In L1, the second west
departure on eleven must be `NL`; eleven begins
`SR,SL,NR,NL,NR`, and twelve begins `WR,WL,ER`.
The four surviving words, N, and the whole orbit remain
open.

Their west departures on eleven are further restricted in
`odd_skew_upper_a_n_third_west_corridor_2026-09-15.md`.
If the third west departure is `NL`, its predecessor
`U` on ten follows a fixed twelve-step path to `E2`
on eight, with no intervening visit to ten. Hence `U`
must be the last event on ten before `E2`. This forces
the third west departure to be `SR` in R2; in L1 its
only possible north predecessor is the fourth `WR`
on ten. The second west departure is `SR` in both R1
and R2, and the two initial words on eleven for R2 are
fixed. L1 requires `tau(I)-tau(E1)>=16` in either turn
case for its third west departure. These restrictions
leave all four words on ten open.

Form R is now completely excluded at the upper cap of
family A in `odd_skew_upper_a_r_exclusion_2026-09-15.md`.
In its sole remaining continuation N, the upper clock
puts the sixth and seventh west departures on eleven
after all north arrivals except the two fixed final ones.
Its ending is forced to be `SR,SL,SR,NL,NR,SL`.
The corresponding return paths force consecutive east
right turns `G10,G11` on twelve with no possible left
turn between them. Taking `G10=EL` instead gives an
eight-step right/right first return on five. This closes
N uniformly, including all four words R1, R2, L1, and
L2 on ten. With the earlier zero-wake and M exclusions,
both values of `omega_6` in upper form R are closed.
The remaining upper two-`ER` forms in family A are P
and Q, each with `omega_6=0,1`; family B and the other
cap profiles in `(1,-3)` remain open.

Form Q is narrowed in
`odd_skew_upper_a_q_requires_wake_six_2026-09-15.md`.
Its `omega_6=0` band is excluded: the last west
departure on nine would force an additional one. Thus
Q requires `h=1`, or `p=m-1`. Its third north arrival
on seven cannot precede the fourth west departure,
because the resulting eight-step first return skips
two stable visits. Four words on seven remain: either
of two prefixes, with that north arrival between the
last two west departures or after both. The last east
arrival on eight is `EL` in all four. Upper form R
is closed; P with either value of `omega_6`, Q with
`omega_6=1`, family B, and the other cap profiles
remain open.

The full offset-eight words for Q are classified in
`odd_skew_upper_a_q_eighth_word_forms_2026-09-15.md`.
There are four prefixes through the third east arrival:
one with `E2=ER` and three with `E2=EL`. The former
forces `D2=SR` on nine; the latter force `D2=NL` and
`WR` immediately before `E2` on eight. Four suffixes
remain in the middle placement and two in the after
placement, giving sixteen and eight formal words.
Where `E5=ER,E6=EL` are consecutive, the final west
pair on nine is `SR,NL`, and an adjacent `ER,EL`
pair on ten is fixed. This classifies the next row but
does not exclude another complete Q word.

The middle placement with `E5=ER` is excluded in
`odd_skew_upper_a_q_middle_right_exclusion_2026-09-15.md`.
The west departure on eleven feeding the fifth south
departure on eight must be `SR`; its twenty-step first
return forces the next west departure to be `NL`.
For suffix `M_R1` this gives a left/left square. For
`M_R0`, a further skipped-return argument forces an
east pair on twelve whose source time contradicts the
order on eight. This closes both suffixes for all four
prefixes. The middle placement now requires the pair
`E4=ER,E5=EL`. Q has sixteen formal words on eight
remaining: eight middle and eight after words. The
whole Q form and the `(1,-3)` orbit remain open.

Both remaining middle suffixes in Q require `D3=NL`
on nine, by
`odd_skew_upper_a_q_middle_third_west_2026-09-15.md`.
An `SR` there forces `F4=ER,F5=EL,F6=ER` on ten.
In `M_L0` there is no south departure left for `F6`;
in `M_L1` the forced final pair `F6=ER,F7=EL`
contradicts the last west-departure square on eleven.
Thus the `WR` immediately before `E6` on eight
supplies `D3=NL`. The final west departure on nine
is `SR` in `M_L0`; three endings remain in `M_L1`.
The same note also excludes `F5=EL` in `M_L0`:
it would require a north arrival on eleven between
two consecutive north departures on ten. This forces
the ending `WL,F5=ER,F6=EL,WR,F7=EL` on ten.
Neither entire suffix, Q, nor the orbit is excluded
by these further restrictions.

The `M_L0` continuation is reduced to two higher-row
endings in `odd_skew_upper_a_q_ml0_two_tails_2026-09-15.md`.
Its last three west departures on eleven occur after
the north arrival from `F6`, leaving only the north
arrivals from `X,F7` available. If the final west
departure is `NL`, eleven ends `NL,SR,NL` and twelve
ends `ER,EL,WR,EL,WR,EL`. If it is `SR`, eleven
ends `SR,NL,NR,SL,SR,SL`, with the corresponding
ten-event ending on twelve fixed in the note.
The earlier split at `F4` is not yet excluded, and
neither higher-row ending closes `M_L0` or Q.

The entire `M_L0` suffix is now excluded in
`odd_skew_upper_a_q_ml0_exclusion_2026-09-15.md`.
The west departure on eleven feeding `L7=WL` has
no possible turn. An `SR` source forces a square
return from `L7` to the next west arrival `b=WR`
that skips `E4,E5`. An `NL` source instead requires
`WR` immediately before `F6=EL`, where the established
predecessor is `F5=ER`. This closes both higher-row
endings simultaneously, for all four prefixes.
Q now has only `M_L1` in the middle placement and
`A_0,A_1` in the after placement: twelve formal
offset-eight words. Q, P, family B, and the other
cap profiles in `(1,-3)` remain open.

The last west-departure order in `M_L1` is narrowed in
`odd_skew_upper_a_q_ml1_last_west_orders_2026-09-15.md`.
If `D4=SR`, it cannot follow the last north arrival
from `c`: either turn at `F5` would violate one of
the last-square constraints on eleven. It must precede
that north arrival, leaving two six-event endings on
ten. If `D4=NL`, the last four east arrivals on ten
are all `EL`. All remaining alternatives share the
ending `SR,SL,SR,NL,NR,SL` on eleven. This closes
one of the three possible orders on nine, not the
entire `M_L1` suffix or Q.

The remaining `D4=SR` alternatives in `M_L1` are
further constrained in
`odd_skew_upper_a_q_ml1_right_west_return_constraints_2026-09-15.md`.
Three late east arrivals on twelve are forced to be
`EL`, with the arrival feeding the penultimate south
visit on eleven fixed as `ER`. In the `F5=ER` branch,
a return on thirteen forces `F4=ER` and the consecutive
triple `F4=ER,WL,F5=ER` with gaps four and four.
In the `F5=EL` branch, a right turn at the west
departure on thirteen feeding ten's last south departure
would give an eight-step left/left return; it is therefore
`NL`. Both whole branches and the `D4=NL` alternative
remain open.

The primitive-diagonal row has a complete additive condition as well. Normalize
the guard rails to transverse levels `1` and `W+1` and identify each odd class
with its level `t=x+y`. Then

```text
sum_O (-1)^t t = 3  (mod 4).
```

The one-lane parity flow is unique and has `E+L=|O|/2=0 (mod 2)`, exactly the
sign required by P3 at growth eight. The moment removes half of the normalized
placements in every tested width but leaves all three possible horizontal/vertical
wake splits. See `growth8_primitive_diagonal_boundary_2026-08-23.md`.

The coordinate reversal count gives a further condition shared by all ten rows.
For drift `(a,b)`, use coordinate residues modulo a nonzero component and exact
coordinate lines for a zero component. If `nu_F` is the number of period events
in one such fibre and `Omega_F` is the number of odd classes there, then

```text
nu^x_F-Omega^x_F = 2*[a != 0]  (mod 4),
nu^y_F-Omega^y_F = 2*[b != 0]  (mod 4).
```

Thus the `(3,-3)` coordinate visit counts are `2+0+0 mod 4`, with the `2` in
the four-class residue. At `(2,0)`, both `x` residues and all four wake-bearing rows
have visit count two modulo four. At `(4,0)`, every `x` residue has visit count
zero modulo four, while an exact row has the same visit-count residue as its
odd-class count. Every coordinate residue at `(2,4)`, `(2,-4)`, and `(4,-4)`
has visit count zero modulo four. The complete line-congruence system remains
feasible on every bounded `(3,-3)` additive placement tested, so this is another
restriction rather than a second orbit exclusion. See
`growth8_diagonal_coordinate_residues_2026-08-23.md`.

## The `(2,-2)` row after the rank theorem

In this row the checker parity is fixed by the `2 x 2` residue cell.  Up to
translations of the residue labels, P22 leaves three joint count types:

```text
[2 0]    [2 0]    [3 1]
[0 6],   [4 2],   [1 3].
```

The first is checker-pure.  Its checker-swapped version is the same type after
translation, and the all-period checker-pure theorem excludes it.  The remaining
types have checker splits `4+4` and `6+2`.  The mixed rank theorem requires
odd interlacing in the `4+4` case and even interlacing in the `6+2` case.  The
independent four-corner weight from the mixed-checker note also fixes

```text
sum_Q floor(t/2)-sum_C floor(t/2)-q_1 = 1  (mod 4).
```

After the displayed normalization, the raw `Q-C` moment is `3 mod 4` for the
`4+4` matrix and `0 mod 4` for the `6+2` matrix.  Neither combined condition is
presently contradictory.

## The two saturated skew rows after the rank theorem

For `(2,4)` and `(2,-4)`, P22 leaves a unique `2 x 4` count type up to
translation: one doubled residue cell lies in one `x mod 2` lane, and the other
three doubled cells lie in the other lane.  In the transverse coordinate
`t=2x-y` or `t=2x+y`, let `T_0,T_1,T_3` be the three endpoint pairs in the
six-class lane, and let `T_A` be the pair in the minority lane.  Writing
`S_A=sum_(t in T_A)t/4` and `S_j=sum_(t in T_j)(t-j)/4`, an additional
four-corner weight gives

```text
S_A-S_0+S_1+S_3 = -s  (mod 4)       for d=(2,4s).
```

The unique parity flow and the one-tour sign also require

```text
sum_{i<j} #{(u,v) in T_i x T_j : u<v} = 1  (mod 2).
```

Placements satisfying both conditions remain, so this removes no residue row.
They are nevertheless all-period restrictions for both chiral orbits.
See `growth8_skew_rank_parity_2026-08-22.md`.

## The full-rail part of `(4,-4)` is removed

Assume each horizontal guard rail has all four residue lanes visited.
Extremal-line rigidity then supplies four singleton odd classes on each, so the two
rails account for the entire wake.  The induced four-lane parity flow is unique,
its edge/local rank correction is even, and the one-tour sign contradicts P3.
Thus this full-rail subfamily is impossible at every period. A hypothetical
`(4,-4)` highway must leave at least one rail lane unvisited. The whole orbit
is not excluded. See `growth8_extremal_m4_exclusion_2026-08-22.md` and the
scope audit named above.

## Reproduction and boundary

Run

```text
python code/python/growth8_residue_case_ledger.py \
  --output results/growth8_residue_case_ledger.json
```

The script constructs all 40 drift vectors, verifies that the displayed quarter-
turn orbits are disjoint and exhaustive, and enumerates every distribution of
eight bases among the available coordinate-residue/checker categories.  It then
checks P22 directly and recomputes the possible period residues.  The output has
`all_checks_passed=true`.

```text
growth8_residue_case_ledger.py
cd889d9ec6d2f18fcf18f90e135a0d5b3abb45c81df868472e6b6e397661b600

growth8_residue_case_ledger.json
f7ec95164ce1a08f6378459130424e449c8490164773d3404391b372567db35f
```

This is a complete ledger for the stated arithmetic inputs, not a list of actual
highways. The subsequent rank argument removes the full-rail `(4,-4)` subfamily,
but this enumeration by itself does not impose P3 order. All ten drift orbits
retain unresolved cases.
