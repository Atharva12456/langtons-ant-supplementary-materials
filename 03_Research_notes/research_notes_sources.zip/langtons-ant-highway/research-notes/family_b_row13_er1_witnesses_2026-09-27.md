# Family B's 21 one-`ER` row-twelve prefixes continue through row thirteen

27 September 2026. This is a negative finding for the present local-exclusion
strategy, not a construction of a highway or a proof that Family B exists.

Family B has `W=6m+4` and wakes
`{0,5,6,8,6p+2,6r+4,W-2,W}` with `2<=p<r<=m-1` and `p+r` odd.
Thus row thirteen is non-wake at every allowed width. The exact row-twelve
restriction in `family_b_lower_row12_er1_restriction_2026-09-26.md` leaves
21 necessary prefixes when row twelve has exactly one `ER`.

**Verified claim.** Each of those 21 prefixes admits at least one
non-wake row-thirteen word that satisfies directional counts, alternating
turns, ordinal edge matching, one-excursion same-cell adjacency, every
witnessed finite first return, and the exact unbounded lifted integer clock.
The witness lengths are 32 for six prefixes and 36 for fifteen prefixes.
This check gives no all-width exclusion; it also leaves the `ER>=2` branch
of row twelve untouched.

`code/python/verify_family_b_row13_er1_witnesses_2026_09_27.py` reconstructs
the established rows zero through ten, loads the 21 row-eleven/twelve
prefixes from `results/family_b_row12_er1_all_2026-09-26.json`, checks each
loaded prefix, and searches row-thirteen count rows and adjacency words until
it finds a valid witness. It tests 473 candidate words, of which 452 fail
the exact clock; the other 21 are explicit witnesses written to
`results/family_b_row13_er1_witnesses_2026-09-27.json`. The clock solver
has an integer period `N>=max(6, number of represented events)` with no
upper bound. It imposes each ordinal edge equation and a gap of at least
four between successive same-row events. The return check rejects only an
explicit finite walk returning to the wrong next event; it does not
extrapolate a quotient cycle.

Run from the repository root:

```text
python code/python/verify_family_b_row13_er1_witnesses_2026_09_27.py
```

The script consumes the earlier verified row-twelve result file, so its
claim is conditional on that prerequisite. Its row-thirteen output is a
set of necessary prefixes, not a complete frontier or a realized tour.
