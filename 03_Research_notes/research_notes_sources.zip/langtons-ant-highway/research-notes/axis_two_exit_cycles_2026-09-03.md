# Four-vertex exit cycles at axis drift two

For drift `(2,0)`, every last-exit cycle consists of the two translation
classes on each of two adjacent rows.  Starting at the lower vertical-arrival
class, its selected edge directions are

```text
E,N,E,S.
```

Every first-departure cycle also uses four vertices on adjacent rows, but
its selected directions are `W,N,W,S`, with voltage `-1`.

For a last-exit cycle, the one-period decomposition from
`cylinder_exit_cycles_2026-09-03.md` becomes

```text
N = 4 + D_1+D_2+D_3+D_4,       D_i in 4 Z_(>=0).
```

The `D_i` are actual closed return excursions, not unspecified paths with
only prescribed displacement.  At growth eight, the known period condition
`N=4 mod 8` also makes their total divisible by eight.

First-visit order gives a second reduction: every trace has a row with two
coupled closed returns of positive lengths summing to `N`.  Their signed
changes add to one period's change with one explicit root correction.

This reduction holds at arbitrary period and transverse height.  It does not
give a bound on the wake contributed by the four excursions, so the axis
growth-eight case remains open.

## Why only two rows occur

A row has exactly one vertical-arrival class `Q_y` and one horizontal-arrival
class `C_y` modulo `(2,0)`.  Every departure from `Q_y` goes horizontally to
`C_y`.  Every departure from `C_y` goes vertically to `Q_(y-1)` or `Q_(y+1)`.
The visit multiplicities of `Q_y` and `C_y` are equal, since horizontal steps
give a bijection from the occurrences of the former to those of the latter.
Under P3, their wake indicators are therefore equal as well.

In either selected exit graph, contract the selected `Q_y -> C_y` edges.
A directed cycle becomes a simple nearest-neighbor cycle on the row line.
Such a cycle must be `y -> y+1 -> y`: at its greatest row, its predecessor
and successor would otherwise repeat the same smaller row.  Restoring the
contracted edges gives four distinct quotient vertices.

The last-exit cycle has voltage `+1` by the cylinder theorem.  Its two
horizontal steps must therefore both be east.  The vertical steps are north
from the lower row and south from the upper row, proving the stated form.

These are geometric edge directions, not a list of the actual selected
incoming headings.  For example, the cycle's east edge may reach `C_y`
before its last visit, which may instead have a west incoming heading.
Consequently the lower cycle row has not been proved non-wake in general,
nor the upper cycle row wake.  That conclusion will hold below only when
the cycle row is an actual extreme of the whole trace.

## Horizontal first/last matching inequalities

Choose representatives `Q=(r,y)` and `C=(1-r,y)`, where `r` is zero or one.
The horizontal voltages from `Q` to `C` are

```text
lambda(E)=r,       lambda(W)=r-1.
```

For first visits, let `u` indicate that the edge leaving first `Q` is east,
and let `z` indicate that the edge entering first `C` is east.  The latter
edge comes from an occurrence of `Q`, which need not be its first.  If the
first lifted times are `F_Q,F_C`, extremality at each endpoint gives

```text
F_Q+1-N(r-1+z) <= F_C <= F_Q+1-N(r-1+u).
```

Since `N>0`, this requires `u<=z`.  Repeating the argument with last lifted
times gives

```text
T_Q+1-N(r-1+u) <= T_C <= T_Q+1-N(r-1+z),
```

now requiring `u>=z`.  Equality of the two direction indicators forces
equality of the bounds.  In that case the selected `Q` departure lands
directly at the selected `C` visit.

There is a precise alternative in the strict cases.  For first visits the
only mismatch is outgoing west and incoming east.  Let `delta_Q` be the
time from first `Q` to the `Q` occurrence feeding first `C`, with physical
copies aligned.  Let `delta_C` be the time from first `C` to the arrival of
the first `Q` west edge.  Both are positive closed-return lengths, and
subtracting the voltage equations gives

```text
delta_Q+delta_C=N,       delta_Q,delta_C in 4 Z_(>0).
```

For last visits the only mismatch is outgoing east and incoming west.  The
corresponding lengths run from the `Q` occurrence feeding last `C` to last
`Q`, and from the last `Q` east-edge arrival to last `C`.  They obey the same
identity.  In particular, a strict mismatch cannot be treated as an exact
matching of the selected visits.

## First-departure cycles go backward

The two-row reduction applies to first-departure cycles as well.  At the
lower row of such a cycle, the selected `C` edge goes north.  The selected
visit is a first visit and turns right, so its actual incoming heading is
west.  Thus `z=0`, and the first matching inequality forces `u=0`: the
lower horizontal cycle edge is west.

If the upper horizontal edge were east, the geometric cycle would have
directions `W,N,E,S`.  It would be a clockwise unit square with voltage
zero.  At a sufficiently future physical copy, each corner's first visit
turns right along its selected square edge.  Its predecessor must therefore
be the previous corner.  The earliest first visit among the four corners
would require an earlier corner visit, a contradiction.  Therefore the
upper horizontal edge is west too.  Every first-departure cycle has directions
`W,N,W,S` and voltage `-1`.

This argument uses the actual incoming heading only to infer `z` at the
lower `C`.  It does not identify that heading with the geometric incoming
cycle edge without the matching inequality.

## The complete first-port profile

The first matching inequality leaves exactly the following first-port pairs
on a visited row:

| State | First `Q` port | First `C` port |
|---|---|---|
| A | SR | WR |
| B | SR | ER |
| C | NR | ER |

The pair `NR,WR` would have `u=1,z=0`, which is forbidden.  The actual bottom
row is A and the actual top row is C.  An A row immediately below a C row
would be the clockwise square excluded above.  Thus every first-departure
cycle consists of adjacent rows AB.

A B row must occur.  The visited rows form an interval; starting from the
bottom A row, the first non-A row cannot be C and must be B.  This also
gives an AB pair.  The lowest C row has a B immediately below it, giving
a BC pair.  Hence the coupled-return construction below applies to every
axis-two trace, not only to an optional local profile.

Now select the predecessor of each first visit and direct these edges
backward.  The first-entry result in `cylinder_exit_cycles_2026-09-03.md`
gives reverse voltage `-1`; the row-line argument again gives four vertices.
Reversing this cycle yields forward directions `E,N,E,S`.  The selected
first incoming headings are S at the lower `Q`, N at the upper `Q`, and E
at both `C` vertices.  Its two first-port states are therefore BC.

Every such BC pair gives the dual period decomposition into four closed
excursions starting at first visits, followed by the selected first-entry
edges.  This records the white starting colour at each excursion root.  It
does not make the other cells encountered there initially white.

The B rows also give a two-return identity.  Choose a representative with
`r=0`; the `r=1` case differs only in copy alignment.  Write `F_Q,F_C` for
the first lifted times.  The positive closed returns from the strict first
mismatch have departure intervals

```text
Q return: [F_Q, F_C-1),
C return: [F_C-N, F_Q+1).
```

The first is at `Q`; the second is at the appropriate translated `C` cell.
They share the first `Q` west-departure event and together omit the `Q`
east-departure event feeding first `C`, relative to one complete period.
If the latter event has turn sign `s` (`+1` for R and `-1` for L), their
turn balances satisfy

```text
T_Q+T_C = g+1-s.
```

At growth eight this is eight when `s=+1`, and ten when `s=-1`.  The two
returns share a history; treating them as independent excursions would lose
this relation.

The same accounting holds cell by cell.  For an interval `I`, let `Delta_I`
be the signed change in its black set, with coefficients in `{-1,0,1}`.
For the period interval `P=[F_C-N,F_C)`, the overlap and omission give

```text
Delta_Q + Delta_C = Delta_P + (1-s) 1_Q.
```

Here all three intervals use the same physical coordinates.  On projecting
by `(2,0)`, the signed period change becomes the wake vector `Omega`, whose
coefficients are zero or one.  Thus

```text
pi(Delta_Q) + pi(Delta_C) = Omega + (1-s) 1_[Q].
```

Projection sums signed coefficients; it does not count distinct changed
cells.  In particular, the mod-four additive charges of this identity give
the existing period residue equations with the displayed root correction.
They are not a further wake obstruction.

## A heading reversal with unchanged root needs six changed cells

Let a finite legal ant segment return to a cell `z=(x_0,y_0)` with the
opposite incoming heading.  Suppose that `z` has the same colour at the two
endpoints.  Then at least six distinct physical cells have odd visit count
in its departure interval.

Write `Delta` for its signed black change and `D` for the support of
`Delta`.  The row-column parity identity P27 makes the incidence graph of
`D` Eulerian: both endpoint tokens are the same coordinate vertex because
the endpoint headings have the same axis.  This graph is simple and
bipartite.  Any nonempty such graph has at least four edges, and its edge
count is even.

The signed endpoint charges rule out four.  For a mod-four weight `w`
satisfying the zero four-corner condition, the additive-charge cocycle gives

```text
sum_x Delta(x) w(x) = F_h(z)-F_(h+2)(z) = 2w(z)  (mod 4).
```

The last equality is the opposite-heading identity in the cocycle proof.
Use, separately, the admissible weights

```text
w_row(x,y) = (-1)^(x+y) [y=y_0],
w_col(x,y) = (-1)^(x+y) [x=x_0].
```

Each weighted sum is two modulo four.  Consequently `D` has a cell on the
root row and a cell on the root column, so `D` is nonempty.  If it had only
four cells, its simple Eulerian incidence graph would be a four-cycle:
the four corners of a rectangle.  One of its two rows would be `y_0` and
one of its two columns would be `x_0`.  The rectangle would therefore
contain `z`.  But unchanged root colour says `z` is absent from `D`.
This contradiction proves `|D|>=6`.

For a B row, the `Q` return starts at its first `SR` visit and ends just
before the feeding east departure.  If that feeding turn is R, its port
is `NR`: the heading has reversed and the root has returned to white.
The six-cell bound applies.  If the feeding turn is L, its port is `SL`;
the root is black, and the ordinary nonempty Eulerian-support bound gives
four cells instead.  The `C` return always changes incoming heading from
E to W, so it has the six-cell bound whenever its root returns to white.

These are physical-cell bounds.  A changed cell may have been black at the
start, and different physical cells may project to the same translation
class.  Neither bound can be added directly to the growth-eight wake count.

## The first-return ray restriction

The coupled returns retain a spatial restriction that arbitrary legal
closed excursions need not satisfy.  Translate a B row to height zero,
normalize the first `C` visit to `(0,0)` at time zero, and put the first
visit to `Q=(1,0)` at time `delta_C-1`.  Then

```text
C return: [0, delta_C),
Q return: [delta_C-1, N-1).
```

The `C` return ends at `(0,0)`, and the `Q` return ends at `(1,0)` just
before the east step feeding first `C+d` at time `N`.

The first visit to `C+kd` is at time `kN`.  The first visit to `Q+kd` is
at time `delta_C-1+kN`.  Thus, before its final `Q` departure, the `C`
return cannot visit any cell `(x,0)` with `x>0`.  Its final two steps are
S,W, because the final `Q` visit is the first `SR` there.  The `Q` return
cannot visit any `(x,0)` with `x>=2`.  These statements exclude a whole
horizontal ray, not only an early return to the named root.

The proof uses first-visit order in translated copies and holds for any
period.  It still leaves the path free to enter those columns on other
rows; no half-plane containment follows.

### The shortest C return

Every B-row `C` return has length at least eight.  A four-step return would
be a unit square.  Starting south and ending west forces directions
`S,E,N,W`, but then its final `Q` arrival is N, not the required first S
arrival.

At length eight the direction word is unique:

```text
S,W,N,E,N,E,S,W.
```

Indeed, the four vertical steps must be `S,N,N,S`.  The horizontal steps
are two east and two west, with the last west.  If the first horizontal
step were east, the next north step would visit `Q=(1,0)` too early.
Thus the horizontal steps must be `W,E,E,W`, proving the claim.  Its turns
are `R,R,R,R,L,R,R,R`, and its signed black change is six.

This return forces the feeding turn `s` to be L.  The physical cell
`Q-d=(-1,0)` feeds first `C` at time `-1`, with the same turn `s` as the
feeding event at time `N-1`.  The eight-step return next visits `(-1,0)`
at time three with port `NR`.  There is no intervening visit there, so
alternation makes the time-minus-one turn L.

The coupled `Q` return has signed change four, but it cannot be the
four-step all-right square.  The eight-step `C` return leaves `(0,1)`
black at time five.  Starting at first `Q` at time seven, the actual next
steps are W to the now-white `C`, then N to `(0,1)`.  That cell turns
left, forcing W.  Hence the `Q` return starts `W,N,W` and has length
greater than four.  With `N=4 mod 8` and `delta_C=8`, this gives

```text
delta_Q >= 12,       N >= 20.
```

### Ray avoidance does not make the discrepancy positive

There is a legal twelve-step return starting at `C=(0,0)` heading E,
with initial black set

```text
{(-1,-1), (-1,-2), (0,-2)}.
```

Its direction and turn words are

```text
directions: S,W,S,E,N,W,N,E,N,E,S,W,
turns:      R,R,L,L,L,L,R,R,L,R,R,R.
```

It first visits `Q=(1,0)` at time eleven, with incoming S and a right
turn.  Before that event it avoids every `(x,0)` with `x>0`.  The repeated
departure cells `C` and `(0,-1)` each have turns R then L;
`(-1,-1)` has L then R.  All other departure cells occur once, so the
displayed turns follow directly from the given initial colours.

At the return to `C`, its colour is again white.  The signed discrepancy is

```text
removed: (-1,-2), (0,-2),
added:   (-1,0), (0,1), (1,1), (1,0).
```

Thus the six-cell bound is sharp even with the ray restriction, while
the signed change is only two.  This finite return does not claim a
P3-periodic extension.  Its entering black cells require earlier histories,
and no contradiction in those histories has been proved here.  Their
compatibility with the other return is the missing global condition.

## Exact lifetime identities at the trace extremes

At the lowest visited row choose representatives

```text
Q=(x,y_min),       C=(x-1,y_min),
```

with `Q` vertical-arrival.  The allowed port words are alternating subsequences
of

```text
Q: SR,SL,SR,SL,...
C: WR,EL,WR,EL,... .
```

They have the same length and start with right turns.  Write `Q_Ri,Q_Li`
and `C_Ri,C_Li` for corresponding right and left occurrences.  A right
departure from `Q` reaches `C` with voltage zero.  A left departure reaches
`C+d` with voltage one.  Within each directed edge block, matching preserves
stable order.  Thus

```text
tau(C_Ri)=tau(Q_Ri)+1,
tau(C_Li)=tau(Q_Li)+1-N.
```

Subtracting gives, for every pair present in the stable words,

```text
bottom Q black lifetime = bottom C black lifetime + N,
bottom C white lifetime = bottom Q white lifetime + N.
```

Here a black lifetime runs from `R_i` to `L_i`, and a white lifetime from
`L_i` to `R_(i+1)`, at one physical cell.  In particular, the lifetimes on
the left are strictly longer than one period.

At the highest visited row choose instead

```text
Q=(x,y_max),       C=(x+1,y_max).
```

The stable port words now use `NR,NL` at `Q` and `ER,WL` at `C`.  Right
departures have voltage zero and left departures voltage minus one, giving

```text
tau(C_Ri)=tau(Q_Ri)+1,
tau(C_Li)=tau(Q_Li)+1+N.
```

Hence

```text
top C black lifetime = top Q black lifetime + N,
top Q white lifetime = top C white lifetime + N.
```

Every nonempty return to a physical cell has length a positive multiple of
four.  Each of the long lifetimes in these displays is therefore at least
`N+4`.  None can be contained in a single excursion of a last-exit-cycle
decomposition, since every such excursion has length less than `N`.

## Which extremes can a last-exit cycle touch?

If a last-exit cycle reaches the lowest trace row, it uses both of that row's
classes.  Its horizontal edge is east.  But the last `Q` port on that row
is `SR` (westward) if wake, and `SL` (eastward) if non-wake.  Thus a cycle
touching the trace bottom requires a non-wake row.

At the highest trace row, the last `Q` port is `NR` (eastward) if wake and
`NL` (westward) if non-wake.  A cycle touching the trace top therefore
requires a wake row.

There are no excursion waits at either boundary class when a cycle has
such contact.  At a non-wake bottom `Q`, any arrival earlier than the final
`L` precedes a subsequent black lifetime longer than `N`.  The wait from
that arrival to the last visit cannot fit in the decomposition.  Thus the
cycle arrives directly at the last `Q` visit.  Its last `SL` departure
matches the last `EL` at `C`, giving zero wait there too.

At a wake top `Q`, an arrival earlier than the final `R` similarly precedes
a white lifetime longer than `N`.  Thus the wait at `Q` is zero, and its
last `NR` departure matches the last `ER` at `C` with zero wait.

Nothing here forces a cycle to touch a trace extreme.  Extreme classes may
belong to trees feeding an interior cycle.  The unresolved case is therefore
not removed by treating a cycle's own lowest row as the trace bottom, or by
assigning one wake row to every interior last-exit cycle.

## A local odd-row count is insufficient

A closed return can have four odd-visit cells on two rows of the same parity.
Here is a literal eight-step example, with no periodicity claim.  Start at
`(0,0)` heading north, with black cells

```text
(1,0), (1,1), (0,1),
```

and all other cells white.  The visited departure cells and their turns are

| Step | Cell | Incoming heading | Turn | Outgoing step |
|---|---|---|---|---|
| 0 | `(0,0)` | N | R | E |
| 1 | `(1,0)` | E | L | N |
| 2 | `(1,1)` | N | L | W |
| 3 | `(0,1)` | W | L | S |
| 4 | `(0,0)` | S | L | E |
| 5 | `(1,0)` | E | R | S |
| 6 | `(1,-1)` | S | R | W |
| 7 | `(0,-1)` | W | R | N |

The final state of the ant is again `(0,0)` with heading north.  The two
repeated cells have opposite turns on their two visits.  The odd-visit cells
are exactly `(0,1),(1,1),(0,-1),(1,-1)`, all on the odd rows `1` and `-1`.
The black domino on row one disappears and a black domino appears on row
minus one; `(1,0)` returns to black.  The turn balance and net black change
are both zero.

This refutes an opposite-parity claim based only on legal closed excursions.
It does not construct a periodic P3 trace: the initial black cells would need
their own consistent earlier histories.  In particular, the excursion's
four odd-visit cells are not four new wake classes.  Their signs depend on
the colours present when the excursion starts.
