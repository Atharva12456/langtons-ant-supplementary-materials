# An upper guard cannot wake at inward offset seven after four quiet rows

Later result (26 September 2026): [the upper-guard early-wake exclusions](odd_skew_upper_guard_early_wakes_2026-09-26.md) remove the remaining width-20 placements discussed below. The earlier local lemma remains valid; larger widths and the full drift orbit are not closed by these results.

24 September 2026. At drift `(1,-3)`, take an upper guard cap with inward
offsets zero, one and two wake. If offsets three, four, five and six are
non-wake, then **offset seven cannot be wake**. This holds at every period
and width. It uses no P22, rank, moment or period-congruence assumption.

A hand proof is now recorded in
`odd_skew_upper_guard_hand_certificate_2026-09-24.md`. It needs only
positive integer period and strict row order: the one clock contradiction
is `2-N>=5`, and the final five cases have explicit four- or eight-step
wrong first returns. Its standard-library checker is
`code/python/verify_upper_guard_hand_certificate.py`. The computational
audit below is an independent verification under the usual stronger
minimum-gap condition.

Rotate the upper headings by 180 degrees. The fixed cap words are
`0:WR`, `1:NR`, `2:WR`. Derive each later count row from directional
flow and binary excess. Enumerate right-first alternating words subject
to necessary zero-voltage first-return adjacency; then reject only a
witnessed wrong finite first return or an infeasible exact upper clock

```text
tau(target)-tau(source)=1+N*voltage,  N>=6,
successive visits to the same cell separated by at least four steps.
```

The complete prefix frontier has survivor counts at inward offsets
three through seven of **`2,1,1,5,0`**. At offset five, one of two
adjacency words violates the clock. At wake offset seven, all five
adjacency words have a witnessed wrong first return. No quotient-cycle
repeat is assumed to be a physical return, and there is no period or
row-length bound. The standalone
`code/python/verify_upper_guard_quiet_3_6_wake7.py` reproduces the
frontier; its output is
`results/upper_guard_quiet_3_6_wake7_checks_2026-09-24.json`.

This local lemma gives the earlier width-18 upper-guard exclusion for
the lower fat `(0,1,111)` band without needing its period residue.
It also removes three minimum-width placements for the lower fat
`(0,0,111)` band with an upper guard. Static P22, even rank and moment
checks find no placement at even widths below twenty and six at width
twenty. Three have upper inward offsets three through six quiet and
seven wake:

```text
{0,2,5,8,13,18,19,20}
{0,2,7,10,13,18,19,20}
{0,2,9,12,13,18,19,20}
```

They are impossible by the lemma. The other three width-20 placements,
and wider placements, remain open. The verifier also independently
enumerates the six static width-20 sets to audit this corollary.
