# Positive-skew growth-eight highways require transverse width at least eighteen

For a finite-support periodic highway with drift `(1,3)` and growth eight,
normalize the transverse coordinate `t=3x-y` to have minimum zero. Its
maximum W is even. The necessary lower bound is

```
W >= 18.
```

This is a computer-assisted exclusion of fixed widths, valid for every
period and every black lifetime. It does not bound W above or close the
drift orbit. No upper period or visit-count cutoff occurs in the argument.

## Complete cap domains and the unbounded count screen

The extrema are singleton `0:NR` and `W:SR`. The lower missing and guard
profiles are excluded in
`positive_skew_cap_reduction_2026-09-30.md`; the lower thin profile has the
rigid prefix given there. Generate the necessary cap words by exact local
flow, R-first alternation, physical first returns and lifted integer clocks.
The lower and upper domains are built separately: the upper domain uses
the opposite clock voltage and is then mapped by a physical half-turn.
R/L labels are preserved; no reflection is used.

The complete lower frontier through level eight has 4,172 words. Projecting
those onto levels zero through seven gives 26 distinct count signatures.
The complete upper frontier through inward offset seven has 14,412 words
and 254 count signatures. Their files are

```
work_positive_skew_frontier_20260930/lower_all_current_depth8.json
work_positive_skew_frontier_20260930/upper_all_strong_depth7.json
```

Each finite generation stage has an exhaustive domain for a structural
reason: its free count parameter is bounded by the previously determined
incoming blocks, as in the cap-reduction note. Search resource limits
only mark a stage incomplete. All stages used here are complete.

At each fixed even W, assign a nonnegative integer count to every port on
every level. Both exterior regions are empty. Impose exact directed-edge
flow, R-minus-L excess equal to a Boolean wake indicator, singleton extrema,
the necessary cap count signatures, and exactly eight wakes. Impose P22,
the additive moment and rank conditions:

```
for j=0,1,2: sum_{t in O, -t=j mod3} (-1)^t = 2 mod4;
sum_{t in O} (-1)^t ceil(t/3) = 1 mod4;
sum_{i<j} #{(n,m) in U_i x U_j: n<m} = 0 mod2,
U_j={ceil(t/3): t in O, -t=j mod3}.
```

Integer counts have no upper bound, and no period variable needs to be
bounded in this count model. Z3 proves the complete model unsatisfiable
for `W=2,4,6,8,10,12,14`. An independent model computes turns and physical
edge targets geometrically, uses the original rank definition, and gives
the same seven unsatisfiable widths. Width zero has only the singleton
extremum and cannot have eight wakes, so it is excluded separately.

## Complete width-sixteen join

For W=16, lower levels 0--7 and upper levels 9--16 are fixed cap domains;
only level eight remains. Group words by count signature before the join.
There are `26*254=6,604` signature pairs. Of these, 6,539 violate a
directed flow across the interface. For the other pairs, exact local
count equations give 421 possible central count vectors. Checking the
other direction of each central interface eliminates 377. The full wake
arithmetic eliminates 41 more. Exactly three complete count structures
remain, with total event counts 98, 114 and 114.

The three structures correspond to 22, 7 and 9 cap-word pairs respectively.
Every one of these 38 pairs has a wrong physical first return using only
assigned cap rows, before any event on level eight. Therefore **every**
possible central word is excluded. No central word enumeration or extra
clock restriction is needed for this last step.

The recorded first-return direction words are `SESENESWNWSWNWNE` for 23
pairs, `SESWNWNE` for eight, and `ESWN` for seven. Each has zero physical
displacement. The full certificates include the start, the incorrectly
returned event, the expected immediate successor, directed ordinals, and
the lifted physical cells, so the occurrence and absence of an earlier
return are checked rather than inferred from the direction word alone.

## Independent verification

The primary complete join and all 38 certificates are

```
work_positive_skew_frontier_20260930/fixed_word_join_W16.json
work_positive_skew_frontier_20260930/fixed_word_join_W16_certificates.json
```

An independent implementation re-groups the cap words, recomputes every
interface, generates the central count domains from separate equations,
evaluates the original arithmetic/rank tests, and traces actual physical
steps using separately generated directed ordinal successors. It produces
exactly the same counts and rejects all 38 pairs:

```
python work_positive_skew_root_20260930/independent_width16_join.py
```

Its complete result, including every rejected word system and independently
constructed physical witness, is `independent_width16_join.json` beside
the source. The independent unbounded-count screen for the seven smaller
widths is

```
python work_positive_skew_root_20260930/independent_small_width.py \
  --lower-prefix work_positive_skew_frontier_20260930/lower_all_current_depth8.json \
  --upper-prefix work_positive_skew_frontier_20260930/upper_all_strong_depth7.json
```

Both were freshly run to PASS. A further separate saved-SMT replay in
`work_positive_skew_frontier_20260930/verify_fixed_width.py` exhausts all
three W=16 count models and independently replays all physical certificates.

This closes only the finite-width range W<=16. Larger widths still have
necessary wake placements and local cap continuations; they require a
new exclusion or a realizable highway construction.
