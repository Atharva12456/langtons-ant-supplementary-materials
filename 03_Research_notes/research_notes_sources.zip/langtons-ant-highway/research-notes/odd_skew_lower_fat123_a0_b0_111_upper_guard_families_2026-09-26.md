# All-width wake families: lower fat `(0,0,111)`, upper guard

Later results: [the early-wake exclusions](odd_skew_upper_guard_early_wakes_2026-09-26.md) remove the two width-20 placements below, and [the width-22 join](odd_skew_lower_fat123_a0_b0_111_w22_guard_2026-09-27.md) excludes the remaining width-22 cases. This note retains the arithmetic classification; the cap pair at larger widths remains open.

For drift `(1,-3)` at growth eight, put the lower transverse level at zero
and the upper guard at even width `W`. The lower initial band fixes wakes
`0,2` and non-wakes `1,3,4`; the upper guard fixes wakes `W-2,W-1,W`.
The other three wakes must lie between levels five and `W-3`. The P22,
even-rank, and moment conditions are necessary for a highway. The
[upper-guard hand lemma](odd_skew_upper_guard_offsets_3_6_impossible_2026-09-26.md)
adds that one of these three wakes must be at `W-3,W-4,W-5,W-6`.

Write `W=6m+r`, with `r` in `{0,2,4}`. Exactly **nine parameter families**
pass these four necessary conditions. In the following table, `F` means
`{0,2,W-2,W-1,W}`, and the displayed triple is added to `F`. All indices
are integers. Empty index ranges contribute no placements.

| `r` | Free wake triple | Index restrictions |
|---|---|---|
| 0 | `6a+4, 6b+2, W-4` | `1<=a<b<=m-2`, `a+b` even |
| 4 | `6a+4, 6b, W-4` | `1<=a<b<=m-1`, `a+b` odd |
| 4 | `6b, 6c, W-6` | `1<=b<c<=m-1`, `b+c` even |
| 4 | `6b+3, 6c+3, W-6` | `1<=b<c<=m-1`, `b+c` odd |
| 2 | `6a+4, 6b+4, W-4` | `1<=a<b<=m-2`, `a+b` odd |
| 2 | `6b+1, 6c+1, W-4` | `1<=b<c<=m-1`, `b+c` even |
| 2 | `6c+1, 6a, W-5` | `1<=c<a<=m-1`, `a-c` odd |
| 2 | `6c+1, 6a+2, W-3` | `1<=c<a<=m-1`, `a-c` odd |
| 2 | `6c+1, 6b+5, W-6` | `1<=c<b<=m-2`, `b+c` odd |

These families are *static candidates*. No line in the table asserts a
return-consistent event order or a realizable ant path.

## Derivation

The signed P22 sum in each residue fibre modulo three must be `2 mod 4`.
For `r=0`, the fixed wakes have signed sums `(2,1,0)` in fibres
`(0,1,2)`. Three free wakes therefore consist of one even wake in fibre
one and a same-parity pair in fibre two. For `r=4`, the fixed sums are
`(0,1,2)`, giving one even fibre-one wake and a same-parity pair in fibre
zero. For `r=2`, the fixed sums are `(2,-1,2)`. The three free wakes are
either all in fibre one (all even, or one even and two odd), or one odd
fibre-one wake together with an opposite-parity pair in fibre zero or two.
These possibilities exhaust P22 because each signed free contribution is
`+1` or `-1`, and there are exactly three of them.

All free wakes sit above both fixed lower wakes and below all fixed upper
wakes. Direct cross-fibre pair counting then makes the even-rank condition
an ordering rule. At `r=0`, the singleton fibre-one wake must precede both
fibre-two wakes. At `r=4`, the singleton must lie outside the pair's
interval. At `r=2`, a triple entirely in fibre one always has even rank;
for a pair in fibre zero or two, the odd fibre-one singleton must lie
outside the pair's interval. This count is independent of the widths and
of the spacings between the three free wakes.

The five fixed wakes contribute `2m` to the moment
`M=sum_{t in O}(-1)^t floor(t/3)`. A free wake `6q+s` contributes
`(+2q, -2q, +2q, -(2q+1), +(2q+1), -(2q+1))` for
`s=(0,1,2,3,4,5)` respectively. Requiring `M=3 mod 4` gives the parity
condition in each table row. The forced upper wake restricts the indices:

* At `r=0`, only the even fibre-two pair can contain a wake among the
  upper inward offsets three through six, and that wake is `W-4`.
* At `r=4`, either the even fibre-zero pair reaches `W-4`, or the even
  fibre-one singleton is `W-6`. The outside-interval rank rule separates
  the three listed cases.
* At `r=2`, a fibre-one triple must contain `W-4`. If the pair is in
  fibre zero, its odd member must be `W-5`. If the pair is in fibre two,
  its odd member can be `W-3` or its even member can be `W-6`.

These exhaust the locations of the required near-upper wake, proving the
table for every even width. The checker
`code/python/lower_fat123_a0_b0_111_upper_guard_schedules.py` independently
enumerates all triples and compares with the table through width 160.
That finite audit tests the algebra; it is not the basis for the all-width
claim.

The minimum static width is 20. At that width the only two remaining
placements are `{0,2,7,12,15,18,19,20}` and
`{0,2,7,14,17,18,19,20}`, from the `r=2` fibre-zero and fibre-two
odd-top families respectively. Neither has yet been excluded by this
arithmetic classification.
