# A lower `(1,2,2)` cap requires a wake on level four or five

For drift `(1,-3)`, every lower cap of profile `(1,2,2)` satisfies

```text
omega_4 + omega_5 >= 1.
```

This is an all-period consequence of stable chronology. It does not assume
growth eight, an upper cap profile, or a bound on any inward multiplicity.
The conclusion supplies an additional wake near this cap; it does not by
itself exclude the cap or the drift orbit.

Use transverse coordinate `t=3x+y` and representatives `(0,t)`. An edge of
voltage `lambda` changes stable lifted time by `1-N*lambda`, with voltages
`1,-1,0,0` for `E,W,N,S`. Stable times increase within each class. Any
period with this drift has `N>=6`, since the step axes alternate and the
vertical displacement has magnitude three.

## Suppose levels four and five are non-wake

The cap normal form gives

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL
5 A: SR,SL,NR,NL,NR,SL
  B: NR,SL,SR,NL,NR,SL.
```

Let `e=omega_6`. The counts on level six are

```text
(ER,EL,WR,WL)=(r,3-r,6+e-3r,3-r),       r=0,1,2.
```

The four-step return from the south predecessor of `5:SR` through
`5:SR,2:WR,3:NR` to the second east arrival on level six excludes `r=0`.
The same return and stable order leave the following possibilities:

| Name | Level five | Level six, followed by `[WR]^e` |
|---|---|---|
| `U1` | A | `ER,EL,WR,EL,WR,WL,WR,WL` |
| `U2` | A | `ER,EL,WR,WL,WR,EL,WR,WL` |
| `U3` | B | `WR,WL,ER,EL,WR,EL,WR,WL` |
| `U4` | A | `WR,EL,WR,WL,ER,EL,WR,WL` |
| `L` | A | `ER,EL,ER,WL` |

For completeness, the final-`WL` restriction used here is independent of
`e`. Put `V=tau(2:WL)` and `Z=tau(4:second WL)`. Edge matching gives
`tau(4:last WR)=V-N-2`, so `Z<=V-N-6`. The third east arrival on level
six has time `Z+2-N<=V-2N-4`, whereas its last south departure feeds the
last `SL` on level five, after the north arrival at time `V-N+3`.
Thus the last south departure on level six is after its last east arrival
and must be `WL`. Its final stable port is consequently `WL` when `e=0`
and a following `WR` when `e=1`. Removing that optional final `WR`
reduces the word classification to the one in
`odd_skew_fat122_even_band_2026-09-12.md`.

The branch `L,e=0` was excluded in that note. We first exclude all four
`U` branches for either value of `e`.

## Two adjacent west departures remove `U1` and `U2`

Let `W1,...,W4` be the west departures on level seven. They feed the
ordered west arrivals `WR,WL,WL,WR` on level four. Write `Ni` for its
north arrivals in order. Exact returns force the consecutive stable pairs

| Branch | First return | Second return |
|---|---|---|
| `U1` | `W2 -> N1` | `W3 -> N3` |
| `U2` | `W2 -> N1` | `W3 -> N4` |
| `U3` | `W2 -> N2` | `W3 -> N4` |
| `U4` | `W2 -> N2` | `W3 -> N4` |

The first return has length twelve for `U1,U2,U3`, and length eight for
`U4`. It starts by following

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> first east arrival on 6.
```

For `U1,U2,U3`, this east arrival is `ER`; continue through
`5:SR,2:WR,3:NR` to the second east arrival on level six, which is `EL`.
For `U4`, the first east arrival itself is `EL`. Its north step gives
the target in the table. The second return is always the four-step path

```text
W3 -> 4:second WL -> 3:last SL -> 6:last EL -> target north arrival.
```

All these returns have zero displacement and no intermediate level-seven
visit. The extra final `WR` when `e=1` does not alter their north ordinals.

In `U1` and `U2`, the source of the first return cannot be `NL`: it
would be a north arrival before `N1`. Thus it is `SR`, followed immediately
by `N1=NL`. This target is the next west departure, namely `W3`. The
return starting there must then end at the next north arrival `N2`.
Its stated target is instead `N3` or `N4`, a contradiction.

## The remaining two `U` branches are impossible

In `U3,U4`, if `W2=SR`, its consecutive target `N2=NL` would again
be `W3`. The second return would require the next north arrival to be
`N4`, skipping `N3`. Therefore `W2=NL`, and consecutive order makes it
`N1`, followed by `N2=NR`.

For `U3`, this gives the eight-step return

```text
6:first WR -> 7:W2 -> 4:first WL -> 3:SR -> 0:WR
           -> 1:NR -> 4:ER -> 3:first SL -> 6:first ER.
```

It has no intermediate level-six visit. Both endpoints turn right, so
`U3` is impossible.

For `U4`, suppose `W3=NL`. Its consecutive target `N4=NR` makes this
source `N3`, fed by the second `WR` on level six. Then

```text
6:second WR -> 7:W3 -> 4:second WL -> 3:last SL -> 6:last EL
```

is a four-step return skipping the intervening `WL,ER` in the level-six
word. Thus `W3=SR`, followed immediately by `N4=NL=W4`. Since `W2`
is the first north arrival, `W1=SR`. These facts force

```text
7: SR,NL,NR,SL,NR,SL,SR,NL,NR,(SL,NR)^e,[SL]^(1-f),
   f=omega_7.
```

Let `E1,...,E4` be the east arrivals on level eight, supplied by
`SL1,NR1,NR2,SL2` on level five. The path from `7:W4=NL` through
`4:last WR,5:NL,2:WL,1:SL,4:EL,5:last NR` ends at `E3`.
If `E3=ER`, its south step would complete an eight-step return to a
south arrival on level seven. But the next stable event after this `NL`
is `NR`. Hence `E3=EL`.

Now take the level-eight south departure feeding `7:W3=SR`. Its path
first follows the four-step return from `W3` to `W4`, then follows the
preceding chain to `E3`. This is a twelve-step return to level eight
with no intermediate visit there. The opposite-turn source must be
`ER`, and consecutive order identifies it as `E2`. But

```text
7:W1=SR -> 4:first WR -> 5:first NR -> E2 -> 7:W3=SR
```

is now a four-step return with two right-turn endpoints. This excludes
`U4`, for either parity on levels six and seven.

## The forced wake on level six

Only branch `L,e=1` remains:

```text
5: SR,SL,NR,NL,NR,SL
6: ER,EL,ER,WL,WR.
```

The twelve-step return from `7:W2` to its first north arrival makes
`W2=SR`, immediately followed by `NL=W3`. There are now two north
arrivals on level seven. Its count equations and R-first order give
exactly the following two words, where `f=omega_7`:

```text
P: SR,SL,SR,NL,NR,SL,SR,[SL]^(1-f),
Q: SR,SL,SR,NL,SR,SL,NR,[SL]^(1-f).
```

Indeed, two `NL` ports would leave only two `SR` ports and no `SL`
(and would require `f=0`), which cannot put two west departures before
the first north arrival in an alternating word. There is therefore one
`NL`, three `SR`, and one `NR`. Two `SR` precede the `NL`; the final
`SR` and the `NR` may occur in either order.

Write the three `SR` ports as `SR1,SR2,SR3`. As in the earlier even-band
argument, two fixed paths are

```text
7:SR1 -> 4:first WR -> 5:first NR -> 8:E2,
7:SR3 -> 4:last WR -> 5:NL -> 2:WL -> 1:SL
      -> 4:EL -> 5:last NR -> 8:E3.
```

If `E3=EL`, its south-departure predecessor would have to be `E2=ER`,
and the first path would return from `SR1` to `SR3` with two right turns.
Thus `E3=ER`, and its south step must return to `SL` immediately after
`SR3`. This removes `P,f=1`.

Let `J` be the level-eight south departure feeding `SR3`. Its eight-step
return to `E3=ER` makes `J=WL`, with `WL,ER` consecutive there.

## The last east arrival and its preceding north departure

For `P`, now with `f=0`, the south arrivals on level seven are
`SR1,SL1,SR2,SL2,SR3,SL3`. Thus `E3=ER` is the last south departure on
level eight, and `E4=EL` follows it immediately in stable order.

For `Q`, `E3=ER` feeds `SL2`. If `f=1`, that is again the last south
arrival and the same conclusion follows. If `f=0`, one last `SL` follows
the sole `NR` on level seven. This `NR` is fed by the final `WR` on
level six. In contrast, `E4` is fed by `6:WL -> 5:last SL`, so

```text
tau(E4)=tau(6:WL)+2-N < tau(6:last WR).
```

It cannot feed the last south arrival on level seven. Hence `E4=EL`,
and the final south departure on level eight is a `WL` after `E4`.
There is no available left turn between `E3=ER` and `E4=EL`: that final
`WL` occurs later, and no other east arrival lies between them. They are
again consecutive stable events.

In every remaining case, the block ending at `E4` is therefore

```text
Z=WR, J=WL, E3=ER, E4=EL,
```

where `Z` is the north departure immediately preceding `E4` in north
departure order. To see that this preceding right turn is `WR`, note that
`J` is the fifth south departure in `P` and the fourth in `Q`. The return
from the first south predecessor through `SR1` to `E2` makes `E2`
either `EL`, or the second south departure `ER`. Thus the right turn
before `J` cannot be either of the earlier east arrivals.

## The inward returns force a forbidden translated path

There are exactly two west departures on level nine, feeding `6:WL,WR`.
Call them `T1,T2` in order, and let `Nq` be the north arrival fed by
`8:E4=EL`. The first has the four-step return

```text
T1 -> 6:WL -> 5:last SL -> 8:E4 -> Nq.
```

If `T1=NL`, its consecutive target is `NR`, so its incoming predecessor
is `8:Z`, the preceding north departure. The return

```text
8:Z -> 9:T1 -> 6:WL -> 5:last SL -> 8:E4
```

would then skip `J,E3` on level eight. Therefore `T1=SR`, and its
consecutive target is `NL=T2`. In particular there is no `SR` later
than `T2` in the level-nine word.

The path from `T2` through `6:last WR,7:NR` ends at an east arrival `F`
on level ten: it is the second east arrival for `P`, and the third for
`Q`. It must be `EL`. Otherwise its south step would return to a
south arrival immediately after `9:T2=NL`; that visit would have to be
`SR`, and the only `SR` on level nine occurs earlier.

The south departure on level ten feeding `9:T1=SR` now has an eight-step
return, through `T1`, the four-step return to `T2`, and the path to `F`.
Its opposite-turn source is `ER`, immediately preceding `F` in stable
order. Thus it is the immediately preceding east arrival `F'`.

For `P`, `F'` is supplied by `7:SL1`. For `Q`, it is supplied by
`7:SL2`. Let `Y` be the level-eight south departure feeding that `SL`.
In `P`, every south departure precedes `E4`; in `Q`, this particular
departure is `E3=ER`. Hence in either case `tau(Y)<tau(E4)`.

But the now-forced path is

```text
8:Y -> 7:SL -> 10:F'=ER -> 9:T1=SR -> 6:WL
    -> 5:last SL -> 8:E4=EL.
```

Its direction word is `SESWSE`, of length six and displacement `(1,-3)`.
Therefore

```text
tau(E4)=tau(Y)+6-N.
```

The strict stable inequality requires `N<6`, contradicting the drift's
kinematic lower bound. This removes the final branch and proves that
levels four and five cannot both be non-wake.

## Remaining cap branches

The lower `(1,2,2)` problem now has three early wake patterns:
`(omega_4,omega_5)=(1,0),(0,1),(1,1)`. The upper cap is unrestricted in
this theorem. The final voltage inequality has the opposite sign in
upper inward coordinates, so this wake restriction is asserted only
for the lower cap in the stated drift orientation.
