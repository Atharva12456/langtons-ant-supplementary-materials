# Excluding the middle-north continuation of form R

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: the remaining N continuation is excluded
in `odd_skew_upper_a_r_exclusion_2026-09-15.md`, closing
the entire upper form R in family A.

Of the two offset-seven words left for form R, word M is
impossible. Only word N remains:

```text
7: SR,SL,SR,NL,NR,NL,SR,SL.
```

For N, the word on nine is fixed as

```text
NR,SL,NR,SL,NR,SL,NR,SL,NR,NL,NR,SL,NR,SL,SR,NL,SR,SL.
```

The second east arrival on ten turns right, and its final
five events are `WL,ER,WL,WR,EL`. The remaining word N
is not excluded here. Forms P and Q, family B, and the
other cap profiles in the `(1,-3)` orbit remain open.

## A common left/left obstruction

Both candidate continuations have

```text
5: NR,SL,SR,NL,NR,SL,NR,SL
6: ER1,WL1,ER2,WL2,WR1,EL,WR2.
```

Write `Wi` for west departures and `Ni` for north arrivals
on seven. The first north arrival is `W3=NL=N1`, supplied
by `6:WR1`; the next is `N2=NR`, supplied by `6:EL`.
In both M and N, the first `SL` on seven precedes `W3`.

Let `Ei` be the east arrivals on eight, `Di` the west
departures on nine, and `Fi` the east arrivals on ten.
The previous reduction gives the consecutive final pair
`E5=ER,E6=EL` on eight. The west targets on six are

```text
D1 -> WL1,       D2 -> WL2,       D3 -> WR1,       D4 -> WR2.
```

The square from `D2` through `6:WL2,5:SL3,E6=EL`
cannot have an `NL` source: its incoming predecessor on
eight would need to be `WR` immediately before `E6`,
where the predecessor is `E5=ER`. Thus `D2=SR`, with
consecutive target `D3=NL`.

The first east arrival `F1` on ten is supplied by the first
`SL` on seven; `F2` by `7:N2=NR`. There is a seven-step
path

```text
D3 -> 6:WR1 -> 7:W3=NL -> 4:second WL -> 3:last SL
   -> 6:EL -> 7:N2=NR -> 10:F2.
```

Suppose `F2=EL`. The south predecessor of `D2` on ten
follows the square from `D2` to `D3` and then this
seven-step path. Its twelve-step first return to `F2`
forces it to be `F1=ER`, immediately before `F2`.

But this forces the eight-step first return

```text
7:first SL -> 10:F1=ER -> 9:D2=SR -> 6:WL2 -> 5:SL3
           -> 8:E6=EL -> 9:D3=NL -> 6:WR1 -> 7:W3=NL.
```

Its direction word is `E S W S E N W N`; the first
return to the starting physical cell is at the displayed
endpoint. Both endpoints turn left. Hence `F2=ER` in
both M and N.

Its south step completes an eight-step first return from
`D3=NL` to `D4=SR`.

## Word M is impossible

In M the third north arrival `N3`, supplied by `6:WR2`,
is `NR`. It supplies the fifth east arrival `F5` on ten.
Consequently

```text
10:F2=ER -> 9:D4=SR -> 6:WR2 -> 7:N3=NR -> 10:F5
```

is a square return. It skips the intervening east arrivals
`F3,F4`, regardless of the turn at `F5`. This excludes M.

In N, `N3=W4=NL`, so this square is not available.
The rest of the note records the restrictions that do follow
for N.

## The complete offset-nine word for N

The word on eight is already fixed:

```text
WR,WL,E1=ER,I=WL,WR,E2=EL,WR,E3=EL,WR,E4=EL,
WR,J=WL,E5=ER,E6=EL.
```

The eight-step return from `D1` through
`6:WL1,5:SR,2:WR,3:NR,6:ER2,5:SL2,E4=EL` cannot
have an `SR` source, whose consecutive target would be
`D2=NL`, contrary to `D2=SR`. Thus `D1=NL`, supplied
by the `WR` immediately before `E4`. It is the sixth
north arrival on nine, and its consecutive target is the
seventh north arrival `NR`, supplied by `E4`.

Before this first west departure, all five north arrivals
are `NR`; alternation forces a single `SL` between each
pair. The eighth north arrival is also `NR`, since the
remaining west departures are `D2=SR,D3=NL,D4=SR`,
and `D3` is the ninth north arrival, supplied by `E6`.
The square from `D2` to `D3` places `D2` after the
eighth north arrival. Since nine is non-wake, these facts
give the entire word

```text
9: NR,SL,NR,SL,NR,SL,NR,SL,NR,D1=NL,NR,SL,NR,SL,
   D2=SR,D3=NL,D4=SR,SL.
```

In particular, `D2,D4` are the seventh and eighth south
arrivals, and the final `SL` is the ninth.

## The ending on ten and eleven

There are only three east arrivals on ten. The second,
`F2=ER`, feeds `D4`, the penultimate south arrival on
nine. If `F3=ER`, alternation between the consecutive
east right turns `F2,F3` would require a `WL` between
them, using two additional south departures. Only one is
available. Thus `F3=EL`.

The south predecessor of `D2` on ten has a twelve-step
first return to `F2=ER`, by the common path above. It
is therefore `Y=WL`, immediately before `F2`, and is
the seventh south departure on ten.

The last west arrival on eight is `J=WL`, immediately
before `E5=ER,E6=EL`. Let `P_J` be the last west
departure on eleven, feeding `J`. It has the eight-step
first return

```text
P_J -> 8:J=WL -> 7:W5=SR -> 4:last WR -> 5:NR3
    -> 8:E5=ER -> 7:last SL -> 10:F3=EL
    -> north arrival on 11.
```

An `SR` source would create a further west departure
`NL`, so `P_J=NL`. Starting at its incoming predecessor
on ten gives an eight-step first return to `F3=EL`;
that predecessor is `X=WR`, immediately before `F3`.

The only south departure after `F2` is `K=WL`, supplying
the last `SL` on nine. Alternation and the non-wake
condition on ten therefore fix its final five events:

```text
10: ...,Y=WL,F2=ER,K=WL,X=WR,F3=EL.
```

There are no further north departures on ten. With eleven
non-wake and no west departures after `P_J`, its final
three events are consequently `P_J=NL,NR,SL`.

## Square gaps and the last east arrival on twelve

The final four events `WL2,WR1,EL,WR2` on six have
successive four-step gaps, by the squares

```text
6:WL2 -> 5:SL3 -> 8:E6=EL -> 9:D3=NL -> 6:WR1;
6:WR1 -> 7:W3=NL -> 4:second WL -> 3:last SL -> 6:EL;
6:EL -> 7:N2=NR -> 10:F2=ER -> 9:D4=SR -> 6:WR2.
```

Let `H` be the last east arrival on twelve, supplied by
`10:K -> 9:last SL`. The equal-voltage paths from
`6:WL2` to `E6` and from `6:EL` to `F2` give
`tau(F2)=tau(E6)+8`. In upper inward time,

```text
tau(H)=tau(K)+2+N,
tau(F3)=tau(E5)+2+N.
```

Since `K>F2` and `E6>E5`, one obtains
`tau(H)>tau(F3)+8`. A right turn at `H` would feed
the last `SL` on eleven, after its last north arrival
from `F3`. It would be both the last east arrival and
last south departure on twelve, forcing a wake there.
But form R now has `h=1`, and upper offsets seven
through fifteen are non-wake. Hence `H=EL`.

At most one south departure on twelve can follow `H`.
Its word therefore ends at `H=EL`, or with `H=EL,WR,WL`.
These endings and the unresolved first east arrival on
ten remain to be handled. They do not close word N or
the entire R form.
