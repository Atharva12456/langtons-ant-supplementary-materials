# Primitive diagonal growth four: the top-boundary obstruction

## Status

This note proves that no finite-support periodic highway of growth four has
primitive diagonal drift. The proof combines an analytic reduction with
computer-assisted verification of the remaining affine cases. It has no period
or voltage bound. Normalize the drift to `d=(1,-1)`, put the singleton bottom rail at
transverse level zero, and let `f_c` be the number of crossings in either
direction through the cut between levels `c` and `c+1`.

The earlier computer-assisted part of the note remains useful as a separate
boundary check.  It proves

```text
max(f_1,f_2,f_3,f_4,f_5) >= 6.                       (1)
```

and the analogous inward statement at the top rail.  The top calculation is
sign-reversed in the original longitudinal coordinate; it is not inferred from
a bare spatial reflection. The top-boundary argument below goes farther: its first
three top-rooted rows leave no possible continuation.  Together with the earlier
axis and even-diagonal theorems, this closes every growth-four drift family.
Growth eight remains open, so the bound `g>=12` is not proved.

## The finite symbolic reduction

At depth `d`, write `n=f_(d-1)` for the number of frontier nodes, `m=f_d` for
their children, and `p` for the number of nonleaf nodes.  Exact stable
alternation gives

```text
4p = n+m+omega     if d is odd,
4p = n+m-omega     if d is even,                         (2)
```

where `omega=(n+m) mod 2`.  Growth four leaves one interior wake level of each
parity.

Assume, contrary to (1), that the first five cuts are at most five.  The cap-four
theorem puts a cut of size five among the first four.  Its first occurrence
cannot be `f_1`: substituting `(n,m)=(1,5)` in (2) gives no integer `p`.
Therefore the first five occurs at depth `j=2`, `3`, or `4`.

The next row has five nodes and at most five children.  Equation (2) gives at
most two nonleaves, so at least three of the five node voltages are fixed leaf
voltages.  The voltage of the depth-one node is one.  After the fixed leaves are
substituted, this root equation leaves at most one free integer parameter among
the remaining voltages.  Every base, endpoint, and earlier event coordinate is
therefore an affine function of one integer.

The primary enumeration checks every cut prefix, every ordered degree row, every
legal placement of the terminal leaves, and every integer order regime of those
affine coordinates.  Coordinate order can change only where two affine functions
are equal, so the complete unbounded check is finite: it evaluates the equality
points that are integral, one integer in every nonempty interval between
successive rational equality points, and both tails.

Earlier rows are required to equal `RLRL...` after sorting by decreasing base,
with contour order breaking ties.  On the terminal row the test is weaker.  It
keeps only leaf turns and the two endpoints of each nonleaf, then asks whether
that fixed word is a subsequence of the required alternating word.  The omitted
interior turns may be inserted anywhere.  Failure of this relaxed test rules out
the actual row.

## Exhaustive table

There are 1,320 cut/degree/leaf cases.  Exact order on the earlier rows reduces
them to the following nine regimes.  `B` and `V` are the terminal bases and
voltages in plane order.

| cut prefix | next cut | `B` | `V` | fixed word | target |
|---|---:|---|---|---|---|
| `(2,3,5)` | 3 | `(1,2,3,1,2)` | `(2,1,-2,1,1)` | `LLRRLRL` | `RLRLRLRL` |
| `(2,3,5)` | 3 | `(3,4,2,3,3)` | `(1,-2,1,1,2)` | `LLRRLRL` | `RLRLRLRL` |
| `(3,1,3,5)` | 2 | `(2,1,3,2,2)` | `(-1,2,-1,-1,-2)` | `RLLLRRR` | `RLRLRLR` |
| `(3,1,3,5)` | 3 | `(2,1,3,2,2)` | `(-1,2,-1,-1,-2)` | `RLLLRRR` | `RLRLRLRL` |
| `(3,2,5)` | 3 | `(2,-1,0,1,2)` | `(-2,1,1,1,0)` | `LLRLRLR` | `RLRLRLRL` |
| `(3,2,5)` | 3 | `(2,1,2,0,1)` | `(-1,1,-1,1,1)` | `LLRRLLR` | `RLRLRLRL` |
| `(3,2,5)` | 3 | `(2,2,-1,0,1)` | `(0,-2,1,1,1)` | `LLLRRLR` | `RLRLRLRL` |
| `(3,5)` | 2 | `(1,0,0,1,0)` | `(-1,-1,1,-1,1)` | `RRLLLRR` | `RLRLRLR` |
| `(3,5)` | 3 | `(1,0,0,1,0)` | `(-1,-1,1,-1,1)` | `RRLLLRR` | `RLRLRLRL` |

None of the fixed words is a subsequence of its target.  Five rows begin with
`L`; each remaining row contains an unrepairable block of equal turns.  Thus all
1,320 cases fail.

At the top rail, inward depth is `d=T-t` and the original `x` coordinate is
retained.  The nonroot self voltage is `(-1)^(d+1)`, and entering a child shifts
`x` by `-1` at odd depth and by zero at even depth.  Stable events are still
ordered by decreasing `x`.  The same 1,320 structural cases leave only two
exact source regimes:

| cut prefix | next cut | `B` | `V` | fixed word | target |
|---|---:|---|---|---|---|
| `(3,5)` | 2 | `(-2,-1,0,1,-1)` | `(2,1,1,-2,1)` | `RLRLLRR` | `RLRLRLR` |
| `(3,5)` | 3 | `(-2,-1,0,1,-1)` | `(2,1,1,-2,1)` | `RLRLLRR` | `RLRLRLRL` |

Neither fixed word embeds in its alternating target, so the top calculation
also has zero survivors.

### Analytic top-adjacent cut

The sign-reversed conventions also give a short computation-free consequence.
Let `u` be the unique depth-one node below the top rail, normalized by
`b(u)=0` and `v(u)=1`.  The level count permits only two or three children.
Suppose there are two, with voltages `z_1,z_2`.  The depth-one voltage recurrence
gives `z_1+z_2=0`, while the three depth-one events occur at

```text
x=0, z_1, 0        with turns R,L,R.
```

Decreasing-`x` alternation is possible only when `z_1=z_2=0`.  Both children
then have base `-1`.  At even depth a leaf has voltage `-1`, so these two
zero-voltage children are nonleaves.  Each contributes fixed `L` endpoints at
`x=-1` and `x=0`.  In stable order the four anchors are

```text
end_1, end_2, start_1, start_2.
```

No event can occur between `end_2` at zero and `start_1` at minus one: coordinates
are integral, `end_2` is the last contour event at its coordinate, and `start_1`
is the first at its coordinate.  They are therefore consecutive `L` turns, a
contradiction.  Thus the first inward cut at the top has multiplicity exactly
three.  Write the three child voltages as `z_1,z_2,z_3`.  Their sum is zero, and
the depth-one event coordinates and turns are

```text
(0,R), (z_1,L), (z_1+z_2,L), (0,R).
```

Exact order forces exactly one proper partial sum to be zero and the other to be
an integer `r<0`.  Consequently the depth-two frontier is in one of the two
families

```text
B=(-1,-1,-1+r), V=(0,r,-r),
B=(-1,-1+r,-1), V=(r,-r,0),                 r<=-1.       (3)
```

For three nodes on the next even row, the complete count-law list of possible
child counts is `1,2,5,6,9,10`.  Counts one and two would leave two leaf parents,
but an even-depth top leaf has voltage `-1`, and either family in (3) contains at
most one such voltage.  Counts nine and ten make all three parents nonleaves.
In either family the last parent ends at `x=0` and the first parent starts at
`x=-1`; these are `L` anchors, and no integral-coordinate event can separate
them.  Those cases also fail.  Thus the first two inward cuts are

```text
(f_1,f_2)=(3,5) or (3,6).                         (4)
```

In both surviving cases the unique even-depth leaf forces `r=-1`, and only the
second family in (3) survives.  The three current nodes therefore have

```text
B=(-1,-2,-1), V=(-1,1,0),
```

with the first node the leaf.  Let the two nonleaf degrees be `a,b`, and write
their successive event coordinates as

```text
q_0=-2,...,q_a=0,       r_0=-1,...,r_b=0.
```

For `f_2=5`, either

```text
a=1: (r_1,...,r_(b-1)) is a permutation of (alpha,0,-1), alpha>=1;
a=2: q_1=alpha>=0 and (r_1,...,r_(b-1)) permutes (0,-1).
```

For `f_2=6`, either

```text
a=1: the proper r-coordinates permute (alpha,0,-1,beta), alpha>=1, beta<=-2;
a=2: q_1=alpha>=0 and r permutes (0,-1,beta), beta<=-2,
     or q_1=beta<=-2 and r permutes (alpha,0,-1), alpha>=1;
a=3: (q_1,q_2) permutes (alpha,beta), alpha>=0, beta<=-2,
     and (r_1,r_2) permutes (0,-1).
```

These conditions are necessary and sufficient for exact order on this even
row: successive coordinate differences define the child voltages.  For example,
`f_2=6`, degrees `(0,1,5)`, `q=(-2,0)` and
`r=(-1,-3,-1,0,1,0)` give the exact child frontier

```text
B'=(-2,-1,-3,-1,0,1), V'=(2,-2,2,1,1,-1).
```

Its stable row is `RLRLRLRLR`, so the six-branch is genuinely locally
realisable.

### The third inward cut

The affine forms settle the entire next row, not only its smallest values.
For `f_2=5`, write the eight forms as

```text
I:  q=(-2,0),       r=(-1, pi(alpha,0,-1), 0),  alpha>=1, pi in S_3;
II: q=(-2,alpha,0), r=(-1, pi(0,-1), 0),        alpha>=0, pi in S_2.
```

The odd-row count and leaf numbers are

```text
f_3:        2 3 6 7 10 11 14 15
p_3:        2 2 3 3  4  4  5  5
leaf count: 3 3 2 2  1  1  0  0.
```

Put `S_i=b_i` and `E_i=b_i+v_i-1` for the first and last fixed `R` anchors of a
nonleaf on this odd row.  Two gaps recur throughout the case split.

* If nodes zero and four are nonleaves, `E_4` is the final contour event at
  `x=-1`, while `S_0` is the first at `x=-2`.  They are consecutive in stable
  order: no integer coordinate lies between them, and neither tie side contains
  a phase slot for the required `L`.
* In type I, `E_0=S_1=-1`; in type II, `E_1=S_2=-1`.  When the indicated pair is
  nonleaf, these are again consecutive `R` anchors, now at the same coordinate
  and at consecutive contour phases.

For `p_3=2`, the leaf equations leave one state,

```text
B=(-2,-1,0,1,-1), V=(2,1,1,-2,1),
```

with nonleaf support `{0,3}` and fixed word `RLRLLRR`.  For `p_3=3`, every
support containing node four dies by the first gap.  The remaining type-II
order has support `{0,1,3}` and leaves `{2,4}`; the remaining generic type-I
order has support `{0,2,3}` and leaves `{1,4}`.  Both have fixed word
`RRRRLLRR`.  At `alpha=1`, the additional type-I support `{0,1,3}` dies by the
second gap.  For `p_3=4`, node four must be the sole leaf.  The only compatible
orders are type I ending in `-1` and type II ordered `(0,-1)`; each has the
second empty gap.  For `p_3=5`, all nodes are nonleaves and the first gap applies
immediately.  Every omitted interior event is `L`, so neither a fixed `LL` nor
an empty slot between consecutive `R` anchors can be repaired.  Thus the entire
`f_2=5` branch is impossible.

For `f_2=6`, the count law gives

```text
f_3: 2 5 6 9 10 13 14 17 18
p_3: 2 3 3 4  4  5  5  6  6.
```

The four-leaf case `f_3=2` has the unique fixed word `RLRLLRLR`.  For `f_3=5`
or `6`, solving the three leaf equations in all forty affine forms leaves five
parameter branches.  Their complete fixed-word set is

```text
RLRLLRRRR, RRRRLLRLR, RLRRRLRLR, RLRLRRRLR, RLRRLRRLR.
```

The first two contain fixed `LL`.  In each remaining word a missing `L` would
have to lie between a specified pair of consecutive `R` anchors: either two
anchors at `x=-1` with consecutive contour phases, or the final anchor at
`x=-1` followed by the first at `x=-2`.  No integer stable key occupies the
required gap.

It remains to check the larger counts.  Node zero is never a leaf in any of the
forty normal forms: its voltage is `2`, `alpha+2`, or `beta+2`, with the stated
parameter domains.  If node five is a nonleaf, its final `R` at `x=-1` and node
zero's first `R` at `x=-2` form the first empty gap above.  Hence:

* for `f_3=17,18`, where all six nodes are nonleaves, the first gap is already a
  contradiction;
* for `f_3=13,14`, the sole leaf must be node five, leaving both nodes at the
  `q/r` block junction nonleaf; their endpoint and start are consecutive `R`
  anchors at `x=-1`;
* for `f_3=9,10`, the two leaves must be node five and one junction node.  The
  leaf equations leave six affine coordinate orders.  In all six the leaves
  are the first `r` node and node five, both at `x=-1`, with no fixed `R` between
  them.  The compressed word is `RRRRLLRRRR`.

Thus `f_2=6` has no continuation either.  A primitive growth-four trace has four
distinct wake levels.  The two extremal levels use two of them, so its even
width is at least four and the three inward rows considered above exist.  The
top-rooted case tree is therefore empty: primitive-diagonal growth four is
impossible at every period.

The reduction is analytic and period-unbounded. Its final exhaustive affine
verification is computer-assisted. The script
`code/python/audit_primitive_g4_top_prefix.py` enumerates the 8 and 40 affine
forms, solves the unit-voltage equations exactly, partitions every remaining
integer parameter line at every base/endpoint gap crossing, and performs exact
integer-gap matching for the omitted events.  It also checks the two
parameter-free endpoint obstructions for the large cuts.  It uses no voltage
bound.  The checked summary and source hash are in
`results/primitive_g4_top_prefix_certificate.json`.

The reproduction and audit commands are:

```text
python code/python/primitive_g4_cap5_symbolic.py
python code/python/verify_primitive_g4_cap5_indep.py
python code/python/verify_primitive_g4_cap5_top.py
python code/python/audit_primitive_g4_cap5.py
python code/python/audit_primitive_g4_top_prefix.py
```

The verifier does not import the primary program.  It constructs affine pairs
directly, derives the terminal voltage sum from the root equation, and builds
the integer order cells from exact rational crossing points.  Both programs
report 1,320 cases, nine regimes, and zero survivors, and they print the same
nine bottom rows above.  The separate top verifier reports 1,320 cases, the two
top regimes above, and zero survivors.  The cross-audit checks all three source
hashes and both certified tables.

Because the established width bound is `W>=10`, five inward levels exist from
either rail.  The bottom and top calculations use their respective signed tree
recurrences; no reflection symmetry is assumed.  No period, width, or voltage
cutoff enters either enumeration.
