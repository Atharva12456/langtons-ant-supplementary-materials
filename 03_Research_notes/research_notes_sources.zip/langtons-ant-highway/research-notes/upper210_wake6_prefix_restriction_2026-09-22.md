# Upper `(1,2,3)` band `210` with a wake at offset six

22 September 2026. This is a **necessary prefix restriction**, not an
exclusion. It applies at every period to the surviving Family B upper-cap
branch whose initial long-row triple is `(j,k,l)=(2,1,0)` and whose inward
offset six is wake. In Family B, inward offsets five and seven through eleven
are non-wake; the cap rows at offsets zero through four are those in
`verify_upper_fat123_210_w6zero.py`. Family B has width at least 28, so all
of the rows checked below occur before the opposite cap.

Complete generic stable-word enumeration through inward row ten gives:

| New row | Wake | Count-compatible rows | Adjacency words | Bad physical first return | Bad lifted clock | Survivors |
|---:|---:|---:|---:|---:|---:|---:|
| 5 | 0 | 3 | 9 | 0 | 0 | 9 |
| 6 | 1 | 41 | 52 | 6 | 5 | 41 |
| 7 | 0 | 226 | 451 | 379 | 23 | 49 |
| 8 | 0 | 283 | 467 | 264 | 26 | 177 |
| 9 | 0 | 1006 | 5393 | 4798 | 192 | 403 |
| 10 | 0 | 2560 | 62826 | 48317 | 7935 | 6574 |

Every one of the 6574 surviving row-ten prefixes has one of these two
**paired** row-five and row-six words (ports separated here by spaces):

| Pair | Inward row 5 | Inward row 6 | At row 9 | At row 10 |
|---|---|---|---:|---:|
| A | `SR SL NR SL NR NL NR SL SR SL` | `WR WL ER WL WR WL WR EL ER EL ER` | 238 | 3698 |
| B | `NR SL SR SL NR NL NR SL SR SL` | `WR WL WR WL ER WL WR EL ER EL ER` | 165 | 2876 |

The companion scripts and saved frontier states are in `work_family_b_upper/`. Run `python work_family_b_upper/crosscheck_210_w6one.py 10` to independently use the generic adjacency
enumerator and compares every surviving word dictionary with the fast unary
frontier from `explore_210_w6one.py`. The generic enumeration imposes the
local count equations, alternating stable-word order, exact ordinal
successor matching, physical first-return order, and upper-sign lifted-clock
feasibility. The fast and generic state sets agree through row ten.
Run `python work_family_b_upper/check_integer_clocks.py 10` to check all 6574 retained prefixes with the exact
integer Z3 clock equations; all 6574 are feasible. The rational fast clock
therefore conceals no integer-clock exclusion through row ten.

The clock check has no period upper bound. It imposes the necessary
`N >= max(6, number of represented events)` and solves the lifted clock
inequalities. A full ant trajectory would have to satisfy further rows and
global constraints. These 6574 locally consistent row-ten prefixes do not establish
existence of a periodic ant, and Family B remains open.

## Bounded scan of the other three Family B upper bands

`work_family_b_upper/quick_other_bands.py` applies the same fast necessary-condition frontier
through inward row eight, with non-wake rows five, seven and eight. These
branches all retain rational-clock-feasible prefixes:

| Initial upper band | Wake at row 6 | Row 5 | Row 6 | Row 7 | Row 8 |
|---|---:|---:|---:|---:|---:|
| Short | 0 | 9 | 8 | 78 | 3053 |
| Short | 1 | 9 | 9 | 191 | 11042 |
| `111` | 0 | 6 | 28 | 20 | 10 |
| `111` | 1 | 6 | 36 | 26 | 25 |
| `120` | 0 | 7 | 39 | 70 | 55 |
| `120` | 1 | 7 | 44 | 90 | 121 |

The short, `111`, and `120` bands receive no offset-eight exclusion from
this scan. Their integer-clock frontiers were not independently checked here.
