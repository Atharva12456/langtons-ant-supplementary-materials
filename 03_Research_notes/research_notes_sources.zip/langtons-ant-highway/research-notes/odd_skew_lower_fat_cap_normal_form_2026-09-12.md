# Stable words at a lower fat cap for drift `(1,-3)`

The two fat cap profiles admit a common five-level normal form. For a lower
cap, exact lifted chronology leaves two possible bands with profile
`(1,2,2)` and twelve with profile `(1,2,3)`. These are necessary conditions;
realizability is unresolved. The proof excludes several branches at every period;
it does not exclude either whole profile or the drift orbit. The two-word
reduction for `(1,2,2)` also holds at the upper cap after rotating the heading
labels by 180 degrees.

No enumeration is used in the proof. In particular, none of the saved partial
frontier witnesses is a premise.

## Coordinates and statement

Use transverse coordinate `t=3x+y`, with the lowest visited level normalized
to zero. Take representative cell `c_t=(0,t)` and drift `d=(1,-3)`. If `tau`
denotes stable lifted time, an edge with voltage `lambda` gives

```text
tau(target) = tau(source)+1-N*lambda,
lambda(E)=1, lambda(W)=-1, lambda(N)=lambda(S)=0.
```

Stable visits to a fixed representative have strictly increasing times.
Consecutive visits to the same physical cell have a positive time difference
divisible by four: a closed walk has equal east/west and north/south counts,
and the two step axes alternate. Thus each such difference is at least four.

Write a port as incoming heading followed by turn. Put `p=1` for profile
`(1,2,2)` and `p=2` for profile `(1,2,3)`. The first three stable rows are

```text
0: WR
1: NR,SL
2: WR,WL                 if p=1,
   WR,WL,WR              if p=2.
```

Let `a=omega_3` and `b=omega_4` be the two wake indicators. Every possible
lower fat cap has nonnegative integers `j,k,l` satisfying

```text
j>=1,                    j+k+l=p+1-a,
l>=1                     if p=2 and a=0,
k>=1                     if p=1.
```

Its next two stable rows are exactly

```text
3: (NR,SL)^(j-1), SR, (SL,NR)^(p-j+1), [SL]^(1-a),
4: (WR,WL)^j, ER, (WL,WR)^k, EL, (WR,WL)^l, [WR]^b.
```

A zero exponent means the corresponding block is absent. The allowed triples
are therefore

| Profile | `a` | Possible `(j,k,l)` |
|---|---:|---|
| `(1,2,2)` | 0 | `(1,1,0)` |
| `(1,2,2)` | 1 | none |
| `(1,2,3)` | 0 | `(1,0,2)`, `(1,1,1)`, `(2,0,1)` |
| `(1,2,3)` | 1 | `(1,0,1)`, `(1,1,0)`, `(2,0,0)` |

In this table `b` may be zero or one. The counts of two and twelve refer
only to the bands in this table, without an assertion that every band extends.

There is a further temporal restriction. Let `U` and `V` be the times of the
first `WR` and the unique `WL` on level two. The listed bands satisfy

```text
V-U >= N+14               if j=2,
V-U >= N+10               if k=1.
```

For profile `(1,2,2)`, the latter bound improves to `V-U>=N+14` by the
overlapping-square argument below. Among the twelve lower `(1,2,3)` bands,
only the four with `j=1,k=0` escape these bounds. No upper bound on such
lifetimes is assumed.

## The west departure on level three is `SR`

Let `h` be the number of `NL` ports on level three. There are `p` north
arrivals from the `WR` ports on level two, and exactly one west departure
to the singleton level zero. Flow and excess give

```text
(NR,NL,SR,SL) = (p-h,h,1-h,p+1-3h-a).
```

Nonnegativity gives `h=0`, except for the possible row with
`p=2,a=0,h=1`. That exceptional row is `NR,NL` in stable order.

It is impossible at a lower cap. Let `C` be the time of the second `WR` on
level two. Its north step feeds the second north arrival on level three,
namely `NL`. The forced path is

```text
2:second WR -> 3:NL -> 0:WR -> 1:NR.
```

The west step has voltage `-1`, so `tau(1:NR)=C+N+3`. On the other hand,
`2:WL -> 1:SL` gives `tau(1:SL)=V+1`. Stable order on level one requires

```text
C+N+3 < V+1,
```

while stable order on level two gives `V<C`. This is a contradiction.
Consequently `h=0`, and level three has counts

```text
(NR,NL,SR,SL) = (p,0,1,p+1-a).
```

## The first east arrival on level four is `ER`

Let `A=tau(0:WR)`. The unique `SR` on level three has time `A-N-1`.
Let `J` be its south-departure predecessor on level four. The path

```text
J -> 3:SR -> 0:WR -> 1:NR -> first east arrival on 4
```

has direction word `SWNE` and returns to the same physical level-four cell
after four steps, with no intermediate visit there. Its endpoints are
consecutive stable events.

The endpoint is the first east arrival because `NR` precedes `SL` on level
one and edge matching preserves order. Since `J` is earlier than this first
east arrival, it cannot be `ER`; a south departure must therefore be `WL`.
The return has the opposite turn, so its endpoint is `ER`. In particular,
`WL,ER` occur consecutively on level four. Their times are

```text
tau(J)=A-N-2,             tau(first ER)=A-N+2.
```

The `ER` step also returns from `3:SR` to level three four steps later.
Its arrival is the next stable event there, so `SR,SL` are consecutive.

## The second east arrival is `EL`

There are two east arrivals on level four, supplied by `1:NR` and `1:SL`.
Let `e` count its `ER` ports and put `D=p+2-a`, the number of south
arrivals on level three. The complete level-four count row is

```text
(ER,EL,WR,WL) = (e,2-e,b+2+D-3e,D-e).
```

We have `e>=1`. If `e=2`, then `EL=0` and `WR=b+D-4`. Since `D<=4`, a
positive `WR` count is possible only for `p=2,a=0,b=1`, when `WR=1`.
If `WR=0`, the first right turn is already an east arrival, leaving no
earlier right turn to precede the required `WL,ER` pair. Those cases are
impossible.

In the sole remaining `e=2` case, the level-four word must be

```text
WR,WL,ER,WL,ER.
```

The `WL` preceding its first `ER` is the first south departure, so `SR`
is the first south arrival on level three. Its counts force

```text
3: SR,SL,NR,SL,NR,SL.
```

Let `C` again be the time of the second `WR` on level two. The second `NR`
on level three has time `C+1`. The last `SL` is fed by the second `ER` on
level four, which in turn is fed by `2:WL -> 1:SL`. Hence that last `SL`
has time `V+3-N`. Stable order would give

```text
C+1 < V+3-N.
```

But `V<C` and `N>=6`, a contradiction. The period lower bound follows
already from the vertical displacement of three and alternating step axes.
Thus `e=1`: the east arrivals are `ER,EL`, in that order.

## Recovering both stable words

Put `s=p+1-a`. The level-four counts are now

```text
(ER,EL,WR,WL) = (1,1,s+b,s).
```

Before the first east arrival, only `WR,WL` can occur. The consecutive
`WL,ER` pair therefore makes this prefix `(WR,WL)^j,ER`, with `j>=1`.
Between `ER` and `EL`, alternation permits only `(WL,WR)^k`. After `EL`,
the remainder is `(WR,WL)^l,[WR]^b`. Counting the `WL` ports gives
`j+k+l=s` and proves the claimed level-four formula.

Its `j`th south departure is the `WL` feeding `3:SR`. Thus `SR` is the
`j`th south arrival on level three. All its other south arrivals are `SL`,
and all its other right turns are `NR`. Alternation now forces the stated
level-three formula.

Suppose `p=2,a=0,l=0`. Every south departure on level four precedes `EL`.
The last south arrival on level three consequently has time less than
`tau(4:EL)+1=V+3-N`. However, its stable word ends with the second `NR`
followed by `SL`, so this last south arrival has time greater than `C+1`.
Again `V<C` and `N>=6` make these inequalities incompatible. This proves
`l>=1` in that branch. At this stage there are eight possible `(1,2,2)`
bands and twelve possible `(1,2,3)` bands. The level-five return below
removes six of the former and completes the table in the statement.

## Bands that require a long black lifetime

Stable order on level one, whose two visits are at `A+1` and `V+1`, gives
`V>=A+4`. If `j>=2`, the first `NR` on level three precedes `SR` by
`2(j-1)` stable gaps. Each gap is at least four. Since its predecessor is
the first `WR` on level two,

```text
U+1 <= A-N-1-8(j-1).
```

Subtracting from `V>=A+4` gives `V-U>=N+8j-2`. The table allows only
`j=1` or `j=2`, yielding the stated bound `N+14` for the latter.

If `k=1`, the table has `j=1`. The first `NR` on level three is followed
by `SL`, whose south-departure source is the `WL` in the middle `(WL,WR)`
block on level four. The times of these events obey

```text
tau(3:first NR)=U+1,
tau(3:following SL)>=U+5,
tau(4:middle WL)>=U+4,
tau(4:middle WR)>=U+8,
tau(4:EL)>=U+12.
```

The three inequalities using stable gaps hold at the same representative
cell in each case. Finally, `2:WL -> 1:SL -> 4:EL` gives
`tau(4:EL)=V+2-N`, proving `V-U>=N+10`.

## Only two bands remain for profile `(1,2,2)`

Suppose `p=1`. Put `c=omega_5` and let `B=p+2-a+b=3-a+b` be the number
of north arrivals on level five. Exactly two west departures there feed
`2:WR,WL`. If `h` counts its `NL` ports, its counts are

```text
(NR,NL,SR,SL) = (B-h,h,2-h,B+2-3h-c).
```

Write `W1,W2` for those west departures and `Nq` for the north arrival fed
by `4:EL`. The level-four word gives `q=j+k+1`. The forced return is

```text
W2 -> 2:WL -> 1:SL -> 4:EL -> Nq.
```

Its direction word is `WSEN`; it returns to the same physical level-five
cell in four steps with no intermediate visit there. Its endpoints must
be consecutive stable events with opposite turns.

If `h=0`, both endpoints would turn right. If `h=2`, nonnegativity forces
`B=4,c=0`; the stable word is `NR,NL,NR,NL`. Its last west departure is
the fourth north arrival, whereas `q=j+k+1<=p+2-a<=3`. The return would
go backward in stable order. Hence `h=1`.

There is now one `SR` and one `NL`. The later west departure cannot be
`SR`, since its opposite-turn target would be the earlier west departure
`NL`. Thus `W2=NL`, and its target is `NR`. Consecutive stable order
makes this `NL` the north arrival immediately preceding `Nq` in north
arrival order.

Let `Z` be the last `WR` before `EL` on level four. It feeds that `NL`,
so there is a second forced four-step return,

```text
Z -> 5:NL -> 2:WL -> 1:SL -> 4:EL.
```

Its direction word is `NWSE`, again with no intermediate level-four event.
Consequently `Z,EL` must be consecutive stable events. In the displayed
level-four normal form this occurs exactly when `k>=1`. When `k=0`,
the `WL,ER` pair lies between the last preceding `WR` and `EL`.

Since `j+k+l=2-a` and `j,k>=1`, we obtain

```text
a=0,                     (j,k,l)=(1,1,0).
```

Thus every lower `(1,2,2)` cap has

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,[WR]^b.
```

The same return also fixes level five up to two words, for each choice
of its wake indicator `c`:

```text
5: SR,SL,NR,NL,NR, (SL,NR)^b, [SL]^(1-c),
or NR,SL,SR,NL,NR, (SL,NR)^b, [SL]^(1-c).
```

Indeed, `NL` is the second north arrival and immediately precedes the
third. The unique `SR` is the earlier west departure, so it precedes
this pair. The first `NR` may occur before or after that `SR`; alternation
then fixes every remaining port. This argument allows either parity on
level five and uses no assumption on any deeper level.

The lifetime bound for this profile improves from `N+10` to `N+14`.
In the earlier time calculation, let `delta_1` be the gap from `3:NR` to
the following `3:SL`, and let `delta_2` be the gap from its predecessor
`4:WL` to the following `4:WR`. These gaps cannot both equal four. If
they did, the endpoint headings force the respective direction words
`ENWS` and `SENW`, and their union is the chronological segment

```text
3:NR -> 6:EL -> 7:NL -> 4:WL -> 3:SL -> 6:EL -> 7:NL -> 4:WR.
```

The two displayed level-six visits are to the same physical cell, with
no visit there between them. Both turn left, which is impossible.
Since `delta_1,delta_2` are positive multiples of four, their sum is at
least twelve. The final stable gap on level four is at least four, so
`V-U>=N+14` follows by the same time calculation.

The entire `(1,2,2)` reduction is valid at the upper cap as well, in inward
coordinates with heading labels rotated by 180 degrees. For `p=1`, the
level-three `NL` alternative is already excluded by nonnegative counts.
The level-four two-`ER` alternative either has a negative count or has no
`WR` before the required `WL,ER` pair. Thus neither of the lower-cap
inequalities involving `N` is needed for this profile. All remaining
returns have zero displacement and retain their chronological order under
the rotation. The long-lifetime bound is specific to the lower cap.

## Growth-eight consequences when a `(1,2,3)` cap has a wake on level three

At growth eight, the three level residues modulo three have wake counts
`4,2,2`. A two-wake fibre has equal checker signs, and the four-wake fibre
has three signs of one kind and one of the other. Consequently the wake
set cannot contain two disjoint pairs such that each pair consists of
opposite-parity levels in the same residue modulo three. If the pairs
belonged to different fibres, both fibres would require four wakes, and
the remaining fibre at least two. If they belonged to the same fibre,
its four signs would sum to zero modulo four, contrary to P22.

For a lower `(1,2,3)` cap with `a=1`, the wakes at levels zero and three
already form one such pair. Level two is also wake. Hence the four-wake
fibre is residue zero; residue two contains level two and exactly one
other even wake. In particular,

```text
omega_(6q+5)=0           for every nonnegative q.
```

This forces level five to be non-wake in all six five-level bands of this
subfamily, including those with `j=2` or `k=1`.

It also excludes an upper missing cap outright. That cap supplies another
opposite-parity pair `W-4,W-1` in a single residue. These levels are distinct
from zero and three because eight distinct wake levels require `W>=8`.
Likewise `W-3` cannot be wake: it would form a second disjoint pair with
the upper endpoint `W`. Thus this whole subfamily has

```text
upper cap is not missing,       omega_(W-3)=0.
```

These exclusions use only P22 and the stated wake levels, so they apply at
every width and period without an inward extension calculation.

## Scope of the reduction

The arguments involving `N` are for the lower cap in the displayed drift
orientation. At an upper cap, rotating the headings and measuring inward
reverses the longitudinal voltage; the same inequalities cannot be copied
with their signs unchanged. The preceding paragraph identifies the
`(1,2,2)` word restriction that does transfer.

The September 9 note reports the exclusion of all cap pairs consisting only
of missing and guard profiles. What remains includes a fat cap at one or
both ends. The present theorem restricts every remaining candidate whose
lower cap is fat, independently of its upper cap and inward width. It leaves
the inward extension of these fourteen bands and the cases with a non-fat
lower cap and a fat upper cap unresolved.
