# Positive-skew cap geometry at drift (1,3)

Update, 1 October 2026: the lower fat ER-first exclusion now has a
separate [hand proof](positive_skew_fat123_er_first_hand_exclusion_2026-10-01.md)
using only ordinal matching, alternation and zero-voltage physical
first returns. Its previous complete finite-domain certificate remains
a regression. New [band-C schedule restrictions](positive_skew_bandC_schedule_reduction_2026-10-01.md)
and a [tight lower-thin subfamily exclusion](positive_skew_tight_thin_reductions_2026-10-01.md)
further restrict the remaining cases. The whole orbit remains open.

Additional continuation, 1 October: a new weak-clock
[upper-six obstruction](positive_skew_bandC_upper6_wake8_reduction_2026-10-01.md)
forces upper wake eight in the lower-C/upper-F122 quiet-four/wake-six
branch. [Remaining-thin upper restrictions](positive_skew_remaining_thin_upper_reductions_2026-10-01.md)
eliminate five lower members under the upper isolated-five schedule
and give seven compact endpoint families. These do not close another
whole lower member or the orbit.

A subsequent [all-growth upper-F122 lemma](positive_skew_upper_thin_quiet34_requires_quiet5_2026-10-01.md)
strengthens that restriction: quiet upper three/four requires quiet
five. The entire isolated-five upper schedule is now excluded,
including its last lower-thin 000/010 endpoint families.

The new [quiet-six upper lemma](positive_skew_upper_thin_quiet6_requires_quiet7_2026-10-01.md)
also excludes upper F122 quiet three through six with wake seven.
For lower band C it removes the whole upper-wake-seven branch and
forces wake eight whenever upper four is quiet. The remaining thin
arithmetic package has 5,222 residue templates; the orbit remains open.

Later in the continuation, the
[thin101/110 upper-six exclusion](positive_skew_thin101_110_upper6_exclusion_2026-10-01.md)
removes both members against upper F122 with only wakes zero/six
through offset eight. The remaining-thin/F122 package now has 5,210
arithmetic residue templates. Both lower members retain other cap
schedules; no whole member or orbit closure follows.

Further continuation, 1 October: lower thin rigidity through seven now
has a complete [hand proof](positive_skew_lower_thin_hand_rigidity_2026-10-01.md).
At growth eight its whole [111 wake-pattern member is excluded](positive_skew_lower_thin_111_exclusion_2026-10-01.md)
for every upper cap, width and period. The other seven thin templates
and the remaining fat bands still require global chronological analysis.

This note works directly with the clockwise Langton rule, primitive drift
`d=(1,3)`, and transverse coordinate `t=3x-y`. It does not import a
negative-skew cap lemma by reflection. The premise is a finite-support periodic
highway, so every stable class word begins with R and alternates R,L.

At every positive period, **neither cap can have the missing profile
(1,1,0), and the lower guard profile (1,1,1) is impossible**. Hence the lower
cap must be (1,2,2) or (1,2,3). The lower (1,2,2) cap has a rigid necessary
prefix through level seven. The lower (1,2,3) third-level short word and
the long word ending in ER are also impossible. The upper guard and both
fat profiles still have local continuations. The lower (1,2,3) cap has only
three initial bands, and its band with wake levels three and four cannot
meet an upper guard at growth eight. These results do not close the
growth-eight drift orbit.

## 1. Coordinates, extrema, and exact matching

The physical moves change `t` by

| Move | E | W | N | S |
|---|---:|---:|---:|---:|
| Change in t | +3 | -3 | -1 | +1 |

At the minimum level a horizontal arrival can only be W. Its R departure is
N, outside the strip, so every such visit would be L. Stable first R rules
this out. A vertical arrival there can only be N, and its only allowed turn
is R. Alternation then makes the class a singleton NR. At the maximum,
the same direct argument gives a singleton SR. Both extrema are vertical,
so their level difference W is even. Normalize the minimum to level zero;
even levels have vertical arrivals and odd levels horizontal arrivals.

Use representatives `c_t=(0,-t)`. For a phase event at `c_t+k*d`, its lifted
time is `tau=i-N*k`. Edge voltages are

```
lambda(E)=1, lambda(W)=-1, lambda(N)=lambda(S)=0,
tau(target)=tau(source)+1-N*lambda.
```

Every fixed directed edge block preserves stable order, since its time shift
is constant. Thus its first departure feeds its first arrival, its second
departure its second arrival, and so on. This ordinal matching retains the
physical copy voltage; it is not arbitrary pairing of quotient ports.

If a forced path returns to its starting physical cell before visiting that
cell anywhere in between, its endpoint is the immediately next stable event
in that class. In particular, its endpoint turn is opposite. The path
`W,N,E,S` has displacement zero and voltage `-1+0+1+0=0`; its endpoint
lifted time is exactly the starting time plus four, for every N.

## 2. Exhaustive first-three-level profiles

Level one has no east arrival, and it supplies the unique northward entry
to level zero. Therefore it is WR or WR,WL. Level two has no west departure.
Its SL count equals the level-one WL count. Alternation gives exactly:

| Profile | Level 0 | Level 1 | Level 2 |
|---|---|---|---|
| missing (1,1,0) | NR | WR | empty |
| guard (1,1,1) | NR | WR | NR |
| fat (1,2,2) | NR | WR,WL | NR,SL |
| fat (1,2,3) | NR | WR,WL | NR,SL,NR |

This is exhaustive without any upper bound on width, period, or lifetimes.

## 3. Missing-cap exclusion and guard normal form

Let U be the unique west departure on level four when level one is WR.
It feeds that WR. Level zero then feeds the unique east arrival on level
three. If this east arrival is ER, there is the forced physical return

```
U -> 1:WR -> 0:NR -> 3:ER -> 4:V,
       W       N       E       S.
```

There is no intermediate level-four event. Consequently U,V are consecutive
stable events with opposite turns. If U=NL, V=SR is a distinct second west
departure, contradicting uniqueness. If U=SR, V=SL occurs after a south
arrival U. Hence **the level-three ER cannot be its first south departure**:
otherwise ordinal matching makes V the first south arrival, contradicting U.

At a missing cap, level two is empty. Level three has one east arrival and
zero north departures. Its only possible words are ER and ER,WL. Its ER
is the first south departure in both. The preceding square excludes both.
Therefore the missing cap is impossible.

At a guard cap, level three has one east arrival and one north departure.
Its port counts are ER=WR=1, EL=0, and WL=2-a, where `a=omega_3`.
Its ER-first orders are excluded by the same square. Thus

```
3: WR,WL,ER,[WL]^(1-a).
```

The ER is its second south departure. Since U cannot be NL, it is SR,
immediately followed by the second south arrival SL. There is only one west
departure on level four, so NL=0. Its first south arrival is U=SR. No event
can precede this SR: a preceding L would be an earlier SL, while a preceding
NR alone would violate alternation. All remaining ports alternate NR,SL.
Writing `b=omega_4` gives the complete guard form

```
4: SR,SL,(NR,SL)^(1-a),[NR]^b.
```

The upper statements follow by the orientation-preserving physical half-turn
`(x,y)->(-x,-y)`. It swaps E/W and N/S, preserves R/L, and swaps the extrema.
In particular an upper guard begins

```
0: SR;  1: ER;  2: SR;
3: ER,EL,WR,[EL]^(1-a);
4: NR,NL,(SR,NL)^(1-a),[SR]^b.
```

This use of a half-turn is not a reflection and does not exchange R with L.
The missing-cap proof uses zero voltage only, so reversing the drift by this
half-turn adds no chronology assumption.

## 4. Lower-guard exclusion at every period

This argument needs positive drift (1,3), not its reversed drift. Let
`a=omega_3`, `b=omega_4`, `c=omega_5`, and retain the lower guard forms
from section 3. Put

```
v=tau(3:WR), w=tau(first 3:WL), so w>v.
```

The four-step physical return from the first 3:WL to 3:ER gives

```
tau(3:ER)=w+4,
tau(4:SR)=w+1, tau(first 4:SL)=w+5.
```

The unique east arrival on level five comes from 3:WR -> 2:NR -> 5:E1.
Its lifted time is `v+2-N`. Every north departure on level five feeds
a 4:NR that follows the first 4:SL, so its time exceeds `w+4`.
For every positive N,

```
v+2-N < w+4 < time of every north departure on level five.
```

Thus E1 cannot be EL, and no WR can precede it. The row starts ER and
has EL=0. Its north-departure count is `d=1-a+b`, giving the entire row

```
5: ER,(WL,WR)^d,[WL]^(1-c).
```

Let D1 be the first west departure on level six. It feeds 3:WR, so

```
D1 -> 3:WR -> 2:NR -> 5:ER -> 6:V
                 W,N,E,S
```

is a four-step physical first return. Since 5:ER is the first south
departure, V is the first south arrival on six. If D1=SR, it would be
an earlier south arrival. Consequently D1=NL and V=SR is the second
west departure D2. They are consecutive stable events. As there is no
earlier south arrival and D1 is the first west departure, all ports
before D1 are NR; alternation makes exactly one such event possible.
We have forced

```
6 begins NR,NL,SR.
```

Let U be the second north departure on level seven; it feeds the second
north arrival on six, which is D1=NL. Its exact successors are

```
U -> 6:NL -> 3:WR -> 2:NR -> 5:ER -> 6:SR
  -> first 3:WL -> 4:SR -> 1:WR -> 0:NR -> 3:ER
  -> first 4:SL -> first 7:E arrival E1.
```

The direction word is `NWNESWSWNESE`. Its displacement is zero, and
every intermediate level is below seven. Thus U,E1 are consecutive
stable events. U cannot be EL because E1 is the first east arrival.
Therefore U=WR and E1=EL. Since U is the second north departure and
E1 immediately follows it, E1 is the third north departure on seven.

Now there is the eight-step first return

```
D2=6:SR -> first 3:WL -> 4:SR -> 1:WR -> 0:NR
        -> 3:ER -> first 4:SL -> 7:E1=EL -> third 6:N arrival,
```

with direction word `WSWNESEN`. There is no intermediate level-six
event. Its endpoint must be the next stable event after D2, hence it
is NL. Thus six begins `NR,NL,SR,NL`, with a third west departure.
If a=1, level three has only two west arrivals, so this is impossible.

If a=0, this third west departure feeds the second 3:WL, which feeds
the second 4:SL. Level four is

```
SR,SL,NR,SL,[NR]^b.
```

Its first SL, its NR, and its second SL supply, in order, the first
three east arrivals E1,E2,E3 on seven. But the forced four-step path

```
7:E1=EL -> 6:third west departure NL -> second 3:WL
        -> second 4:SL -> 7:E3
```

has direction word `NWSE`, displacement zero, and no intermediate
level-seven event. It makes E1,E3 consecutive stable visits while
E2 must lie strictly between them. This is a contradiction.

All values of a,b,c and every later wake choice are covered. Only the
clock inequality in the first paragraph uses N, and it uses just N>0.
No growth-eight residue condition, period congruence, width bound, or
lifetime bound is needed. Therefore **a finite-support periodic highway
with drift (1,3) cannot have a lower guard cap at any growth**.

This proof does not transfer to the upper guard: after a half-turn the
clock term `v+2-N` becomes `v+2+N`. The missing proof and the five-row
guard normal form are independent of that sign and do transfer.

## 5. Two lower (1,2,3) third-level words are impossible

Here levels one and two are respectively `WR,WL` and `NR,SL,NR`.
Write `u=tau(1:WR)`, `w=tau(1:WL)`, so `w>u`. The middle event
on level two has time `w+1`. The unique east arrival on level three,
fed by `1:WR -> 0:NR -> 3:E`, has time `u+2-N`.

Aggregate flow and alternation give a short word `WR,EL`, possible only
when `omega_3=0`, or the long words

```
k=0: ER,WL,WR,WL,WR,[WL]^(1-omega_3);
k=1: WR,WL,ER,WL,WR,[WL]^(1-omega_3);
k=2: WR,WL,WR,WL,ER,[WL]^(1-omega_3).
```

In the short word, the EL is the second north departure on level three.
It feeds the last NR on level two at time `u+3-N`. Stable order on
level two requires `u+3-N>w+1`. Since lifted times are integers,
`w>=u+1` and `u+3-N>=w+2`, so `N<=u+1-w<=0`, a contradiction.

In the `k=2` long word, the two WR events feed the first and last NR
on level two. The time `z` of its second WR therefore satisfies `z>w`.
The ER follows this WR, so `u+2-N>z`. But `u<w<z` implies
`z>=u+2`, again contradicting `N>0`. This covers both wake bits.

These arguments use only three levels, exact lifted times, and strict
stable order. They use no growth budget, period congruence, or bound
on width or lifetimes. Section 7 supplies a complete finite-domain exclusion
of `k=0` and restricts the level-four continuation of `k=1`; the opening
update links the later hand proof of the `k=0` exclusion.

## 6. Lower (1,2,2) rigidity

The separate all-period hand proof, also regressed by a complete
finite-domain check, shows that every lower (1,2,2) cap has

```
0: NR;
1: WR,WL;
2: NR,SL;
3: WR,WL,ER,WL;
4: SR,SL,SR;
5: ER,WL,ER,[WL]^(1-c);
6: NR,NL,SR,NL,(NR,SL)^(3-c),[NR]^e;
7: WR,WL,WR,EL,(WR,WL)^(3-c+e-f),[WR]^f,
```

where `c=omega_5`, `e=omega_6`, and `f=omega_7` are arbitrary bits.
In particular `omega_3=0` and `omega_4=1` are necessary at every
width and period, independently of growth eight. The hand proof in
`positive_skew_lower_thin_hand_rigidity_2026-10-01.md` establishes
completeness by physical returns, exact counts and two inequalities
using N>0 in the lower lifted clock. The original computational
certificate below remains an independent regression of the same
eight necessary partial templates. They are not highways.

For an odd level t, let A be the number of east departures at t-3 and
D the number of north arrivals at t-1. With E=the EL count, every
possible count vector is

```
ER=A-E, EL=E, WR=D-E, WL=A+D-3E-omega_t,
0<=E<=min(A,D), all counts nonnegative.
```

For an even level t, let B be the number of south departures at t-1
and C the number of west arrivals at t-3. With S=the SR count,

```
SR=S, SL=B-S, NL=C-S, NR=omega_t+B+C-3S,
0<=S<=min(B,C), all counts nonnegative.
```

These bounds are consequences of flow, not imposed visit cutoffs.
Starting at the fixed cap, induction therefore generates a finite complete
domain at each of levels three through seven. Enumerate every R-first
alternating word of each count multiset. Match directed ports by ordinal.
Reject only a witnessed physical first return with a wrong next event, or
an unsatisfiable system consisting of `N>0`, strict row order, and
`tau(target)=tau(source)+1-N*voltage`. Physical tracing truncation, if
reached, keeps a candidate; it never rejects one. There is no P22 condition,
eight-wake budget, event-count bound, period congruence, or imposed four-step
gap in this checker.

The complete survivor counts at levels 3--7 are `4,14,15,48,8`.
At level seven all 131,648 raw alternating words are exhausted:
131,640 fail a finite physical first return and precisely the displayed
eight prefixes survive. Separate adjacency and raw implementations agree.

## 7. The lower (1,2,3) cap has only three initial bands

After the hand timing exclusions, every row-three/four pair belongs to
the `k=0` or `k=1` long words. Exact counts, alternation and the physical
square in section 3 give four `k=0` pairs and eighteen `k=1` pairs.
Their complete count domains contain no unbounded free parameter.

For each pair, build levels five through seven from the complete count
equations in section 6. A word generator may impose the following proved
necessary condition before emitting a word: if a departure from the new
row traverses assigned older rows and first returns to the **same physical
cell**, the returned directed-arrival ordinal must be the next stable event.
The condition is imposed only when the accumulated physical copy voltage
is zero. Other quotient returns impose no next-event constraint. All
remaining raw R-first alternating words are emitted, and each receives a
physical first-return test and an exact integer clock with only `N>=1`
and strict stable order.

The separate implementation
`work_positive_skew_caps_20260930/verify_fat123_rigidity_csp.py` imports no
frontier code, computes the constraints by tracing physical coordinates,
and has no resource cutoff. Its complete stages are:

| Branch | Starting pairs | Level-five survivors | Level-six survivors | Level-seven survivors |
|---|---:|---:|---:|---:|
| k=0, ER first | 4 | 33 | 122 | 0 |
| k=1, ER between WR events | 18 | 26 | 212 | 41 |

The terminal `k=0` domain represents 14,347,143 raw alternating words;
6,292 meet the necessary next-visit constraints, and every one has an
explicit wrong physical first return. The terminal `k=1` domain represents
19,602,774 raw words; 3,160 meet those constraints, 3,055 fail physical
returns, 64 fail exact integer clocks, and 41 survive. Every emitted
rejection, all parent/count domains, and every clock SMT input are retained.
The independent implementation was freshly rerun successfully and agrees
with the separate frontier. Its generator was checked to use only the
necessary zero-copy adjacency implication just stated.

Thus the first five levels of a lower (1,2,3) cap are exactly one of:

```
common 0: NR; 1: WR,WL; 2: NR,SL,NR;

A: 3: WR,WL,ER,WL,WR,WL; 4: SR,SL,SR,SL;
B: 3: WR,WL,ER,WL,WR,WL; 4: SR,SL,SR,SL,NR;
C: 3: WR,WL,ER,WL,WR;    4: SR,SL,SR.
```

The local theorem uses no P22 condition, growth budget, period congruence,
width cutoff, event-count bound, four-step gap, or lifetime bound.
The finite-domain certificate for k=0 here is computer-assisted; the later
hand proof is linked in the opening update. The middle k=1 branch's
three row-four bands also have a separate hand proof in
`positive_skew_fat123_middle_hand_rigidity_2026-09-30.md`. It excludes
the one-SR forms by physical first returns and exact timing, and the
remaining unwanted two-SR form by `tau(1:WL)=tau(last 3:WL)+2+N`.
Its walks and timing were independently audited. Necessary partial
continuations survive in all three bands; none is declared a highway.

## 8. Verification and remaining scope

Run from the project root:

```
python code/python/verify_positive_skew_cap_reduction.py
```

The verifier constructs headings and edge targets geometrically, uses a
separate R/L multiset-interleaving generator, and solves integer clocks
with Z3. It imports none of the exploratory frontier code. It checks
missing, lower guard, and lower (1,2,2) domains from their fixed first
three rows, and compares the last thin domain with the displayed templates.
The saved result is
`results/positive_skew_cap_reduction_missing_guard_thin_audit.json`.

The missing frontier has survivor counts `2,0` at levels three and four;
the guard has `4,4,8,33,0` at levels three through seven. Its terminal
row exhausts 25,254 raw words, all with wrong physical first returns.
The hand proofs in sections 3--5 do not depend on this computational
regression. The later hand proof of thin rigidity linked in section 6 also
justifies that result independently of this computational regression.

The upper guard cannot be excluded by reversing the lower clock sign.
With reversed voltage, a relaxed exact frontier still has 212 necessary
upper-guard prefixes through inward offset seven. Both lower fat caps
also retain continuations. Thus the remaining cap pairs are lower
`(1,2,2)` or `(1,2,3)` against upper guard, `(1,2,2)`, or `(1,2,3)`.
There is no whole-orbit exclusion, upper bound on width, or valid highway
construction in these results.

## 9. Band C cannot meet an upper guard at growth eight

Now impose the eight-wake budget. Band C forces wakes `0,2,3,4`; an upper
guard forces `W-2,W-1,W`. A growth-eight trace has eight distinct wake
classes, and the primitive drift `(1,3)` has exactly one translation class
at each integer transverse level. Since lower level one is quiet, the
strip has at least nine levels, so `W>=8`. Therefore `W-2>=6>4`, and
the fixed lower and upper bands are disjoint.
There is just one other wake, strictly between level four and `W-2`.

Use fibre label `j=-t mod3` and checker sign `(-1)^t`. If `W=0 mod6`,
fibre one already has the opposite-sign pair `2,W-1`. If `W=2 mod6`,
fibre two already has the opposite-sign pair `4,W-1`. Each would need
two extra wakes to obtain signed sum `2 mod4`; only one wake remains.
Both width residues are impossible by P22.

If `W=4 mod6`, the seven fixed wakes in increasing order have fibre word

```
0,1,0,2,1,0,2.
```

Fibre zero has signed sum -1, while the other two fibres have signed sum
2. P22 forces the remaining wake into fibre zero with negative sign.
The rank sign equals the number of increasing-fibre pairs in the ordered
wake word: for distinct fibres `i<j`, `n_i<n_j` is equivalent to
`3n_i-i<3n_j-j`, including when n values tie. The fixed word has eleven
such pairs, so odd rank. Inserting the remaining fibre-zero wake between
the lower and upper bands adds two increasing pairs, one with each later
upper fibre-one/two endpoint, and no earlier smaller-fibre pair. Rank
therefore stays odd, contradicting the necessary even rank.

This exhausts all even W. **The lower (1,2,3) band C / upper-guard cap
pair is excluded at every width and period at growth eight.** The proof
uses P22, rank and the already proved local band; it needs no moment
condition or bounded coordinate enumeration. Bands A and B with an upper
guard, and all three bands with a fat upper cap, remain unresolved.

## 10. Two further all-width cap exclusions

Use the independently proved `W>=18` from
`positive_skew_width16_exclusion_2026-09-30.md`, so all cap wake bands
used below are disjoint. All residual wakes lie between their fixed bands.

### Band C forces an upper (1,2,3) offset three to be quiet

Suppose upper offsets zero, two and three are wake. Together with lower
`0,2,3,4`, there are seven fixed wakes and just one residual wake.
For `W=0 mod6`, fibre zero already has four wakes with two positive and
two negative signs. Its signed sum zero cannot be repaired with the single
residual wake. For `W=2 mod6`, all three fibre sizes are odd (`3,3,1`),
so one residual wake cannot make them all even. For `W=4 mod6`, fibre
zero contains the opposite-sign lower pair `0,3`, requiring two extra
wakes for P22, while only one remains. Every even width is impossible.

Thus lower band C cannot meet an upper (1,2,3) cap with wake offset three.
The upper third level must be non-wake; this does not exclude that upper
cap when offset three is quiet.

### Band B excludes upper quiet-three, wake-four (1,2,3) caps

Lower band B has wakes `0,2,4` and quiet levels one and three. Suppose
an upper (1,2,3) cap has quiet offset three and wake offset four. Its
outer wakes are exactly `W-4,W-2,W`, with offsets one and three quiet.
The six fixed wakes contain two positive-sign wakes in each fibre, for
every even W. P22 therefore forces the remaining two wakes into one
common fibre, with opposite signs: they are a `3+1` split in the unique
four-class fibre. Both are strictly between the two fixed bands.

The lower fixed fibre word is `0,1,2`. The upper word is respectively
`1,2,0`, `2,0,1`, or `0,1,2` as `W=0,2,4 mod6`. The combined rank
has respectively seven, seven, or nine increasing-fibre pairs, all odd.
The two residual wakes have the same fibre label. Their cross terms
with every fixed wake cancel in parity because both lie in the same
interval between the bands; their mutual same-fibre term is zero.
They cannot change the odd rank. This contradicts the necessary even rank.

Hence the lower band B / upper (1,2,3) quiet-three, wake-four subfamily
is excluded at every width and period. Other upper schedules remain open.

The complete modulo-twelve regression

```
python work_positive_skew_root_20260930/verify_new_cap_rank_exclusions.py
```

checks 72 residue templates for each band-C exclusion and 864 for the
band-B exclusion, using the original longitudinal-rank definition. All
fail P22 or even rank. These are exhaustive unbounded residue shadows,
not a coordinate search: signs depend on residues, and the rank depends
on ordered fibre labels. The hand proofs above provide the exclusion.

## 11. Remaining cap families and subsequent restrictions

At growth eight, band C also has quiet levels five and seven. Either wake
would create a second fibre with opposite-sign fixed endpoints, forcing
two four-class fibres plus a third fibre of at least two classes, exceeding
the eight-wake budget. Level six may still be wake or quiet.

| Lower cap band | Remaining upper possibilities |
|---|---|
| thin (1,2,2) | G; (1,2,2); (1,2,3), with further wake restrictions; lower bits111 is excluded, F122 wakes {0,6} through eight are excluded for bits101/110, and F123 quiet3/4,wake5 is excluded for bits110 |
| (1,2,3) A | G; (1,2,2); (1,2,3) |
| (1,2,3) B | G; (1,2,2); (1,2,3) except quiet-three/wake-four |
| (1,2,3) C | (1,2,2) with quiet offsets three/five/seven and wake eight whenever four is quiet; (1,2,3) with extra upper wakes through nine only {}, {4}, {4,8}, {7} |

The necessary lower wake patterns through seven and upper wake patterns
through inward offset seven admit a complete arithmetic parametrization
by an ordered finite residue word plus arbitrary nonnegative twelve-step
gaps. The separate implementation
`work_positive_skew_root_20260930/classify_two_cap_wake_prefixes.py` checks
all nineteen lower and forty-one upper wake patterns retained by the
complete exact frontiers. Its dynamic program counts every compatible
bulk residue word; every accepted state has an explicit unbounded wake
realization independently checked by the original P22, moment and rank
formulas. The data are `two_cap_wake_prefix_classification.json` beside
the source. This parametrization does not preserve physical visit words
or assert realizability.

All remaining rows of the table have unbounded arithmetic survivors and
necessary local turn continuations. Closing the whole orbit still requires
an obstruction using their full coupled chronological histories, or an
actual finite-support highway construction. No finite-depth survivor count
or arithmetic template is a whole-orbit closure.

The later [generic upper-F123 wake-five exclusion](positive_skew_upper_fat_quiet34_wake5_exclusion_2026-10-01.md)
requires wake six or seven whenever three/four are quiet and five wakes.
At growth eight the lower-thin110 endpoint arithmetic forces both six and
seven quiet, closing that entire all-width cap family. The original
41-pattern arithmetic snapshot remains historical; a separate verified
filter removes this pattern and the two earlier generic F122 patterns.

The [upper-F122 wakes-three/four lemma](positive_skew_upper_thin_wake34_quiet567_exclusion_2026-10-02.md)
also excludes quiet offsets five/six/seven, for both choices at eight/nine
and every growth. Hence a wake at three and four requires a wake among
five/six/seven. This closes lower-thin110 against that upper cap family
at growth eight. The exact remaining-thin/F122 residue package now has
5,114 templates, and the global depth-seven strong upper domain has
14,399 necessary prefixes after four proved generic pattern exclusions.
The current filtered snapshots are dated 2 October; the original
41-pattern parametrization remains a historical necessary domain.
None of these numbers counts trajectories or measures orbit completion.

Lower-thin101 is additionally excluded at width eighteen by a
[complete independently audited join](positive_skew_thin101_width18_exclusion_2026-10-02.md).
The member remains open at arbitrary width.

The [3 October quiet-bridge continuation](positive_skew_quiet_bridge_chronology_2026-10-03.md)
adds a bit-ten-uniform hand restriction for the thin101 row-eight
`SR SL` branch and excludes the whole width-24 saturated
thin101/upper-F123 wakes-seven/eight cap family by an independently
checked join through lower row twelve. Its particular aggregate count pump is
physically impossible, while other quiet bridges remain open. The
thin110/F122 wakes-four/seven upper frontier is complete and independently
checked through twelve, with 2,076 necessary survivors under the shared
period floor. Proved translated-order and single-new-visit return guards
reduce its search domain without losing a survivor. Deeper stages are
incomplete, and the full orbit remains open.

The [4 October complete width-22 join](positive_skew_thin011_width22_exclusion_2026-10-04.md)
also excludes lower-thin011 / upper-F123 wake six at width 22. It covers
all count and word domains, with exact full-count periods 210, 226, or
242 and no arbitrary count or period ceiling. Independent full coverage,
geometry, word-existence, and clock audits have passed and are bound to
the saved sources. This cap family's remaining possible widths start at
28; the arbitrary-width family and full orbit remain open.

An independently checked [strong quiet-fourteen lookahead](positive_skew_upper47_strong_lookahead_2026-10-04.md)
also excludes two explicitly displayed upper-row-twelve prefixes of the
thin110 / upper-F122 wakes-four/seven family at every family width.
Their 28 and 36 necessary row-thirteen extensions are all rejected:
21 and 27 by complete zero-copy word domains, and the remaining seven
and nine by independently reconstructed strong physical/order domains.
These are prefix exclusions; the rest of the cap family and the orbit
remain open.

## 12. Band C with an upper (1,2,3) cap has quiet lower level eight

Suppose lower level eight were wake. Lower wakes `0,2,3,4,8` and upper
`W-2,W` would leave exactly one residual wake t. All of these fixed
positions are distinct by `W>=18`. P22 excludes `W=2 mod6`, where all
three fixed fibre sizes are odd, and `W=4 mod6`, where the mixed-sign
lower fibre-zero pair requires two extra wakes.

For `W=0 mod6`, P22 forces t into fibre zero with positive sign, so
`t=6q`, q>=1. The seven fixed wakes have ordered fibre word
`0,1,0,2,1,2,0`, of even rank (ten increasing pairs). If `t>8`, the
residual fibre-zero wake adds one increasing pair with the later upper
fibre-two wake, making rank odd. Thus t must lie between levels four
and eight, leaving only `t=6`.

The complete moment at that sole placement is

```
sum_O (-1)^t ceil(t/3) = 4m+7 = 3 mod4,  W=6m,
```

contradicting the required moment one. Therefore every remaining lower
band-C / upper (1,2,3) candidate has quiet lower level eight. This
eliminates all 118 wake-eight local band-C prefixes among the 225 complete
lower continuations through eight; 107 quiet-eight prefixes remain.
The implication is conditional on this upper cap, and does not exclude
the wake-eight branch when the upper cap is (1,2,2).

`work_positive_skew_root_20260930/verify_fatC_upperF123_quiet8.py` checks
every modulo-twelve residual case, separately before and after the fixed
level-eight wake, using the original P22, rank and moment definitions.
Its fresh complete regression passes. The hand argument, rather than a
bounded coordinate test, proves the lemma.

