# Width-18 fat placement A is excluded for lower fat `(0,1,111)`

24 September 2026. At drift `(1,-3)`, consider the lower `(1,2,3)` band
with `omega_3=0`, `omega_4=1`, and `(j,k,l)=(1,1,1)`. The endpoint
P22, odd-skew moment, and rank conditions permit the width-18 upper-fat
wake placement

```text
O={0,2,4,6,8,15,16,18}.
```

This placement is impossible by a count on the common center row `t=9`.
The complete lower stable-word frontier through level eight has 82 prefixes.
Their level-eight rows have **11 or 15 north departures**, which must feed
the same number of north arrivals on level nine. From the upper fat cap, the
inward wake offsets are `{0,2,3,10,12,14,16,18}`. The complete upper
frontier through inward offset nine has exactly one prefix. Its center word is

```text
NR,SL,NR,SL,NR,NL,NR,NL,NR,SL.
```

After rotating headings back by 180 degrees, this word has **three north
arrivals**. Since the center row is the same physical quotient row from
both caps, its north-arrival count cannot be both 3 and 11 or 15.

The checker `code/python/verify_lower_fat123_a0_b1_111_width18_a.py`
reproduces both complete frontiers and saves
`results/lower_fat123_a0_b1_111_width18_a_checks_2026-09-23.json`.
It derives row counts from directional flow and excess, enumerates the
alternating words subject to finite boundary-return adjacency, rejects
only witnessed wrong first returns, and checks exact integer clock
feasibility with `N=6 (mod 8)` and no upper bound. The result excludes
this wake placement, not all width-18 placements or the full drift orbit.
