# Every missing cap has a wake at offset six; family M-II is impossible

23 September 2026

## Lemma

At drift `(1,-3)`, every missing cap, lower or upper, has a wake at inward
offset six.

Measure inward offsets from the cap. At the upper cap, rotate all headings by
180 degrees. The cap rows are `0: WR`, `1: NR`, `2:` empty. Take offset six
non-wake and let every other offset have either parity. Every row from offset
three on is enumerated from the flow and excess equations and right/left
alternation. A word is discarded only in three cases:

- a zero-displacement return is violated while the word is built;
- a witnessed finite same-cell first return lands on the wrong event (no
  quotient-cycle extrapolation);
- the lifted clock is infeasible:

```text
tau(target) = tau(source) + 1 + SIGN*N*lambda,   N >= 6,   same-cell gaps >= 4,
SIGN = -1 at the lower cap, +1 at the upper cap.
```

| Cap | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| lower missing | 2 | 1 | 2 | 3 | 8 | 4 | 14 | **0** | | |
| upper missing | 2 | 1 | 2 | 3 | 8 | 6 | 23 | 21 | 88 | **0** |

Rows up to offset twelve exist in any candidate or are enumerated as empty
words, so the lemma holds at every period and every width. No P22, rank or
moment condition is used, and no bound on the period, width or row length.
`code/python/verify_missing_cap_offset6_lemma.py` (Z3 clock) reproduces both
rows and writes `results/missing_cap_offset6_checks_2026-09-23.json`.
`code/java/StableWordFrontier.java`, which uses an exact parametric clock,
gives the same counts. A split by the parities of offsets five, seven and eight
kills every branch at or before the same offsets.

The lemma strengthens two earlier results:

- the lower-missing bound `omega_6+omega_7>=1`
  (`odd_skew_excursions_and_domino_transfer_2026-08-31.md`);
- the rule that offset five is non-wake when offsets six and seven are
  (`odd_skew_guard_missing_families_2026-09-03.md`).

It also implies the quiet-cap lemma of
`odd_skew_upper_missing_quiet_band_2026-09-23.md`.

## Consequences

**Family M-II is impossible.** A lower missing cap with an upper `(1,2,3)` cap
has wake set in family M-I or M-II
(`lower_missing_upper_fat123_wake_families_2026-09-22.md`). M-II has wake set
`{0,1,4,7,6k+2,6j+1,6m,6m+2}`, which leaves level six non-wake. Hence only M-I
remains: `W=6m+4`, `{0,1,4,6,6i+4,6k+2,6m+2,6m+4}`, `1<=i<k<=m-1`, `i+k` odd.

**Upper missing caps.** An upper missing cap needs upper offset six to be wake.
This gives a second proof that the lower band `(0,1,1,1,1)` has no upper missing
cap: its forced upper schedule leaves offset six non-wake. For the lower band
`(0,0,1,1,1)` with an upper missing cap, the only schedules through offset
fourteen that survive are `{0,1,4,6}` and `{0,1,4,6,10}`. The other sixteen
listed schedules die by offset twelve in explicit upper-cap runs.

Missing caps pair only with the open lower `(1,2,3)` bands `(0,*,1,1,1)` as
upper caps, or with an upper `(1,2,3)` cap as the lower cap. The lemma adds no
further exclusion there. The `(1,-3)` orbit remains open.
