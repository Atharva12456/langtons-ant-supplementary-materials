# A lower wake at four cannot be followed by non-wakes at five and six

For a lower `(1,2,2)` cap in the `(1,-3)` orbit, the pattern

```text
(omega_4,omega_5,omega_6)=(1,0,0)
```

is impossible at every period. The proof uses exact returns through
level eleven and lifted-time order, with no hypotheses on later
wake indicators. Together with the preceding lower-cap results,
it shows that every lower `(1,2,2)` cap has a wake at level six.
The remaining three lower bands are not excluded here.

## Fixed rows and notation

The lower-band and level-seven normal forms give

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,WR
5: SR,SL,NR,NL,NR,SL,NR,SL
6: ER,EL,ER,WL,WR,WL.
```

Write `f=omega_7`. There are two possible level-seven words:

```text
P: SR,SL,SR,NL,SR,SL,NR,SL,SR,[SL]^(1-f);
Q: SR,SL,SR,NL,SR,SL,SR,SL,NR,[SL]^(1-f).
```

Let `W1,...,W5` be their west departures. Their turns are
`SR,SR,NL,SR,SR`. Label the six east arrivals on level eight by
`E1,...,E6`, supplied by `5:SL1,NR1,NR2,SL2,NR3,SL3`.
The return from `W4` already forces `E3=ER`, the fifth south
departure on level eight.

There are three west departures `D1,D2,D3` on level nine, feeding
the west arrivals `WL,WR,WL` on level six. Label the east arrivals
on level ten as `Fi`. The three-step path from `D2` through
`6:WR,7:NR` ends at `F3` for P and at `F4` for Q.

Whenever a forced first same-cell return joins stable events, the
endpoints are consecutive and have opposite turns. Edge matching
preserves order. A path of length six and displacement `(1,-3)`
gives a stable-time difference `6-N`, which cannot join a class
event to a later stable event since `N>=6`.

## Word P: the last west departure precedes the last south arrival

Suppose first that `E5=EL`. The four-step return through `W5`
forces the consecutive pair `E4=ER,E5=EL`. The path

```text
D1 -> 6:first WL -> 5:SL2 -> E4=ER -> 7:W5=SR
   -> 4:last WR -> 5:last NR -> E5=EL -> north arrival on 9
```

is an eight-step first same-cell return. Its source cannot be
`NL`. If it were, its incoming predecessor `X` on level eight
would be the north departure immediately preceding `E5`, and

```text
8:X -> 9:D1=NL -> 6:first WL -> 5:SL2 -> 8:E4=ER
```

would force `X=EL` to be the preceding east arrival `E3`, contrary
to `E3=ER`. Hence `D1=SR`, followed immediately by `NL=D2`.

If `F3=EL`, the south predecessor of `D1` on level ten has a
twelve-step first return, following the eight-step return to
`D2` and its three-step path to `F3`. Its source is the preceding
east arrival `F2=ER`, supplied by the `SL` after `7:W4`.
This forces

```text
8:E3=ER -> 7:SL2 -> 10:F2=ER -> 9:D1=SR
        -> 6:first WL -> 5:SL2 -> 8:E4=ER.
```

The direction word is `SESWSE`, so it contradicts `E3<E4` in
stable order. Thus `F3=ER`.

Its south step completes a four-step return from `D2=NL` to a
new `SR`, necessarily `D3`. If `E6=EL`, the four-step return
from `D3` through `6:last WL,5:last SL,E6` would end at another
`NL`, a fourth west departure on level nine. Therefore `E6=ER`.

Since `E4=ER` feeds `W5`, the later south departure `E6=ER` must
feed a following `SL`. This forces `f=0`. That last `SL` on
level seven supplies `F5`, and the now forced path

```text
10:F3=ER -> 9:D3=SR -> 6:last WL -> 5:last SL
         -> 8:E6=ER -> 7:last SL -> 10:F5
```

has length six and displacement `(1,-3)`. It contradicts `F3<F5`.
Thus `E5=EL` is impossible in P.

It remains to take `E5=ER`. Its south step returns from the last
right turn `W5=SR` to a following `SL`, forcing `f=0`. Thus `E5`
is the last south departure on level eight. The later east arrival
is necessarily `E6=EL`, immediately following `E5`: any intervening
left turn would be another east arrival or another south departure.

The four-step return from `D3` through `6:last WL,5:last SL,E6`
forces `D3=NL`, since an `SR` source would create a further west
departure at its `NL` target. Its incoming predecessor on level
eight must then be `WR`, immediately preceding `E6=EL` in stable
order. That event is instead `E5=ER`. This excludes P.

## Word Q: the remaining north arrival comes last

In Q, `W5` is the sixth south arrival on level seven, whereas
`E3=ER` is the fifth south departure on level eight. If `E5=EL`,
its return through `W5` would force `E4=ER` as the sixth south
departure. But alternation between the consecutive east arrivals
`E3=ER,E4=ER` requires an intervening `WL`, inserting another
south departure between ordinals five and six. Hence `E5=ER`.

Its south step feeds the `SL` immediately after `W5`, so `E5` is
the seventh south departure. The sixth departure is a `WL`, denoted
`J`, immediately followed by `E5` in stable order. As in the
adjacent-wake exclusion, these south ordinals force `E4=EL` and
the consecutive pair `E3=ER,E4=EL`.

The four-step return from `D1` through
`6:first WL,5:SL2,E4=EL` rules out `D1=NL`: its incoming north
predecessor on level eight would have to be the immediately
preceding `WR`, but the preceding stable event is `E3=ER`.
Thus `D1=SR`, with consecutive target `NL=D2`.

If `F4=ER`, its south step would return from `D2=NL` to
`D3=SR`. The last-west-departure argument would then force
`E6=ER`. But `E5` is already the seventh south departure, and
Q has at most eight south arrivals. Alternation between the
consecutive east arrivals `E5=ER,E6=ER` would insert a `WL`,
putting `E6` at ordinal at least nine. Therefore `F4=EL`.

The eight-step first return from the south predecessor of `D1`
through `D2` to `F4` consequently forces the consecutive pair

```text
F3=ER,F4=EL.
```

Here `F3` is supplied by the `SL` immediately after `W5`, hence
by the south departure `E5=ER` on level eight.

The same south-ordinal argument shows that `E6=ER` is impossible,
whether or not `F4` turns right. Hence `E6=EL`, and the four-step
return from `D3` through `6:last WL,5:last SL,E6` forces `D3=NL`.
Its incoming predecessor is `WR`, immediately preceding `E6`.

There must therefore be one more south departure after `E5` and
before `E6`; otherwise `E5=ER,E6=EL` would be consecutive. It
is the `WL` supplying the final `SL` after `7:NR`, so `f=0`.
Call it `K`. The tail on level eight is now fixed as

```text
E3=ER,E4=EL,X1=WR,J=WL,E5=ER,K=WL,X2=WR,E6=EL,[WR]^g,
g=omega_8.
```

## The last east arrival on level ten

The north departure `E4=EL` feeds `D2=NL`; the next north
departure `X1=WR` feeds an `NR`. The following one, `X2=WR`,
feeds `D3=NL`, whose consecutive target is the `NR` supplied by
`E6=EL`. There is no south arrival between these events: a left
south arrival would require another right turn before the next
specified north arrival, while all the remaining west departures
are already the two specified `NL` ports. Thus every south arrival
on level nine after `D1=SR` occurs after the north arrival from
`E6`.

The last east arrival `F5` on level ten is supplied by
`8:K -> 7:last SL`. Its time is

```text
tau(F5)=tau(K)+2-N < tau(E6).
```

If it turned right, it would feed a south arrival after `D1`,
which, by the preceding paragraph, is later than
`tau(E6)+1`. This is impossible. Hence `F5=EL`.

The same comparison puts every south departure on level ten
after `F3=ER` later than `F5`. Therefore there is no `WL`
between `F4=EL` and `F5=EL`; alternation gives the consecutive
block

```text
F4=EL,WR,F5=EL.                                       (1)
```

## Two adjacent west departures on level eleven

The level-eight west arrivals `J=WL,K=WL` are adjacent in west
arrival order. Their matching west departures on level eleven,
denoted `P1,P2`, are consequently adjacent. The first has the
sixteen-step first same-cell return

```text
P1 -> 8:J=WL -> 7:W5=SR -> 4:last WR -> 5:last NR
   -> 8:E5=ER -> 7:SL3 -> 10:F3=ER -> 9:D1=SR
   -> 6:first WL -> 5:SL2 -> 8:E4=EL -> 9:D2=NL
   -> 6:WR -> 7:NR -> 10:F4=EL -> north arrival on 11.
```

The second has the four-step first return

```text
P2 -> 8:K=WL -> 7:last SL -> 10:F5=EL
   -> north arrival on 11.
```

Write their north targets as `Na,Nb`. Block (1) gives `b=a+2`.
If `P1=SR`, its consecutive target `Na=NL` would be `P2`,
whose return would then have to end at `N(a+1)`. Therefore
`P1=NL=N(a-1)`.

Let `X` be its incoming predecessor on level ten. It is the north
departure immediately preceding `F4`. Since `F3=ER,F4=EL` are
consecutive stable events, `X` precedes `F3`. The first part of
the long return gives the eight-step first same-cell return

```text
10:X -> 11:P1=NL -> 8:J=WL -> 7:W5=SR -> 4:last WR
     -> 5:last NR -> 8:E5=ER -> 7:SL3 -> 10:F3=ER.
```

Its source must be `EL`, immediately preceding `F3`. Thus
`X=F2=EL`, supplied by the `SL` after `7:W4`, whose predecessor
is `8:E3=ER`. It follows that

```text
8:E3=ER -> 7:SL2 -> 10:F2=EL -> 11:P1=NL -> 8:J=WL
```

is a four-step first same-cell return. But `E4=EL,X1=WR` lie
strictly between `E3` and `J` in the forced level-eight tail.
This final skipped-visit contradiction excludes Q.

## Remaining lower bands

Both level-seven continuations are impossible, so `(1,0,0)` is
excluded. The pattern `(1,1,0)` was excluded in
`odd_skew_fat122_adjacent_wakes_force_six_2026-09-13.md`, and
`omega_4=0` already forces `(omega_5,omega_6)=(1,1)`.
Every lower `(1,2,2)` cap therefore has `omega_6=1`.

The remaining wake-indicator triples are

```text
(omega_4,omega_5,omega_6)=(0,1,1), (1,0,1), or (1,1,1).
```

This does not exclude these three bands or the other cap profiles
in the `(1,-3)` orbit. The lifted-time comparisons in the proof
are lower-cap comparisons and have not been transferred to the
upper orientation.
