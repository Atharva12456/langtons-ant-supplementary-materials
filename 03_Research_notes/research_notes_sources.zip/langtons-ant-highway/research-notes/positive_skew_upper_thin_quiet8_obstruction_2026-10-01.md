# Quiet offset eight closes the unsaturated lower-thin 111 family

Date: 2026-10-01. Original physical drift: exactly `(1,3)`.
Whole-orbit status remains **OPEN**.

## Local theorem, independent of growth eight

For a finite-support periodic clockwise Langton highway with drift `(1,3)`,
an upper `(1,2,2)` cap with quiet inward offsets three through seven must
have **wake offset eight**. This is a computer-assisted finite-domain
theorem with an independent raw-word checker. It has no width bound,
period upper bound, lifetime bound, P22 premise, wake budget, period
congruence, imposed four-step stable gap or lower bound on N by event count.

After an orientation-preserving half-turn, use lower-looking upper rows:

```
0: NR; 1: WR,WL; 2: NR,SL;
```

All stable words start R and alternate R,L. On representatives `(0,-s)`
with physical copy `(k,-s+3k)`, the correct upper lifted clock is

```
tau(target) = tau(source) + 1 + N*dx, N integer >=1,
```

and each row has strictly increasing integer lifted times. The sign is
**+N**, as appropriate to the reversed physical drift after this half-turn.
R and L are preserved. Edges match departures and arrivals by directed
ordinal, retaining the physical copy change dx. A zero-displacement
physical first return must reach the immediately next stable event.

## Complete small domain

`verify_allquiet_raw.py` starts at the three cap rows and assigns quiet
offsets three through eight. It imports no frontier code and uses no
adjacency pruning. For each new row, exact flow and alternation give all
nonnegative count vectors. With A east departures three rows earlier,
D north arrivals one row earlier, B south departures one row earlier,
and C west arrivals three rows earlier, the quiet-row equations are

```
odd:  ER=A-e, EL=e, WR=D-e, WL=A+D-3e;
even: SR=q, SL=B-q, NL=C-q, NR=B+C-3q.
```

The free parameters e and q are bounded by nonnegativity, not by imposed
visit cutoffs. A separate R/L multiset-interleaving generator emits every
raw R-first alternating word exactly once. Geometric headings determine
edge targets and copy changes. Every finite-return rejection is replayed
in physical coordinates, including absence of an intermediate physical
return. A finite trace limit only retains an extra candidate. For all
remaining candidates Z3 checks the exact integer clock with N>=1 and
strict row order; each of the six rejected clock inputs is retained and
freshly replayed as UNSAT. No resource cutoff is used.

The complete stages are:

| Assigned quiet offset | Parent prefixes | Count vectors | All raw words | Physical rejections | Clock rejections | Survivors |
|---|---:|---:|---:|---:|---:|---:|
| 3 | 1 | 1 | 2 | 0 | 0 | 2 |
| 4 | 2 | 4 | 38 | 34 | 1 | 3 |
| 5 | 3 | 6 | 57 | 52 | 0 | 5 |
| 6 | 5 | 15 | 230 | 214 | 5 | 11 |
| 7 | 11 | 42 | 4,748 | 4,743 | 0 | 5 |
| 8 | 5 | 20 | 2,370 | 2,370 | 0 | 0 |

Thus offsets three through seven have exactly five necessary prefixes,
even under the relaxed all-period clock. They coincide exactly with the
five `10000000` prefixes in the complete strong saved upper frontier.
The independent weak derivation, rather than that comparison, establishes
completeness here. Its 7,419 rejection certificates include all 7,413
finite physical-return failures and all six clock UNSAT inputs.

All five prefixes share `3:WR,WL,ER,WL`. Their rows four through seven are:

```
A:
4: NR,SL,NR,NL,SR,SL;
5: WR,WL,WR,EL,ER,WL;
6: NR,SL,NR,NL,SR,NL,NR,SL;
7: WR,WL,WR,EL,ER,WL,ER,WL,WR,EL.

B:
4: SR,SL,NR,NL,NR,SL;
5: WR,WL,ER,WL,WR,EL;
6: SR,SL,SR,NL;
7: ER,WL,ER,EL,ER,WL.

C:
4: SR,SL,NR,NL,NR,SL;
5: WR,WL,ER,WL,WR,EL;
6: SR,SL,NR,NL,NR,SL,NR,NL;
7: WR,WL,WR,EL,ER,WL,WR,EL,ER,WL.

D:
4: SR,SL,NR,NL,NR,SL;
5: WR,WL,ER,WL,WR,EL;
6: SR,SL,NR,NL,NR,SL,NR,NL;
7: WR,WL,WR,EL,WR,WL,ER,EL,ER,WL.

E:
4: SR,SL,NR,NL,NR,SL;
5: WR,WL,ER,WL,WR,EL;
6: SR,SL,NR,SL,NR,NL,NR,NL;
7: WR,WL,WR,WL,WR,EL,ER,EL,ER,WL.
```

Each has B=5 and C=4 at eight. Its entire quiet-eight count domain is

```
q=0: NR9,NL4,SL5;               126 raw words;
q=1: NR6,NL3,SR1,SL4;           245 raw words;
q=2: NR3,NL2,SR2,SL3;           100 raw words;
q=3: NL1,SR3,SL2;                 3 raw words.
```

These four domains contain 474 raw words per prefix and no free
unbounded parameter. Every one fails a replayed finite physical first
return. The longest recorded witness has twenty moves for A and twelve
for each other prefix. No clock solver is needed at offset eight.

The separate adjacency extension `extend_quiet.py --depth 10` closes at
eight too: twenty count vectors representing 2,370 raw words reduce to
eight emitted words, all failing physical returns. It visits only 506
adjacency recursion nodes. The raw check above provides independence from
that pruning implementation. Root independently used a third compass and
ordinal implementation and also rejected all 2,370 raw words by finite
physical returns.

## A further hand exclusion of prefix A

Prefix A itself cannot extend to offset eight, even if offset eight wakes.
Write D_i for west-departure ordinals on eight and S_i for south-arrival
ordinals there. There are exactly four west departures, supplied by the
four west arrivals on five.

First S1 cannot be SR. Otherwise the square

```
first 7:WL -> 8:S1=SR -> first 5:WR -> first 4:NR -> first 7:EL
                 S             W             N             E
```

is a physical first return to seven, skipping the next 7:WR. Hence S1=SL.

Tracing D1 through the fixed old rows gives a twenty-step physical first
return to S2, with word `WNENWNENWNESWSESWSES`. All intermediate rows are
at most seven. D1 cannot be SR because the only south arrival preceding
S2 is S1=SL. Therefore D1=NL and its immediate successor is S2=SR, which
is also D2.

The four-step D3 return has word `WNES`:

```
D3 -> second 5:WR -> second 4:NR -> third 7:E=ER -> S4.
```

If D3=NL, S4=SR is also D4. But then

```
second 5:WR -> second 4:NR -> third 7:E=ER -> S4=SR -> last 5:WL
                  N               E                S            W
```

is a physical first return to five, skipping the immediate next 5:EL.
Thus D3=SR. It must be S3, immediately followed by S4=SL. Now D2=S2=SR
and D3=S3=SR are consecutive in both the west-departure list and the
south-arrival list. Alternation requires an L event between these two R
events. Such an L is either NL, an intervening west departure, or SL, an
intervening south arrival. Both violate those consecutive ordinals.

This hand argument strengthens the treatment of A. The remaining four
prefixes are excluded by the small complete raw quiet-eight certificate
above; no all-five hand exclusion is claimed here.

## Consequence for the unsaturated lower-thin 111 family

The exact growth-eight endpoint family supplied by the arithmetic
classification is

```
W=6m+4;
wakes={0,4,5,6,7,6q-2,6p-1,W};
2<=q<=p<=m-1; m+p+q even.
```

It has an upper `(1,2,2)` cap. The two residual wakes have inward
distances

```
W-(6p-1)=6(m-p)+5 >=11,
W-(6q-2)=6(m-q)+6 >=12.
```

Since m>=3, the lower fixed wake closest to the upper cap has distance
`W-7=6m-3>=15`. Thus every inward offset from one through ten is quiet,
apart from the mandatory wake at offset zero. In particular offsets
three through seven and eight are quiet, contradicting the local theorem.

Therefore **the entire unsaturated `p<=m-1` lower-thin 111 / upper-F122
subfamily is excluded at every width and period**. Quiet nine and ten
need not be explored, and no quiet-eleven or quiet-twelve subbranch search
is needed. This note alone does not handle the saturated p=m family or
the other upper caps, and does not claim a whole-orbit exclusion.

## Reproduction and artifacts

Run from the repository root:

```
python -B work_positive_skew_unsaturated111_20261001/verify_allquiet_raw.py
python -B work_positive_skew_unsaturated111_20261001/extend_quiet.py --depth 10
```

The independent checker requires Python and `z3-solver`. It saves
`allquiet_raw_result.json` and `allquiet_raw_certificates.json` here. The
separate adjacency continuation saves `quiet10_strong.json` and
`quiet10_strong_certificates.json`; it explicitly records closure at eight,
the seed/source fingerprints, and complete-stage status. The latter
imports the established exploratory engines read-only. Both programs
write only in this work directory.  Local intermediate survivors are necessary
partial data, not highways. Whole-orbit status remains **OPEN**.


The canonical copy was integrated on 1 October 2026. The complete
[lower-thin111 exclusion](positive_skew_lower_thin_111_exclusion_2026-10-01.md)
combines these local results with all-width arithmetic; the whole orbit
remains open.
