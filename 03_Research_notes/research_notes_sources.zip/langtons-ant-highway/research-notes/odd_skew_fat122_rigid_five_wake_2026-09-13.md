# A wake at offset five forces the three-visit offset-six row

Later result (21 September 2026): [the upper fat-cap theorem](odd_skew_upper_fat122_exclusion_2026-09-21.md) excludes family A. Family B remains open. The local derivation and earlier family status below are retained.

At either `(1,2,2)` cap in the `(1,-3)` drift orbit, suppose inward
offset four is non-wake and offset five is wake. Then the stable word at
offset six is `ER,EL,ER`, in inward heading labels. In particular,

```text
wake offsets:      0,5,6,8,
non-wake offsets:  1,2,3,4,7.
```

The statement uses only zero-displacement returns and holds at either
cap, independently of growth and period. At growth eight it excludes
family C of `odd_skew_fat122_three_visit_wake_families_2026-09-13.md`.
It also shows that the hypotheses of that note exhaust the lower
`(1,2,2)` branch with `omega_4=0`: the lower early-wake theorem supplies
`omega_5=1`, and the present theorem supplies the three-visit row.

## The possible words at offset six

Use inward offsets, rotating heading labels by 180 degrees at the upper
cap. The previously proved `(1,2,2)` cap normal form is

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL
5 A: SR,SL,NR,NL,NR
  B: NR,SL,SR,NL,NR.
```

Put `e=omega_6`, and let `z` be the number of `ER` ports there. Flow
gives the complete count row

```text
(ER,EL,WR,WL)=(z,3-z,5+e-3z,2-z),       z=0,1,2.
```

The south predecessor of `5:SR` has the four-step same-cell return

```text
6:south departure -> 5:SR -> 2:WR -> 3:NR
                  -> second east arrival on 6.
```

Its endpoints are consecutive stable visits. For `z=0` they would
both turn left, so this row is impossible. For `z=2`, nonnegative
counts force `e=1` and the three-visit word `ER,EL,ER`. It remains to
exclude `z=1`.

If the second east arrival is `EL`, its source in this return is
`ER`, necessarily the first east arrival. For word A on offset five
this is the first south departure, so the pair is the initial
`ER,EL`. For word B it is the second south departure, giving the
prefix `WR,WL,ER,EL`.

If the second east arrival is `ER`, its source is `WL`, and the
first east arrival is `EL` before that consecutive pair. This requires
word A: the return step from this `ER` gives a south arrival after
`5:SR`, whereas in word B that `SR` is the last south arrival.

Placing the remaining ports in alternating slots now gives exactly
the following words, each followed by `[WR]^e`:

| Name | Offset five | Offset six |
|---|---|---|
| K1 | A | `ER,EL,WR,EL,WR,WL` |
| K2 | A | `ER,EL,WR,WL,WR,EL` |
| K3 | A | `WR,EL,WR,WL,ER,EL` |
| K4 | B | `WR,WL,ER,EL,WR,EL` |

## Adjacent west departures

Number the four west departures on offset seven as `W1,...,W4`.
They feed the west arrivals `WR,WL,WL,WR` on offset four. Let `Ni`
denote its north arrivals in stable order. Forced first same-cell
returns give

| Word | Return from W2 | Return from W3 |
|---|---|---|
| K1 | `W2 -> N1` | `W3 -> N3` |
| K2 | `W2 -> N1` | `W3 -> N4` |
| K3 | `W2 -> N2` | `W3 -> N4` |
| K4 | `W2 -> N2` | `W3 -> N4` |

The first path begins

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> first east arrival on 6.
```

For K3 this east arrival is `EL`, and its north step completes the
return in eight steps. In the other words it is `ER`; the path
continues through `5:SR,2:WR,3:NR` to the second east arrival `EL`,
then north, for a twelve-step return. The second return is always

```text
W3 -> 4:second WL -> 3:last SL -> 6:last EL -> north arrival on 7.
```

It has length four. The optional final `WR` on offset six changes
none of the displayed north ordinals.

Recall the adjacent-west ordinal test. If adjacent west departures
return to `Na,Nb` and the first is `SR`, its consecutive target
`Na=NL` is the second west departure. That departure must return to
the next north arrival, so `b=a+1`. If this equality fails, the first
west departure must instead be `NL=N(a-1)`. In particular, `a=1`
and `b!=2` are incompatible.

This immediately excludes K1 and K2. In K3 and K4 it gives
`W2=NL=N1`. For K4 the resulting eight-step return

```text
6:first WR -> 7:W2 -> 4:first WL -> 3:SR -> 0:WR
           -> 1:NR -> 4:ER -> 3:first SL -> 6:first ER
```

has two right-turn endpoints, with no intermediate offset-six visit.
Thus K4 is also impossible.

## The remaining word K3

For K3, suppose `W3=NL`. Its consecutive target `N4=NR` would make
it `N3`, fed by the second `WR` on offset six. The four-step return

```text
6:second WR -> 7:W3 -> 4:second WL -> 3:last SL -> 6:last EL
```

would then skip the intervening `WL,ER` in that stable word.
Therefore `W3=SR` and its consecutive target is `N4=NL=W4`.
Since `W2` is the first north arrival, `W1=SR`.

There are `4+e` north arrivals on offset seven. Alternation fixes
the word through `W4` as

```text
7: SR,NL,NR,SL,NR,SL,SR,NL.
```

For `e=0` this is the whole word. For `e=1` it is followed by `NR`
and possibly a final `SL`. In particular, no south arrival can be
the stable successor of `W4=NL`: its successor is either absent or
the remaining `NR`.

Let `E1,E2,E3` be the east arrivals on offset eight, fed by
`5:SL,NR1,NR2`. Two fixed paths are

```text
7:W1=SR -> 4:first WR -> 5:first NR -> E2,
7:W4=NL -> 4:last WR -> 5:NL -> 2:WL -> 1:SL
        -> 4:EL -> 5:last NR -> E3.
```

If `E3=ER`, its south step completes an eight-step return from
`W4` to a south arrival on offset seven. This contradicts the
successor just identified. Hence `E3=EL`.

Now take the offset-eight south departure feeding `W3=SR`. Follow
its south step, the four-step return from `W3` to `W4`, and the
seven-step path from `W4` to `E3`. This is a twelve-step first
same-cell return to offset eight. Its source must be the right-turn
east arrival immediately preceding `E3`, namely `E2=ER`.

But then the first displayed path completes the four-step return

```text
7:W1=SR -> 4:first WR -> 5:first NR -> E2=ER -> 7:W3=SR.
```

Both endpoints turn right. This contradiction excludes K3 and
finishes the exclusion of `z=1`.

## The forced wake pattern and family C

Only `z=2,e=1` remains, with word `ER,EL,ER`. The zero-displacement
return proof in `odd_skew_fat122_three_visit_six_2026-09-12.md` now
forces offset seven to be non-wake and offset eight to be wake.
None of those steps uses the lower-cap voltage inequality, so the
conclusion holds at either cap.

In family C of the wake-family note, the upper cap is `(1,2,2)`
with inward offsets four non-wake and five wake. The present theorem
therefore forces a wake at upper offset eight, or at level `W-8`.
Yet that level is even in residue two, whose only even wake in C is
eight. This would require `W=16`, whereas C requires `W>=22`.
Thus family C is excluded at every period and width.

Combining the present theorem with the lower early-wake bound gives
the following remaining alternatives whenever the lower cap is
`(1,2,2)` and level four is non-wake:

```text
A: W=6m+2,
   O={0,5,6,8,6r+4,6p+2,W-4,W},
   1<=r<p<=m-1, r+p even, upper cap (1,2,2);

B: W=6m+4,
   O={0,5,6,8,6p+2,6r+4,W-2,W},
   2<=p<r<=m-1, p+r odd, upper cap (1,2,3).
```

These two families remain open. The later lower-band exclusions in
`odd_skew_fat122_four_six_band_exclusion_2026-09-14.md` and
`odd_skew_fat122_adjacent_wake_band_exclusion_2026-09-14.md`, together
with the earlier exclusions, rule out every lower `(1,2,2)` cap
with a wake at level four. Thus A and B now exhaust this lower
cap profile. The other cap profiles in the orbit remain outside
this classification.

## The common non-wake band at the upper cap

The remaining parameter restrictions give a fixed interval for the next
local argument. Write all wake positions as upper inward offsets.

In family A, put `h=m-p` and `k=m-r`. The exact ordered wake offsets are

```text
0,4,6h,6k-2,6m-6,6m-4,6m-3,6m+2,
1<=h,       h+2<=k<=m-1,       h+k even.
```

Indeed, `r<p` and their common parity give `p-r>=2`, hence `k>=h+2`.
The first wake after offset four is therefore at offset `6h`. If `h=1`,
the next one is at least sixteen, so offsets seven through fifteen are
non-wake. If `h>=2`, offsets five through eleven are non-wake.

In family B, put `h=m-r` and `k=m-p`. Its ordered wake offsets are

```text
0,2,6h,6k+2,6m-4,6m-2,6m-1,6m+4,
1<=h<k<=m-2,       k-h odd.
```

For `h=1`, the wake at offset six is followed by no further wake before
offset fourteen. For `h>=2`, no wake follows offset two before offset
twelve.

Thus both surviving families have upper offsets seven through eleven
non-wake, and upper offset five is also non-wake. Offset six may be wake.
The cap profiles and the wake at offset four in A or offset two in B
distinguish the two local problems. An exclusion of these upper patterns
would complete the lower `(1,2,2)` profile, since the later exclusions
force `omega_4=0`; such an exclusion is not proved here.

The later note `odd_skew_upper_a_single_er_reduction_2026-09-14.md`
uses these non-wake conditions to reduce the upper single-`ER`
branch of A to `h=1` and one fixed offset-seven word. That
last word is excluded in
`odd_skew_upper_a_single_er_exclusion_2026-09-14.md`.
The upper two-`ER` branch of A and family B remain open.
