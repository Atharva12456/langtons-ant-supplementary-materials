# Tight lower-thin families at literal drift (1,3)

Further continuation, 1 October 2026: the entire lower111 member is
now [excluded for every upper cap, width and period at growth eight](positive_skew_lower_thin_111_exclusion_2026-10-01.md).
Both parameter branches that survived the initial reduction below
contradict quiet upper offset eight. This note retains the earlier
arithmetic classification and isolated-five reduction as provenance.

This audit concerns growth eight and the literal positive drift `(1,3)`.
All coordinates remain unbounded;
the finite coordinate checks below regress formulas, not the existence or
nonexistence of an entire family of highways.

There is one new all-width restriction among the requested tight branches:

> In lower bits `111` with upper F122, the endpoint family with
> `q<p=m` is impossible. The remaining endpoint parameters satisfy
> either `q<=p<=m-1`, or `q=p=m` with m even.

The separate known width exclusion W>=18 makes the saturated case have
even m>=4. The arithmetic audit itself also includes the W=16 endpoint
shadow; that shadow is not a highway.

The small local obstruction used here also applies to other branches:

> An upper F122 cap with quiet offsets three and four and wake offset five
> must have wake offset six, independently of growth and with unbounded
> positive integer period.

The first-six-row normal classification in this local lemma is
computer-assisted. Once those three normals are given, the seventh-row
contradiction is the short physical-return argument below.

## Independent compact-family audit

The fixed lower wakes are respectively `{0,4,5,6,7}`, `{0,4,6,7}`,
`{0,4,5,7}`, and `{0,4,5,6}`. Attach upper wake W at F122 and
upper wakes `W-2,W` at F123. The old compact formulas are correct:

| Branch | Width and two residual wakes | Bounds | Moment modulo four |
|---|---|---|---|
| 111/F122 | `W=6m+4`, `{6q-2,6p-1}` | `2<=q<=p<=m` | `1+2(m+q-p)` |
| 011/F123 | `W=6m+4`, `{6p+2,6q-2}` | `1<=p<q<=m` | `1+2(p+q)` |
| 101/F123 | `W=6m`, `{6q-2,6p-1}` | `2<=q<=p<=m-1` | `1+2(q-p)` |
| 110/F123 I | `W=6m`, `{6p+3,6q-1}` | `1<=p<q<=m-1` | `1-2(p+q)` |
| 110/F123 II | `W=6m+4`, `{6p+2,6q+2}` | `1<=p<q<=m-1` | `3+2(p+q)` |
| 110/F123 III | `W=6m+4`, `{6p-1,6q-1}` | `2<=p<q<=m` | `1-2(p+q)` |

Requiring moment one gives the stated old parity conditions: `m+p+q`
even in the first row, `p+q` odd in row II, and `p+q` even otherwise.

For completeness, P22 forces unsigned fibre sizes `4,2,2`. A two-wake
fibre has uniform sign; a four-wake fibre has a `3+1` sign split. Checking
the three even width classes gives the following exhaustive residual signs:

- 111/F122: only W four modulo six; one positive fibre-two residual and
  one negative fibre-one residual.
- 011/F123: only W four modulo six; one positive fibre-one residual and
  one positive fibre-two residual.
- 101/F123: only W zero modulo six; one positive fibre-two residual and
  one negative fibre-one residual.
- 110/F123: W zero modulo six requires negative fibre-zero and fibre-one
  residuals. W four modulo six requires both residuals in fibre one with
  their common sign either positive or negative. W two modulo six is
  impossible.

Here fibre means `j=-t mod3`. The ordered positive-skew rank condition
requires `q<=p` in 111 and 101, and `p<q` in 011 and row I of 110.
For the two same-fibre 110 rows, distinct residuals can simply be indexed
with `p<q`. The remaining bounds express residual positions at least eight
and below the upper outer quiet pair. Direct substitution gives the moment
column. These sign, order, and moment calculations establish the all-width
classification; coordinate enumeration is not used to establish completeness.

`audit_tight_thin_families.py` independently computes original fibre
coordinates `j=(-t)%3`, `n=ceil(t/3)`, signed charges, and the original
cross-fibre longitudinal rank inequalities. It imports no old checker. For
every even width 10 through 180 and every possible pair of residual
positions, it compares direct arithmetic with the six formulas. All
1,652,060 candidate wake sets agree, with 11,669 accepted sets. It also
checks an unbounded endpoint ray obtained by increasing m by two while
keeping p,q fixed. The coordinate bound is only a regression.

## Exact intersections with the saved local wake domains

The lower source is the complete `lower_thin_fast_depth9.json`, with
25,278 survivors, not the older incomplete depth-nine file. The upper
source is the complete `upper_all_strong_depth7.json`, with 14,412
survivors and the upper clock sign `+N`. Source hashes and domains are
saved in `tight_thin_family_audit.json`.

The table lists additional upper wake offsets three through seven; the
outer F122/F123 wakes are implicit. All listed surviving local schedules
have unbounded endpoint realizations in the compact parameters.

| Compact family | Arithmetic upper schedule | Parameter condition | Saved upper domain |
|---|---|---|---|
| 111/F122 | `{}` | `p<=m-1` | 5 prefixes |
| 111/F122 | `{5}` | `q<p=m` | **0 prefixes** |
| 111/F122 | `{5,6}` | `q=p=m` | 1 prefix |
| 011/F123 | `{}` or `{6}` | `{6}` iff `q=m` | 112 or 158 prefixes |
| 101/F123 | `{}` or `{7}` | `{7}` iff `p=m-1` | 112 or 96 prefixes |
| 110/F123 I | `{}` or `{7}` | `{7}` iff `q=m-1` | 112 or 96 prefixes |
| 110/F123 II | `{}` | always | 112 prefixes |
| 110/F123 III | `{}` or `{5}` | `{5}` iff `q=m` | 112 or 6 prefixes |

These schedule formulas follow directly by subtracting each residual
coordinate from W. In 111/F122 the two distances are
`6(m-q)+6` and `6(m-p)+5`; thus offsets three, four, and seven are quiet,
offset five is wake exactly when `p=m`, and offset six exactly when
`q=m`. The new local lemma rules out exactly `q<p=m`. If `q=p=m`, the
moment condition further forces m even.

The lower through-nine domain adds no further wake-pattern exclusion to
these branches. The relevant exact lower pattern counts are:

| Lower bits five through seven | Bits eight,nine | Prefixes |
|---|---|---|
| 111 | 00 | 179 |
| 011 | 00 or 10 | 1,833 or 3,598 |
| 101 | 00 | 55 |
| 110, row I | 00 or 01 | 289 or 234 |
| 110, row II | 00 or 10 | 289 or 289 |
| 110, row III | 00 | 289 |

For 011, level eight is wake iff p=1. For 110 row I, level nine is wake
iff p=1; for row II, level eight is wake iff p=1. All other entries are
quiet by their coordinate forms. The parity and bounds admit each
displayed lower/upper schedule combination at arbitrarily large widths.
The coordinate regression contains 17 schedule pairs, of which precisely
the isolated upper-five case fails the saved upper domain. Compatibility
of two wake patterns does not join their turn words or establish P3.

## Small local upper-five obstruction

Use the orientation-preserving half-turn to display upper rows in the
same ports as lower rows. The clock equation is then
`tau(target)=tau(source)+1+N*lambda`, with N a positive unbounded integer.
The actual physical upper ports are obtained by E/W and N/S exchange.

Fix an upper F122 cap, quiet offsets three and four, wake five, and
suppose six is quiet. Exact port counts, R-first alternation, physical
first returns, and strict integer clock order reduce the first six rows
to the following three cases. This reduction is computer-assisted; it
uses no P22, growth budget, period congruence, visit-count cutoff, or
four-step stable-gap condition.

All three have common rows

```
0 NR; 1 WR,WL; 2 NR,SL; 3 WR,WL,ER,WL.

case 1:
4 NR,SL,NR,NL,SR,SL
5 WR,WL,WR,EL,ER
6 NR,SL,NR,NL,SR,NL

case 2:
4 SR,SL,NR,NL,NR,SL
5 WR,EL,ER,WL,WR
6 NR,NL,SR,SL,NR,NL

case 3:
4 SR,SL,NR,SL,NR,NL
5 WR,WL,WR,EL,ER
6 NR,SL,NR,NL,SR,NL
```

On row seven there are four east arrivals E1,...,E4 and four north
departures N1,...,N4. A north departure is WR or EL. Tracing only older
rows gives the following physical first returns. Every listed path has
zero displacement and no intermediate row-seven visit, so its endpoint
is the next stable event with the opposite turn.

| Case | Return | Direction word |
|---|---|---|
| 1 | N3 to E2 | `NWNENWNESWSESWSE` |
| 1 | N4 to E4 | `NWSE` |
| 2 | N2 to E1 | `NWNENWSESWSWNESE` |
| 2 | N4 to E4 | `NWSE` |
| 3 | N3 to E1 | `NWNENWSESWSWNESE` |
| 3 | N4 to E3 | `NWSE` |

In case 3, N3 cannot be EL, because it would be an earlier east arrival
than E1. Hence N3 is WR, E1 is EL and is N4. Its four-step first return
then makes E1 and E3 consecutive, although ordinal matching puts E2
strictly between them. This is impossible.

In case 1, N4 cannot be WR: its returned E4 would be EL and a fifth
north departure. If N3 were WR, E2 would be EL and equal N4, making E2
and E4 consecutive while E3 lies between them. Thus N3 is E1=EL, its
returned E2 is ER, N4 is E3=EL, and E4 is ER. There are two WR events
before E1. Alternation and the exact port counts force row seven to be

```
WR,WL,WR,EL,ER,EL,ER,[WL]^(1-omega7).
```

In case 2, N2 must be WR, so its returned E1 is EL and equal N3. N4
again cannot be WR. Alternation makes E2 be ER and N4 be E3=EL; E4
is ER. The same displayed row-seven word is forced.

Now both cases fail a short older-row physical first return. In case 1,
the second NR on row four follows `ENWS` to its third south arrival SL.
This skips the intervening NL and SR. In case 2, the SR on row six
follows `WSWNESEN` to its third north arrival NR, skipping the intervening
SL. Both paths have zero displacement and no intermediate visit to the
starting row. Their endpoints therefore cannot be the next stable event.

This covers both choices of the row-seven wake bit, proving the local
implication. It is not valid to omit the quiet-offset-four hypothesis:
the upper F122 domain has schedules with wake four and five but quiet six.

## Verification

```
python work_positive_skew_thin_20261001/audit_tight_thin_families.py
python work_positive_skew_thin_20261001/probe_upper_thin_5_implies_6.py
python work_positive_skew_root_20261001/replay_thin_upper_obstruction.py
```

The independent raw probe exhausts 2, 38, 48, 57, and 1,242 words at
levels three through seven, leaving respectively 2, 3, 3, 3, and zero
prefixes. Its two integer-clock rejections retain exact SMT inputs with
N>=1 and no upper bound. Every other rejection records a finite physical
return witness; a repeated quotient cycle without a witness is retained.
The root's separate geometric compass and ordinal replay freshly verified
all 1,374 physical certificates and rederived both clock UNSAT results.

These checks yield a small local cap reduction and the specified
all-width subfamily exclusion. They do not close the lower-thin branch,
join the unbounded bulk histories, or close the `(1,3)` growth-eight orbit.


Reproduction code and audit data for this note are retained in
`work_positive_skew_thin_20261001`. The canonical copy was integrated on 1 October 2026.
