# Width 20 upper guard excluded for lower fat `(0,1,111)`

For growth eight and drift `(1,-3)`, fix the lower fat `(1,2,3)` band
`(omega_3,omega_4,j,k,l)=(0,1,1,1,1)` and an upper guard cap. The
width-20 cap pair is impossible at every period. This is a finite-width
exclusion; wider instances of the cap pair remain open.

## The sole wake placement

At width `W=20`, the caps fix wakes `{0,2,4,18,19,20}`. The other two
must lie between levels 5 and 17. Directly testing every pair against
P22, even rank, and the odd-skew moment `3 mod 4` leaves only

```text
O = {0,2,4,10,16,18,19,20}.
```

The verifier repeats this static enumeration. It uses no upper-guard
lemma to establish uniqueness at width 20.

## Exhaustive two-cap join

The lower cap is extended through level 8, yielding 76 chronological
stable-word prefixes in eight count signatures. The upper guard is
extended through inward offset 8, yielding 124 prefixes in six count
signatures. The upper words are rotated by a half-turn into physical
levels 12–20, preserving event order. Both cap frontiers use exact
unbounded integer clocks with `N=6 mod 8`, right/left alternation,
ordinal edge matching, and only finite witnessed wrong returns.

For every physical level `0..20`, integer port counts obey nonnegativity,
row parity, right-minus-left excess `1` exactly at the eight wakes, and
heading-by-heading flow between adjacent transverse levels. The two cap
count signatures are fixed in this full-strip system. Of their 48
signature pairs, 31 are compatible. For each compatible pair, blocking
one model's three middle-row count vectors at levels 9–11 makes the
system unsatisfiable. Thus each pair has exactly one possible middle
count pattern; no arbitrary row-size cap enters the enumeration.

Chronological words for the three middle rows are then exhausted from
their forced counts. The word generator enforces alternation, ordinal
matching, and already forced next-visit adjacency. A generated word is
discarded only after an explicit zero-displacement finite walk reaches
the wrong stable event. The counts are:

| Extension | Parents | Adjacency words | Finite-return survivors |
|---|---:|---:|---:|
| Level 9 | 8,254 cap word pairs | 6,286 | 1,890 |
| Level 10 | 1,890 | 21,818 | 7,331 |
| Level 11 | 7,331 | **1** | **0** |

The sole full-strip word at level 11 has a 56-step ordinal walk from
`(level 0, event 0)` back to **that same event**, with net horizontal
voltage zero. Level zero has only one stable event, so this is a
same-cell return that cannot be its next stable visit. The result JSON
contains all 21 row words and the complete 56-edge path. A separate
standard-library checker reconstructs the turns, ordinal flow, wake
excess, and path from those words.

Run from the repository root:

```text
python code/python/verify_lower_fat123_a0_b1_111_w20_guard.py
python code/python/check_lower_fat123_a0_b1_111_w20_guard_witness.py
```

The first command writes
`results/lower_fat123_a0_b1_111_w20_guard_checks_2026-09-26.json`.
Neither checker bounds the period, extrapolates a quotient cycle into a
physical return, or cuts off middle-row lengths. The earlier
[width-18 guard exclusion](odd_skew_lower_fat123_a0_b1_111_width18_guard_2026-09-23.md)
and [smaller-width exclusion](odd_skew_lower_fat123_a0_b1_111_width16_2026-09-23.md)
combine with this result to put the next possible width for **this cap
pair** at 22. At width 22, P22/rank/moment leave two static schedules;
the [upper-guard offsets-3–6 lemma](odd_skew_upper_guard_offsets_3_6_impossible_2026-09-26.md)
leaves `{0,2,4,6,18,20,21,22}`. It is a necessary placement, not a
constructed highway.
