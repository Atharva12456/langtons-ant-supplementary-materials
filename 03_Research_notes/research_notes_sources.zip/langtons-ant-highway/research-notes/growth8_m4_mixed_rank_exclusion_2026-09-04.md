# The mixed wake at drift `(4,-4)` is impossible

Date: 2026-09-04.

## Statement

No finite-support periodic highway of growth eight and drift `(4,-4)` has
four horizontal-arrival and four vertical-arrival odd translation classes.

The proof is an all-period rank calculation.  The finite checks used while
auditing the block signs are not part of the proof.

## Residue shape of a mixed wake

Put \(t=x+y\) and \(r=x\pmod4\), with vertical-arrival classes `Q` on even
levels and horizontal-arrival classes `C` on odd levels.  The signed
coordinate-residue law is \(2\pmod4\) in every `x mod 4` and `y mod 4`
fibre.  Since there are eight wake classes, every one of the four fibres in
either coordinate contains exactly two wakes, and those two wakes have the
same checker sign.

In a `4+4` split, every coordinate residue is consequently incident either
to two `Q` wakes or to two `C` wakes.  Exactly two `x` residues and two `y`
residues are of type `Q`.

Let \(a\) and \(b\) count the even `x` and even `y` residues of type `Q`.
A `Q` wake has coordinate residues of the same parity, so degree balance
gives \(a=b\).  A `C` wake has residues of opposite parity; balancing its
even-`x` and odd-`y` ends gives \(2-a=b\).  Thus

\[
 a=b=1.
\]

The `Q` wake is therefore two doubled residue edges, one even-even and one
odd-odd.  The `C` wake is two more doubled edges, one even-odd and one
odd-even.  The two classes on any doubled edge have transverse levels
differing by a nonzero multiple of four.

## Binary block equations

Reduce every directed edge-block multiplicity modulo two.  At a `C` class
write \(s_{j,r},n_{j,r}\) for its south and north blocks; at a `Q` class
write \(w_{t,r},e_{t,r}\) for its west and east blocks.  If
\(D^C,D^Q\) are the two wake indicators, flow conservation is equivalent to

\[
\begin{aligned}
 s_{j,r}&=n_{j,r}+D^C_{j,r},\\
 w_{t,r}&=e_{t,r}+D^Q_{t,r},\\
 n_{j,r}&=n_{j-2,r}+D^C_{j,r}+D^Q_{j-1,r},\\
 e_{t,r}&=e_{t-2,r-2}+D^Q_{t,r}+D^C_{t-1,r-1}.
\end{aligned}
\tag{1}
\]

The second coordinate is modulo four.  Zero boundary values below the wake
determine the finite solution uniquely.  For one doubled wake edge, (1)
gives one finite `x` interval and one finite `y` interval; call their union
a doubled-edge gadget.

Let

\[
 F(D)=E(D)+L(D)\pmod2,
\]

where \(E\) is the edge-block inversion parity and

\[
 L=\sum_Q p_v(D_v+1)+\sum_C D_v(p_v+1)
\tag{2}
\]

is the local rank correction.  Here \(p_v\) is the parity of the positive
incoming and outgoing blocks.  Since the solution of (1) is linear in
\(D\), \(F\) is a quadratic function of the wake indicator.

## The four-gadget sign

The needed quadratic calculation is independent of the lengths and relative
heights of the four doubled-edge gadgets:

\[
 \boxed{F(D)=0.}
\tag{3}
\]

Here are the details that remove any bounded-placement assumption.  Translate
the even `x` and even `y` residues of type `Q` to zero.  If
\(\epsilon_x,\epsilon_y\in\{1,-1\}\) locate the odd `Q` residues, the four
doubled edges are

\[
\begin{array}{c|c}
Q&(0,0),\ (\epsilon_x,\epsilon_y)\\
C&(2,\epsilon_y+2),\ (\epsilon_x+2,2),
\end{array}
\tag{4}
\]

with residues read modulo four.  Substitute one pair of endpoints for each
row of (4) into (1).  Moving any one endpoint by four levels inserts one
four-level piece into each of its two coordinate intervals.  In the
source/target order `(level,lane,port)`, the new edge inversions against the
other three gadgets occur in equal pairs.  The remaining two inversions are
exactly the two changes in (2).  Hence \(F\) is unchanged.  Repeating this
move reduces arbitrary distinct endpoints to adjacent representatives.

For those representatives the source/target port table is

\[
\begin{array}{c|c|c|c}
(\epsilon_x,\epsilon_y)&F(Q_{00})+F(Q_{\epsilon_x\epsilon_y})
&F(C_{2,\epsilon_y+2})+F(C_{\epsilon_x+2,2})
&\text{six cross terms}\\ \hline
(1,1)&0&0&0\\
(1,-1)&0&0&0\\
(-1,1)&0&0&0\\
(-1,-1)&0&0&0
\end{array}
\tag{5}
\]

Each individual doubled-edge gadget has \(F=1\); this accounts for the
zeros in the middle columns, since each column contains two gadgets.  The
last column is obtained by pairing the possible reversed block pairs in
(1); equal-target-port pairs are included, as required by the negative-
before-positive convention.  Equations (4)--(5), together with the
four-level invariance, prove (3) for arbitrary endpoint heights.

## Rank contradiction

The port-sorting factorisation gives

\[
 K\equiv1+E+L=1+F(D)\equiv1\pmod2.
\tag{6}
\]

On the other hand, the period congruence at drift `(4,-4)` is
\(N\equiv0\pmod8\).  Exact stable alternation puts every left turn at odd
stable rank, so

\[
 K\equiv\#L=\frac{N-8}{2}\equiv0\pmod2.
\tag{7}
\]

Equations (6)--(7) contradict one another.  Therefore the mixed `4+4`
arrival-axis split is impossible.

The remaining `(4,-4)` problem is the pure-horizontal `8+0` split.  Its
wake graph is still 2-regular, but its sign depends on the transverse labels,
not only on the number of graph components; no component-count shortcut is
being asserted here.
