# Wake placements for a lower guard cap and an upper `(1,2,3)` cap

22 September 2026

## Result and scope

Take drift `(1,-3)` and growth eight.  Suppose the lower cap has profile
`(1,1,1)` (guard) and the upper cap has profile `(1,2,3)` (fat).  Normalize the
transverse levels to `0<=t<=W`, with the lower cap at level zero.  Then the
wake set `O` is one of the placements in the following eight parameter
families.  In every family `O` contains the five cap wakes `0,1,2,W-2,W`, and
`x,y,z` (or `u,v,w`) denote the three remaining wakes.

| Family | Width | Extra wakes | Integer restrictions |
|---|---|---|---|
| A1 | `W=6m` | `z=6k+2`, `x=6i+1`, `y=6j+1` | `1<=i<j<=m-1`, `1<=k<=m-1`, `i+j+k` even, `k<i` or `k>=j` |
| A2 | `W=6m` | `z=6k+2`, `x=6i+4`, `y=6j+4` | `0<=i<j<=m-2`, `1<=k<=m-1`, `i+j+k` odd, `k<=i` or `k>j` |
| C1 | `W=6m+4` | `z=6k`, `x=6i+1`, `y=6j+1` | `1<=i<j<=m`, `1<=k<=m`, `i+j+k` odd, `k<=i` or `k>j` |
| C2 | `W=6m+4` | `z=6k`, `x=6i+4`, `y=6j+4` | `0<=i<j<=m-1`, `1<=k<=m`, `i+j+k` even, `k<=i` or `k>j` |
| B0 | `W=6m+2` | `6i+4`, `6j+4`, `6l+4` | `0<=i<j<l<=m-1`, `i+j+l` even |
| B1 | `W=6m+2` | `6i+1`, `6j+1`, `6l+4` | `1<=i<j<=m-1`, `0<=l<=m-1`, `i+j+l` odd |
| B2 | `W=6m+2` | `u=6i`, `v=6j+3`, `w=6l+1` | `1<=i<=m-1`, `0<=j<=m-1`, `1<=l<=m-1`, `i+j+l` even, `[i<=l]=[j<l]` |
| B3 | `W=6m+2` | `u=6i+2`, `v=6j+5`, `w=6l+1` | `1<=i<=m-1`, `0<=j<=m-1`, `1<=l<=m-1`, `i+j+l` even, `[l<=i]=[l<=j]` |

The Iverson conditions in the last column are the rank parity; the parity
conditions on the parameter sums are the additive moment.  No other width is
possible for this cap pair apart from the three residues `W=0,2,4 mod 6`, and
each residue class has only the listed shapes.

The families are pairwise disjoint.  Their smallest widths and first
placements are

| Family | first `W` | a first placement | number at that width |
|---|---|---|---|
| B2 | 14 | `{0,1,2,3,6,7,12,14}` | 1 |
| A2 | 18 | `{0,1,2,4,10,14,16,18}` | 1 |
| B1 | 20 | `{0,1,2,4,7,13,18,20}` | 2 |
| B3 | 20 | `{0,1,2,8,11,13,18,20}` | 4 |
| C1 | 22 | `{0,1,2,6,7,19,20,22}` | 2 |
| C2 | 22 | `{0,1,2,6,10,16,20,22}` | 3 |
| A1 | 24 | `{0,1,2,8,13,19,22,24}` | 3 |
| B0 | 26 | `{0,1,2,4,10,22,24,26}` | 2 |

The number of placements at widths `W<=44` is `686`, and at widths `W<=80` it
is `9802`, per width

```text
W : 14 18 20 22 24 26 28 30 32 34 36 38  40 42  44 ...  80
#  :  1  1 10  5  5 30 12 14 72 30 30 135 52 55 234 ... 1800
```

These are necessary conditions valid at every period.  They are not
constructions, and by themselves they exclude no width.  The derivation is by
hand and uses only the cap wakes, P22, the rank parity and the additive
moment.  An exhaustive enumeration over all eight-element wake sets confirms
the classification exactly, placement for placement, for every even
`W<=80`.

## Premises

1. **Caps.**  The lower guard cap has rows `0:WR`, `1:NR`, `2:WR`; levels
   `0,1,2` are wakes.  The upper `(1,2,3)` cap has one, two and three visits on
   levels `W`, `W-1`, `W-2`, so `W` and `W-2` are wakes and `W-1` is not.  Both
   extreme arrivals are horizontal, so `W` is even.  Eight distinct wakes need
   `W>=8`, so the five cap wakes are distinct.
2. **P22.**  There are exactly eight wake levels.  In each residue fibre
   `O_r={t in O : t=r mod 3}` the signed sum of the checker signs `(-1)^t` is
   `2 mod 4`.  With eight wakes this is equivalent to: fibre sizes `4,2,2`, each
   two-element fibre has equal parities, and the four-element fibre splits
   `3+1` by parity.  (Each fibre sum must be even and non-zero mod 4, so every
   fibre has even size at least two.)
3. **Rank** (`growth8_odd_skew_additive_2026-08-23.md`).  With
   `I_ij=#{(a,b) in O_i x O_j : a<b}`, the sum `I=I_01+I_02+I_12` is even.  As
   noted in `odd_skew_missing_guard_exclusion_2026-09-03.md`, labelling the
   fibres by `t mod 3` instead of the normalized labels does not change the
   parity, because every fibre has even size.
4. **Moment** (same note, `s=-1`), lower cap at level zero:

   ```text
   M = sum_(t in O) f(t) = 3 (mod 4),      f(t) = (-1)^(t+1) floor((t+1)/3).
   ```

   Values used below: `f(0)=f(1)=0`, `f(2)=-1`,
   `f(6a)=-2a`, `f(6a+1)=2a`, `f(6a+2)=-(2a+1)`, `f(6a+3)=2a+1`,
   `f(6a+4)=-(2a+1)`, `f(6a+5)=2a+2`.

## Derivation

Write the fixed wakes by residue and parity: `0` (res 0, even), `1` (res 1,
odd), `2` (res 2, even), and the upper pair `W`, `W-2` (both even).  Three
extra wakes remain.  A fixed fibre containing two opposite parities must be
the four-element fibre.

### Width `W=6m` (families A)

Here `W` has residue 0 and `W-2` residue 1.  The fibre of residue 1 contains
`1` (odd) and `W-2` (even), so it is the four-element fibre
`O_1={1,W-2,x,y}`; its `3+1` split forces `x,y` of equal parity.  The other
fibres are `O_0={0,W}` and `O_2={2,z}` with `z` even, so `z=6k+2`.  Since
`8<=z<=W-4`, `1<=k<=m-1`.  If `x,y` are odd then `x=6i+1`, `y=6j+1` with
`7<=x<y<=W-5`, so `1<=i<j<=m-1`.  If they are even then `x=6i+4`,
`y=6j+4` with `4<=x<y<=W-8`, so `0<=i<j<=m-2`.

Rank: `I_01=4`, `I_02=2`, `I_12=2+[x<z]+[y<z]`.  So `[x<z]=[y<z]`.  For odd
`x`, `x<z` iff `i<=k`, giving "`k<i` or `k>=j`"; for even `x`, `x<z` iff
`i<k`, giving "`k<=i` or `k>j`".

Moment: the cap wakes give `f(0)+f(1)+f(2)+f(6m)+f(6m-2) = -1-2m-(2m-1) =
-4m`.  With odd `x,y`: `M=-4m+2i+2j-(2k+1)`, and `M=3 mod 4` iff `i+j+k` is
even (A1).  With even `x,y`: `M=-4m-(2i+1)-(2j+1)-(2k+1)`, and `M=3 mod 4` iff
`i+j+k` is odd (A2).

### Width `W=6m+4` (families C)

Now `W` has residue 1 and `W-2` residue 2.  The fibre of residue 1 contains
`1` and `W` of opposite parity: `O_1={1,W,x,y}` with `x,y` of equal parity.
Then `O_2={2,W-2}` and `O_0={0,z}` with `z` even, `z=6k`, `6<=z<=W-4`, so
`1<=k<=m`.  Odd `x=6i+1<y=6j+1<=W-3` gives `1<=i<j<=m`; even
`x=6i+4<y=6j+4<=W-6` gives `0<=i<j<=m-1`.

Rank: `I_01=5+[z<x]+[z<y]`, `I_02=3`, `I_12=4`.  So `[z<x]=[z<y]`, and in both
parities `z<x` iff `k<=i`, giving "`k<=i` or `k>j`".

Moment: cap wakes give `-1+f(6m+4)+f(6m+2)=-1-2(2m+1)=-4m-3`, and `f(z)=-2k`.
Odd `x,y`: `M=-4m-3-2k+2i+2j`, so `M=3` iff `i+j+k` odd (C1).  Even `x,y`:
`M=-4m-3-2k-(2i+1)-(2j+1)`, so `M=3` iff `i+j+k` even (C2).

### Width `W=6m+2` (families B)

Now `W` has residue 2 and `W-2` residue 0, so the fixed fibres are
`{0,W-2}` (even, even), `{1}`, and `{2,W}` (even, even).  Residue 1 has one
fixed wake and needs at least one more.  The three extra wakes therefore
split in one of three ways.

* **(a) `O_1` is the four-element fibre**, `O_1={1,x,y,z}`.  The `3+1` split
  with `1` odd means either all three extras are even (`=4 mod 6`, B0) or
  exactly two are odd (`=1 mod 6`) and one even (B1).  Level `W-1=6m+1` is
  non-wake, so odd extras satisfy `7<=6i+1<=W-7`, i.e. `1<=i<=m-1`; even
  extras satisfy `4<=6l+4<=W-4`, i.e. `0<=l<=m-1`.
* **(b) `O_0` is the four-element fibre**, `O_0={0,W-2,u,v}` with one even
  `u=6i` and one odd `v=6j+3` (`6<=u<=W-8`, `3<=v<=W-5`), and `O_1={1,w}` with
  `w=6l+1<=W-7` odd (B2).
* **(c) `O_2` is the four-element fibre**, `O_2={2,W,u,v}` with even
  `u=6i+2` (`8<=u<=W-6`) and odd `v=6j+5` (`5<=v<=W-3`), and `O_1={1,w}` as in
  (b) (B3).

Rank.  (a): `I_01=4`, `I_02=3`, `I_12=5`; `I=12` is even for every placement,
so the rank parity gives nothing.  (b): `I_01=2+[u<w]+[v<w]`, `I_02=5`,
`I_12=3`, so `[u<w]=[v<w]`, i.e. `[i<=l]=[j<l]`.  (c): `I_01=2`, `I_02=5`,
`I_12=5+[w<u]+[w<v]`, so `[w<u]=[w<v]`, i.e. `[l<=i]=[l<=j]`.

Moment.  The cap wakes give `-1+f(6m+2)+f(6m)=-1-(2m+1)-2m=-4m-2`.
B0: `M=-4m-2-(2i+1)-(2j+1)-(2l+1)`, so `M=3` iff `i+j+l` even.
B1: `M=-4m-2+2i+2j-(2l+1)`, so `M=3` iff `i+j+l` odd.
B2: `M=-4m-2-2i+(2j+1)+2l`, so `M=3` iff `i+j+l` even.
B3: `M=-4m-2-(2i+1)+(2j+2)+2l`, so `M=3` iff `i+j+l` even.

This completes the classification.  Disjointness is clear: the families differ
in `W mod 6`, in the fibre that carries four wakes, or in the parity pattern
of the extras.

## Near-cap wake patterns

Only the wakes near either cap enter the local chronology.  In lower levels
the extra wakes lie in the following residues mod 6, and in upper offsets
`u=W-t` in the listed residues:

| Family | lower levels of extras (mod 6) | upper offsets of extras (mod 6) |
|---|---|---|
| A1 | `x,y=1`, `z=2` | `x,y=5`, `z=4` |
| A2 | `x,y=4`, `z=2` | `x,y=2` (`>=8`), `z=4` |
| C1 | `x,y=1`, `z=0` | `x,y=3`, `z=4` |
| C2 | `x,y=4`, `z=0` | `x,y=0`, `z=4` |
| B0 | all `=4` | all `=4` |
| B1 | two `=1`, one `=4` | two `=1`, one `=4` |
| B2 | `u=0`, `v=3`, `w=1` | `u=2` (`>=8`), `v=5`, `w=1` (`>=7`) |
| B3 | `u=2`, `v=5`, `w=1` | `u=0`, `v=3`, `w=1` (`>=7`) |

In particular upper offset three is a wake only in C1 (`x` or `y=W-3`) and B3
(`v=W-3`), and upper offset four is a wake only in A (`z=W-4`), C (`z=W-4`),
B0 and B1 (an even extra at `W-4`).  In all other placements the upper
`(1,2,3)` four-band reduction
(`odd_skew_upper_fat123_four_band_reduction_2026-09-21.md`) applies.  Lower
level three is a wake only in B2 (`j=0`), lower level four only in A2, C2
(`i=0`), B0 (`i=0`) and B1 (`l=0`), lower level five only in B3 (`j=0`).

Every family also contains placements with all three extra wakes arbitrarily
far from both caps (take `m` large and the parameters near `m/2` with the
required parity and order).  Hence a complete exclusion of this cap pair by
local chronology must handle the schedule in which lower levels `3,...,D` and
upper offsets `3,...,D` are all non-wake.

## Verification

From `code/python/`:

```text
python lower_guard_upper_fat123_families.py 80
```

prints

```text
brute 9802 closed 9802 closed distinct 9802 equal True
per W: {14: 1, 18: 1, 20: 10, 22: 5, 24: 5, 26: 30, 28: 12, 30: 14, 32: 72, ...}
through W=44: 686
per family: {'A1': 855, 'A2': 861, 'B0': 490, 'B1': 1512, 'B2': 2205, 'B3': 2184, 'C1': 840, 'C2': 855}
```

The brute force enumerates, for every even `W<=80`, all three-element sets of
extra wakes from `{3,...,W-3}` added to `{0,1,2,W-2,W}`, and keeps those passing
the three tests literally (fibre signed sums `=2 mod 4`, rank sum even, moment
`=3 mod 4`).  The closed form generates the eight families.  The two lists
coincide.

`python lower_guard_upper_fat123_check_formulas.py` recomputes, for all 28,340 placements of the eight
shapes with the rank and moment conditions dropped (`W<=80`), the pair counts
`I_01,I_02,I_12` and the moment `M`, and compares them with the expressions in
the derivation above.  It prints `checked 28340 relaxed placements, mismatches 0`.
