# Seven wake families for positive-skew lower band C and upper (1,2,3)

Consider drift `(1,3)`, growth eight, and `t=3x-y` with lower boundary zero.
Lower band C has stable rows

```
0: NR; 1: WR,WL; 2: NR,SL,NR;
3: WR,WL,ER,WL,WR; 4: SR,SL,SR.
```

Its fixed wakes are `0,2,3,4`. The upper (1,2,3) cap has fixed wakes
`W-2,W` and quiet offset one. The earlier cap and width results imply
`W>=18`, quiet upper offset three, and quiet lower levels five, seven
and eight. See `positive_skew_cap_reduction_2026-09-30.md` and
`positive_skew_width16_exclusion_2026-09-30.md`.

The following seven integer families are **exactly** the endpoint wake sets
passing P22, rank and moment under these assumptions. They are necessary
wake shadows, not periodic ant traces. Their full chronology remains open.

## Classification

Let O be the complete eight-wake set. The table lists the residual wakes
after the lower and upper fixed bands. In the first four rows, upper offset
four is quiet, and the fixed set is `F={0,2,3,4,W-2,W}`. In the last
three rows, upper offset four is wake, and the fixed set is
`F={0,2,3,4,W-4,W-2,W}`. In all rows `O=F union residual`, `W>=18`,
and m,p,q are integers.

| Upper offset four | Width | Residual wakes | Bounds and parity |
|---|---|---|---|
| quiet | `W=6m` | `{6q,6p+2}` | `1<=q<=p<=m-2`, p+q odd |
| quiet | `W=6m+2` | `{6q,6p+4}` | `1<=q<=p<=m-2`, p+q even |
| quiet | `W=6m+4` | `{6q,6p}` | `1<=q<p<=m-1`, p+q even |
| quiet | `W=6m+4` | `{6q+3,6p+3}` | `1<=q<p<=m-1`, p+q odd |
| wake | `W=6m` | `{6q}` | `1<=q<=m-1`, m+q even |
| wake | `W=6m+2` | `{6q}` | `1<=q<=m-1`, m+q odd |
| wake | `W=6m+4` | `{6q}` | `1<=q<=m-1`, m+q even |

Each row has unbounded arithmetic realizations. For example increasing m
by two while fixing p,q preserves parity and all bounds, moving the upper
fixed band by twelve. This proves unbounded endpoint freedom, not a
periodic extension of stable visit words.

## Completeness from fibre signs

At a wake level t, use `j=-t mod3`, `n=ceil(t/3)`, and checker sign
`(-1)^t`. P22 requires signed sum `2 mod4` in every fibre. With eight
wakes the unsigned sizes are a permutation of `4,2,2`; a four-class fibre
has a `3+1` sign split, while each two-class fibre has uniform sign.

If upper offset four is quiet, there are two residual wakes, both strictly
between level four and `W-4`. For `W=0 mod6`, the fixed fibre counts and
signs force one positive fibre-zero residual (`6q`) and one positive
fibre-one residual (`6p+2`). For `W=2 mod6`, they force positive
fibre-zero and fibre-two residuals (`6q,6p+4`). For `W=4 mod6`, both
residuals are in the mixed lower fibre zero, with a common sign: either
both `6q,6p`, or both `6q+3,6p+3`. These alternatives exhaust P22.

If upper offset four is wake, each upper width residue places one extra
positive endpoint in every fibre. Fibre zero then has three fixed wakes
of signed sum one, and the others each have two positive wakes. P22
forces the sole residual into fibre zero with positive sign, so `6q`.
There is no other fibre/sign choice.

All displayed bounds follow from distinctness and
`4<residual<W-4`. In the two different-fibre quiet-offset-four cases,
the rank condition further forces `q<=p`, as shown next. Same-fibre
residual pairs can be ordered with `q<p` without loss.

## Rank and moment

The positive-skew rank is the parity of increasing-fibre pairs in the
ordered transverse wake list. This follows directly from
`n_i<n_j iff 3n_i-i<3n_j-j` for i<j, including tied longitudinal values.

For the first two families, the fixed wake word has odd rank. The sum
of each residual's interactions with the fixed bands is even, so the
mutual residual pair must contribute one. It does so exactly when the
fibre-zero wake comes before the other residual, equivalently `q<=p`.
The remaining five families have even fixed rank and even residual cross
terms; rank adds no further condition.

For the additive moment `M=sum_O (-1)^t ceil(t/3)`, the seven cases give:

| Case in table order | M modulo four |
|---|---|
| 1 | `3+2(p+q)` |
| 2 | `1+2(p+q)` |
| 3 | `1+2(p+q)` |
| 4 | `3-2(p+q)` |
| 5 | `1+2(m+q)` |
| 6 | `3+2(m+q)` |
| 7 | `1+2(m+q)` |

Requiring M=1 gives exactly the parity column. Thus P22, rank and moment
yield every restriction in the table, and direct substitution proves
their sufficiency for those arithmetic conditions. Nothing here asserts
sufficiency for P3 or for a single physical period.

## Audit and remaining mathematical step

```
python work_positive_skew_root_20260930/verify_fatC_upperF123_families.py
```

The independent direct-coordinate audit exhausts all residual positions
at every even width 18 through 120 and compares them with the seven
formulas. It finds exactly 2,279 accepted endpoint sets, with no mismatch.
It also checks every one of the 23 independently generated unbounded
examples from the complete two-cap residue dynamic program. The fresh
run passes. These finite checks regress the formulas; the preceding
fibre/rank/moment derivation establishes their all-width scope.

The local lower and upper word frontiers still contain continuations
compatible with these wake families. Closing this cap pair requires an
argument about the coupled ordered visits across its arbitrary gaps.
Closing the whole `(1,3)` orbit also requires all other remaining lower
bands and upper cap pairs. This endpoint classification closes neither.
