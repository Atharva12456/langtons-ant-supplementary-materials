# Remaining lower-thin arithmetic after the new upper lemmas

Update: the subsequent
[stronger local obstruction](positive_skew_upper_thin_quiet34_requires_quiet5_2026-10-01.md)
excludes upper F122 quiet three/four with wake five altogether. Both
000/010 families in section 1 are therefore now excluded at every
width and period. Section 1 and its DP counts preserve the intermediate
arithmetic classification. The five allquiet families in section 2
remain unresolved. A further
[quiet-six/wake-seven exclusion](positive_skew_upper_thin_quiet6_requires_quiet7_2026-10-01.md)
removes another 1,036 residue templates, leaving 5,222 in the complete
remaining-thin/upper-F122 package. The report for this stage is
`results/positive_skew_remaining_thin_upperF122_residues_2026-10-01.json`;
section 3 preserves its intermediate 6,264-template classification.

The subsequent
[thin101/110 upper-six exclusion](positive_skew_thin101_110_upper6_exclusion_2026-10-01.md)
removes both members under upper wakes `{0,6}` through eight, leaving
5,210 templates. The report for this later stage is
`results/positive_skew_remaining_thin_upperF122_residues_2026-10-01_d.json`.
The earlier counts remain historical arithmetic stages, not current
survivor counts.

Use literal drift `(1,3)`, growth eight, lower transverse boundary zero,
and `t=3x-y`. Lower thin has wakes zero and four and quiet levels one,
two and three. Its lower bits mean `(omega5,omega6,omega7)`.
The `111` branch is already excluded. This note works with the other
seven branches and an upper F122 cap. Root inspected the independent
checker and hand derivations and reran the complete coordinate and
unbounded-residue audits successfully. This is a research continuation;
the paper files were not edited.

There are two useful new restrictions, both valid for all widths:

1. If upper offsets three and four are quiet and five is wake, the
   only possible lower bits are `000` or `010`, and `W=2 mod6`.
   The exact endpoint shadows are the two compact families below.
2. If upper offsets three through seven are quiet, the newly forced
   wake at eight restricts lower `011` to W four modulo six, lower
   `101` to W zero modulo six, and lower `110` to W zero or four
   modulo six. Five compact families give the exact endpoint shadows.

These are necessary arithmetic and local chronology restrictions.
Accepted shadows remain unbounded and do not establish turn-word
extensions or periodic ant traces. The full orbit remains open.

## 1. Upper wake five allows only lower 000 or 010

The previously proved weak local upper lemmas imply

```
upper F122, quiet3,quiet4,wake5
  => wake6,quiet7,wake8.
```

Here the full upper wake pattern through eight is `{0,5,6,8}`.
No growth restriction, period bound, P22, period congruence, or stable
gap four is used in those local lemmas; their small prefix
classification is computer-assisted.

First handle possible cap overlap. Eight wakes plus the known quiet
lower levels one,two,three imply even W>=10. W=10 is impossible because
the forced upper wake at eight would be lower quiet level two. For
W>=12, the five upper quiet positions at offsets `1,2,3,4,7` are
disjoint from the three lower quiet positions. Eight wakes and eight
distinct quiet positions imply W>=16. Thus the fixed lower wakes
zero,four and the four upper wakes are all distinct, and every upper
wake is above the lower band through seven. This uses only counting,
not the separate width-sixteen exclusion.

Let fibre be `j=-t mod3` and sign be `(-1)^t`. P22 at growth eight
has unsigned fibre sizes 4,2,2: its two-wake fibres have uniform sign,
and its four-wake fibre has a 3+1 sign split.

For W zero modulo six, the six fixed wakes give three positive
fibre-zero wakes and two positive/one negative fibre-two wakes. Each
of those fibres would have to be the four-wake fibre. This is impossible.
For W four modulo six, they give three positive fibre-two wakes and
an opposite-sign pair in fibre one, again requiring two four-wake fibres.

Thus W is two modulo six. The fixed fibre signs are

```
fibre0: 2 positive, 1 negative;
fibre1: 2 positive, 0 negative;
fibre2: 1 positive, 0 negative.
```

The two additional wakes must be one positive fibre-zero wake and
one positive fibre-two wake. A lower wake at five would be negative
in fibre one; a lower wake at seven would be negative in fibre two.
Both are impossible. Hence lower bits are exactly `000` or `010`.
This excludes every lower pattern having omega5=1 or omega7=1 under
the stated upper schedule, including five of the seven remaining branches.

Write W=6m+2. The exact endpoint families are:

| Lower bits | Complete wake set | Bounds and parity |
|---|---|---|
| 000 | `{0,4,6q,6p+4,W-8,W-6,W-5,W}` | `2<=q<p<=m-2`, p+q odd |
| 010 | `{0,4,6,6r+4,W-8,W-6,W-5,W}` | `2<=r<=m-2`, r even |

In the first row, the positive fibre-zero residual is `6q`; quiet
lower six gives q>=2. The fibre-two residual is `6p+4`. Both are
strictly below `W-8`, yielding the displayed upper bounds. The fixed
fibre word `0,2,0,1,0,1` has six increasing pairs. The residual
cross terms with fixed wakes add three, and their mutual pair adds
one iff `6q<6p+4`, equivalently q<=p. Thus rank is
`9+[q<=p]` and requires q<=p. Its moment is

```
3+2(p+q) mod4,
```

so p+q is odd; equality q=p is therefore impossible. In the second
row the fixed lower wake six supplies the extra positive fibre-zero
wake. Rank is ten, and the moment is `1+2r mod4`, giving r even.
The least permitted r is two.

The minimal endpoint widths are respectively W=32 and W=26, with
witnesses

```
000: {0,4,12,22,24,26,27,32};
010: {0,4,6,16,18,20,21,26}.
```

Increasing m by two while keeping p,q or r fixed moves the four
upper wakes by twelve and preserves every condition. These are
unbounded arithmetic families, not highways.

## 2. Quiet upper three through seven gives five tighter families

The other new weak local lemma says

```
upper F122, quiet offsets3..7 => wake8.
```

The upper outer pair at offsets one,two is also quiet, so its full
wake schedule through eight is `{0,8}`. W=10 would place the wake
at lower quiet level two. For W>=12, the seven upper quiet positions
at offsets one through seven are disjoint from lower quiet levels
one through three. Eight wakes plus ten quiet positions force even
W>=18. Thus the lower band through seven and upper band through
eight are disjoint without importing a bounded-width exclusion.

For lower `011`, `101`, or `110`, there are exactly two residual
wakes between level seven and `W-8`. With the fixed lower wakes
appropriate to the named bits and upper wakes `W-8,W`, the complete
endpoint families are:

| Lower bits | Width | Residual wakes | Bounds and parity | Minimal endpoint W |
|---|---|---|---|---:|
| 011 | `6m+4` | `{6p+2,6q-2}` | `1<=p<q<=m-1`, p+q odd | 22 |
| 101 | `6m` | `{6q-2,6p-1}` | `2<=q<=p<=m-2`, p+q odd | 30 |
| 110 I | `6m` | `{6p+3,6q-1}` | `1<=p<q<=m-2`, p+q odd | 24 |
| 110 II | `6m+4` | `{6p+2,6q+2}` | `1<=p<q<=m-2`, p+q even | 34 |
| 110 III | `6m+4` | `{6p-1,6q-1}` | `2<=p<q<=m-1`, p+q odd | 28 |

The fixed lower wakes are `{0,4,6,7}`, `{0,4,5,7}`, and `{0,4,5,6}`
respectively. No alternative width or fibre/sign assignment is omitted.
For 011, its mixed fibre two must be the four-wake fibre. Adding the
upper wake W or W-8 at width zero or two modulo six would also force
four wakes in fibre zero, so only width four is possible. For 101,
the lower mixed fibre two and negative fibre-one wake rule out widths
two and four. For 110, width two adds an opposite-sign pair in fibre
one and a third positive wake in fibre zero, which cannot both fit
4,2,2. At widths zero and four the indicated residual signs exhaust P22.

One can obtain the rows directly from the earlier tight lower/F123
classification. Replacing its fixed upper wake `W-2` by `W-8`
preserves fibre, sign, and its order after both residuals, but decreases
the moment by two. The P22 and rank arguments are unchanged; every
old parity flips, and requiring both residuals below `W-8` gives the
tighter bounds in this table. Their moments modulo four are respectively

```
3+2(p+q), 3+2(q-p), 3-2(p+q), 1+2(p+q), 3-2(p+q).
```

This establishes completeness and sufficiency for P22/rank/moment,
without implying any actual upper or lower chronological continuation.
Each family admits m increasing by two with the residual parameters
fixed, so no width bound is imposed.

## 3. Complete unbounded residue pruning for all seven lower bits

The independent checker also carries out a finite residue dynamic
program for lower bits `000` through `110` and all saved necessary
upper-F122 wake patterns through seven, allowing either bit at eight.
Its alphabet is t modulo twelve, preserving sign, fibre, additive
moment and the ordered increasing-fibre rank. It imports neither the
old arithmetic checker nor the frontier engine.

For W>=18 the two cap bands are disjoint. The remaining bulk letters
represent arbitrary strictly ordered positions in `[8,W-9]`. Every
accepted residue template has a greedy realization at arbitrarily large
W: choose bulk positions with their specified residues, and choose W
in its even residue class at least nine above the last bulk position.
Moving the upper band by twelve preserves all conditions. Conversely,
every endpoint set with these cap schedules maps to one tested template.
Thus this is finite-alphabet enumeration of unbounded gaps, not finite
width enumeration.

The only possible smaller even widths are ten,twelve,fourteen,sixteen.
They are separately enumerated with the exact overlapping cap bands;
no accepted endpoint set occurs in this remaining-thin/F122 package.
This is a finite overlap check, not a width cutoff for the large-width
classification.

The new local lemmas remove the quiet-eight variant of upper patterns
`10000000` and `10000110` through seven. Their other necessary patterns
are unchanged. For fixed lower and upper bands through eight, the exact
residue-template counts are:

| Lower bits | Before these new lemmas | After |
|---|---:|---:|
| 000 | 16,634 | 5,074 |
| 001 | 960 | 316 |
| 010 | 1,328 | 424 |
| 011 | 48 | 14 |
| 100 | 1,478 | 386 |
| 101 | 54 | 14 |
| 110 | 174 | 36 |
| total | 20,676 | 6,264 |

These count arithmetic residue templates, not wake placements, traces,
or turn-word realizations. The upper source is the complete saved
`upper_all_strong_depth7.json`; its source hash is retained in the report.
For the new `{0,5,6,8}` upper schedule, exactly four residue templates
remain under lower000 and two under lower010, agreeing with the two
compact formulas. For upper `{0,8}`, lower011/101/110 have respectively
4,4,12 templates, agreeing with the five compact formulas.

## 4. Reproduction and scope

### Continuation, 2 October 2026

The earlier tables describe the dated arithmetic snapshot. After the
stronger quiet-three/four lemma and the all-width thin101/110 upper-six
exclusions, the remaining count was 5,210. The new
[generic upper-F122 wake-three/four exclusion](positive_skew_upper_thin_wake34_quiet567_exclusion_2026-10-02.md)
removes the whole quiet-five/six/seven schedule, for both bits eight.
It deletes another 96 templates, leaving **5,114** in
`results/positive_skew_remaining_thin_upperF122_residues_2026-10-02_e.json`:
lower000 4,158; 001 252; 010 336; 011 ten; 100 330; 101 ten; 110 eighteen.
Lower111 stays excluded. These are exact unbounded arithmetic residues,
not trajectories or a completion percentage.

The [high-thin endpoint classification](../work_positive_skew_high_thin_endpoints_20261002/high_thin_endpoint_families.md)
gives seven exact compact one-residual families and two arithmetic
exclusions, with a separate direct-coordinate audit of 64,534 sets.
In particular lower110/F122 wake-three/four forces quiet five through
eight and is now excluded by the new generic lemma. Lower011/F123
wake six forces quiet eight through thirteen; lower110/F122 wake four
and seven forces quiet eight through sixteen. These remaining schedules
still require chronology, and incomplete local extensions exclude none.

```
python work_positive_skew_remaining_thin_arithmetic_20261001/audit_remaining_thin.py
```

The coordinate audit independently uses the original fibre longitudinal
coordinates and cross-fibre inequalities. It compares the seven compact
formulas against every candidate endpoint set in the named branches at
each even width ten through 180. All 1,504,375 candidate sets agree.
The accepted counts are 1,547 and 182 in the two upper-wake56 cases,
and 1,925,1,729,1,925,1,547,1,729 in table order for the upper-allquiet
cases. It confirms every minimal endpoint width and an unbounded
upper-band shift. Those finite tests regress the hand derivations;
they do not establish their all-width scope.

The exact DP report is `remaining_thin_residue_pruning.json` and the
coordinate report is `compact_family_coordinate_audit.json`. Every
accepted large-width template retains an unbounded endpoint witness.
No whole lower-bit branch other than the previously excluded111 is
claimed closed here, and no endpoint-only calculation proves a highway.
