# The lower-missing / upper-guard cap pair is impossible

Later result (9 September 2026): [the complete guard/missing exclusion](odd_skew_guard_missing_complete_exclusion_2026-09-09.md) closes both lower-guard / upper-missing families. The remaining-family statements below describe the earlier stage; the full drift orbit remains open.

Consider a growth-eight periodic trace with drift `(1,-3)`.  A missing cap has
outer multiplicities `(1,1,0)`; a guard cap has `(1,1,1)`.  The lower-missing /
upper-guard pair is impossible at every period.  The proof combines an exact
P3 return argument with the P22 and odd-skew rank conditions.  It uses neither
an additive moment condition nor a computer search.

Normalize the transverse levels to `0<=t<=W`.  Both extreme arrivals are
horizontal, so `W` is even.  Since the primitive drift has one translation
class per level, eight wake classes require `W>=8`.  Write `O` for the set of
wake levels.

## The local input

At a lower missing cap, the four-step cap calculation gives wake levels
`0,1,4`, with level two empty.  The strengthened same-cell return argument in
`odd_skew_excursions_and_domino_transfer_2026-08-31.md` proves

```text
omega_6+omega_7 >= 1.                                  (1)
```

For clarity, this argument does not assume an upper guard.  If levels five
through seven are even, the exact return paths force level nine to be wake,
regardless of level eight's parity.  P22 forbids that wake at growth eight.
If level five is wake while six and seven are even, a shorter four-step
same-cell return gives a contradiction.  These exhaust the two possibilities
for level five and prove (1).

## Residues and the rank sign

Let `O_j={t in O:t=j mod 3}`.  Up to one common sign, the checker sign at level
`t` is `(-1)^t`.  P22 says that the signed sum in every fibre is `2 mod 4`.
Each fibre therefore contains an even number of wake classes, at least two.

The wakes at levels one and four have opposite signs in the same fibre.
That fibre needs at least two more wakes.  Since there are eight in total,

```text
|O_0|=2,       |O_1|=4,       |O_2|=2.                 (2)
```

The two wakes in either two-class fibre have the same parity.  The odd-skew
rank theorem also gives

```text
I = sum_(i<j) #{(u,v) in O_i x O_j : u<v} = 0 mod 2.  (3)
```

The usual normalization labels these fibres by `(t+1) mod 3`.  Using `t mod 3`
in (3) is harmless: a cyclic relabelling reverses comparisons only across a
whole fibre, and every product of two fibre cardinalities is even.

## An upper guard forbids both levels six and seven

An upper guard contributes singleton wakes `W-2,W-1,W`.

If `W=1 mod 3`, the two-class fibre `O_0` contains level zero and level `W-1`.
Their parities are opposite, contrary to P22.

Suppose `W=6m`.  The entire fibre `O_0` is `{0,W}`, so level six is not wake.
The four-class fibre has the form

```text
O_1={1,4,a,W-2}.
```

Its extra level `a` must be even: levels one and four cancel, and `W-2` is
even.  Thus level seven is not wake either.

It remains to take `W=6m+2`.  At width eight the fibre containing levels one
and four has only the available levels `1,4,7`, too few for (2).  For larger
widths the residue sets must be

```text
O_0={0,W-2},
O_1={1,4,a,W-1},       a=1 mod 6,
O_2={b,W},             b=2 mod 6.
```

Here `a>=7`, while the empty level two gives `b>=8`; both extra levels lie
below the upper guard.  Directly counting the ordered cross-fibre pairs gives

```text
I_01=1,       I_02=1,       I_12=[a<b]       mod 2.
```

For example, the unreduced first two counts are five and three.  The last is
`6+[a<b]`.  Equation (3) therefore requires `b<a`, excluding `a=7`.
Also `O_0={0,W-2}` excludes level six once width eight has been removed.

Thus every possible width of a lower-missing / upper-guard trace makes both
levels six and seven non-wake.  This contradicts (1) and excludes the pair.

## The other homogeneous cap pairs

The same residue/rank calculation gives hand proofs of the two exclusions
previously recorded by the all-width invariant sieve.

For two missing caps, each opposite-sign wake pair at offsets one and four
requires a four-class fibre.  If the two pairs lie in different fibres, they
require at least `4+4+2=10` wake classes.  If they lie in the same fibre and
`W>8`, their four distinct signs cancel, rather than summing to `2 mod 4`.
At `W=8` the shared fibre has only the levels `1,4,7`, so it cannot contain
four wake classes.  Two missing caps are therefore impossible using P22
alone.

For two guard caps, six distinct wakes are fixed at

```text
0,1,2,W-2,W-1,W.
```

At widths `0` or `4 mod 6`, two fibres contain opposite-sign fixed pairs;
each needs two additional wakes, exceeding the remaining budget of two.
At width `2 mod 6`, all fixed pairs already have the required signed sum.
The two extra wakes must then lie in one fibre with opposite signs.
They make an even contribution to (3): both are between the fixed caps and
have the same residue, so their cross terms with the fixed wakes cancel.
The residue word of the six fixed wakes is `0,1,2,0,1,2`, whose rank sum is
nine, hence odd.  This contradicts (3).

Consequently, among caps restricted to missing or guard, the only orientation
not excluded is

```text
lower guard / upper missing.
```

This is not an exclusion of the whole `(1,-3)` orbit.  Caps with profiles
`(1,2,2)` or `(1,2,3)` remain outside this argument.  The surviving orientation
also has the static witness

```text
W=18,       O={0,1,2,8,13,14,17,18}.
```

Its signed fibre sums are `-2,2,-2`, its rank sum is even, and its normalized
additive moment is `-5=3 mod 4`.  These static checks do not construct a
periodic trace.  A further exact return lemma now rules out this placement:
upper offset five is wake while offsets six and seven are non-wake.

The surviving guard/missing wake placements are reduced to two parameter
families in `odd_skew_guard_missing_families_2026-09-03.md`.  That proof gives
width at least 20, and at least 30 when the width is divisible by six.  It
does not exclude the families at arbitrary width.
