# A hand proof that every missing cap has offset five even and offset six wake

**Status, 23 September 2026.** At drift `(1,-3)`, every missing cap `(1,1,0)`, lower or
upper, has

* inward offset five **non-wake** (`omega_5=0`), and
* inward offset six **wake** (`omega_6=1`),

at every period and every width. The first statement uses only same-cell first returns, so
it holds at both caps with the same proof. The second uses the same returns and exactly
one lifted-time inequality, which is different at the two caps. No P22, rank or moment
condition is used. No bound on the period, width, row length or black lifetime is used,
and neither is the rule that same-cell gaps are at least four: the clock is used only
through `N>0` and strict order within a row.

This replaces the enumeration behind `odd_skew_missing_cap_offset6_2026-09-23.md` by a
proof that can be checked by hand. It also extends the lower-cap statement
`omega_5=0` to the upper cap. The search frontiers quoted there (lower `2,1,2,3,8,4,14,0`,
upper `2,1,2,3,8,6,23,21,88,0`) die exactly where the proof below says they must: the
`omega_5=1` branch at level eight, the lower `omega_6=0` branch at level ten, and the upper
one at level twelve. The computer was used only to find the argument and to check the
finite claims listed in the last section.

## Conventions and the facts used

Measure inward offsets `t` from the cap. At the upper cap rotate every heading label by 180
degrees; turns are unchanged and the local port equations keep their form. A port is an
arrival heading and a turn. Even offsets carry `ER,EL,WR,WL`, odd offsets `NR,NL,SR,SL`.
Departures:

```text
ER->S  EL->N  WR->N  WL->S      NR->E  NL->W  SR->W  SL->E
shifts: E +3, W -3, N +1, S -1;     voltages: lambda(E)=+1, lambda(W)=-1, lambda(N)=lambda(S)=0.
```

`t:Xi` denotes the event at position `i` (counted from 0) of the stable word on offset `t`,
with port `X`. On one row we write `N_k`, `S_k`, `E_k`, `W_k` for its `k`-th north, south,
east, west *arrival* at the appropriate parity, except that on odd rows `W_k` is the `k`-th
**west departure** (an `NL` or an `SR`), and on even rows `D_k` is the `k`-th **south
departure** (an `ER` or a `WL`). Thus an `NL` is both an `N_j` and a `W_k`, an `SR` is both an
`S_j` and a `W_k`, an `ER` is both an `E_j` and a `D_k`.

We use only the following established facts.

1. **Alternation.** Every stable word starts with `R` and alternates `R,L`. Equivalently,
   consecutive visits to one cell have opposite turns; the excess `#R-#L` is `omega_t`.
2. **Ordinal matching.** The `k`-th departure with heading `h` from offset `t` feeds the
   `k`-th arrival with heading `h` on offset `t+shift(h)`.
3. **First return.** Follow successors from an event `x` on offset `t`, keeping the copy
   counter (sum of voltages). If the walk reaches offset `t` with copy counter zero, and did
   not do so earlier, it lands on the event immediately after `x` in the stable word; in
   particular `x` is not the last event. Together with 1, the landing event has the turn
   opposite to that of `x`. All returns below have zero displacement, so this fact is the
   same at both caps.
4. **Counts.** At even `t` with `a` east arrivals and `d` south departures,
   `ER=er, EL=a-er, WL=d-er, WR=omega_t+a+d-3er`. At odd `t` with `b` north arrivals and
   `c` west departures, `NR=b-nl, NL=nl, SR=c-nl, SL=b+c-3nl-omega_t`.
5. **Lifted clock.** `tau(target)=tau(source)+1+sigma*N*lambda`, with `sigma=-1` at the lower
   cap and `sigma=+1` at the upper cap, and the events of a stable word have strictly
   increasing `tau`. Only `N>0` is used. Along a walk of `L` steps and net voltage `Lambda`
   the clock gives `tau(end)=tau(start)+L+sigma*N*Lambda`.
6. **Cap rows.** A missing cap has the rows

   ```text
   0: WR      1: NR      2: (empty)      3: SR,SL      4: WR,WL,ER
   ```

   with `0:WR->1:NR`, `1:NR->4:ER`, `3:SR->0:WR`, `3:SL->` the unique east arrival on six,
   `4:WR->N_1(5)`, `4:WL->3:SR`, `4:ER->3:SL`. Offset seven has exactly two west departures,
   feeding `4:WR` and `4:WL` in that order.

## 1. Four local tools

### 1.1 Start rule

The first event of an odd row is an `R`, so it is an `NR` or an `SR`. If it is an `NR` it is
`N_1`; if it is an `SR` it is `W_1`. Hence **the first event of an odd row is `N_1=NR` or
`W_1=SR`**; in particular `N_1=W_1` (an `NL`) is impossible. Likewise the first event of an
even row is a `WR` (then it is the first west arrival and the first north departure) or an
`ER` (then it is `E_1=D_1`).

### 1.2 Square lemma

*Let `t` be odd and suppose rows `t-3` and `t-2` begin with `WR` and `NR`. If `W_1` of row
`t` is an `SR`, then `W_1` is immediately followed by an `SL` on row `t`, and on row `t+1`
the south departure feeding `W_1` is a `WL` immediately followed by `E_1=ER`.*

*Proof.* `W_1` feeds the first west arrival of row `t-3`, its first event `WR`. That event is
the first north departure there, so it feeds `N_1` of row `t-2`, its first event `NR`, which
is the first east departure there and feeds `E_1` of row `t+1`. Let `V` be the south
departure on `t+1` feeding `W_1`. The walk

```text
V -> t:W_1 -> (t-3):WR -> (t-2):NR -> (t+1):E_1          directions S,W,N,E
```

has zero displacement and meets no event of row `t+1` in between, so `E_1` is the visit right
after `V`, with opposite turn. `V` is `ER` or `WL`; an `ER` would be an east arrival before
`E_1`. So `V=WL` and `E_1=ER`. Then `E_1` departs south, and
`W_1 -> (t-3):WR -> (t-2):NR -> E_1 -> t` (directions `W,N,E,S`) is a first return on row
`t`: the event after `W_1` is a south arrival with turn `L`, an `SL`. QED

### 1.3 The two-west lemma (Lemma M)

*Let `t` be odd with rows `t-3`, `t-2` beginning `WR`, `NR`. Suppose*

* *(H2) some forced first return shows that `N_2` is the event immediately after `W_2`, and*
* *(H3) `N_2` is not `W_3` (this holds vacuously if row `t` has only two west departures).*

*Then no stable word exists on row `t`.*

*Proof.* By (H2) the turns of `W_2` and `N_2` are opposite. If `W_2=SR` then `N_2=NL`; it
departs west and comes right after `W_2`, so it is `W_3`, contrary to (H3). Hence `W_2=NL`
and `N_2=NR`. The `NL` is a north arrival immediately before `N_2`, so `W_2=N_1`. Then `W_1`
precedes `N_1` and is not a north arrival: `W_1=SR`. By the start rule the first event is
`N_1` or `W_1`; `N_1` is an `L`, so the row starts with `W_1=SR`. The square lemma puts an
`SL` in position 1. Position 2 must be an `R`. An `SR` there would be `W_2`, which is an
`NL`; an `NR` there would be a north arrival earlier than the first north arrival `N_1`
(which is at position 2 or later and is an `L`). The row has at least three events, so this
is a contradiction. QED

Lemma M uses row `t+1` only through the square lemma.

### 1.4 The eight-step return on offset seven

Row three has a single east departure `3:SL`, so row six has a single east arrival `6:E_1`.
If it is an `EL`, the walk

```text
7:W_2 -> 4:WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER -> 3:SL -> 6:E_1=EL -> 7:N_k       WSWNESEN
```

is a first return (offsets `4,3,0,1,4,3,6` in between), where `k` is the rank of `6:EL`
among the north departures of row six. **Hence `W_2` of row seven is immediately followed
by `N_k`, with opposite turn.** The same walk from `7:NL3` is used below.

## 2. Offset five is non-wake (both caps)

Suppose `omega_5=1`. Row five has one north arrival (from `4:WR`) and no west departure (row
two is empty), so its counts are `NR=1`, `SL=1-omega_5=0`: **row five is `NR`**. Row six has
one east arrival and no south departure, so `(ER,EL,WR,WL)=(0,1,1+omega_6,0)` and **row six is
`WR,EL` or `WR,EL,WR`**. Its `EL` is the second north departure, so the eight-step return
gives (H2) on row seven. Row seven has only two west departures, so (H3) holds. Rows four and
five begin `WR`, `NR`. Lemma M at `t=7` gives a contradiction. **Hence `omega_5=0`, at either
cap.** QED

(The contradiction needs row eight only through the square lemma, which is why the search
frontier `1,1,1,2,4,0` for levels `3..8` dies at level eight.)

## 3. Offset six is wake

From now on `omega_5=0`, so **row five is `NR,SL`** (`5:NR->E_1(8)`, `5:SL->E_2(8)`). Suppose
`omega_6=0`. Row six has `a=1`, `d=1`; `er=1` would give `WR=-1`, so the counts are
`(ER,EL,WR,WL)=(0,1,2,1)` and row six is

```text
A: WR,EL,WR,WL        or        B: WR,WL,WR,EL.
```

### 3.1 Order A

The `EL` is the second north departure, so the eight-step return gives (H2) on row seven,
which has two west departures. Lemma M at `t=7` excludes A.

### 3.2 Order B forces row seven

Now `6:EL3` is the third north departure, so `W_2` of row seven is immediately followed by
`N_3`, with opposite turn. If `W_2=SR`, then `N_3=NL` would be a third west departure; row
seven has two. So `W_2=NL`, `N_3=NR`, and `W_2=N_2`. If `W_1` were an `NL` it would be `N_1`,
against the start rule; so `W_1=SR`. If `N_1` were an `NL`, it would be a west departure
before `W_2=N_2`, hence equal to `W_1`, which is an `SR`; so `N_1=NR`. Row seven has three north arrivals (from
`6:WR0,WR2,EL3`) and two west departures, so it contains one `SR`, one `NL`, two `NR`, and
`2-omega_7` further `SL` (from the excess). The square lemma (rows four and five begin `WR`,
`NR`) makes `SR` immediately followed by `SL`.

Place the alternating word, which has at most six events. The pair `NL,N_3` occupies an odd
and the next even position, so it is at `1,2` or `3,4`. At `1,2`, position 0 would have to be
both `N_1` and `W_1`. So `NL,N_3` are at `3,4`; positions `0,2` hold `W_1` and `N_1`, and `W_1` must be at 0 because its `SL`
follows it. Therefore

```text
7: SR0, SL1, NR2, NL3, NR4, [SL5]          (SL5 present iff omega_7=0),
```

with `6:WR0->7:NR2`, `6:WR2->7:NL3`, `6:EL3->7:NR4`, `7:SR0->4:WR`, `7:NL3->4:WL`, and east
departures `SL1,NR2,NR4,[SL5]` feeding `E_1,E_2,E_3,[E_4]` of row ten. The eight-step return
from `7:NL3` lands on `7:NR4`.

### 3.3 Row eight is P or Q

By the square lemma at `t=7`, the south departure `D_1` of row eight (it feeds `7:SR0=S_1`)
is a `WL`, immediately followed by `E_1=ER`; so `E_1=D_2`. Row eight has two east arrivals
and `3-omega_7` south departures, so

```text
(ER,EL,WR,WL) = (er, 2-er, omega_8+5-omega_7-3er, 3-omega_7-er),     er>=1, WL>=1.
```

By the start rule row eight begins with a `WR` (an `ER` there would be `E_1=D_1`). An event
before `D_1` is not a south departure, and not an east arrival (it would precede `E_1`), hence
a `WR`; alternation allows only one: row eight begins `WR0,WL1,ER2`. If `er=2`, then `WL>=1` forces `omega_7=0`
and `WR=omega_8-1`, so `WR<=0`, contradicting `8:WR0`. Hence `er=1` and the remaining events
are `EL` (`=E_2`), `1-omega_7` more `WL` and `omega_8+1-omega_7` more `WR`, alternating:

```text
omega_7=1:   8: WR0, WL1, ER2, EL3, [WR4]                       (type P)
omega_7=0:   P: WR0, WL1, ER2, EL3, WR4, WL5, [WR6]
             Q: WR0, WL1, ER2, WL3, WR4, EL5, [WR6]              (final WR iff omega_8=1).
```

In both types `8:WL1->7:SR0`, `8:ER2->7:SL1`, `5:NR->8:ER2`, `5:SL->8:E_2`.

**Three walks out of row nine.** Row nine has exactly three west departures (row six has three
west arrivals `WR0,WL1,WR2`). By ordinal matching, in both types:

```text
(alpha)  9:W_1 -> 6:WR0 -> 7:NR2 -> 10:E_2                                        W N E
(beta)   9:W_2 -> 6:WL1 -> 5:SL -> 8:E_2 (an EL) -> 9:N_k                           W S E N
(gamma)  9:W_3 -> 6:WR2 -> 7:NL3 -> 4:WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER -> 3:SL
               -> 6:EL3 -> 7:NR4 -> 10:E_3                                        W N W S W N E S E N E
```

where `k` is the rank of `8:E_2` among the north departures of row eight (`k=2` in P, where
`8:E_2=EL3`; `k=3` in Q, where `8:E_2=EL5`). If `10:E_2` (resp. `10:E_3`) is an `ER`, the walk
`alpha` (resp. `gamma`) continues south to row nine and is a zero-displacement first return of
4 (resp. 12) steps. Walk `beta` is a first return of 4 steps.

### 3.4 Type P is impossible (both caps)

* **P1.** By `beta` with `k=2`, `W_2` is immediately followed by `N_2`, with opposite turn.
* **P2.** If `W_2=NL`, then `N_2=NR` and `W_2=N_1`. Then
  `8:WR0 -> 9:N_1=W_2 -> 6:WL1 -> 5:SL -> 8:EL3` (`N W S E`) is a first return on row eight,
  so `WR0` would be followed by `EL3`; it is followed by `WL1`. Hence `W_2=SR`, `N_2=NL`, and
  `N_2` is the next west departure: `N_2=W_3`.
* **P3.** `10:E_3=EL`: otherwise `gamma` returns to row nine right after `W_3=NL` at a south
  arrival with turn `R`, an `SR`, which would be a fourth west departure.
* **P4.** Let `J` be the south departure of row ten feeding `W_2=SR`. The walk
  `J -> 9:W_2 -(beta)-> 9:N_2=W_3 -(gamma)-> 10:E_3` has 16 steps
  `SWSENWNWSWNESENE`, zero displacement, and no intermediate visit to offset ten. So `E_3` is
  the event right after `J`, with opposite turn: `J=ER`, an east arrival immediately before
  `E_3`, i.e. `J=E_2`.
* **P5.** Now `alpha` returns: `9:W_1 -> 6:WR0 -> 7:NR2 -> 10:E_2=J -> 9:W_2`. So `W_2`
  immediately follows `W_1` with opposite turn: `W_1=NL`. It is a north arrival before
  `W_2<N_2`, hence `W_1=N_1`.
* **P6.** Then `8:WR0 -> 9:N_1=W_1 -(alpha)-> 10:E_2 -> 9:W_2 -> 6:WL1 -> 5:SL -> 8:EL3`
  (`NWNESWSE`, offsets `9,6,7,10,9,6,5` in between) is a first return on row eight landing on
  `EL3`, whereas `8:WR0` is followed by `WL1`. Contradiction.

No clock and no count beyond "three west departures on row nine" was used, and no parity of
offsets `7..10` was assumed. **Type P is impossible at both caps**; this explains why the lower
frontier dies at level ten.

(This re-proves, more briefly and with no parity assumption on offsets `7..10`, the
September 1 lower-cap results of `odd_skew_excursions_and_domino_transfer_2026-08-31.md`,
whose level-nine and level-ten arguments used the 12- and 16-step walks above for particular
count rows.)

### 3.5 Type Q at the lower cap

Type Q needs `omega_7=0`, so `7:SL5` exists and `8:WL3=D_3` feeds it. Put `c=tau(6:WL1)` and
`b=tau(6:WR2)`, so `c<b`. With `sigma=-1`:

```text
tau(8:EL5) = c + 2 - N                       (6:WL1 -> 5:SL -> 8:EL5, two steps, voltage +1)
tau(7:NL3) = b + 1,   tau(7:NR4) = b + 9      (6:WR2 -> 7:NL3; eight-step return)
tau(8:WL3) = tau(7:SL5) - 1 > tau(7:NR4) - 1 = b + 8.
```

Hence `tau(8:EL5) < b+2-N < tau(8:WL3)`, while Q lists `WL3` before `EL5`. **Type Q is
impossible at the lower cap.** (This is the inequality of the September 1 note.)

This completes the lower cap: **a lower missing cap has `omega_6=1`.**

### 3.6 Type Q at the upper cap

At the upper cap (`sigma=+1`) the inequality of 3.5 is void, and Q must be followed further.
In Q the north departures of row eight are `WR0,WR4,EL5,[WR6]`, so `beta` has `k=3`:

* **Q0.** `W_2` of row nine is immediately followed by `N_3`, with opposite turn.

**Clock fact (upper cap only).** `tau(9:N_1) < tau(9:W_1)`. Put `p=tau(4:WR)`, `q=tau(6:WR0)`.

```text
4:WR -> 5:NR -> 8:ER2 -> 7:SL1          tau(7:SL1) = p + 3 + N
7:SR0 -> 4:WR,  8:WL1 -> 7:SR0          tau(8:WL1) = p - 2 + N
8:WR0 before 8:WL1, 8:WR0 -> 9:N_1      tau(9:N_1) < p - 1 + N
6:WR0 -> 7:NR2 after 7:SL1              q + 1 > p + 3 + N
9:W_1 -> 6:WR0 (a west step)            tau(9:W_1) = q - 1 + N > p + 1 + 2N.
```

So `tau(9:W_1)-tau(9:N_1) > N+2 > 0`. Consequently `N_1` is not a west departure:
**`N_1=NR`**, and it precedes every west departure.

**Case II: `W_2=SR`.** By Q0, `N_3=NL`, the next west departure: `N_3=W_3`. Steps P3, P4 and P5
apply verbatim, with `beta` now ending at `N_3=W_3` (the 16-step walk is
`J -> 9:W_2 -(beta)-> 9:N_3=W_3 -(gamma)-> 10:E_3`): `10:E_3=EL`, the feeder `J` of `W_2` is
`E_2=ER`, and `W_1=NL` is immediately followed by `W_2`. The north arrival `W_1` precedes `N_3` and is not
`N_1` (clock fact), so `W_1=N_2`.

* *Row nine begins `NR, NL, SR, NL`.* By the start rule the first event is `N_1=NR` (`W_1` is
  an `NL`). Between `N_1` and `W_1=N_2` lie no north arrivals and no west departures, hence at
  most `SL`s; an `SL` after `N_1` would need an `R` next, and none is available before `W_1`.
  So `N_1,W_1,W_2,W_3` are positions `0,1,2,3`.
* *Row ten begins `WR, EL, ER, EL`.* `W_2` is the first south arrival of row nine, so
  `J=E_2=D_1`. Then `E_1` precedes `D_1`, so it is not an `ER`: `E_1=EL`. The first event is a
  `WR` (an `ER` would be `E_1`). Events before `E_1` are west arrivals that are not south
  departures, so exactly one `WR` precedes `E_1`. After `E_1` comes an `R`; a `WR` would need
  an `L` next, which would be an east arrival (`E_2`, an `ER`) or a south departure before
  `D_1`. So positions `2,3` are `E_2=ER`, `E_3=EL`. The north departures of row ten begin
  `WR0, EL1`, and `10:EL1=E_1` is fed by `7:SL1`.

**Case I: `W_2=NL`.** By Q0, `N_3=NR` and `W_2=N_2`. If `W_1` were an `NL` it would be `N_1`,
against the clock fact; so `W_1=SR`.

* *Row nine begins `NR, SL, SR, NL, NR`.* By the clock fact the row starts with `N_1=NR`.
  No `R` lies strictly between `N_1` and `W_2`, except `W_1`: an `NR` there would be a north
  arrival between `N_1` and `N_2=W_2`, and an `SR` there would be a west departure before
  `W_2`, hence `W_1`. By alternation exactly one `L` lies between `N_1` and `W_1`; it is not a
  north arrival, so it is an `SL`. Nothing lies between `W_1` (an `R`) and `W_2` (an `L`):
  the events there contain no `R`, so they would be a single `L` followed by the `L` `W_2`. So
  `N_1, SL, W_1, W_2, N_3` are at positions `0..4`.
* *Row ten begins `WR, WL, ER, EL`.* If `10:E_2` were an `ER`, walk `alpha` would return to
  row nine right after `W_1=9:SR2` at a south arrival, but `9:NL3` follows. So `E_2=EL`. Let
  `K` be the south departure feeding `9:SR2`, the second south arrival: `K=D_2`. The walk
  `K -> 9:SR2 -> 6:WR0 -> 7:NR2 -> 10:E_2` (`S W N E`) is a first return, so `K` is an `R`
  immediately before `E_2`: `K=ER=E_1`. `D_1` precedes `E_1` and is not an east arrival:
  `D_1=WL`. The first event is a `WR` (an `ER` would be `E_1=D_1`, but `E_1=D_2`); before
  `E_1` the only south departure is `D_1`; alternation forces `WR, WL, ER=E_1, EL=E_2`. The
  north departures of row ten begin `WR0, EL3`; `10:EL3=E_2` is fed by `7:NR2`, and
  `10:ER2=D_2` feeds `9:SR2=W_1`.

**Lemma M at `t=11` (both cases).** Rows eight and nine begin with `WR` and `NR`. Row eleven
has west departures feeding `8:WR0, WL1, WL3, WR4, [WR6]`; in particular `W_3(11)->8:WL3->7:SL5`
(`8:WL3=D_3` feeds `S_3(7)=SL5`).

* (H2), case II:
  `11:W_2 -> 8:WL1 -> 7:SR0 -> 4:WR -> 5:NR -> 8:ER2 -> 7:SL1 -> 10:EL1 -> 11:N_2`
  (`WSWNESEN`).
* (H2), case I:
  `11:W_2 -> 8:WL1 -> 7:SR0 -> 4:WR -> 5:NR -> 8:ER2 -> 7:SL1 -> 10:ER2 -> 9:SR2 -> 6:WR0
  -> 7:NR2 -> 10:EL3 -> 11:N_2` (`WSWNESESWNEN`).

  Both walks have zero displacement and no intermediate visit to offset eleven.
* (H3), case II: if `N_2(11)=W_3(11)`, then `7:SL1 -> 10:EL1 -> 11:W_3 -> 8:WL3 -> 7:SL5`
  (`E N W S`) is a first return on row seven, so `SL1` would be followed by `SL5`; it is
  followed by `NR2`.
* (H3), case I: if `N_2(11)=W_3(11)`, then `7:NR2 -> 10:EL3 -> 11:W_3 -> 8:WL3 -> 7:SL5` makes
  `NR2` followed by `SL5`; it is followed by `NL3`.

Lemma M gives a contradiction. **Type Q is impossible at the upper cap**, and therefore **an
upper missing cap has `omega_6=1`.** QED

The self-similarity is worth recording: in upper type Q, rows `8..11` play the part that rows
`4..7` play in the proof of `omega_5=0`, and the same Lemma M finishes both. The search
frontier `...,23,21,88,0` dies at level twelve because Lemma M needs row twelve only through
the square lemma; every level-eleven survivor of that search begins `SR,NL,NR`, the shape
forced in the proof of Lemma M just before the square lemma is applied.

## 4. Summary of what is used where

| Step | Returns | Counts | Clock |
|---|---|---|---|
| `omega_5=0` (both caps) | square, eight-step | rows 5, 6 | none |
| order A | square, eight-step | row 6 | none |
| rows 7, 8 | square, eight-step | rows 7, 8 | none |
| type P (both caps) | `alpha`, `beta`, `gamma`, 16-step, 8-step | "three west departures on row 9" | none |
| type Q, lower | eight-step | none | `tau(8:EL5)<tau(8:WL3)`, `sigma=-1` |
| type Q, upper | `alpha`,`beta`,`gamma`, 16-step, Lemma M at 11 | "three west departures on row 9" | `tau(9:N_1)<tau(9:W_1)`, `sigma=+1` |

Only `N>0` and strict order within rows are used from the clock.

## 5. Finite claims checked by computer

The checkers are in `code/python/` and need only Python:

* `python verify_missing_cap_hand_walks.py` follows every displayed walk by ordinal matching on
  the displayed (partial) rows. It checks each walk's direction word, its endpoint (heading,
  ordinal and, when known, position), its zero displacement where a return is claimed, and
  the step counts and net voltages behind the clock identities of 3.5 and 3.6. All checks pass.
* `python verify_missing_cap_hand_words.py` enumerates all alternating words with the stated
  counts. It confirms the word lists of sections 2 and 3.1-3.3 (rows six, seven, eight). In
  upper type Q, it also confirms two things. Every row-nine word satisfying the clock fact and
  Q0 begins `NR,SL,SR,NL,NR` (case I) or, after the P5 adjacency, `NR,NL,SR,NL` (case II).
  Every row-ten word satisfying the stated conditions begins `WR,WL,ER,EL` (case I) or
  `WR,EL,ER,EL` (case II).
* `python verify_missing_cap_lemma_m.py` confirms the combinatorial Lemma M by brute force for all
  odd-row counts with `2<=b<=7`, `2<=c<=6` (65,763 words; none satisfies the hypotheses). This is
  redundant with the hand proof.
* The earlier search frontiers (`verify_missing_cap_offset6_lemma.py`) only corroborate the
  proof; nothing above rests on them.

## 6. Consequences

* **Missing-cap wake pattern through offset six**, at both caps and every period: offsets
  `0,1,4,6` are wake and `2,3,5` are non-wake.
* The offset-six lemma (`odd_skew_missing_cap_offset6_2026-09-23.md`) now has a hand proof, and
  with it the impossibility of family M-II and the second proof that the lower band
  `(0,1,1,1,1)` has no upper missing cap.
* At the upper cap, `omega_5=0` is new in this generality. It contains the September 3 return
  lemma (offset five non-wake when six and seven are) and the rule used to remove `q=m-1` in
  guard/missing family I.
* The quiet upper-missing lemma (`odd_skew_upper_missing_quiet_band_2026-09-23.md`) is implied.
* Nothing here closes a cap pair by itself; the `(1,-3)` orbit remains open.
