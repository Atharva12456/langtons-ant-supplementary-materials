# Excluding the lower four-six wake band

At a lower `(1,2,2)` cap in the `(1,-3)` orbit, the band

```text
(omega_4,omega_5,omega_6)=(1,0,1)
```

is impossible. The forced tail from
`odd_skew_fat122_four_six_wake_order_2026-09-14.md` has a
twelve-step first return whose endpoints both turn right.
The contradiction is independent of the period and of all
later wake indicators.

Together with the earlier exclusions, this proves that every
lower `(1,2,2)` cap has wakes at both levels five and six.
The remaining early triples are `(0,1,1)` and `(1,1,1)`.
Neither those bands nor the other cap profiles in the orbit
are excluded by this note.

## The forced part of the tail

Use the notation and reductions of the preceding note. The
remaining level-seven word is

```text
SR,SL,SR,NL,SR,SL,SR,SL,NR,SL,NR,[SL]^(1-f).
```

The relevant tail on level eight is

```text
E3=ER,E4=EL,X1=WR,J=WL,E5=ER,E6=EL,X2=WR,K=WL,... .
```

The four west departures on level nine are
`D1=SR,D2=NL,D3=SR,D4=NL`, feeding the four west
arrivals `WL1,WR1,WL2,WR2` on level six. On level ten,
`F3=ER,F4=EL` are consecutive; they are supplied by
`7:SL3,NR2`. The preceding east arrival `F2` is supplied
by `7:SL2`, whose incoming predecessor is `8:E3`.

Let `P_J,P_X` be the west departures on level eleven
feeding `8:J,8:X2`. They are adjacent in west-departure
order, since no west arrival lies between `J` and `X2`.

## The north departure from F4 feeds P_X

The forced path from `P_J` is the sixteen-step first return

```text
11:P_J -> 8:J=WL -> 7:W5=SR -> 4:last WR -> 5:last NR
       -> 8:E5=ER -> 7:SL3 -> 10:F3=ER -> 9:D1=SR
       -> 6:WL1 -> 5:SL2 -> 8:E4=EL -> 9:D2=NL
       -> 6:WR1 -> 7:NR2 -> 10:F4=EL -> north arrival on 11.
```

Suppose `P_J=NL`. Its incoming predecessor `X` on level
ten is then the north departure immediately preceding
`F4`. Because `F3=ER,F4=EL` are consecutive, `X` precedes
`F3`. The beginning of the same path gives the eight-step
first return

```text
10:X -> 11:P_J=NL -> 8:J=WL -> 7:W5=SR -> 4:last WR
     -> 5:last NR -> 8:E5=ER -> 7:SL3 -> 10:F3=ER.
```

Its endpoints must be consecutive and have opposite turns,
so `X=F2=EL`. This forces the square return

```text
8:E3=ER -> 7:SL2 -> 10:F2=EL -> 11:P_J=NL -> 8:J=WL.
```

It skips the intervening stable events `E4,X1`, a
contradiction. Therefore `P_J=SR`. The endpoint of its
sixteen-step return is consequently the next stable event
`NL`. It is also the next west departure, namely `P_X`.
Thus the north departure from `10:F4=EL` feeds
`11:P_X=NL`, which feeds `8:X2=WR`.

## The twelve-step contradiction

Starting at `8:E5=ER`, the now prescribed path is

```text
8:E5=ER -> 7:SL3 -> 10:F3=ER -> 9:D1=SR -> 6:WL1
        -> 5:SL2 -> 8:E4=EL -> 9:D2=NL -> 6:WR1
        -> 7:NR2 -> 10:F4=EL -> 11:P_X=NL -> 8:X2=WR.
```

Its direction word is

```text
S E S W S E N W N E N W.
```

Taking the starting cell as `(0,0)`, the successive cells are

```text
(0,0), (0,-1), (1,-1), (1,-2), (0,-2), (0,-3), (1,-3),
(1,-2), (0,-2), (0,-1), (1,-1), (1,0), (0,0).
```

Thus the endpoint is the first return to the starting
physical cell, not merely a translated copy of it. Both
endpoint ports, `E5=ER` and `X2=WR`, turn right, whereas
successive visits to a cell must alternate their turns.
Equivalently, the forced return skips the stable event
`E6=EL` between them. This excludes the tail and hence
the entire `(1,0,1)` lower-cap band.

This last contradiction has zero displacement. Its use here
still depends on the preceding lower-orientation reductions;
the complete band exclusion has not been asserted for an
upper cap.
