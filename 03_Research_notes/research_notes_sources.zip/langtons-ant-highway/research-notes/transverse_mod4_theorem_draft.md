# Transverse mod-four level theorem — working draft (17–18 August 2026)

Historical draft, superseded by
[line_parity_research_2026-08-18.md](line_parity_research_2026-08-18.md).
The candidate status and unresolved checks below describe this earlier stage.

Status: **candidate theorem, under hostile audit.** Verified on the genuine
period-104 standard highway and by exhaustive check of every sub-lemma; the
sub-lemmas are elementary and analytic, so the claim is not a bounded search
result. Nothing here is promoted until the audit closes.

## 0. Setting and normalisation

A *periodic highway* is a bi-infinite ant trace with `p_{i+N} = p_i + d` for a
fixed nonzero drift `d` and ant period `N`, arising as the asymptotic regime of
a finite-support start. Throughout, `d` is diagonal and normalised so that
`d = (m,-m)` with `m >= 1`; quarter-turn rotations cover the other
diagonal signs.

Set the **transverse level**

```text
t = x + y,
```

which is constant along `d`. Every ant move changes `t` by exactly `+-1`,
because a move changes exactly one of `x,y` by `+-1`.

Write `f_t` for the number of period moves crossing the cut `(t,t+1)` upward and
`m_{t,r}` for the number of period events in the translation class
`(t, x mod m)`. Put `m_t = sum_r m_{t,r}`, the number of period events at
level `t`.

## 1. Three elementary sub-lemmas

**Lemma A (arrival axis is a function of level parity).**
Ant headings alternate between the horizontal and the vertical axis, because
every step turns by a quarter turn. Since `t` also changes parity at every
step, the axis of the move *arriving* at a cell is determined by the parity of
that cell's level. Normalise `t` so that **horizontal arrivals are exactly the
odd levels** (`C` levels); vertical arrivals are the even levels (`Q` levels).

*Exhaustively verified:* `sublemma_check.py`, all closed diagonal-drift
heading-reset words of every even length `<= 14`, 8,532 words, 0 failures.

**Lemma B (reflect/continue rule).**
With `t = x + y` and drift normalised so `d = (m,-m)`:

```text
odd  level (horizontal arrival, vertical departure):  R  <=>  t reverses,
even level (vertical arrival, horizontal departure):  R  <=>  t continues.
```

*Proof.* At an odd level the incoming heading is `E` or `W` and the outgoing is
`N` or `S`. Incoming `E` means `x` rose, so `t` rose; outgoing `S` means `y`
fell, so `t` fell. The right turn from `E` is `S`, so `R` reverses the sense of
`t`; the right turn from `W` is `N`, likewise a reversal. At an even level the
incoming heading is `N` or `S` and the outgoing is `E` or `W`; the right turn
from `N` is `E`, and both raise `t`, so `R` continues; the right turn from `S`
is `W`, and both lower `t`. []

*Exhaustively verified:* 114,520 individual step checks, 0 failures.
(The rule flips if one uses `t = x - y` for a drift with `ab > 0`; the
normalisation above is the one that makes the stated form correct.)

**Lemma C (flow at a level).**
Let `M_t` be the number of period events at level `t` that are local maxima of
`t` (arrive from below, leave downward) and `n_t` the number of local minima.
The quotient level walk is closed, so each cut is crossed equally often in both
directions, and counting the four incoming/outgoing combinations at level `t`
gives

```text
m_t = f_{t-1} + f_t,        M_t - n_t = f_{t-1} - f_t.
```

Hence the number of **reflections** at level `t`,

```text
rho_t := M_t + n_t,
```

satisfies `rho_t = M_t - n_t = f_{t-1} - f_t = f_{t-1} + f_t = m_t  (mod 2)`.

*Exhaustively verified:* 39,688 level checks, 0 failures.

## 2. The theorem

**Theorem (transverse mod-four level theorem).**
For a periodic highway with diagonal drift `d = (m,-m)`, at every transverse
level `t`,

```text
sum_r ceil (m_{t,r}/2) = m_t  (mod 2)     if t is odd,
sum_r floor(m_{t,r}/2) = m_t  (mod 2)     if t is even.
```

*Proof.* Because the translation class of a cell is `(t, x mod m)`, every cell
of the class `(t,r)` is visited exactly `m_{t,r}` times over all time: the
period events of that class are `(i_k, x_k)`, `k = 1..m_{t,r}`, and the visits
to the cell of the class with longitudinal coordinate `X` occur at the
`m_{t,r}` distinct times `i_k + ((X - x_k)/m) N`. Each such cell is white
before the highway reaches it, so its turns read `R,L,R,L,...` in time order,
giving `ceil(m_{t,r}/2)` right turns and `floor(m_{t,r}/2)` left turns. The
period events of the class are in bijection with the visits to any one of its
cells, so the class contributes exactly `ceil(m_{t,r}/2)` right turns to the
period.

By Lemma B the reflections at an odd level are exactly its right turns and at
an even level exactly its left turns, so

```text
rho_t = sum_r ceil (m_{t,r}/2)   (t odd),
rho_t = sum_r floor(m_{t,r}/2)   (t even).
```

Lemma C gives `rho_t = m_t (mod 2)`. []

**Corollary (primitive diagonal).** For `d = (1,-1)` there is one class per
level, so `m_t = m_{t,0}` and the theorem reads

```text
t odd  :  m_t = 0 or 1  (mod 4),
t even :  m_t = 0 or 3  (mod 4).
```

Equivalently, **every level of even multiplicity has `m_t = 0 (mod 4)`**, every
odd level of odd multiplicity has `m_t = 1 (mod 4)`, and every even level of
odd multiplicity has `m_t = 3 (mod 4)`. In particular no even level has
`m_t in {1,2}`, and no odd level has `m_t in {2,3}`.

## 3. Immediate consequences at primitive-diagonal growth four

Let `d = (1,-1)`, `g = 4`. The odd-multiplicity levels are exactly the `g = 4`
translation classes of the settled wake, so there are four of them. Write the
occupied levels as `T_0 .. T_1` and `W = T_1 - T_0`.

1. Every level with `T_0 < t < T_1` outside the four wake levels has
   `m_t = 0 (mod 4)`, hence `m_t >= 4`.
2. Every even level has `m_t >= 3` (it is `3 (mod 4)` if a wake level and
   `0 (mod 4)` otherwise).
3. `N = sum_t m_t = 3 . 1 + 1 . 3 = 6 = 2 (mod 4)` using the residue-theorem
   split of the four wake levels (three at odd `t`, one at even `t`; see §4).
4. `sum_{t odd} m_t = N/2` counts horizontal arrivals, and is `3 (mod 4)`,
   so `N = 6 (mod 8)`.
5. `f_t` is **never** `0 (mod 4)`: writing `c_t` for the number of wake levels
   `<= t`, one gets `f_t = (-1)^{t-T_0} c_t (mod 4)` with `c_t in {1,2,3}` on
   the occupied cuts.
6. Non-negativity of `M_t, n_t` forces `|f_{t-1} - f_t| <= rho_t`, i.e. roughly
   `max <= 3 min` on adjacent cuts. With the proved extremal theorem
   (`m_{T_0} = m_{T_1} = 1`, so `f_{T_0} = f_{T_1-1} = 1`) this pins the two
   cuts next to each boundary: `f_{T_0+1}, f_{T_1-2} in {2,3}`, hence
   `m_{T_0+1}, m_{T_1-1} in {3,4}`. Since only one even level may be a wake
   level, at most one of `m_{T_0+1}, m_{T_1-1}` equals 3.

## 4. What is still assumed, and what is open

- §3 items 3–4 use the signed mod-four wake-residue theorem in the form "the
  four wake levels split 3–1 by checker parity". For primitive diagonal the
  checker parity of a cell is exactly `t mod 2`, so the signed sum over the
  four wake levels is `+-2`, which forces a 3–1 split. **This step must be
  re-derived directly from the paper's Theorem 7.1 rather than assumed.**
- The proved transverse rigidity theorem is used for `m_{T_0} = m_{T_1} = 1`
  and for `T_0, T_1` both being horizontal-arrival (odd) levels, hence `W`
  even. Its applicability to `m = 1` drift must be confirmed against §9.
- **Open:** the constraint system of §3 is finite for each `W` but `W` is
  unbounded, so this is not yet an exclusion of primitive-diagonal growth
  four. A `W`-uniform argument, or an upper bound on `W`, is the missing step.

## 5. Reproduction

```text
scratchpad/lang/reflection_parity_check.py   # all identities on the real period-104 highway
scratchpad/lang/sublemma_check.py 14         # exhaustive sub-lemma verification
```
