# Excluding the lower band with wakes at four, five, and six

At a lower `(1,2,2)` cap in the `(1,-3)` orbit,

```text
(omega_4,omega_5,omega_6)=(1,1,1)
```

is impossible. There are two positions for the remaining
north right turn on level seven. The first contradicts
lifted-time order; the second forces a third west departure
on level nine, where only two are available.

Combined with the preceding exclusions, this leaves only
`(omega_4,omega_5,omega_6)=(0,1,1)` at a lower `(1,2,2)`
cap. Its two wake families A and B remain open, as do the
other cap profiles in the `(1,-3)` orbit.

## The fixed rows

Write `f=omega_7` and `g=omega_8`. The lower-band normal
form gives

```text
4: WR,WL,ER,WL,WR,EL,WR
5: SR,SL,NR,NL,NR,SL,NR
6: ER,EL,ER,WL,WR.
```

The level-seven theorem leaves

```text
P: SR,SL,SR,NL,SR,SL,NR,SL,SR,[SL]^(1-f);
Q: SR,SL,SR,NL,SR,SL,SR,SL,NR,[SL]^(1-f).
```

Label the west departures on level seven by `W1,...,W5`.
There are five east arrivals `E1,...,E5` on level eight;
`E3=ER` is the fifth south departure. The two west
departures `D1,D2` on level nine feed `6:WL,WR`. Let
`Fi` denote the east arrivals on level ten.

## The north right turn cannot precede W5

For P, the level-seven note already forces `f=0,g=1`
and the following tail on level eight:

```text
E3=ER,I=WL,WR,E4=EL,WR,WL,E5=ER.
```

Here `I`, the sixth south departure, feeds the `SL`
between `7:NR` and `7:W5`. It therefore supplies `F4`.
The preceding east arrival `F3` is supplied by the `NR`
whose source is `6:WR`. Thus

```text
tau(F4) = tau(I)+2-N < tau(E4),
tau(F3) = tau(6:WR)+2-N
        > tau(6:WL)+2-N = tau(E4).
```

This contradicts `F3<F4`. Hence P is impossible.

## The tail forced by Q

In Q, `W5` is the sixth south arrival on level seven.
If `E5=EL`, its return through `W5` would force `E4=ER`
as the sixth south departure on level eight. This is
impossible after `E3=ER` at ordinal five: alternation
between successive east right turns requires an intervening
`WL`. Therefore `E5=ER`, at south ordinal seven.

Let `J` feed `W5`. The square

```text
8:J -> 7:W5=SR -> 4:last WR -> 5:last NR -> 8:E5=ER
```

forces `J=WL`, immediately before `E5`. The south
ordinals and east order now force

```text
E3=ER,E4=EL,X=WR,J=WL,E5=ER.                         (1)
```

Indeed, `E4=ER` would put `E5` at south ordinal at least
nine; there is no other south departure between `E3`
and `J`, and no stable event between `J` and `E5`.

There are `8-f` south departures in total. If `f=1`,
`E5` is both the last east arrival and the last south
departure; it must end the word. If `f=0`, the remaining
south departure is `K=WL` and the tail is

```text
E3=ER,E4=EL,X=WR,J=WL,E5=ER,K=WL,[WR]^g.             (2)
```

## The two west departures on level nine

The square from `D1` through `6:WL,5:SL2,E4=EL`
cannot have an `NL` source. Such a source would require
an incoming `WR` immediately preceding `E4`, whereas
its predecessor in (1) is `E3=ER`. Hence `D1=SR`,
immediately followed by `D2=NL`.

The three-step path from `D2` through `6:WR,7:NR` ends
at `F4`. If `F4=ER`, its south step would complete a
square return from `D2=NL` to a third west departure
`SR`. Therefore `F4=EL`.

The south predecessor of `D1` on level ten follows the
eight-step first return

```text
10:Y -> 9:D1=SR -> 6:WL -> 5:SL2 -> 8:E4=EL
     -> 9:D2=NL -> 6:WR -> 7:NR -> 10:F4=EL.
```

Consequently `Y=F3=ER`, immediately preceding `F4`.
The arrival `F3` is supplied by `7:SL3`, whose incoming
predecessor is `8:E5=ER`. The preceding east arrival
`F2` is supplied by `7:SL2`, from `8:E3=ER`.

## The west departure feeding J must turn right

Let `P_J` be the west departure on level eleven feeding
`8:J`. It has the sixteen-step first return

```text
11:P_J -> 8:J=WL -> 7:W5=SR -> 4:last WR -> 5:last NR
       -> 8:E5=ER -> 7:SL3 -> 10:F3=ER -> 9:D1=SR
       -> 6:WL -> 5:SL2 -> 8:E4=EL -> 9:D2=NL
       -> 6:WR -> 7:NR -> 10:F4=EL -> north arrival on 11.
```

If `P_J=NL`, its incoming north predecessor `Z` on level
ten precedes `F3`, since `F3=ER,F4=EL` are consecutive.
The eight-step first return

```text
10:Z -> 11:P_J=NL -> 8:J=WL -> 7:W5=SR -> 4:last WR
     -> 5:last NR -> 8:E5=ER -> 7:SL3 -> 10:F3=ER
```

forces `Z=F2=EL`. The square

```text
8:E3=ER -> 7:SL2 -> 10:F2=EL -> 11:P_J=NL -> 8:J=WL
```

would then skip `E4,X` in (1). Thus `P_J=SR`.

Its sixteen-step return ends at the next west departure
`NL`. In particular, `J` cannot be the last west arrival
on level eight. This excludes `f=1`. In (2), the next
west arrival after `J` is `K`, so its matching departure
`P_K` on level eleven is `NL`, supplied by `10:F4=EL`.

## A third west departure is unavoidable

Now `f=0`, and the last `SL` on level seven is supplied
by `8:K`. The square

```text
10:F4=EL -> 11:P_K=NL -> 8:K=WL -> 7:last SL -> 10:F5
```

forces `F5=ER`, immediately after `F4`. But then

```text
9:D2=NL -> 6:WR -> 7:NR -> 10:F4=EL -> 11:P_K=NL
        -> 8:K=WL -> 7:last SL -> 10:F5=ER -> south arrival on 9
```

is an eight-step first return to the cell of `D2`.
Its direction word is `W N E N W S E S`; no earlier
step revisits the starting cell. Since its source turns
left, its south-arrival endpoint must be `SR`. That is
a third west departure on level nine, a contradiction.

Both level-seven continuations are excluded. No later wake
choices or period bounds beyond `N>=6` were used. The
clock comparison excluding P is in the lower orientation;
the whole band exclusion is not asserted for an upper cap.
