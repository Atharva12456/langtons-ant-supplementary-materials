# Width sixteen is impossible for the last lower fat `(1,2,3)` band

26 September 2026. At drift `(1,-3)`, take the lower fat `(1,2,3)` band
`(omega_3,omega_4,j,k,l)=(1,1,1,1,0)`. Its upper cap must be fat `(1,2,3)`
by the established cap exclusions. The P22, rank, and moment classification
has one width-sixteen wake placement:

```text
W=16,  O={0,2,3,4,6,12,14,16}.
```

This note excludes that placement at every period. Width twelve was excluded
earlier by center-row length, so the band now requires `W>=18`. The full
`(1,-3)` drift orbit remains open.

The lower initial words on rows zero through four are fixed by the lower-cap
normal form. In inward coordinates after a half-turn, the upper initial words
on offsets zero through two are `WR`, `NR SL`, and `WR WL WR`. Extend the lower
cap through center row eight with wake sequence `(0,1,0,0)` on rows five
through eight. Extend the upper cap through inward offset seven with wake
sequence `(0,1,0,0,0)` on offsets three through seven. The upper clock has
the opposite voltage sign because its drift points the other way. For both
caps the verifier uses an exact integer period `N>=max(6, represented event
count)`, with no upper bound, and successive visits on a stable row at least
four time steps apart.

The exhaustive necessary-prefix frontiers have lower survivor counts
`8,15,17,45` on rows five through eight and upper survivor counts
`4,8,60,389,1263` on inward offsets three through seven. Each row word is
right-first alternating, obeys directional flow and the prescribed wake, and
passes all explicitly witnessed finite first-return and lifted-clock checks.
The enumeration prunes forced same-cell first-return adjacency while building
each row. That pruning is necessary; it does not assume that a repeating
quotient node is a physical return.

At the physical center row eight, the 45 lower words have port counts
`(ER,EL,WR,WL)` as follows:

| Counts | Lower states |
|---|---:|
| `(3,4,7,6)` | 32 |
| `(4,3,4,5)` | 10 |
| `(2,1,6,7)` | 3 |

The upper row-eight directional count equations admit only the middle lower
profile after the half-turn. Its ten lower states and 288 compatible upper
states give 2,880 center count pairs. Of those, 2,440 violate the ordinal
balance on the physical east edge from row seven to row ten. The remaining
440 pairs balance both edges that cross the cut. In every one, using the
rotated lower center word as upper inward row eight yields an explicit finite
walk that first returns to the same physical cell at the wrong next stable
event. Thus no center pair remains. The center rejection does not require a
new clock solve.

For example, one four-step upper square visits zero-based stable-event
positions `4:0 -> 5:0 -> 8:2 -> 7:4 -> 4:3`, with cumulative horizontal
voltages `0,0,1,1,0`. Its ports are `WR -> NR -> ER -> SR -> WL`.
It returns to the same physical cell on row four at event three, skipping
the required immediate next event one. The result JSON gives the indexed
path, and the verifier checks an explicit wrong return for every one of the
440 balanced pairs.

`code/python/verify_lower_fat123_a1_b1_110_w16.py` regenerates both
frontiers and the join from the fixed cap words; it reads no checkpoint or
scratch result. Its output,
`results/lower_fat123_a1_b1_110_w16_checks_2026-09-26.json`, includes every
frontier count, the 440 return-witness distribution, and one sample walk with
cumulative horizontal voltage. The checker uses no period cutoff, row-length
cutoff, or quotient-cycle return extrapolation. It is a computer-checked
exclusion of this width and cap pair, not a formal proof of the whole orbit.
