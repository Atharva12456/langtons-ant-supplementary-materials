# A level-ten clock-pair restriction for the last wake-three lower band

This concerns drift `(1,-3)` and the lower fat `(1,2,3)` cap with
`omega3=omega4=1` and `(j,k,l)=(1,1,0)`. The exact level-nine checker
`work_last_a1_band/verify.py` leaves 104 necessary-condition prefixes. No period upper bound, cap width,
row-length, or black-lifetime bound is imposed.

An `ER` event on level ten is the `k`th east arrival from level seven and
the `l`th south departure to level nine. Write `i(k)` for the corresponding
level-seven event and `j(l)` for the level-nine event. Ordinal matching and
the exact lifted clock law give

```text
T(10,ER) - T(7,i(k)) = 1-N
T(9,j(l)) - T(10,ER) = 1,
so T(9,j(l)) - T(7,i(k)) = 2-N.
```

Here `N` is the unknown period. The equation is necessary at every period,
and the old rows already impose all witnessed edge equations, successive
same-cell gaps of at least four, and `N >= max(6, number of old events)`.
For each of the 104 prefixes, `work_last_a1_band/analyze.py` tests every source/arrival pair
against this integer clock system. It rejects 4,894 of 6,044 pairs. The
separate local first-return test rejects 848 pairs, all among those 4,894.

At level ten, both values of `omega10` are explored. The row-flow equations
give 1,222 count rows. A memoized exact word recurrence uses stable
right/left alternation, the forbidden `ER` pairs, and every forced
zero-copy return adjacency through the old rows. It finds that 549 count
rows admit at least one word, with 282,823 words in total. These are
*necessary-condition* words, not a complete level-ten return/clock
frontier. The JSON also records one word that separately passes the full
finite physical-return and lifted-clock tests. Thus the lower band remains
open at level ten.

Run `python work_last_a1_band/analyze.py` from the repository root. It
rebuilds the 104 level-nine prefixes without a cached state file and writes
`work_last_a1_band/level10_pair_restriction.json`. The argument depends on the paper-level
P22, first-return and clock laws used by `work_last_a1_band/verify.py`; it is not a Lean
formalization.
