# A hand proof of the upper-guard offset-seven restriction

At drift `(1,-3)`, suppose the upper guard has inward rows

```text
0: WR       1: NR       2: WR
```

and offsets `3,4,5,6` are non-wake. Then offset `7` is non-wake. The proof below uses only exact flow counts, alternating turns, ordinal edge matching, finite same-cell first returns, and a positive integer period with strictly increasing integer times along each row. It needs no P22, rank, moment, period congruence, minimum gap of four, or bound on period, width, row length, or lifetime.

## 1. Conventions

Use the usual 180-degree rotation of heading labels at the upper cap. A port is its arrival heading followed by its turn. The departures, inward shifts, and voltages are

```text
ER -> S   EL -> N   WR -> N   WL -> S
NR -> E   NL -> W   SR -> W   SL -> E
shift:   E +3, W -3, N +1, S -1
voltage: E +1, W -1, N  0, S  0
```

The upper clock on an edge is `tau(target)-tau(source)=1+N*voltage`. All positions in this note are **one-based**: `(t,i)` is event `i` of row `t`. Each stable word starts with `R` and alternates `R,L`.

Write `D_k` for the `k`th south departure (`ER` or `WL`) on an even row, and `W_k` for the `k`th west departure (`SR` or `NL`) on an odd row. `E_k` and `N_k` refer to arrival ordinals. When a finite path returns to its starting row at zero net voltage, its first such return must be the immediately following event of that row. Thus a verified return `D_k -> E_j` or `W_k -> N_j` imposes immediate adjacency.

The exact count equations are as follows. On an even row, if the old rows force `a` east arrivals and `d` south departures, then

```text
(ER,EL,WR,WL) = (e, a-e, omega+a+d-3e, d-e).
```

On an odd row, if the old rows force `b` north arrivals and `c` west departures, then

```text
(NR,NL,SR,SL) = (b-n, n, c-n, b+c-3n-omega).
```

Only nonnegative integer counts are allowed. These equations determine all the small word lists below; there is no row-size cutoff.

## 2. Rows three, four, and five are forced

Row three has counts `(NR,NL,SR,SL)=(1,0,1,2)`, hence two words:

```text
NR SL SR SL           or           SR SL NR SL.
```

Row four has `(a,d)=(1,3)`, so its two count options are

```text
(ER,EL,WR,WL) = (0,1,4,3) or (1,0,1,2).
```

The row-four south departure which enters the `SR` on row three follows the square

```text
4:D_k -> 3:SR -> 0:WR -> 1:NR -> 4:E_1.
```

It has zero voltage and no earlier return to row four, so `D_k` must be immediately followed by `E_1`. If row three is `NR SL SR SL`, this is `D_2 -> E_1`. The first count option would require a `WL` immediately followed by `EL`, two left turns. In the second option, inspecting the two alternating words `ER WL WR WL` and `WR WL ER WL` shows that `E_1=ER` is at or before `D_2`, which is impossible. Thus this row-three word is excluded.

For `3: SR SL NR SL`, the same square instead requires `D_1 -> E_1`. The first count option again demands two consecutive left turns; the second leaves exactly

```text
3: SR SL NR SL
4: WR WL ER WL.
```

Row five again has counts `(1,0,1,2)`, hence the same two possible words as row three. Exclude `5: SR SL NR SL` using just these three paths:

```text
(4,1) -> (5,3)                        length 1, voltage  0
(4,2) -> (3,1)                        length 1, voltage  0
(5,1) -> (2,1) -> (3,3)               length 2, voltage -1.
```

Their upper clock equations give the identity

```text
[tau(3,3)-tau(3,1)] + [tau(5,3)-tau(5,1)]
    + [tau(4,2)-tau(4,1)] = 2-N.
```

Strict integer row order makes the three brackets at least `2,2,1`. Consequently `2-N >= 5`, or `N <= -3`, contradicting a positive period. Therefore

```text
5: NR SL SR SL.
```

## 3. Exactly five words remain on row six

Here `(a,d)=(3,3)`, so the count options are

```text
(ER,EL,WR,WL) = (0,3,6,3), (1,2,3,2), (2,1,0,1).
```

The second south departure has the square return

```text
6:D_2 -> (5,3):SR -> (2,1):WR -> (3,3):NR -> 6:E_2.
```

Thus `D_2` is immediately followed by `E_2`. The first count option is impossible because it requires `WL` followed by `EL`. Alternation and this one adjacency rule leave four words for the middle option and one for the last:

| Label | Row six |
|---|---|
| A | `WR EL WR WL WR WL ER EL` |
| B | `WR WL ER EL WR EL WR WL` |
| C | `WR WL ER EL WR WL WR EL` |
| D | `WR WL WR EL WR WL ER EL` |
| E | `ER WL ER EL` |

For the middle option there are only `4*6=24` raw alternating words: place the unique `ER` in one of four right slots and the two `EL` in two of four left slots. The rule `D_2 -> E_2` leaves the four displayed words. For the last option there are only `ER EL ER WL` and `ER WL ER EL`; only the latter obeys the rule.

## 4. Wake row seven is impossible

Assume `omega_7=1`. In cases A--D, `(b,c)=(5,3)`, giving the three options

```text
(NR,NL,SR,SL) = (5,0,3,7), (4,1,2,4), (3,2,1,1).
```

In E, `(b,c)=(1,3)`, giving `(1,0,3,3)` or `(0,1,2,0)`.

The west departures on row seven enter row-four west arrivals in order. Following those paths through the displayed rows gives the immediate-return rules in the middle columns below. Every listed return has zero voltage and does not encounter row seven earlier. A blank means that this path leaves the known rows before a return is determined.

| Row-six case | Return from `W_2` | Return from `W_3` | Remaining alternating row-seven words |
|---|---|---|---|
| A | `N_2` | `N_5` | `SR NL NR SL NR NL NR` |
| B | `N_2` | `N_4` | `SR NL NR NL NR SL NR` |
| C | `N_2` | `N_5` | `SR NL NR SL NR NL NR` |
| D | `N_3` | `N_5` | `NR SL SR NL NR NL NR`; `SR SL NR NL NR NL NR` |
| E | | `N_1` | none |

The return rules are easy to check directly. In every case `W_3` follows

```text
7:W_3 -> (4,4):WL -> (3,4):SL -> 6:E_3 -> 7:N_j.
```

The final `E_3` is an `EL`; its north-departure ordinal gives the table's `j`. For `W_2`, begin with

```text
7:W_2 -> (4,2):WL -> (3,1):SR -> (0,1):WR
      -> (1,1):NR -> (4,3):ER -> (3,2):SL -> 6:E_1.
```

In A and D, `E_1` is `EL`, which immediately gives the stated return. In B and C, `E_1=ER` continues through `(5,3):SR`, `(2,1):WR`, `(3,3):NR`, and `6:E_2=EL`, giving the stated return. In E it instead leaves via `(5,2):SL` to offset eight, so no return is asserted.

For completeness, the last column follows by a small hand case split. In A--D, zero `NL` is impossible because each required return from an `SR` would need a following `NL`. With one `NL`, the two return rules force `W_2=SR`, immediately followed by `W_3=NL`, immediately followed by `NR`. This would make the two target north ordinals consecutive, whereas each table row has a difference of at least two. With two `NL`, there are just `4*3=12` raw alternating words; putting the unique `SR` in each right slot and the unique `SL` in each left slot leaves exactly the words displayed. In E, zero `NL` fails at the return from `W_3=SR`; the other count option has the unique word `SR NL SR`, whose last event is `W_3` and cannot be followed by `N_1`.

Finally, all five words in the last column violate a finite first return on row six:

* In A and both D words, follow

  ```text
  (6,5):WR -> (7,6):NL -> (4,4):WL -> (3,4):SL -> (6,8):EL.
  ```

  This four-step path has net voltage zero and skips events six and seven of row six. Its first return should have been `(6,6)`.

* In B and C, follow

  ```text
  (6,1):WR -> (7,2):NL -> (4,2):WL -> (3,1):SR
           -> (0,1):WR -> (1,1):NR -> (4,3):ER
           -> (3,2):SL -> (6,3):ER.
  ```

  This eight-step path has net voltage zero and skips event two of row six. Its first return should have been `(6,2)`.

Neither path revisits row six before its displayed endpoint. These contradictions exhaust all cases, proving `omega_7=0`.

## 5. Independent certificate check

`code/python/verify_upper_guard_hand_certificate.py` uses only Python's standard library. It checks the three clock paths, the return table, the five final paths, and all raw alternating permutations allowed by the exact count equations. The sole clock rejection uses the displayed identity `2-N >= 5`; no solver is imported. The complete audit is

| Offset | Raw alternating words | Finite-return exclusions | Clock exclusions | Survivors |
|---|---:|---:|---:|---:|
| 3 | 2 | 0 | 0 | 2 |
| 4 | 12 | 11 | 0 | 1 |
| 5 | 2 | 0 | 1 | 1 |
| 6 | 46 | 41 | 0 | 5 |
| 7 | 577 | 577 | 0 | 0 |

Run from the repository root:

```text
python code/python/verify_upper_guard_hand_certificate.py
```

It writes `results/upper_guard_hand_certificate_2026-09-24.json`, including the five paths with cumulative voltages. The result is a local upper-cap restriction, not closure of the full `(1,-3)` suborbit.
