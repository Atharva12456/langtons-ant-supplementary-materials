# The upper U branch has one possible offset-eight word

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

The five words in
`odd_skew_upper_a_u_eighth_words_2026-09-14.md` reduce
to B0 alone:

```text
8: WR,WL,ER,WL,WR,EL,WR,EL,WR,EL,WR,WL,ER,EL.
```

In addition, the first two west departures on offset nine
must be `D1=SR,D2=NL`. The U branch itself remains open;
this note does not exclude family A's upper two-`ER`
branches, family B, or the other cap profiles.

## The third south departure precedes E3

Keep the fixed U words and labels from the preceding notes.
Let `I` be the third south departure on offset eight. It
feeds the `SL` between `7:N3=NR` and `7:N4=NR`. Those
north arrivals are supplied by `6:EL1` and `6:WR3`.
North and south steps have zero voltage, so their order gives

```text
tau(6:EL1) < tau(I) < tau(6:WR3).                    (1)
```

The north arrival `7:W4=NL=N7` is supplied by the final
`6:WR5`. The fixed seven-step path from `W4` through
`4:WR2,5:NL,2:WL,1:SL,4:EL,5:NR2` ends at `8:E3`.
It has zero longitudinal voltage. Hence

```text
tau(E3)=tau(6:WR5)+8 > tau(6:WR3) > tau(I).          (2)
```

In word A from the five-word list, the third south departure
is `E4=ER`, after `E3`. In B2 and B3, `I=WL` is also
after `E3`. All three contradict (2). Only B0 and B1
remain.

## What follows if D2 turns right

The square from `D2` through `6:WL1,5:SL1,E2=EL`
has a north-arrival target. Suppose `D2=SR`; its
consecutive target is then `D3=NL`.

The next forced path has length eleven:

```text
D3 -> 6:WR2 -> 7:W2=NL -> 4:first WL -> 3:SR
   -> 0:WR -> 1:NR -> 4:ER -> 3:first SL -> 6:EL1
   -> 7:N3=NR -> 10:F3.
```

If `F3=ER`, its south step completes a twelve-step first
return from `D3=NL` to `D4=SR`. But then the square

```text
10:F3=ER -> 9:D4=SR -> 6:WR3 -> 7:N4=NR -> 10:F5
```

skips `F4` in east-arrival order. Thus `F3=EL`.

The south predecessor of `D2` on ten follows the square
to `D3` and then the eleven-step path just displayed.
This is a sixteen-step first same-cell return to `F3=EL`.
It forces that predecessor to be `F2=ER`, immediately
before `F3`.

The square

```text
D1 -> 6:WR1 -> 7:N1=NR -> 10:F2=ER -> D2=SR
```

now forces `D1=NL`, immediately before `D2`. Thus the
three departures are consecutive stable events

```text
D1=NL,D2=SR,D3=NL.                                 (3)
```

Their two north arrivals are consecutive in north-arrival
order as well, and the second is supplied by `8:E2=EL`.

## B1 is impossible

In B1, the first two north departures on eight are its
initial `WR` and `E2=EL`. Consequently (3) would make
`D1=NL` the first north arrival on nine. It is also the
first west departure there. No earlier right turn is
available: an `NR` would be an earlier north arrival,
and an `SR` an earlier west departure. This contradicts
the right-turn first visit.

On the other hand, B1 cannot have `D2=NL`. The square
from `D2` to the north arrival supplied by `E2` would
require an incoming `WR` immediately before `E2` on
eight. Its stable predecessor in B1 is `E1=ER`.
Thus both turns at `D2` are impossible in B1, excluding
the fourth word from the original five-word list.

## B0 also cannot have D2=SR

It remains to exclude assumption (3) in B0. In that word,
the first three north departures on eight are

```text
its initial WR, the WR after I, and E2=EL.
```

Thus (3) places `D1` at the second north arrival and
`D3` at the third. The complete initial word on nine is

```text
NR,D1=NL,D2=SR,D3=NL.                               (4)
```

There is no additional visit between these events: before
the first west departure any south arrival would be `SL`,
and alternation would then require an additional right turn
before `D1=NL`. None is available.

In particular, `D2` is the first south arrival on nine.
It is supplied by `F2=ER`, so the earlier east arrival
`F1` on ten cannot turn right. Hence `F1=EL`.
There can be no `WL` before `F2`, since it is the
first south departure on ten. With the already consecutive
pair `F2=ER,F3=EL`, the initial word on ten is therefore

```text
WR,F1=EL,F2=ER,F3=EL.                               (5)
```

Let `P1,P2,P3` be the west departures on eleven feeding
the first three west arrivals on eight: its initial `WR`,
its first `WL`, and `I=WL`. There is an eight-step
first return

```text
P2 -> 8:first WL -> 7:W1=SR -> 4:first WR -> 5:NR1
   -> 8:E1=ER -> 7:first SL -> 10:F1=EL
   -> north arrival on 11.
```

By (5), its target is the second north arrival on eleven.
If `P2=NL`, it must be the first north arrival there.
Then the preceding west departure is `P1=SR`, immediately
followed by `P2=NL`: no intervening north arrival or
additional west departure is available.

The three-step path from `P1` through the initial `WR`
on eight and the initial `NR` in (4) ends at the first
east arrival `G1` on twelve. If `G1=ER`, its south step
would return from `P1=SR` to `SL`, contradicting the
immediate successor `P2=NL`. Thus `G1=EL`.
The south predecessor of `P1` on twelve would then
have a square return to `G1=EL`, requiring an earlier
east arrival `ER`. But `G1` is the first east arrival.
This excludes `P2=NL`.

Therefore `P2=SR`, with consecutive target `P3=NL`
supplied by `F1=EL`. The resulting square

```text
10:F1=EL -> 11:P3=NL -> 8:I=WL -> 7:second SL -> 10:F4
```

skips `F2,F3` in east-arrival order. This contradiction
excludes `D2=SR` in B0.

It follows that `D2=NL`. Its north-arrival source is
the second north departure on eight, the `WR` after
`I`. The first west departure cannot be `NL`: it would
have to be the first north arrival and would again lack
an earlier right turn. Thus `D1=SR`, as claimed.

## Remaining middle departures on nine

For later work, two further turn restrictions follow from
the same paths. The fixed data are now

```text
D1=SR, D2=NL, D5=NL, D6=SR, D7=NL, D8=SR.
```

If `D3=NL`, the twelve-step return through `F3=ER`
would force `D4=SR` and the square from `F3` to `F5`
already excluded above. Therefore `D3=NL` requires
`F3=EL`.

If instead `D3=SR` and `F3=EL`, its south predecessor
on ten would have a twelve-step first return to `F3`,
forcing that predecessor to be `F2=ER`. The square
from `D1` through `6:WR1,7:N1,F2` would then return
from `D1=SR` to `D3=SR`, with two right-turn endpoints.
Hence `D3=SR` requires `F3=ER`.

Also, `D4=NL` requires `F5=EL`: a right turn at `F5`
would complete a square from `D4=NL` to `D5=SR`,
contrary to the already forced `D5=NL`.

These restrictions do not construct a trace. The later
prefix argument in
`odd_skew_upper_a_single_er_exclusion_2026-09-14.md`
excludes B0 without resolving the remaining choices at
`D3,D4` separately, and closes the single-`ER` upper
branch of family A.
