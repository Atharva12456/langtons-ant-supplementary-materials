# Status of the lower fat `(1,2,3)` bands with `omega_3=0`

22 September 2026

The two `(j,k,l)=(2,0,1)` bands, with either value of `omega_4`, are
excluded at every period by the forced six-step path proved in
`odd_skew_lower_fat123_a0_j2_exclusion_2026-09-22.md` and checked by
`code/python/verify_lower_fat123_a0_j2_exclusion.py`.

The `(1,0,2)` bands in the table below were subsequently [excluded at level nine](https://drive.google.com/file/d/1bZqZeOF4G8RBfFNCvwofZAnTFb7RH66G/view?usp=drivesdk) for both `omega_4` values. The two `(1,1,1)` bands remain open. The earlier `code/python/probe_lower_fat123_a0.py` applies the row-count
equations, the generic necessary one-excursion adjacency filter, physical
first returns, exact lifted clocks with `N>=6`, and a permissive P22 partial
wake test. It leaves the following numbers of prefixes:

| `(j,k,l)` | `omega_4` | Level 5 | Level 6 | Level 7 | Level 8 |
|---|---:|---:|---:|---:|---:|
| `(1,0,2)` | 0 | 4 | 42 | 60 | 452 |
| `(1,0,2)` | 1 | 4 | 57 | 240 | not checked |
| `(1,1,1)` | 0 | 14 | 50 | 32 | 102 |
| `(1,1,1)` | 1 | 16 | 80 | 264 | not checked |

These are necessary-prefix survivors only. They do not establish an ant
orbit, and this table by itself does not exclude any branch. The later level-nine exclusion settles the two `(1,0,2)` branches. The
individual JSON files contain count-row, raw-word, adjacency, physical-return
and clock statistics for each level checked. No period or width cutoff was
used. When `omega_4=1`, P22 forbids `omega_5=omega_7=1`: levels 2/5 and 4/7 would give opposite checker signs in two distinct residue-three fibres, requiring more than eight total wakes. This does not close either branch. The `j=1,k=1` branches additionally have the proven lower-cap
black-lifetime bound `V-U>=N+10` from the September 12 normal-form note;
the present probe adds no new global bound.
