# Rank parity and an additive moment for the saturated skew drifts

This note treats the two growth-eight drift orbits represented by `(2,4)` and
`(2,-4)`.  It gives an all-period chronology condition, but not an exclusion.

## Statement

Write the drift as `d=(2,4s)`, where `s` is `1` or `-1`, and use quotient
coordinates

```text
r = x mod 2,             t = 2x-sy.
```

The P22 residue matrix has one doubled `y mod 4` cell in one `r` lane and three
doubled cells in the other.  Translate the origin so that the two-class lane is
`r=0`, its cell has `y=0 mod 4`, and the six-class lane is `r=1`.  In the
`t` coordinate the four doubled fibres are then

```text
A: r=0, t=0 mod 4,
B_0,B_1,B_3: r=1, t=0,1,3 mod 4.
```

Let `T_j` be the two transverse levels occupied by the odd classes in `B_j`.
For two of these three fibres put

```text
I_ij = #{(u,v) in T_i x T_j : u<v}  (mod 2).
```

Every finite-support periodic highway in either skew orbit would satisfy

```text
I_01 + I_03 + I_13 = 1  (mod 2).                         (1)
```

There is also a mod-four moment.  Write

```text
S_A = sum_(t in A) t/4,
S_j = sum_(t in T_j) (t-j)/4,       j=0,1,3.
```

Then

```text
S_A-S_0+S_1+S_3 = -s  (mod 4).                           (2)
```

The definition is insensitive to which member of a pair is written first:
reversing the inequality replaces a count by `4-count`, which has the same
parity.  It is also preserved when the transverse orientation is reversed by a
quarter turn.

## Why the boundary has this form

At `|b|=4`, the density inequality is saturated.  P22 therefore puts exactly two
odd classes in each `y mod 4` residue, with the same checker sign.  Both classes
must lie in one `x mod 2` lane.  The `x` margins are `2+6`, so one `y` residue is
assigned to the minority lane and the other three to the majority lane.  This is
the unique `2 x 4` count matrix up to translation.  The four cells are doubled,
which is why every set `T_j` has two elements congruent modulo four.

The checker split is `2+6`, and the period congruence gives

```text
N = 0  (mod 8).                                           (3)
```

## The extra additive weight

The moment (2) does not come from the separate `x`- and `y`-residue indicators
used in P22.  Consider instead

```text
w_s(x,y)=(-1)^(x+y) [floor(x/2)-s floor(y/4)]  (mod 4).
```

It has zero four-corner sum and is periodic under `(x,y)->(x+2,y+4s)`.
Integrating the north-heading potential along three northeast diagonals and one
reversed southeast diagonal when `s=1` (and the reversed path when `s=-1`) gives
monodromy `3 mod 4`.  Conservation over one period is therefore

```text
sum_(o in O) w_s(o) + 3 = 0  (mod 4).
```

For `t=j+4k`, the values on the four normalized fibres are

```text
             A       B_0       B_1       B_3
s=1          k       -k        k         k+1
s=-1         k       1-k       k-1       k
```

Each fibre has two points.  Summing the appropriate row gives exactly (2).

## The finite parity flow

Checker parity at `(r,t)` is `r+t mod 2`.  At an even vertex the ant arrives
vertically and its outgoing blocks are `W,E`; at an odd vertex the outgoing
blocks are `S,N`.  In the quotient the targets are

```text
E_r(t) -> (1-r,t+2),       W_r(t) -> (1-r,t-2),
N_r(t) -> (r,t-s),         S_r(t) -> (r,t+s).
```

Reduce all block multiplicities modulo two.  At each vertex the incoming and
outgoing sums both equal its odd-class indicator.  The finite solution is unique.
Indeed, a nonzero zero-boundary solution would have a block with least transverse
source level.  The paired outgoing block points lower; the required paired input
at its target comes from a still lower source.  This contradicts minimality.

Existence can be read off from four elementary chains.  For a doubled even vertex
at levels `u` and `u+4`, the six-block segment is

```text
E_r(u), W_r(u+4),
S_r(u+1), N_r(u+1), S_r(u+3), N_r(u+3).                 (3)
```

The only doubled odd vertex is `B_0`.  Its segment contains both horizontal
blocks and both vertical blocks at `(0,u+2)` and `(1,u+2)`, together with the
vertical block directed into the interval at `(1,u)` and the opposite block at
`(1,u+4)`.  Thus the endpoint blocks are `S_1(u),N_1(u+4)` when `s=1`, and
`N_1(u),S_1(u+4)` when `s=-1`.  Concatenating consecutive segments from `u` to
`v-4` gives the unique chain between any two endpoints `u<v` in one fibre.

## The sign

Let `E` be the directed-block permutation sign and `L` the usual sum of local
port corrections.  Both are functions of the parity flow.  Comparing the source
and target orders of the blocks in (3) and in the odd-vertex segment gives the
following finite table.

- At drift `(2,4)`, a segment has zero self-sign.  Distinct segments interact
  only when they belong to two different majority-lane fibres and their chain
  indices differ by zero or minus one.
- At drift `(2,-4)`, every segment has self-sign one and consecutive segments in
  the same chain interact once.  A complete chain therefore has sign one,
  independently of its length.  There are four chains, so these four signs
  cancel.  The cross-chain table is the same as for `(2,4)`.

Summing the two nonzero relative positions over two finite chains telescopes to
the interlacing of their endpoint pairs.  The minority chain has zero cross term.
Consequently, in both chiralities,

```text
E+L = I_01 + I_03 + I_13  (mod 2).                       (4)
```

Put `ell=(x-r)/2` and `tau=i-N*ell`.  Along any one directed quotient block,
successor changes `tau` by a constant, including at the period seam.  Port sorting
therefore factors the one-cycle phase successor as `K=1+E+L`, where `K` is the
sum of the stable ranks of the left turns.  Exact P3 alternation puts every left
turn at odd rank, so `K=#L`.  By (3),

```text
#L = (N-8)/2 = 0  (mod 2).
```

Substitution in (4) proves (1).

## Audit

The regression solves the finite GF(2) block system directly in both
chiralities, without inserting the chain solution.  It then computes `E+L` from
the block orders and local formulas and compares it with (4).  It separately
checks the four-corner weight, drift periodicity, potential monodromy, and (2).
The default run makes 148 segment self/cross checks, 1,446 additive-weight checks,
and 2,592 full boundary comparisons.  In each chirality, 184 of the 1,296 tested
placements satisfy both (1) and (2), so the combined result is still a restriction
rather than an exclusion.

```text
python code/python/growth8_skew_rank_parity_audit.py \
  --output results/growth8_skew_rank_parity_audit.json
```

```text
growth8_skew_rank_parity_audit.py
0efe7fe308bfcfabc521df8ab3050046c2982e8da548a8940b8bbab2060e139f

growth8_skew_rank_parity_audit.json
b852ac903b41e310ec995bc31a0b906a2d727881fbdc3b71e73923044973b1ca
```
