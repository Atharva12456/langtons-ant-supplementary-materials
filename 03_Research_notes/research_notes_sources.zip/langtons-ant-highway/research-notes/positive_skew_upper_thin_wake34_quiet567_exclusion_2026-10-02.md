# Upper thin wakes three/four cannot be followed by quiet five through seven

For literal drift `(1,3)`, an upper F122 cap with wakes three/four and
quiet five through seven is impossible, for either wake bit at eight
and either wake bit at nine.
This local statement is independent of growth, width and the positive
integer period. At growth eight it excludes the entire lower-thin110 /
upper-F122 wakes-three/four cap family. The whole orbit remains **open**.

## Complete independently enumerated local domain

The upper orientation-preserving half-turn has initial words
`0:NR`, `1:WR,WL`, `2:NR,SL`. R/L and stable event order are preserved.
Edge clocks use `1+N*dx`, integer `N>=1` with no upper bound and strict
stable order. No period residue, growth, P22 or gap-four filter is used.

All count vectors follow the exact ordinal-flow recurrence and
nonnegativity; all R-first alternating multiset words are enumerated
without adjacency pruning in the independent audit. Direct compass
steps recover the target row and copy coordinate. A repeated quotient
with nonzero translation is retained conservatively, never rejected as
physical adjacency. Each discarded word has an actual wrong physical
first return or a direct Z3 integer-clock contradiction.

| Offset | Wake bit | Count vectors | Raw words | Survivors |
|---|---:|---:|---:|---:|
| 3 | 1 | 1 | 2 | 2 |
| 4 | 1 | 4 | 24 | 2 |
| 5 | 0 | 4 | 38 | 4 |
| 6 | 0 | 8 | 76 | 6 |
| 7 | 0 | 18 | 276 | 2 |
| 8 | 0 | 8 | 948 | 1 |
| 9 | 0 | 4 | 474 | 0 |
| 9 | 1 | 3 | 396 | 0 |
| 8, wake branch | 1 | 8 | 1,136 | 1 |
| 9 after wake eight | 0 | 4 | 899 | 0 |
| 9 after wake eight | 1 | 4 | 756 | 0 |

All 5,025 raw words are covered: 5,006 physical rejections, one clock
rejection, and 18 retained intermediate prefixes. All four terminal
choices of bits eight/nine are completely empty. The audit imports neither frontier nor fast-clock
code and reaches no resource cap. Its independent recurrence, raw
multiset enumeration, compass/ordinal graph and direct integer solver
give a second implementation of the exclusion.

Reproduce:

```text
python work_positive_skew_upperthin_high110_20261002/audit_wake34_raw.py
python work_positive_skew_upperthin_high110_20261002/check_wake8.py
```

## Short terminal physical contradiction

The unique necessary prefix through quiet eight is

```
0 NR; 1 WR WL; 2 NR SL;
3 WR WL ER;
4 SR SL NR NL NR;
5 WR WL ER WL WR EL;
6 SR SL NR NL NR SL;
7 WR WL WR EL ER WL ER WL;
8 NR SL NR NL SR NL SR SL NR SL.
```

For wake eight, the unique necessary prefix differs only by a final NR
at row eight. On nine, let D_i denote the i-th north departure, and E_i
the i-th east arrival. There are four east arrivals and five north
departures for quiet eight, or six north departures for wake eight.
Two zero-displacement first-return paths through the fixed old rows
force the stable adjacencies

```
D_3 -> E_1,  direction word NWNESWSWNESE;
D_4 -> E_4,  direction word NWSE.
```

The first path visits old events, in order, `8:NL(first)`,
`5:WR(first)`, `4:NR(first)`, `7:ER(first)`, `8:SR(first)`,
`5:WL(first)`, `6:SR`, `3:WR`, `2:NR`, `5:ER`, `6:SL(first)`.
The second visits `8:NL(second)`, `5:WL(second)`, `6:SL(second)`.
Each returns physically to row-nine's starting cell for the first time;
ordinal edge matching gives the stated arrival ordinals.

D_3 cannot be EL, because that event itself would be an east arrival
preceding E_1. Thus D_3 is WR (R) and its immediately following E_1 is
EL (L). That E_1 is itself the next north departure D_4. Its immediately
following E_4 must be ER, but E_2 and E_3 cannot occur between adjacent
events E_1 and E_4. This is impossible for either terminal wake bit.
The paths and contradiction are unchanged by the final NR in the wake-eight
branch. Only the prefix reduction through eight is computer-assisted; this
terminal contradiction is a direct ordinal/physical argument.

## All-width lower-thin110 consequence at growth eight

Lower `110` fixes wakes `{0,4,5,6}`. Upper F122 with wakes three/four
fixes `W-4,W-3,W`. Growth eight leaves one residual. The known complete
width-sixteen exclusion supplies `W>=18`, so these seven fixed wakes
are distinct and the residual lies above the lower band through seven.

P22 requires fibre sizes 4,2,2 with a 3+1 split in the four-wake fibre
and uniform signs in each two-wake fibre, using fibre `j=-t mod3` and
sign `(-1)^t`. Width zero modulo six fills fibre zero with four wakes
while fibre one has an opposite-sign pair needing two additional wakes.
Width four would require two four-wake fibres. Hence `W=6m+2`; fibre
zero is the lower pair `{0,6}`, fibre two is `{4,W-4}`, and the fixed
fibre-one wakes `{5,W-3,W}` have two negatives and one positive.
The residual must be negative fibre one, giving exactly

```
O={0,4,5,6,6r+5,W-4,W-3,W},
1<=r<=m-2,  m-r even.
```

The fixed signed moment is `2m+3`; subtracting `2r+2` leaves
`1+2(m-r)`, so the displayed parity is necessary and sufficient for
moment one modulo four. The rank is twelve, hence even. The residual
interval and quiet lower seven give the displayed bounds. The minimum
arithmetic width is twenty. Its residual upper distance is
`6(m-r)-3=9,21,33,...`, so offsets five through eight are all quiet.
This contradicts the stronger local lemma, excluding the whole cap family for
every width and positive period. The endpoint sets are necessary
arithmetic shadows, not ant trajectories.
