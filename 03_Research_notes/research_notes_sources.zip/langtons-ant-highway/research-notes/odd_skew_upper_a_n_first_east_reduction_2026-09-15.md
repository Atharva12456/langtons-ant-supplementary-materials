# Four words on ten for the remaining N continuation

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: N is excluded uniformly in
`odd_skew_upper_a_r_exclusion_2026-09-15.md`.
All four words remaining at the end of this reduction
are therefore closed.

In form R, continuation N, the first east arrival on ten
precedes its third south departure by at least sixteen
steps in lifted time. This initially leaves five words on
ten. The left-turn word L0 is then impossible, leaving
four. In L1, the second west departure on eleven must
turn left; its initial word and the first three events
on twelve are forced.

These restrictions do not exclude N. Forms P and Q,
family B, and the other cap profiles of the `(1,-3)`
orbit remain open.

## Notation

Use the words established in
`odd_skew_upper_a_r_middle_exclusion_2026-09-15.md`.
In particular,

```text
7: SR,SL,SR,NL,NR,NL,SR,SL;
8: a=WR,C=WL,E1=ER,I=WL,b=WR,E2=EL,c=WR,E3=EL,
   d=WR,E4=EL,e=WR,J=WL,E5=ER,E6=EL;
9: NR,SL,NR,SL,NR,SL,NR,SL,NR,NL,NR,SL,NR,SL,SR,NL,SR,SL.
```

Let `F1,F2,F3` be the east arrivals on ten, and let
`S1,...,S9` be its south departures. The previous note
fixes its final five events as

```text
T = Y=WL, F2=ER, K=WL, X=WR, F3=EL,
```

where `Y=S7`, `F2=S8`, and `K=S9`. All words in this
note are in stable order. Powers of a two-letter block
mean concatenation; an exponent of zero gives an empty
block.

## A gap identity before S3

Write `A` for the first `ER` on six. There is a fixed
eight-step path

```text
8:I=WL -> 7:second SR -> 4:first WL -> 3:SR -> 0:WR
       -> 1:NR -> 4:ER -> 3:first SL -> 6:A=ER.
```

Its direction word is `S W S W N E S E`. It has zero
voltage, so

```text
tau(A) = tau(I) + 8.
```

The following two paths have the same length and voltage:

```text
8:E1=ER -> 7:first SL -> 10:F1;
6:A=ER  -> 5:first SL -> 8:E2=EL.
```

Both have directions `S E`. Cancelling their common
lifted-time increment gives

```text
tau(E2) - tau(F1) = tau(I) - tau(E1) + 8.             (1)
```

On eight, `E1` immediately precedes `I`. Their gap is
at least four, so `E2` is at least twelve steps later
than `F1`.

The third north arrival on nine is supplied by `E2=EL`.
It immediately precedes the third south arrival, `SL`,
which is supplied by `S3` on ten. The two incoming
vertical steps have zero voltage. Thus

```text
tau(S3) - tau(E2)
  = tau(9:third SL) - tau(9:third NR) >= 4.
```

Together with (1), this proves

```text
tau(S3) - tau(F1)
  = [tau(9:third SL) - tau(9:third NR)]
    + [tau(I) - tau(E1)] + 8
  >= 16.                                           (2)
```

In particular, `F1<S3`. No upper bound on a black or
white lifetime is used. The period term cancels in (1).

## Five preliminary words

If `F1=ER`, it is one of the south departures and must
therefore be `S1` or `S2`. With `F2=ER,F3=EL`, the
non-wake condition gives seven `WL` and six `WR` ports
on ten. Alternation and the fixed tail give exactly these
two possibilities:

```text
R1: F1=ER, (WL,WR)^5, T;
R2: WR,WL, F1=ER, (WL,WR)^4, T.
```

If `F1=EL`, every south departure preceding it is a
`WL`. By (2), their number `k` is zero, one, or two.
There are now eight `WL` and nine `WR` ports on ten.
The three possible words are

```text
L0: WR, F1=EL, (WR,WL)^6, WR, T;
L1: WR,WL,WR, F1=EL, (WR,WL)^5, WR, T;
L2: (WR,WL)^2, WR, F1=EL, (WR,WL)^4, WR, T.
```

Before (2), alternation alone allowed `F1=ER` at any
of `S1,...,S6`, or `F1=EL` after `k=0,...,6` south
departures. The gap identity excludes eight of those
thirteen words. This is a reduction of words within N,
not a count of closed or remaining drift orbits.

## The second west departure on eleven

Let `P1,P2,P3` be the first three west departures on
eleven, feeding `8:a,C,I` respectively. In each left-turn
case `Lk`, the path

```text
P2 -> 8:C=WL -> 7:first SR -> 4:first WR -> 5:first NR
   -> 8:E1=ER -> 7:first SL -> 10:F1=EL
   -> north arrival on 11
```

is an eight-step first return. Its endpoint is the
`(k+2)`-nd north arrival on eleven.

If `P2=NL`, its consecutive target is `NR`, and `P2`
is the `(k+1)`-st north arrival. If `P2=SR`, its target
is `NL=P3`. In the latter case there is also the square

```text
8:E1=ER -> 7:first SL -> 10:F1=EL -> 11:P3=NL -> 8:I=WL,
```

so `tau(I)-tau(E1)=4`.

In L0, `P2=NL` is impossible. It would be the first
north arrival, forcing the earlier west departure to
be `P1=SR`, immediately before `P2=NL`. There is no
available right turn for an intervening event.

But

```text
P1 -> 8:a=WR -> 9:first NR -> 12:first east arrival G1
```

has only three steps. If `G1=ER`, its south step gives
a square return from `P1=SR` to `SL`, contrary to the
immediate successor `P2=NL`. If `G1=EL`, the south
predecessor of `P1` on twelve has a square first return
to `G1`. It must be `ER`, requiring an east arrival
before the first one. Both turns are impossible.

Consequently L0 forces `P2=SR`, `P3=NL` supplied by
`F1`, and the four-step gap from `E1` to `I`.

## L0 is impossible

The forced square gives `tau(I)-tau(E1)=4`, so (1)
becomes

```text
tau(E2) - tau(F1) = 12.                             (3)
```

But the L0 word on ten contains the consecutive events

```text
F1=EL, WR, S1=WL, WR, S2=WL.
```

Their four gaps total at least sixteen. On nine, the
second `SL`, supplied by `S2`, immediately precedes
the third `NR`, supplied by `E2`. Cancelling their
incoming vertical steps gives `tau(E2)-tau(S2)>=4`.
Therefore

```text
tau(E2) - tau(F1)
  = [tau(E2) - tau(S2)] + [tau(S2) - tau(F1)]
  >= 4 + 16 = 20,
```

contrary to (3). This excludes the whole word L0.

## L1 requires P2=NL

Suppose L1 instead has `P2=SR`. The same square again
gives (3). Now the consecutive events after `F1` are

```text
F1=EL, WR, S2=WL.
```

Each of their two gaps is at least four, as is the gap
from `S2` to `E2` obtained on nine. Equation (3) forces
all three to equal four. In particular, `F1` must return
to the same physical cell at the next `WR` after four
steps.

Its actual four-step continuation, however, is fixed:

```text
10:F1=EL -> 11:P3=NL -> 8:I=WL -> 7:second SR -> 4:first WL.
```

The direction word `N W S W` does not return to the
starting cell. Thus `P2=SR` is impossible in L1.

It follows that `P2=NL` is the second north arrival
on eleven, immediately followed by its third north
arrival `NR`, supplied by `F1`.

The first west departure `P1` must be `SR`. Its only
possible north predecessor would be the first north
arrival, which cannot itself be `NL=P1`: no earlier
right turn would then be available on eleven.

As above, a right turn at the first east arrival `G1`
on twelve gives a square from `P1` to `SL`; a left turn
would require an earlier east arrival. Hence `G1=ER`,
and the immediate successor of `P1` is `SL`, not `P2`.
The first north arrival must lie between them. The
initial word on eleven is therefore

```text
11: P1=SR,SL,first NR,P2=NL,third NR,... .
```

The south predecessor of `P1` on twelve is `WL`,
immediately before `G1=ER`, by its square return. Since
`P1` is the first south arrival on eleven and `G1` is
the first east arrival on twelve, this also fixes

```text
12: WR,WL,G1=ER,... .
```

The surviving words on ten are R1, R2, L1, and L2.
This excludes nine of the thirteen initial placements,
but does not exclude N or the `(1,-3)` orbit.
