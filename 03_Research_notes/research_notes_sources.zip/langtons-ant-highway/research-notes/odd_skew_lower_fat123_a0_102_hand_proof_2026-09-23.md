# A first-return proof that the lower fat `(1,2,3)` bands `(0,b,1,0,2)` are impossible

23 September 2026

## Result and scope

For drift `(1,-3)`, in lower-cap coordinates `t=3x+y`, the two lower
`(1,2,3)` bands with `omega_3=0` and `(j,k,l)=(1,0,2)`,

```text
0: WR
1: NR,SL
2: WR1,WL,WR2
3: SR,SL1,NR1,SL2,NR2,SL3
4: WR1,WL1,ER,EL,WR2,WL2,WR3,WL3,[WR4]^b          b = omega_4 in {0,1},
```

cannot occur at any period. The computer certificate
`odd_skew_lower_fat123_a0_102_exclusion_2026-09-22.md` found that every
level-nine continuation fails a witnessed first return. This note gives a
hand proof. It explains the failure by one mechanism that works for both
values of `b`.

The proof uses only four facts: right/left alternation, ordinal edge
matching, the count of west departures on row five, and first returns
along explicit closed walks. It uses **no** lifted clock, no lower bound on
`N`, no wake parity at levels five to nine, and no P22, rank or moment
condition. Every case split below is shown to be exhaustive.

Idea. Short closed walks force the start of each row from five to eight.
The first four W-arrivals on row six are then fixed, and a twelve-step
return makes the fourth west departure on row nine the first north arrival
there. From that event, the walk through row six and row five reaches the
third east arrival `F3` on row eight. If `F3` turns left, the walk comes back to
row nine and skips a north arrival. If `F3` turns right, the walk goes down
into row seven. Prefix it with the forced four-step path
`7:W1 -> 4:WR1 -> 5:n1 -> 8:F2 -> 9:p1`. The result is a closed walk from
the first event of row seven that lands on a south arrival, while the next
stable event there is a north arrival.

## Conventions

A port is an arrival heading followed by a turn. Departures are

```text
ER->S, EL->N, WR->N, WL->S,   NR->E, NL->W, SR->W, SL->E,
level shift E +3, W -3, N +1, S -1.
```

At an even level every event is an E-arrival (`ER`, `EL`), a `WR`
(W-arrival, N-departure) or a `WL` (W-arrival, S-departure). At an odd
level every R-port is an N-arrival (`NR`) or a W-departure (`SR`), and every
L-port is `NL` (both an N-arrival and a W-departure) or `SL`. The framework
facts used are those of `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`:

* **(A) Alternation.** A nonempty stable word begins with R and alternates,
  so consecutive stable events have opposite turns.
* **(M) Ordinal matching.** The r-th departure with heading `h` from row `t`
  feeds the r-th arrival with heading `h` on row `t+shift(h)`. Events of a
  fixed arrival (or departure) class occur in the stable word in rank order.
* **(F) First return.** Consider a walk along successors that starts at
  event `e` on row `t`, has net displacement `(0,0)` (equal numbers of E
  and W steps, and of N and S steps), and meets row `t` at no intermediate
  event. Its endpoint is then the stable successor of `e`: it is the event
  immediately after `e` (so `e` is not the last event of its row), and it
  has the opposite turn. Every closed walk
  below meets its start row at no intermediate event, and each has zero
  net voltage.

"Closed walk" below means a walk with displacement `(0,0)` that satisfies
(F). The script `code/python/verify_lower_fat123_a0_102_hand_walks.py` checks each one step by step.

Edges inside rows 0-4 that are used (all by (M)):
`0:WR->1:NR`, `1:NR->4:ER`, `1:SL->4:EL`, `2:WR1->3:NR1`, `2:WL->1:SL`,
`2:WR2->3:NR2`, `3:SR->0:WR`, `4:WL1->3:SR`, `4:ER->3:SL1`.
Edges that leave or enter rows 0-4:

* the E-departures `3:SL1,NR1,SL2,NR2,SL3` feed the E-arrivals `E1,...,E5`
  of row six;
* the N-departures `4:WR1,EL,WR2,WR3,[WR4]` feed the N-arrivals
  `n1,n2,...,n(4+b)` of row five;
* row five has exactly three W-departures `D1,D2,D3`, feeding
  `2:WR1,2:WL,2:WR2`;
* the W-departures `W1,W2,...` of row seven feed `4:WR1,4:WL1,4:WR2,...`
  (there are `6+b` of them).

Rows five to nine are nonempty because they receive these arrivals. The
argument therefore holds at every width.

## Step 1: row five

**(1a) `D2=SR`.** Suppose `D2=NL`. Then `D2` is also an N-arrival, fed by
some N-departure `U` on row four. The walk

```text
U -N-> 5:D2 -W-> 2:WL -S-> 1:SL -E-> 4:EL
```

is closed, so `U` immediately precedes `4:EL`. That predecessor is `4:ER`,
which departs south. This is a contradiction.

**(1b) `D3=n2=NL` immediately follows `D2`.** The walk

```text
5:D2 -W-> 2:WL -S-> 1:SL -E-> 4:EL -N-> 5:n2
```

is closed (`4:EL` is the second N-departure of row four). Hence `n2`
immediately follows `D2=SR` and turns left, so `n2=NL`. It is a
W-departure right after `D2`, so `n2=D3`.

**(1c) Row five begins `D1,SL,n1,SL,D2,D3` or `n1,SL,D1,SL,D2,D3`, and
`D1=SR`, `n1=NR`.** If `D1=NL`, then `D1` is an N-arrival before `n2`, so
`D1=n1`. The first event of the row is an R and cannot be `D1`, which turns
left. That event would then be an N-arrival before `n1` or a W-departure
before `D1`, which is impossible. Hence `D1=SR`. Every `NL` is a
W-departure and `D1=D2=SR`, so the only `NL` is `D3`, and `n1=NR`. Every R before `D2` is an N-arrival before `n2` (only `n1`) or a
W-departure before `D2` (only `D1`). Also, `n1` precedes `D2`, because it
precedes `n2=D3`, which immediately follows `D2`. So exactly two R's
precede `D2`. By (A), `D2` sits at position 4 and positions 0-3 read
`R,L,R,L`. The two L's are not `NL`, so they are `SL`.

We call the first form **case P**
(`SR,SL,NR,SL,SR,NL`) and the second **case Q** (`NR,SL,SR,SL,SR,NL`).
In both cases `D2` is the fourth S-arrival of row five. `D1` is the first S-arrival
in case P and the second in case Q. In case P, the first three S-arrivals
are `5:SR@0, 5:SL@1, 5:SL@3`, and the first three E-departures are
`5:SL@1, 5:NR@2=n1, 5:SL@3`. (Here `@i` is the position in the stable
word, counted from 0.)

(Alternation and the counts then give the whole row,
`X,SL,Y,SL,SR,NL,(NR,SL)^(1+b),NR,[SL]^(1-omega_5)`. Only the six-event
prefix is used below.)

## Step 2: row six

Write `sigma_r` for the r-th S-departure of row six. It feeds the r-th
S-arrival of row five.

**(2a) `E4=EL`.** The walk `5:D3 -W-> 2:WR2 -N-> 3:NR2 -E-> 6:E4` is forced.
If `E4=ER`, one further S step returns to row five. This closed walk would
make the successor of `D3=NL` an R-port that arrives from the north, that
is `SR`. That would be a fourth W-departure, but row five has only three.

**(2b) `E3=ER=sigma_4`, and `E4` immediately follows it.** Let `Z=sigma_4`.
It feeds `D2`, the fourth S-arrival. The eight-step walk

```text
Z -S-> 5:D2 -W-> 2:WL -S-> 1:SL -E-> 4:EL -N-> 5:D3 -W-> 2:WR2 -N-> 3:NR2 -E-> 6:E4
```

is closed. So `E4=EL` immediately follows `Z`, and `Z` turns right. As an
S-departure it is `ER`, an E-arrival immediately before `E4`, so `Z=E3`.
In particular **exactly three S-departures precede `E3`.**

**(2c)** Let `Z1` be the S-departure feeding `D1`. It is `sigma_1` in case
P and `sigma_2` in case Q. The walk

```text
Z1 -S-> 5:D1 -W-> 2:WR1 -N-> 3:NR1 -E-> 6:E2
```

is closed. So `E2` immediately follows `Z1` and has the opposite turn.
`Z1` is `ER` or `WL`, which gives four cases.

* **P1 (case P, `Z1=ER`).** `Z1` is an E-arrival immediately before `E2`,
  so `Z1=E1=ER` and `E2=EL`. An event before `E1` would be neither an
  E-arrival nor an S-departure, hence a `WR`. The event just before
  `E1=ER` would then be an L, which is impossible. So row six begins
  `ER(E1),EL(E2)`, and `E2` is its **first** N-departure.
* **P2 (case P, `Z1=WL`).** `E2=ER` immediately follows `Z1=sigma_1`. `E1`
  precedes `Z1` and is not an S-departure, so `E1=EL`. Position 0 is an R
  that is not an E-arrival (`E1` turns left), so it is `WR`. Position 1 is
  `E1`: a `WL` there would be `Z1`, which has `E1` before it. Position 2
  is R. It cannot be `E2`, since `Z1` must come directly before `E2`, so
  it is `WR`. Position 3 is an L that is not an E-arrival (`E2` turns
  right), so it is `WL=sigma_1=Z1`, and position 4 is `E2=ER=sigma_2`.
  Position 5 is an L and not `E3=ER`, so it is `WL=sigma_3`. If position 6
  were `WR`, position 7 would be a fourth S-departure before `E3`. So
  position 6 is `E3`, and position 7 is `E4`:

  ```text
  6: WR, EL(E1), WR, WL, ER(E2), WL, ER(E3), EL(E4), ...
  ```

  Here `E1` is the **second** N-departure. The first four W-arrivals are
  `@0,@2,@3,@5`, and `6:WL@3, 6:ER@4, 6:WL@5` are `sigma_1,sigma_2,sigma_3`.
* **Q1 (case Q, `Z1=ER`).** As in P1, `Z1=E1=ER` and `E2=EL`. Now
  `sigma_1` precedes `E1` and is a `WL`, so position 0 is `WR` and position 1
  is `WL=sigma_1`. If position 2 were `WR`, position 3 would be an L before
  `E1`, which is a second `WL` before `Z1=sigma_2`. So row six begins
  `WR,WL,ER(E1),EL(E2)`, and `E2` is the **second** N-departure.
* **Q2 (case Q, `Z1=WL`)** is impossible. `E2=ER` immediately follows
  `Z1=sigma_2`, so `E2=sigma_3` while `E3=sigma_4`. The L right after `E2`
  would be an E-arrival between `E2` and `E3` or an S-departure between
  `sigma_3` and `sigma_4`, and neither exists.

## Step 3: row seven (only P2 survives)

Let `m_r` be the r-th N-arrival of row seven, fed by the r-th N-departure of
row six. Let `Gamma` be the forced walk from `4:ER`:

```text
P2:  4:ER -> 3:SL1 -> 6:E1(EL) -> 7:m2
P1:  4:ER -> 3:SL1 -> 6:E1(ER) -> 5:D1 -> 2:WR1 -> 3:NR1 -> 6:E2(EL) -> 7:m1
Q1:  4:ER -> 3:SL1 -> 6:E1(ER) -> 5:D1 -> 2:WR1 -> 3:NR1 -> 6:E2(EL) -> 7:m2
```

In P1 `E1` is `sigma_1`, which feeds the first S-arrival `D1` of case P. In
Q1 it is `sigma_2`, which feeds the second S-arrival `D1` of case Q. Write
`q=1` in P1 and `q=2` otherwise. `Gamma` has displacement `(1,0)` and no
row-four event after its start.

**(3a) `m_q=NR`.** If `m_q=NL`, it departs west into a W-arrival of row
four. That closes `Gamma` into a walk from `4:ER` that satisfies (F). The
stable successor of `4:ER` is `4:EL`, an E-arrival (this is where `k=0` is
used). Contradiction.

**(3b)** The walk `7:W2 -W-> 4:WL1 -S-> 3:SR -W-> 0:WR -N-> 1:NR -E->`
`Gamma` ends at `m_q`, and it is closed (8 steps in P2, 12 in P1 and Q1).
So `m_q=NR` immediately follows `W2`, and `W2` turns left: `W2=NL`, an
N-arrival before `m_q`. In **P1** (`q=1`) no N-arrival precedes `m1`, which is
a contradiction. In P2 and Q1, `W2=m1`, and `m2` follows it immediately.

**(3c) Q1 is impossible.** The walk

```text
6:WR@0 -N-> 7:m1=W2 -W-> 4:WL1 -S-> 3:SR -W-> 0:WR -N-> 1:NR -E-> 4:ER -S-> 3:SL1 -E-> 6:E1
```

is closed. `6:WR@0` is the first N-departure. The walk lands on `E1`,
which is at position 2 in Q1, but the successor of position 0 is position
1. (In P2 the same walk lands on position 1.)

**(3d) In P2, row seven begins `SR(W1), NL(W2=m1), NR(m2)`.** Events before
`W2=m1` are not N-arrivals, and the only W-departure among them is `W1`. So
the only R available before `W2` is `W1=SR`. Position 0 is therefore `W1`.
Position 1 is an L. If it were an `SL`, position 2 would be an R before
`W2`, since `W2` turns left and cannot sit at position 2. No such R
exists, so position 1 is `W2`.

## Step 4: row eight begins `ER,EL`

Let `F1,F2,F3` be the first three E-arrivals of row eight, fed by
`5:SL@1, 5:n1, 5:SL@3` (Step 1, case P). The forced walk

```text
Delta:  7:W1 -W-> 4:WR1 -N-> 5:n1 -E-> 8:F2
```

has displacement `(0,1)`.

**(4a) `F2=EL`.** If `F2=ER`, its S step closes `Delta` from `7:W1` and lands
on an S-arrival of row seven. The successor of `W1=7:SR@0` is the
N-arrival `7:NL@1`, so this is a contradiction.

**(4b) `F1=ER` is the first S-departure, at position 0.** The first
S-departure `Y1` of row eight feeds the first S-arrival of row seven,
namely `W1`. The walk `Y1 -S-> Delta` is closed, so `Y1` immediately
precedes `F2=EL` and turns right. It is therefore `ER`, and hence `F1`. An
event before `F1` is neither an E-arrival nor an S-departure, so it is
`WR`. The event just before `F1=ER` would then be an L, which is
impossible. So row eight begins `ER(F1),EL(F2)`, and `F2` is its first
N-departure.

## Step 5: every row nine is contradictory

Let `X_r` be the r-th W-departure of row nine. It feeds the r-th W-arrival
of row six, so `X3->6:WL@3` and `X4->6:WL@5`. Let `p_r` be the r-th
N-arrival of row nine; `p1` is fed by `F2`.

**(5a) `X3=SR` and `p1=NL=X4`, consecutively.** The twelve-step walk

```text
9:X3 -W-> 6:WL@3 -S-> 5:D1 -W-> 2:WR1 -N-> 3:NR1 -E-> 6:ER@4 -S-> 5:SL@1
     -E-> 8:F1 -S-> 7:W1 -W-> 4:WR1 -N-> 5:n1 -E-> 8:F2 -N-> 9:p1
```

is closed. It uses `6:WL@3=sigma_1`, `6:ER@4=E2=sigma_2`, `5:SL@1` as the
first E-departure, and `F1` as the first S-departure. So `p1` immediately
follows `X3` with the opposite turn. `X3=NL` would be an N-arrival before
`p1`, so `X3=SR`, `p1=NL`, and `p1` is the next W-departure `X4`. (With
(A) this forces row nine to begin `SR,SL,SR,SL,SR,NL`.)

**(5b) The contradiction.** The forced walk

```text
9:X4 -W-> 6:WL@5 -S-> 5:SL@3 -E-> 8:F3
```

uses `6:WL@5` (the fourth W-arrival and `sigma_3`), which feeds the third
S-arrival `5:SL@3`, the third E-departure. `F3` has two possible ports.

* `F3=EL`. Then `F3` feeds `p_q`, where `q` is its rank among
  N-departures. `F2` and `F3` are consecutive E-arrivals and both turn left.
  The event right after `F2` is therefore an R that is not an E-arrival, a
  `WR` N-departure. So `q>=3`. The walk from `X4=p1` to `p_q` is closed,
  so `p_q` would be the stable successor of `p1`, but `p2` lies strictly
  between them.
* `F3=ER`. Then `F3` departs south into row seven, and the eight-step walk

  ```text
  7:W1 -> 4:WR1 -> 5:n1 -> 8:F2 -> 9:p1=X4 -> 6:WL@5 -> 5:SL@3 -> 8:F3 -> 7:(S-arrival)
  ```

  is closed. Its directions are `W,N,E,N,W,S,E,S`, and it meets row seven
  at no intermediate event. So it must end at the successor `7:NL@1` of
  `W1`, but it ends at an S-arrival.

Every choice of row nine is contradictory. Both initial bands are
impossible at every period. ∎

## Remarks

* **What is used where.** `k=0` (`4:ER` immediately followed by `4:EL`) is
  used in (1a) and (3a). `j=1` (rows three and four begin
  `SR,SL1` and `WR1,WL1,ER`) fixes the edges `4:WL1->3:SR` and
  `4:ER->3:SL1` used in (3b) and (3c). The detailed forms of rows three and
  four fix the edges `3:NR1->E2` and `3:NR2->E4` and the ranks used in
  Step 2. `b` enters only through the row lengths, and no wake indicator
  at levels 5-9 is used.
* **The clock is not needed.** The published enumeration applied the
  lifted clock at every level and recorded clock rejections at levels 6-8.
  The hand proof shows these are inessential. As a consistency check (not
  a premise), rerunning the same enumeration with the clock switched off
  gives:

  | `b` | level 5 | 6 | 7 | 8 | 9 |
  |---:|---:|---:|---:|---:|---:|
  | 0 | 4 (P 2, Q 2) | 42 (P1, P2, Q1: 14 each) | 72 (all P2) | 744 (all P2) | **0** |
  | 1 | 4 (P 2, Q 2) | 66 (22 each) | 504 (all P2) | see log | **see log** |

  The survivors at every level have exactly the prefixes derived above
  (a no-clock rerun of the enumeration asserts them).
* **Contrast with the upper cap.** At an upper `(1,2,3)` cap, the band
  `(1,0,2)` already dies at level five by an `N+10` clock inequality
  (`odd_skew_upper_fat123_four_band_reduction_2026-09-21.md`). At the lower
  cap the voltage signs reverse, and the same chain only bounds `N` from
  below. Put `V=tau(2:WL)`. Steps 1-2 give `tau(2:WR2)=V+4` and
  `tau(4:WL2)=V-4`, and the successor `n3` of `D3` then forces `N>=14`.
  There is no contradiction there. The obstruction is instead the purely
  combinatorial ladder of Steps 1-5.
* **Scope.** This is a hand proof inside the stable-word framework of the
  September 12 normal form (alternation, ordinal matching, and first
  returns, all proved there). It does not rely on the computer
  enumeration. It does not touch the open lower bands `(0,*,1,1,1)` and
  `(1,1,1,1,0)`, where `k=1` removes the step (3a).

## Checks

* `python code/python/verify_lower_fat123_a0_102_hand_walks.py` (self-contained) re-derives every
  displayed walk from the stated row prefixes for `b=0,1`. For each walk it asserts the rank and
  heading of every step, the endpoint, zero displacement and voltage, and the absence of
  intermediate visits to the start row (`all walk certificates passed`).
* As evidence only, the enumeration `code/python/verify_lower_fat123_a0_102_exclusion.py`, rerun
  with the clock switched off, finds survivors with exactly the prefixes derived in Steps 1-4 at
  every level, and an empty level-nine frontier.
