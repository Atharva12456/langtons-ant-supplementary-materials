# Excluding M_L0 in form Q

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

The middle suffix `M_L0` is impossible for all four
prefixes on eight. Its two higher-row endings need
not be treated separately: the square at `L7` already
has no possible west predecessor on eleven.

This removes four more formal words on eight from Q.
Its middle placement now has only suffix `M_L1`;
the after placement still has `A_0,A_1`. With four
prefixes, twelve formal words remain. This is not an
exclusion of Q or the whole `(1,-3)` orbit.

## The fixed pair on ten

The existing reduction
`odd_skew_upper_a_q_middle_third_west_2026-09-15.md`
gives, in `M_L0`,

```text
8: ...,E3=ER,L7=WL,E4=ER,E5=EL,b=WR,L9=WL,c=WR,E6=EL;
10: ...,U=WL,F5=ER,F6=EL,X=WR,F7=EL.
```

The port `L7=WL` supplies the `SL` after the middle
north arrival on seven, which in turn supplies `F6`.
In particular, `F5=ER,F6=EL` are consecutive stable
events on ten.

## Neither turn is possible on eleven

Let `P` be the west departure on eleven feeding `L7`.
There is a square first return

```text
P -> 8:L7=WL -> 7:SL after the middle north arrival
  -> 10:F6=EL -> north arrival on eleven.
```

Suppose `P=SR`. Its consecutive target is `NL`, the
next west departure after `P`. The next west arrival
on eight after `L7` is `b=WR`; call its predecessor
on eleven `Pb`. Thus `Pb=NL` is supplied by `F6`.
But then

```text
8:L7=WL -> 7:that SL -> 10:F6=EL -> 11:Pb=NL -> 8:b=WR
```

is a square first return on eight. It skips both
`E4=ER` and `E5=EL`, which lie between `L7` and `b`
in stable order. Hence `P` cannot be `SR`.

Suppose instead that `P=NL`. Starting at its north
predecessor on ten gives the square first return

```text
north predecessor -> 11:P=NL -> 8:L7=WL -> 7:that SL -> 10:F6=EL.
```

The predecessor must turn right, hence be `WR`,
immediately before `F6=EL`. The actual predecessor
is `F5=ER`, which departs south and cannot supply
`P`. This is also impossible.

Both possible west turns at `P` have been excluded.
Therefore no `M_L0` continuation exists, including
either of the higher-row endings recorded in
`odd_skew_upper_a_q_ml0_two_tails_2026-09-15.md`.
