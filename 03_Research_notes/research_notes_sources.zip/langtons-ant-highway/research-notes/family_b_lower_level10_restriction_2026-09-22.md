# A row-ten restriction in lower `(1,2,2)` Family B

22 September 2026. This is an all-period **necessary prefix restriction** at
drift `(1,-3)`. It does not exclude Family B or close the drift orbit.

Family B has `W=6m+4` and wakes

```text
{0,5,6,8,6p+2,6r+4,W-2,W},
2<=p<r<=m-1,  p+r odd.
```

The first later wake is at least level fourteen. In particular, levels nine
and ten are non-wake. The lower-cap return argument fixes rows zero through
seven, and gives two row-eight words:

```text
8A: ER,EL,WR,WL,WR,WL,WR,WL,ER
8B: WR,EL,WR,WL,ER,WL,WR,WL,ER.
```

Both force `9: (NR,SL)^4`, as checked separately in
`code/python/verify_family_b_level9_word.py`. Flow counts and R-first
alternation then allow exactly 32 row-ten words after either row-eight word.
All 64 pass the local physical first-return test. Exact lifted-clock
feasibility eliminates 24 of the 32 after 8A and 15 of the 32 after 8B:

| Row eight | Raw row-ten words | Bad physical return | Bad lifted clock | Retained |
|---|---:|---:|---:|---:|
| 8A | 32 | 0 | 24 | 8 |
| 8B | 32 | 0 | 15 | 17 |

The retained words are listed in `work_family_b_global/lower_level10_restriction.json`. For each
finite word, the checker solves integer equations on every known successor
edge. In lower-cap coordinates an east or west edge of voltage `v=+1` or
`-1` imposes `tau(target)=tau(source)+1-N*v`; vertical edges have `v=0`.
Successive stable visits on a row have time gap at least four. It also imposes
`N>=max(6, number of displayed events)`, since those events have distinct
phases in any full period. These are necessary conditions for any period,
with no upper bound on `N` or `W`. They are not sufficient for a full tour.

Run `python work_family_b_global/verify_lower10_restriction.py` from the
repository root. The script uses exhaustive `row_options` and
`stable_words` from `code/python/p2_research.py`, verifies the unique row-nine
word again, checks every row-ten first return, and writes the result JSON.
The row-eight normal form and completeness of the stable-word framework are
the hand prerequisites; the checker is a finite certificate, not a formal
proof of those prerequisites.

This does not create a cross-cap contradiction. In particular, the upper
`210` branch still requires `r=m-1` from its separate offset-six
restriction. Then `p+m` is even and the closest wake beyond upper offset six
is at least inward offset fourteen. Both paired upper row-five/six patterns
retain prefixes with exact integer clocks even when `N>=1,000,000`, as
`work_family_b_global/check_upper_large_period.py` confirms on saved row-ten states. This tests
only prefix equations; it rules out a small upper period bound from those
particular prefixes, not every later-period argument.
