# A quiet upper missing cap is impossible; the lower band `(0,1,1,1,1)` has no upper missing cap

23 September 2026

## Lemma

At drift `(1,-3)`, an upper missing cap whose inward offsets
`5,6,7,8,9,11,12` are all non-wake is impossible at every period. Offset ten may
have either parity.

Use upper inward offsets with headings rotated by 180 degrees. The cap rows are
`0: WR`, `1: NR`, `2:` empty. Offsets three and four are enumerated with both
wake values; offsets `5-9,11,12` are non-wake and offset ten takes both values.
Every later row is enumerated from the flow and excess equations and
right/left alternation. A word is discarded only for a violated
zero-displacement return while it is built, a witnessed finite same-cell first
return to the wrong event (no quotient-cycle extrapolation), or an infeasible
upper-cap clock

```text
tau(target) = tau(source) + 1 + N*lambda,   N >= 6,   same-cell gaps >= 4.
```

| Offset | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Survivors | 2 | 1 | 1 | 2 | 3 | 2 | 5 | 4 | 6 | **0** |

At offsets three and four only the known cap rows `SR,SL` and `WR,WL,ER`
survive. No P22, rank or moment condition, and no bound on period, width or row
length, is used. The lemma strengthens the September 9 table, whose hypothesis
also made offset ten non-wake.

`code/python/verify_upper_missing_quiet_5_12_lemma.py` (Z3 clock) reproduces
the table and writes `results/upper_missing_quiet_5_12_checks_2026-09-23.json`.
The Java frontier explorer, with its exact parametric clock, gives the same
counts with and without cycle extrapolation.

## Corollary: lower band `(0,1,1,1,1)` with an upper missing cap

Take the lower `(1,2,3)` band with `omega_3=0`, `omega_4=1`,
`(j,k,l)=(1,1,1)`: lower wakes `0,2,4`, non-wakes `1,3`. An upper missing cap
adds wakes `W,W-1,W-4` and non-wakes `W-2,W-3`. Two wakes `x,y` remain.

P22 fixes the fibres. In every residue class of `W` modulo six, one fibre holds
an opposite-parity fixed pair and must be the four-wake fibre, and the other two
are two-wake fibres of equal parity:

| `W mod 6` | four-wake fibre | two-wake fibres | `x` | `y` |
|---|---|---|---|---|
| 0 | `{2,W-4,W-1,x}` | `{0,W}`, `{4,y}` | `2 mod 6` | `4 mod 6` |
| 2 | `{4,W-4,W-1,x}` | `{2,W}`, `{0,y}` | `4 mod 6` | `0 mod 6` |
| 4 | `{0,W-4,W-1,x}` | `{4,W}`, `{2,y}` | `0 mod 6` | `2 mod 6` |

Both extra wakes are even, so every odd upper offset is non-wake. The offset
`W-x` is `4 mod 6` and `W-y` is `2 mod 6` in every row, so offsets `6` and `12`
are non-wake.

The rank parity excludes offset eight. Counting the ordered cross-fibre pairs
gives `I=11+[y<x]`, `13+[y<x]` and `8+[x<y]` in the three rows, so the rank
condition requires `y<x`, `y<x` and `x>y` respectively. If `y=W-8`, then `x`
would have to lie strictly between `W-8` and `W`, in the residue class displayed
for `x` and different from `W-4`; no such level exists. Hence offset eight is
non-wake.

Thus offsets `5-9,11,12` are non-wake, and the lemma applies. **The lower band
`(0,1,1,1,1)` cannot have an upper missing cap.** A brute-force enumeration of
all P22, rank and moment placements through `W=160` confirms that the only upper
wake patterns through offset twelve are `{0,1,4}` and `{0,1,4,10}`. The additive
moment is not needed.

The band remains open with upper guard and upper `(1,2,3)` caps. For the band
`(0,0,1,1,1)` with an upper missing cap, the lemma removes the schedules whose
offsets `5-9,11,12` are non-wake. Twelve other upper schedules through offset
fourteen remain.

## Compression of wake schedules

Let a wake placement contain no wake in `[T-12,T)`. Shifting every wake at or
above `T` down by twelve preserves each level modulo six and its parity, hence
P22. It also preserves the relative order, hence the rank parity. Each shifted
term `(-1)^(t+1) floor((t+1)/3)` of the additive moment changes by `+-4`, so the
moment modulo four is unchanged. Cap-local conditions below `T-12` and above
`T` are unaffected. With eight wakes, a width `W >= 2D+130` always leaves such a
gap between depth `D` from either cap. So every pair of lower and upper wake
prefixes of depth `D` that occurs at some width already occurs at a width below
`2D+130`. Brute-force schedule lists through that width are therefore complete.
