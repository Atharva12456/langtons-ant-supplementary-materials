# Level-seven order when the lower fourth level is wake

Consider a lower `(1,2,2)` cap in the `(1,-3)` orbit, with
`omega_4=1`. Write `c=omega_5`, `e=omega_6`, and `f=omega_7`.
The lower-band theorem fixes the level-five word starting `SR,SL`
and the initial level-six triple `ER,EL,ER`.

Put `k=1-c+e`, the number of `WR` ports on level six. Level seven
has the following necessary word for some `0<=j<=k`:

```text
SR,SL,SR,NL,SR,SL,(NR,SL)^j,SR,(SL,NR)^(k-j),[SL]^(1-f).
```

Its west departures, in order, are always `SR,SR,NL,SR,SR`.
When `(c,e)=(0,1)`, the endpoint `j=2` is impossible.

There is a further restriction in the surviving band `(c,e)=(1,1)`.
If `j=1`, then `f=0`, level eight is wake, and it has one of the
two words

```text
ER,EL,WR,WL,WR,WL,WR,WL,ER,WL,WR,EL,WR,WL,ER;
WR,EL,WR,WL,ER,WL,WR,WL,ER,WL,WR,EL,WR,WL,ER.
```

This subcase therefore has exactly the wakes `0,4,5,6,8` through
level eight. Its continuation is not excluded. All statements here
are all-period lower-cap restrictions.

## The last two west departures

Use the common rows from
`odd_skew_fat122_five_lower_bands_2026-09-13.md`. Let `Wi` be the
west departures on level seven, and `Ni` its north arrivals. The
initial triple on level six gives

```text
W1=SR,       W2=SR,       W3=NL=N1.
```

The preceding note also proves `W4=SR`, immediately followed by
`SL`. Let `J` be the first `WL` on level six, and suppose a north
arrival `N2` exists on level seven. Its source `X` is the first
`WR` on level six and satisfies `tau(J)<tau(X)`.

Label the east arrivals on level eight as `Ei`. The fixed path
from `W4` gives `tau(E3)=tau(W4)+7`, whereas
`6:J -> 5:SL2 -> 8:E4` gives `tau(E4)=tau(J)+2-N`.
The order `E3<E4` implies

```text
tau(W4) < tau(J)-N-5 < tau(X)+1 = tau(N2).
```

Thus `W4` occurs before any remaining north arrival. The word on
level seven starts `SR,SL,SR,NL,SR,SL`.

If `W5=NL=N2`, there would be no north right turn between
`N1=NL` and `N2=NL`. The intervening `W4=SR` is already followed
by `SL`. A right turn is still needed before `W5`, but it could
be neither a north arrival nor another west departure. This is
impossible.

The only other possible north ordinal for `W5=NL` is `N3`, when
`(c,e)=(0,1)`. Its source is the final `WR` on level six, after
the final `WL`. The path from `W5` through
`4:last WR,5:last NR` gives

```text
tau(E5)=tau(6:last WR)+4.
```

But `6:last WL -> 5:last SL -> 8:E6` gives
`tau(E6)=tau(6:last WL)+2-N`, contradicting `E5<E6`.
Hence `W5=SR` as well.

All remaining north arrivals are `NR`. Inserting their `k` copies
before or after `W5`, with alternation, proves the stated word.
For `(c,e)=(0,1)`, if both north arrivals preceded `W5`, the same
comparison would give `tau(E5)>tau(6:last WR)` and
`tau(E6)<tau(6:last WR)`. Thus `j=2` is excluded.

## The band with `(c,e,j)=(1,1,1)`

Here the relevant fixed rows are

```text
5: SR,SL,NR,NL,NR,SL,NR
6: ER,EL,ER,WL,WR
7: SR,SL,SR,NL,SR,SL,NR,SL,SR,[SL]^(1-f).
```

On level eight, `E3=ER` is already forced by the return from
`W4=SR`; it is the fifth south departure. Let `D1,D2` be the two
west departures on level nine, feeding `6:WL,WR`. The three-step
path from `D2` through `6:WR,7:NR` ends at the third east arrival
`F` on level ten. The preceding east arrival `F'` there is supplied
by the `SL` immediately after `7:W4`.

Suppose first that `E5=EL`. The square from the south predecessor
of `W5` forces the consecutive pair `E4=ER,E5=EL`. The return

```text
D1 -> 6:WL -> 5:SL2 -> E4=ER -> 7:W5=SR
   -> 4:last WR -> 5:last NR -> E5=EL -> north arrival on 9
```

has length eight and is a first same-cell return on level nine.
The source cannot be `NL`: its incoming predecessor `X` on level
eight would be the north departure immediately preceding `E5`,
and `X -> D1 -> 6:WL -> 5:SL2 -> E4` would be a four-step first
return. It would force `X=EL=E3`, contradicting `E3=ER`.

Therefore `D1=SR`, with consecutive target `NL=D2`. If `F=ER`,
its south step would complete a four-step return from `D2=NL`
to a further `SR`, contradicting that `D2` is the last west
departure on level nine. Hence `F=EL`.

The south predecessor of `D1` on level ten follows the eight-step
return to `D2`, then the three-step path to `F`. This is a
twelve-step first same-cell return, so its source is the preceding
east arrival `F'=ER`. The resulting path is

```text
8:E3=ER -> 7:SL -> 10:F'=ER -> 9:D1=SR -> 6:WL
        -> 5:SL2 -> 8:E4=ER.
```

It has direction word `SESWSE`, length six, and displacement
`(1,-3)`. It would give `tau(E4)=tau(E3)+6-N`, contrary to
`E3<E4` and `N>=6`. Thus `E5=EL` is impossible.

It follows that `E5=ER`. Its south step returns from the last
right turn `W5=SR` to a following `SL`, forcing `f=0`. This is
the eighth and last south departure on level eight, and `E5` is
also its last east arrival. No left turn can follow it: an `EL`
would be another east arrival and a `WL` another south departure.
Thus level eight is wake.

## The two words on level eight

Between the fifth south departure `E3=ER` and the eighth `E5=ER`
there are only two south departures. If `E4=ER`, alternation
between each successive pair of east right turns would require
an intervening `WL`, putting `E5` at south ordinal at least nine.
Therefore `E4=EL`.

Now `D1` has the four-step first return through
`6:WL,5:SL2,E4=EL` to a north arrival on level nine. If it were
`SR`, its target would again be `NL=D2`. The same argument with
`F,F'` would give the six-step translated path from `E3` to `E4`
and the same time contradiction. Hence `D1=NL`.

Its incoming predecessor on level eight must consequently be
`WR`, immediately preceding `E4=EL`. The seventh south departure
on level eight feeds `W5=SR`, so it is `WL`, immediately followed
by `E5=ER`. These facts fix the final block as

```text
E3=ER,WL,WR,E4=EL,WR,WL,E5=ER.
```

For the first two east arrivals, the square through `W1` allows
either initial `E1=ER,E2=EL`, or prefix
`WR,E1=EL,WR,WL,E2=ER`. The third and fourth south departures
before `E3` must be `WL`. Alternation then fixes the two complete
fifteen-visit words in the statement.

These are necessary orders, not traces. Both the `j=0`
continuation of this band and the listed `j=1` words are
subsequently excluded in
`odd_skew_fat122_adjacent_wake_band_exclusion_2026-09-14.md`.
The remaining lower-cap work is recorded in the case ledger.
