# The full-rail growth-eight subfamily at drift `(4,-4)` is impossible

## Statement

No finite-support periodic highway with growth eight and drift in the quarter-turn
orbit of `(4,-4)` visits all four residue lanes on both extremal lines.

Scope correction, 3 September 2026: full rail occupancy is an additional
hypothesis, not a consequence of extremal singleton visits. The earlier
whole-orbit claim is withdrawn; see `rail_occupancy_scope_audit_2026-09-03.md`.

This is an analytic all-period subfamily exclusion. The bounded audit named at the end
checks the block algebra but is not used as a finite search over periods or widths.

## The wake is exactly the two guard rails

Normalize the drift to `d=(4,-4)` and put `t=x+y`, `r=x mod 4`.  Let `alpha` and
`beta` count odd translation classes on horizontal- and vertical-arrival levels.
The extremal-line theorem says that both guard rails are horizontal and that each
visited class there is a singleton. Under the full-occupancy hypothesis, each
rail contributes `m=4` odd classes, one in every lane. Since the total
growth is eight,

```text
alpha=8,       beta=0.
```

There are no other odd classes.  If the rail levels are `1` and `W+1`, then `W`
is even and the excess-one boundary is

```text
D[1,r]=D[W+1,r]=1       for r=0,1,2,3,
D[t,r]=0                at every interior vertex.
```

The period congruence also shows that `N=0 (mod 8)`: all eight odd classes have
one checker sign, so the number `A` on the even checker is either zero or eight,
and `N/2+4-4+A=0 (mod 4)`.

## The parity flow

Reduce every directed edge multiplicity modulo two.  A horizontal-arrival vertex
has vertical outgoing blocks `S,N`; a vertical-arrival vertex has horizontal
blocks `W,E`.  At each vertex, both the incoming and outgoing parity sums equal
`D[t,r]`.  This reduction loses no sign information: block-pair inversions are
products of multiplicities modulo two, and the local formulas use only their
parities and `D`.

At the bottom rail the exterior block is zero, so the inward block is one in all
four lanes.  Incoming parity then makes the corresponding block at level two one.
Because the level-two boundary is zero, its other outgoing block is also one.
Repeating these two steps forces both blocks at every interior vertex and the
single inward block at the top rail.  This is the unique finite parity flow.

The local rank correction vanishes.  At an interior vertex the positive incoming
and outgoing parities are both one, while `D=0`; at a rail vertex they differ and
`D=1`.  Substitution in the two local formulas

```text
vertical-arrival:    p(D+1),
horizontal-arrival:  D(p+1)
```

gives zero in every case.

## The edge-block sign

Order blocks by `(t,r,port)`, negative port before positive port, at source and
target.  For the full parity flow just described, a direct count of reversed block
pairs for general lane count `m` gives

```text
E_count = m^2 W + m^2(W-1) + (m-1)W.
```

The first term counts adjacent-level reversals.  The second combines the two-level
and same-level mixed-port reversals; the last comes from the two cyclic lane shifts
on each interior vertical-arrival level.  Since `W` is even,

```text
E = E_count = m  (mod 2).
```

Here `m=4`, so `E=0`, and the local term is also zero.  The port-sorting
factorisation of the one-cycle phase successor therefore gives

```text
K = 1+E+L = 1  (mod 2).
```

Exact P3 alternation gives the opposite answer: every left turn has odd stable
rank, and

```text
K = #L = (N-8)/2 = 0  (mod 2)
```

because `N=0 (mod 8)`.  This contradiction proves the statement.

## Audit

```text
python code/python/growth8_extremal_m4_rank_audit.py \
  --output results/growth8_extremal_m4_rank_audit.json
```

The audit constructs the finite GF(2) flow system for every modulus through eight
and every even width through twenty.  In all 80 systems the solution is unique and
is the full block set.  It then compares the direct inversion count with the closed
formula above and checks every local correction.  These are bounded regressions of
the displayed induction and count, not an exhaustion of possible highways.
The program sets the rail boundary to one in every lane; it does not prove
that a highway must have this boundary.

```text
growth8_extremal_m4_rank_audit.py
e1f2a1e12b4ec36a6380537da1076f868c6d716e5d0cd41d042b77e6f5761fc9

growth8_extremal_m4_rank_audit.json
ad33827ca50272365198b7a93f3ad120d0e5b98f00c7f9d50352352b328fdcf9
```
