# Three necessary early upper-fat wake-six words

For literal `(1,3)`, an upper F123 cap with quiet three/four/five, wake
six and quiet seven through ten has only three necessary prefixes through
seven. This is a complete independently audited local implication, valid
with integer `N>=1`, unbounded above, upper clocks `+N` and strict stable
order. It is not an exclusion of the cap or of the whole orbit.

All three have the cap `0:NR`, `1:WR,WL`, `2:NR,SL,NR` and share

```
3 WR WL WR WL ER WL;
4 NR SL SR SL NR NL NR SL;
5 WR WL WR EL ER WL WR WL ER WL.
```

Their remaining pairs are

```
A
6 NR SL NR NL SR SL SR SL SR NL NR;
7 WR WL WR EL ER WL ER WL ER EL ER WL WR WL.

B
6 NR SL NR NL SR SL SR SL SR NL NR;
7 WR WL WR EL ER WL ER WL ER WL ER WL WR EL.

C
6 NR SL NR NL SR SL SR SL NR NL NR SL NR NL NR;
7 WR WL WR EL ER WL WR WL WR EL WR WL ER WL ER WL WR EL.
```

The complete domains through offsets three to ten have survivor counts
`4,9,29,160,164,111,190,415`. The independent audit rederived every count
vector and every emitted candidate without frontier or fast-clock imports,
replayed 46,862 physical certificates, proved 32,929 rejected unbounded
clocks, and cross-checked 668 distinct clock signatures with Z3. Through
ten, the three early prefixes account for 324, 89 and two continuations.

The first quiet-ten stage was incomplete. A separately saved checkpoint
completed its remaining parents, deduplicated the exact candidate keys
and passed independent completeness verification. At the 2 October
checkpoint, quiet eleven was incomplete, with 3,414 partial survivors
after 19 of 415 parents; it provided no exclusion. Offsets twelve/thirteen
had not been attempted at that checkpoint.

At growth eight, lower-thin011 / upper-F123 wake-six has exact endpoint
family `W=6m+4`, residual `6r+2`, `1<=r<=m-2`, with even `m+r`.
Its residual upper distance is `14+12h`, and its arithmetic minimum width is 22.
Upper seven through thirteen are therefore quiet, so this three-prefix
restriction applies to that entire remaining family. It is not a
finite-width inference; the endpoint sign/rank/moment proof is in the
[exact classification](../work_positive_skew_high_thin_endpoints_20261002/high_thin_endpoint_families.md).

All 415 completed local words remain clock-feasible even after imposing
the necessary event-count floor `N>=assigned upper events+38`, where 38
is the lower011 footprint and the two assigned bands are disjoint.
Two independent implementations agree. Their earlier period witnesses
35 through 55 were never upper bounds. No closed quotient successor
cycle occurs in the 415 words. Thus this event-count floor alone cannot
close the family; a further physical/ordinal constraint is still needed.

The full evidence and reproduction commands are in
[the bounded probe note](../work_positive_skew_upperfat_wake6_20261002/findings.md).
The later [width-22 exclusion](positive_skew_thin011_width22_exclusion_2026-10-04.md)
rules out that member of this endpoint family; larger widths remain unresolved.
The full `(1,3)` orbit remains **open**.
