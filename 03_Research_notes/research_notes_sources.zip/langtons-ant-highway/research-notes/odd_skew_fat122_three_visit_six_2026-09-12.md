# The three-visit level-six branch requires two fat caps

Consider growth eight and drift `(1,-3)`, with a lower `(1,2,2)` cap.
Suppose level four is non-wake, level five is wake, and level six has
two `ER` ports. Then the wake and non-wake pattern through level eight is
forced:

```text
wake:      0,5,6,8
non-wake:  1,2,3,4,7.
```

Moreover, the upper cap is neither missing nor guard. It must be fat.
An upper `(1,2,3)` cap is possible only at widths `W=4 mod 6`.
These are all-period restrictions; the two-fat-cap continuation remains
unresolved.

## Three visits on level six

The lower-cap normal form gives

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL
5 A: SR,SL,NR,NL,NR
  B: NR,SL,SR,NL,NR.
```

With `e=omega_6`, the level-six counts are

```text
(ER,EL,WR,WL)=(r,3-r,5+e-3r,2-r).
```

For `r=2`, nonnegativity forces `e=1` and the entire stable word is
`ER,EL,ER`. The south departure feeding `5:SR` has the four-step return
through `5:SR,2:WR,3:NR` to the second east arrival on level six.
Its source is the first `ER` and its target is `EL`. The first south
arrival on level five is therefore `SR`, so word A is forced.

## Levels seven and eight

There are four west departures and one north arrival on level seven.
The second west departure has the twelve-step return

```text
W2 -> 4:first WL -> 3:SR -> 0:WR -> 1:NR -> 4:ER
   -> 3:first SL -> 6:first ER -> 5:SR -> 2:WR
   -> 3:NR -> 6:EL -> only north arrival on 7.
```

Its endpoints have opposite turns and are consecutive stable events.
The source must be `SR`, the target `NL`, giving

```text
7: SR,SL,SR,NL,SR,[SL]^(1-f),       f=omega_7.
```

Call the three right-turn south arrivals `SR1,SR2,SR3`. Level eight has
three east arrivals `E1,E2,E3`, supplied by `SL,NR1,NR2` on level five.
There are fixed paths

```text
7:SR1 -> 4:first WR -> 5:first NR -> E2,
7:SR3 -> 4:last WR -> 5:NL -> 2:WL -> 1:SL
      -> 4:EL -> 5:last NR -> E3.
```

The second path has length seven and ends at the physical cell immediately
north of its starting level-seven cell. If `E3=EL`, the south departure
feeding `SR3` would have an eight-step return to this `EL`, forcing its
opposite-turn source to be the immediately preceding east arrival `E2=ER`.
The first path would then give a four-step `SR1`-to-`SR3` return with
two right-turn endpoints. Thus `E3=ER`.

Its south step returns to the next stable visit after `SR3`, forcing that
visit to be `SL`. Hence `f=0`. The source of the eight-step level-eight
return is `WL`, immediately followed by `E3=ER`. These are the fourth
and fifth south departures there, and the fifth is the last.

The south predecessor of `SR1` has a four-step return to `E2`. If
`E2=EL`, that source is `E1=ER`. If `E2=ER`, the source is `WL`, and
`E1=EL` since it precedes the first south departure. Thus level eight
has two `ER` ports in either case. Its counts, with `b=omega_8`, are

```text
(ER,EL,WR,WL)=(2,1,2+b,3).
```

The visit `E3=ER` is both the last east arrival and the last south
departure. Every `EL` and `WL` consequently precedes it. No event can
follow it in an alternating stable word, since the next event would
have to turn left. The word ends with this right turn, so `b=1`.
The two possible stable words are

```text
8: ER,EL,WR,WL,WR,WL,WR,WL,ER,
or WR,EL,WR,WL,ER,WL,WR,WL,ER.
```

This proves the claimed wake pattern without any assumption on level nine.

## P22 removes both thin upper caps

The opposite checker signs at levels five and eight lie in residue two
modulo three, so that fibre must be the four-wake fibre. The two other
fibres each contain exactly two wakes. In particular,

```text
O_0={0,6},               |O_1|=2,               |O_2|=4.
```

There are five fixed non-wake levels through level eight. Eight distinct
wakes therefore require `W>=12`.

An upper guard supplies the three consecutive wakes `W-2,W-1,W`. One
of them lies in residue zero and is at least ten, contradicting
`O_0={0,6}`.

An upper missing cap supplies an opposite-sign pair at `W-4,W-1`.
That pair must lie in the four-wake fibre, residue two; otherwise a
second fibre would need four wakes. This forces `W=0 mod 3`, but the
upper endpoint `W` would then be an additional wake in `O_0`, again
impossible.

Both thin upper profiles are excluded. If the upper profile is `(1,2,3)`,
both `W` and `W-2` are wake. Neither can lie in `O_0`, so `W=1 mod 3`.
Since the width is even, this is `W=4 mod 6`.
