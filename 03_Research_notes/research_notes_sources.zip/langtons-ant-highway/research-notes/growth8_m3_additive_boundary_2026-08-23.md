# The additive condition for full rails at drift `(3,-3)`

## Result

Suppose a finite-support periodic highway has growth eight and drift in the
quarter-turn orbit of `(3,-3)`, and assume all three residue lanes are visited
on each extremal line. Normalize the transverse coordinate to
`t=x+y`, and put the lower and upper guard rails at levels `b` and `b+W`.
Extremal rigidity makes `W` even.  If the period-start ant is on level `p`, then
`b-p` is odd: the start heading is vertical, while the rail arrivals are
horizontal.

The two rails contain six of the eight odd translation classes.  The residue
theorem puts the remaining horizontal class and the remaining vertical class in
the same `x mod 3` lane and the same `y mod 3` residue.  After translating the
lane labels, write them as `(0,h)` and `(0,v)`.  Here `h` is odd, `v` is even,
and

```text
k=(v-h)/3
```

is an odd integer.  Every such highway must satisfy

```text
k = W+1  (mod 4).                                      (1)
N = 6    (mod 8).
N >= 4W+12|k|+2.                                       (6)
```

Scope correction, 3 September 2026: extremal rigidity proves singleton
visits, not full rail occupancy. Everything below that uses the six rail
classes has the additional full-occupancy hypothesis. See
`rail_occupancy_scope_audit_2026-09-03.md`.

In this subfamily, `W=4` is impossible, while `W=6` remains arithmetically
possible. Since `k` is odd, the second inequality gives `N>=4W+14`. These are
all-period restrictions on the full-rail subfamily, not on the whole orbit.

## The complete additive family on the forced boundary

Write a drift-periodic mod-four weight as `w[r,t]`, where `r=x mod 3` and the lane
index is read modulo three.  The zero four-corner condition is

```text
w[r,t]+w[r+1,t+1]+w[r,t+1]+w[r+1,t+2]=0  (mod 4).       (2)
```

Thus two consecutive transverse rows determine the whole weight.  Let

```text
A_t=sum_(r=0)^2 w[r,t],       S=A_0+A_1.
```

Summing (2) over the lanes shows that `(-1)^t A_t` is an arithmetic progression.
After translating the transverse origin so that `p` is even and `b` is odd,

```text
A_b+A_(b+W)+A_p-A_(p+1)
    =[2(b-p)+W-1]S.                                     (3)
```

The same recurrence, now followed in lane zero for three transverse steps, gives

```text
w[0,h]+w[0,h+3k]=-kS                                   (4)
```

whenever `h` and `k` are odd.  The endpoint charge consists of the two rail sums,
the two extra classes, and the north-heading monodromy `A_p-A_(p+1)`.  Equations
(3)--(4) reduce it to

```text
[2(b-p)+W-1-k]S.                                        (5)
```

The two initial rows in (2) are arbitrary, so `S` can be any residue modulo four.
Since `b-p` is odd, the coefficient in (5) is `W+1-k` modulo four.  Consequently
every drift-periodic zero-four-corner weight obeys its endpoint equation if and
only if (1) holds.  On this forced boundary, there is no second condition hidden
elsewhere in the additive mod-four family.

One convenient generator makes (1) visible without the recurrence calculation:

```text
w(x,y)=(-1)^(x+y)(floor(x/3)+floor(y/3))  (mod 4).
```

It is periodic under `(x,y)->(x+3,y-3)`, has zero four-corner sum, and its
north-heading potential has monodromy one.  Its value on the eight odd classes is

```text
sum_O w = 2-W+k  (mod 4).
```

Here the last display uses the harmless rail normalization `b=1`.  Charge
conservation, `sum_O w+1=0`, is exactly (1), independently of the start level.

## The period class

Choose phase zero to be a vertical arrival and translate its cell to the origin.
The origin is then even in the checkerboard colouring, and a class is even-checker
exactly when its arrival axis is vertical. The two rails supply six horizontal
classes, and the extra class at level `h` is horizontal as well. The class at
level `v` is the only vertical one. Thus the number `A` of even-checker odd
classes is one. The kinematic congruence

```text
N/2+3-3+A = 0  (mod 4)
```

therefore gives `N=6 (mod 8)`. In particular, this orbit cannot occur at period
58 in the full-rail subfamily. This does not remove that period class from
the whole drift orbit by a hand argument.

## Period cost of separating the two extra classes

The transverse line law turns the separation `|v-h|=3|k|` into a period lower
bound. Normalize the rails to levels `1` and `W+1`, and let `f_t` be the number
of upward crossings of the cut between levels `t` and `t+1`. If `G_t` is the
number of odd classes at levels at most `t`, then

```text
f_t = (-1)^(t+1) G_t  (mod 4).                          (7)
```

There are three rail classes below both extra levels, four between them, and five
above them. Hence the `3|k|` cuts between `h` and `v` have `f_t=0 mod 4` and so
`f_t>=4`. On the other `W-3|k|` cuts, the least positive representatives
alternate between one and three. Their combined count is odd, begins and ends
with three, and has sum `2(W-3|k|)+1`. Therefore

```text
sum_(t=1)^W f_t >= 2W+6|k|+1.
```

The transverse walk crosses every cut equally often in both directions, so
`N=2 sum_t f_t`. This proves (6). Equality in this counting bound takes every
cut at its least positive representative; it does not assert that those counts
form a single ant tour.

## Why this does not close the orbit

There are normalized placements satisfying (1) at every even width from six
onward.  When `W=2 mod 4`, take `(h,v)=(5,2)`, so `k=-1`; when `W=0 mod 4`, take
`(h,v)=(3,6)`, so `k=1`.  The first choices occur at widths six and eight.

Since `N=6 (mod 8)`, the number of left turns `(N-8)/2` is odd. The lifted-rank
factorization therefore asks for parity-flow sign zero. The direct audit finds
sign zero on all 185 additive survivors through
width thirty.  That computation is a regression for compatibility, not an
all-width proof.  It shows why the new congruence cannot be presented as a rank
contradiction. The coordinate-residue audit also checks (6) on the same 185
placements. At widths `6,8,10` the least possible periods are respectively
`38,46,54`; at width twelve the least is `62`.

## Audit

```text
python code/python/growth8_m3_boundary_audit.py \
  --output results/growth8_m3_boundary_audit.json
```

The default run tests 370 normalized boundary placements.  It evaluates the six
coordinate generators of the full `4^6` additive family, checks their equivalence
to (1), verifies the explicit weight and its monodromy, and solves the finite
three-lane parity flow for every additive survivor. It also checks that every
normalized boundary has one even-checker odd class and period residue six. Its result is
`all_checks_passed=true`.

All these placements already include all three lanes on both rails. The
audit does not test partial-rail boundaries or establish their impossibility.

```text
growth8_m3_boundary_audit.py
78c8db53226a7c62ae22ea984bcc98c8b034e148e41b9f0e931addd9cccca1ce

test_growth8_m3_boundary_audit.py
414e290d60dd1c31d506fd5e51d0da2f29a5c88ede6e7691644462c293f803a4

growth8_m3_boundary_audit.json
6f0b1bf3767f568e407f59dde64706fc1a7ccdfca0b886b6921e3ca2e95d80f9
```
