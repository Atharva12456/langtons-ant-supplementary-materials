# Further prefix reductions for drift `(1,-3)`

22 September 2026

The stable-word and lifted-time conditions exclude the following branches at every period:

| Cap and initial band | Additional condition | First level with no continuation |
|---|---|---:|
| Lower `(1,2,3)`, `omega_3=0`, `(j,k,l)=(1,0,2)` | Both values of `omega_4`; all later wake choices | 9 |
| Lower `(1,2,3)`, `omega_3=0`, `(j,k,l)=(2,0,1)` | Both values of `omega_4`; all wake choices at levels 5 and 6 | 6 |
| Lower `(1,2,3)`, `omega_3=1`, `(j,k,l)=(2,0,0)` | Both values of `omega_4`; all later wake choices | 6 |
| Lower `(1,2,3)`, `omega_3=1`, `omega_4=0`, `(j,k,l)=(1,0,1)` | P22 forces `omega_5=0`; both values of `omega_6,omega_7` | 7 |
| Lower `(1,2,3)`, `omega_3=1`, `omega_4=0`, `(j,k,l)=(1,1,0)` | P22 forces `omega_5=0` and then `omega_9=0`; all other early wake choices | 10 |
| Lower `(1,2,3)`, `omega_3=1`, `omega_4=1`, `(j,k,l)=(1,0,1)` | P22 forces `omega_5=omega_7=0`, and `omega_9=0` if `omega_6=1`; all other early wake choices | 9 |
| Upper `(1,2,3)`, non-wake offsets 3 and 4, `(j,k,l)=(2,1,0)` | Offset 6 non-wake; offsets 5, 7 and 8 non-wake | 8 |

The first six rows exclude nine of the twelve initial lower `(1,2,3)` bands beyond the remaining lower `(1,2,2)` Family B. The upper result restricts Family B but does not exclude it. None of these results closes the whole `(1,-3)` drift orbit.

## Lower `(1,2,3)` band `(1,0,2)`

Both `omega_4` values now have an empty level-nine frontier after exhaustive count rows, alternating stable words, witnessed finite first returns, and exact integer lifted clocks. No P22 wake pruning, period upper bound, width bound, or row-length bound is imposed. The level-eight survivor counts are 452 and 3,112; at level nine every word satisfying necessary boundary adjacency has a witnessed wrong return, leaving zero. Empty rows are included, so the check also covers widths below nine. The separate audited note `odd_skew_lower_fat123_a0_102_exclusion_2026-09-22.md`, checker `verify_lower_fat123_a0_102_exclusion.py`, and result `lower_fat123_a0_102_checks_2026-09-22.json` give the exact counts and scope.

## Lower `(1,2,3)` band `(2,0,1)`

For `omega_3=0`, both `omega_4` values have a forced six-step contradiction at level six. Eight distinct wake levels require a transverse width at least seven, so this level exists in every full candidate. The raw-word checker `verify_lower_fat123_a0_j2_exclusion.py` explores both wake values at levels five and six. It finds eight physical-return-compatible level-five words for each `omega_4`; their level-six extensions number 49 and 98 after physical returns. In every extension, ordinal matching forces the level and port path

```text
1:NR -> 4:ER -> 3:SL2 -> 6:ER -> 5:SR -> 2:WL -> 1:SL.
```

The precise level-five and level-six event ordinals vary, but every path has directions `E,S,E,S,W,S`, voltage `+1`, and six steps. Thus `tau(1:SL)-tau(1:NR)=6-N<=0` for `N>=6`, contradicting the stable same-cell gap of at least four. No P22 pruning or period cutoff is used. The separate note `odd_skew_lower_fat123_a0_j2_exclusion_2026-09-22.md` gives the raw counts and scope.

## Lower `(1,2,3)` band `(2,0,0)`

The first five rows, in the lower-cap coordinates of `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`, are

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: NR,SL,SR,SL,NR
4: WR,WL,WR,WL,ER,EL,[WR]^omega_4.
```

This is the sole `(j,k,l)=(2,0,0)` band with `omega_3=1`. Both `omega_4` values are checked. The flow equations and alternating right/left order produce 84 level-five words when `omega_4=0`, and 172 when `omega_4=1`, across both possible level-five wake indicators. Exact same-cell first returns reduce these to four and eight words. Lifted clocks leave two and four words, respectively. No period upper bound is imposed.

All retained level-five words have the prefix

```text
NR,SL,SR,SL,NR,SL,SR,NL
or
SR,SL,NR,SL,NR,SL,SR,NL.
```

For `omega_4=1`, each has a final `NR` or `NR,SL` tail. At level six, the return condition leaves ten words for `omega_4=0` and twenty for `omega_4=1`, across both wake choices. Every one contains the same six-step path, with ordinal matching along each edge:

```text
1:NR -> 4:ER -> 3:SL2 -> 6:ER2 -> 5:SR2 -> 2:WL -> 1:SL.
```

Its directions are `E,S,E,S,W,S`, giving displacement `(1,-3)`. In the lower-cap lifted clock, the two row-one visits therefore satisfy

```text
tau(1:SL)-tau(1:NR)=6-N.
```

The left side is at least four because these are successive stable visits to one representative cell. A period has `N>=6`; hence the right side is at most zero. This contradiction disposes of every level-six candidate. `verify_lower_fat123_a1_j2_exclusion.py` enumerates the words, checks each first-return order, asserts the same forced path in all thirty final candidates, and checks the integer clock equations independently.

## Lower `(1,2,3)` band `(1,0,1)` with non-wake level four

Here rows three and four are `SR,SL,NR,SL,NR` and `WR,WL,ER,EL,WR,WL`. The already proved P22 consequence for `omega_3=1` makes every level `5 mod 6` non-wake, so `omega_5=0`. The generic stable-word adjacency enumerator leaves two words on level five. Both wake choices at level six leave six prefixes. At level seven, both wake choices give forty-five count rows, twelve words satisfying the one-excursion adjacency test, and zero words satisfying all physical first-return requirements.

`verify_lower_fat123_a1_b0_101_exclusion.py` reproduces the complete finite prefix calculation. The third step uses no clock infeasibility and no restriction on `omega_6` or `omega_7` beyond their binary wake values. This is a computer-checked local exclusion; a short hand derivation of the twelve rejected level-seven words has not been written.

## Lower `(1,2,3)` band `(1,1,0)` with non-wake level four

Here rows three and four are `SR,SL,NR,SL,NR` and `WR,WL,ER,WL,WR,EL`. P22 forces `omega_5=0`. Exact prefix enumeration leaves four, five, four, fourteen and six states after levels five through nine, then none after level ten. Every level-six survivor has `omega_6=1`. Since wakes `0,3,6` already occupy the four-wake residue-zero fibre with signs `+,-,+`, level nine cannot be wake; otherwise that fibre would have a forbidden `2+2` checker split. The fourth wake in it must occur at an even level at least twelve, so the level-ten row is present in any full candidate.

The standalone checker `verify_lower_fat123_a1_b0_110_exclusion.py` independently implements row count equations, word generation, ordinal matching, physical returns, P22 prefix restrictions and lifted clocks. It checks all 17,680 level-ten alternating words. The separate note `odd_skew_lower_fat123_b0_110_exclusion_2026-09-22.md` and result `lower_fat123_a1_b0_110_checks_2026-09-22.json` give the complete counts and exact scope. This is an all-period computer-checked prefix exclusion, not a hand classification of the deeper orbit.

## Lower `(1,2,3)` band `(1,0,1)` with wake level four

Here rows three and four are `SR,SL,NR,SL,NR` and `WR,WL,ER,EL,WR,WL,WR`. The wakes at levels zero and three occupy opposite checker signs of one residue-three fibre. With only eight total wakes, that fibre must have a `3+1` split and the two other fibres must each have a matching-sign pair. Hence P22 forces `omega_5=omega_7=0`. It also rules out simultaneous wakes at levels six and nine, which would make the residue-zero fibre `2+2`. The fourth wake of the residue-zero fibre cannot occur earlier than level twelve: after wakes zero and three, the earliest same-parity pair is six and twelve, or nine and fifteen. Therefore every full candidate has width at least twelve, so level nine is present.

The standalone `verify_lower_fat123_a1_b1_101_exclusion.py` derives every row count from directional flow, enumerates alternating words subject only to necessary first-return adjacency, then checks explicit physical first returns. It leaves respectively 2, 6, 6 and 88 prefixes after levels five through eight. At level nine, all 88 boundary-adjacent words have a witnessed wrong return: level-seven event zero returns to event three of the same cell, skipping events one and two. No lifted-clock, period, width, or row-length cutoff is used. The detailed counts are in `lower_fat123_a1_b1_101_checks_2026-09-22.json`.

## Remaining lower `(1,2,3)` bands

The three initial bands not excluded here are `(j,k,l)=(1,1,1)` with `omega_3=0` and either `omega_4`, and `(1,1,0)` with `omega_3=omega_4=1`. The last of these has 104 necessary-condition prefixes after an exact level-nine clock check. At level ten, a forced `ER` source/arrival clock equation excludes 4,894 of 6,044 possible pairs, but an explicit prefix still passes full local return and clock tests; see `odd_skew_lower_fat123_a1_b1_110_level10_restriction_2026-09-22.md`. For `(1,1,1)`, the `omega_4=0` branch retains 394 prefixes through level nine; the `omega_4=1` branch retains 675 through level eight without P22 pruning. See `odd_skew_lower_fat123_a0_111_open_prefix_2026-09-22.md`. These prefixes are not periodic ant traces.

## Upper `(1,2,3)` band `(2,1,0)` with non-wake level six

In upper inward coordinates with headings rotated by 180 degrees, the initial rows are

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: NR,SL,SR,SL,NR,SL
4: WR,WL,WR,WL,ER,WL,WR,EL.
```

Assume inward levels five through eight are non-wake. The generic stable-word adjacency enumeration and exact upper-sign lifted clocks leave respectively 9, 36 and 23 prefixes after levels five, six and seven. The 23 level-seven prefixes induce 130 count rows at level eight. None has a stable word satisfying the forced same-cell return adjacency. `verify_upper_fat123_210_w6zero.py` reproduces these counts using the generic enumerator, separately from the earlier fast unary frontier script. It uses `N>=max(6, number of represented events)`, a necessary bound because all represented quotient events occupy distinct phases of the period. No upper bound on `N`, row size, or black lifetime is used.

Family B has width `W=6m+4` and wake set

```text
{0,5,6,8,6p+2,6r+4,W-2,W},
2<=p<r<=m-1,   p+r odd.
```

It has non-wake upper offsets five, seven and eight. Its upper offset six is wake exactly when `r=m-1`. Consequently the surviving `(2,1,0)` initial upper band of Family B requires `r=m-1` and `p+m` even. This leaves the short upper band, the `(1,1,1)` and `(1,2,0)` bands, and the `(2,1,0)` band with a wake at offset six unresolved.

For the wake-six `(2,1,0)` branch, exact integer-clock enumeration leaves 6,574 locally consistent prefixes through inward row ten, all with one of two paired row-five/six words. The other three upper initial bands also have locally consistent prefixes through row eight for both wake-six values. See `upper210_wake6_prefix_restriction_2026-09-22.md`; those survivors do not establish a periodic ant.

Separately, Family B has a unique lower level-nine word `(NR,SL)^4` for either surviving level-eight word. This follows from its non-wake level nine and directional flow; `family_b_level9_necessary_word_2026-09-22.md` records the argument. At non-wake level ten, 32 alternating words are count-compatible in each branch; exact lower lifted clocks leave eight after row-eight word A and seventeen after word B. See `family_b_lower_level10_restriction_2026-09-22.md`. These local survivors do not exclude Family B.

## Verification boundary

These checks enumerate all stable words permitted by the stated local count equations; they do not assume a period upper bound. The adjacency and physical-return filters are necessary conditions from the stable-word framework. The lower `(2,0,1)` and `(2,0,0)` contradictions have explicit drift paths after finite word reduction. The lower `(1,0,2)` check for both wake-four values, the `(1,1,0)` non-wake-four check, and the `(1,0,1)` wake-four check also have standalone enumeration implementations. The exclusions have not been formalized in Lean. An empty prefix proves those stated branches impossible; a surviving prefix in any other branch is not an ant trace.
