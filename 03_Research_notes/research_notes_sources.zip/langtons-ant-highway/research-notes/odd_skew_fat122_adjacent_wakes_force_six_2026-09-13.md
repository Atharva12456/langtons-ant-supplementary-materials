# Wakes at lower levels four and five force a wake at six

For a lower `(1,2,2)` cap with drift `(1,-3)`,

```text
omega_4=omega_5=1  implies  omega_6=1.
```

The proof excludes the four-visit word on level six, independently
of every later wake indicator and of the period. It removes one of
the five bands in `odd_skew_fat122_five_lower_bands_2026-09-13.md`.
The four remaining lower bands do not yet exclude the cap profile
or the drift orbit.

## Suppose level six is non-wake

The lower-band normal form fixes

```text
0: WR
1: NR,SL
2: WR,WL
3: SR,SL,NR,SL
4: WR,WL,ER,WL,WR,EL,WR
5: SR,SL,NR,NL,NR,SL,NR
6: ER,EL,ER,WL.
```

Let `Wi` be the west departures on level seven. They feed the
level-four west arrivals `WR,WL,WL,WR,WR`. There is only one north
arrival on level seven, supplied by `6:EL`. The twelve-step return
from `W2` through the lower cap ends there, forcing the consecutive
pair `W2=SR`, `W3=NL`. Its other west departures are all `SR`.
Thus, for `f=omega_7`,

```text
7: SR,SL,SR,NL,SR,SL,SR,[SL]^(1-f).
```

Number the east arrivals on level eight as `E1,...,E5`. Their
sources on level five are `SL1,NR1,NR2,SL2,NR3`, in that order.
The fixed paths from `W1,W4,W5` end at `E2,E3,E5`:

```text
W1 -> 4:first WR -> 5:first NR -> E2;
W4 -> 4:second WR -> 5:NL -> 2:WL -> 1:SL
   -> 4:EL -> 5:second NR -> E3;
W5 -> 4:last WR -> 5:last NR -> E5.
```

Each endpoint is the physical cell immediately north of its
starting level-seven cell. As in the preceding normal-form proof,
these paths force `E3=ER`: if it were `EL`, its eight-step return
from the south predecessor of `W4` would force `E2=ER`, and the
path from `W1` would close a four-step right-to-right return to
`W4`. Hence `E3=ER` is the fifth south departure on level eight,
feeding the `SL` immediately after `W4`.

Level nine has exactly one west departure, denoted `D`, because
the only west arrival on level six is its final `WL`. We now use
this fact to exclude both turns at `E5`.

## If the last east arrival is `EL`

Suppose `E5=EL`. The south predecessor of `W5=SR` has a four-step
first same-cell return to `E5`. Its source must be `E4=ER`, and
`E4,E5` are consecutive stable events on level eight.

The sole west departure `D` has the eight-step first return

```text
D -> 6:WL -> 5:SL2 -> E4=ER -> 7:W5=SR
  -> 4:last WR -> 5:last NR -> E5=EL -> north arrival on 9.
```

If `D=SR`, its consecutive target would be `NL`, producing a
second west departure on level nine. Thus `D=NL`, with consecutive
target `NR`. Let `X` be its incoming predecessor on level eight.
It is the north departure immediately preceding `E5=EL` in north
departure order. Since `E4=ER,E5=EL` are consecutive stable events,
`X` lies before `E4`.

But the shorter path

```text
8:X -> 9:D=NL -> 6:WL -> 5:SL2 -> 8:E4=ER
```

is a four-step first same-cell return. Its source must be `EL`,
immediately preceding `E4` in stable order. It would therefore be
the third east arrival `E3=EL`, contrary to `E3=ER`.

The argument uses the first return to `E4`, not the longer path
through `E5`: the latter also visits the same level-eight cell at
`E4` and is not a first return.

## If the last east arrival is `ER`

Suppose instead `E5=ER`. Its south step completes a four-step
return from `W5=SR`, forcing a following `SL`. Thus `f=0`, and
the south arrivals on level seven are exactly

```text
SR,SL,SR,SR,SL,SR,SL.
```

Consequently `E3=ER` is the fifth south departure on level eight,
and `E5=ER` is the seventh. The sixth south departure, denoted `J`,
feeds `W5=SR`. Its four-step first return to `E5=ER` makes
`J=WL`, immediately followed by `E5` in stable order.

The intervening east arrival `E4` cannot be `ER`. A left turn
between the consecutive east arrivals `E3=ER` and `E4=ER` would
have to be `WL`, contributing an additional south departure before
`E4`. There would then be no room for `E4` and the later `E5` in
the remaining south-departure positions six and seven. Therefore
`E4=EL`.

In fact `E3=ER,E4=EL` are consecutive stable events. A `WL` between
them would be the only remaining south departure `J`, whose next
stable event is already `E5`, not `E4`. An intervening `WR` would
itself require such a left turn. No other east arrival is available
between `E3` and `E4`.

Now `D` has the four-step first return

```text
D -> 6:WL -> 5:SL2 -> E4=EL -> north arrival on 9.
```

Again `D=SR` would create a second west departure at its `NL`
target. Hence `D=NL`, with target `NR`. Its incoming predecessor
`X` on level eight is the north departure immediately preceding
`E4`. The path

```text
8:X -> 9:D=NL -> 6:WL -> 5:SL2 -> 8:E4=EL
```

is a four-step first same-cell return. It requires `X=WR` to be
the immediately preceding stable event. That event is instead
`E3=ER`, a south departure. This is the final contradiction.

Both turns at `E5` are impossible. The assumption `omega_6=0`
is therefore false. The return contradictions after the initial
band use only zero displacement; the lower-cap restriction enters
through the five-band normal form.
