# Excluding the single-ER upper cap in family A

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Family A cannot have exactly one `ER` port at upper
offset six. The reductions through U and B0 leave three
possible initial words on offset ten. Two give skipped
returns; the third contradicts the upper lifted-time order.

Consequently the upper `(1,2,2)` cap in family A must
have exactly two `ER` ports at offset six. Those branches,
family B, and the other cap profiles in the `(1,-3)` orbit
remain open.

The argument uses the established non-wake conditions at
upper offsets seven through eleven. Although it follows
paths to twelve, it does not need twelve to be non-wake.

## Fixed notation and the first north arrival on nine

Use inward offsets and rotated headings. The previous
reductions leave

```text
5: NR1,SL1,SR,NL,NR2,SL2,NR3,SL3
6: WR1,WL1,WR2,EL1,WR3,WL2,ER,WL3,WR4,EL2,WR5
7: SR,SL,NR,NL,NR,SL,NR,NL,NR,NL,SR,SL
8: a=WR,C=WL,E1=ER,I=WL,b=WR,E2=EL,c=WR,E3=EL,
   d=WR,E4=EL,e=WR,J=WL,E5=ER,E6=EL.
```

The west departures `Di` on nine feed, in order,

```text
6:WR1,WL1,WR2,WR3,WL2,WL3,WR4,WR5.
```

The preceding note
`odd_skew_upper_a_u_unique_eighth_word_2026-09-14.md`
forces `D1=SR,D2=NL`. The latter is supplied by `8:b`,
the second north departure on eight. Its square through
`6:WL1,5:SL1,E2=EL` returns to the following `NR` on
nine. Write `M1=NR` for the first north arrival on nine,
supplied by `8:a`.

There are exactly two possible initial orders on nine:

```text
A: D1=SR,SL,M1=NR,D2=NL,NR,...;
B: M1=NR,SL,D1=SR,D2=NL,NR,... .                     (1)
```

Before `D2`, the only right turns available are `D1`
and `M1`. Alternation forces the single intervening `SL`
and excludes any additional events in these prefixes.

Let `Fi` be the east arrivals on ten. The first is supplied
by the first `SL` on seven, from `8:E1`; the second by
the first `NR` on seven, from `6:WR1`; and `F4` by the
second `SL` on seven, from `8:I`.

## Three initial words on ten

The three-step path from `D1` through `6:WR1,7:first NR`
ends at `F2`. If `F2=EL`, the south predecessor of
`D1` on ten has a square return to it, forcing the
consecutive pair `F1=ER,F2=EL`.

In prefix A of (1), `D1` is the first south arrival,
so this pair starts the word on ten. In prefix B, it
is the second south arrival, forcing the prefix
`WR,WL,F1=ER,F2=EL`.

If `F2=ER`, its south step completes a square from
`D1=SR` to the following `SL`. This excludes prefix B,
where the immediate successor of `D1` is `D2=NL`.
In prefix A, `F2` is the second south departure on ten.
The first east arrival must be `F1=EL`: taking it to
be `ER` would require a `WL` between the first two
south departures. The south predecessor of `D1` is
then `WL`, immediately before `F2=ER` by its square
return. This fixes the third prefix below:

```text
I:   F1=ER,F2=EL,...;
II:  WR,WL,F1=ER,F2=EL,...;
III: WR,F1=EL,WR,WL,F2=ER,... .                      (2)
```

Cases I and III have prefix A on nine; case II has
prefix B.

## The first three west departures on eleven

Let `P1,P2,P3` be the west departures on eleven feeding
`8:a=WR,C=WL,I=WL`. In cases I and II, `P2` has the
twelve-step first return

```text
P2 -> 8:C=WL -> 7:W1=SR -> 4:first WR -> 5:NR1
   -> 8:E1=ER -> 7:first SL -> 10:F1=ER -> 9:D1=SR
   -> 6:WR1 -> 7:first NR -> 10:F2=EL
   -> north arrival on 11.
```

In case III it instead has the eight-step first return
ending at the north arrival supplied by `F1=EL`:

```text
P2 -> 8:C=WL -> 7:W1=SR -> 4:first WR -> 5:NR1
   -> 8:E1=ER -> 7:first SL -> 10:F1=EL
   -> north arrival on 11.
```

These paths have no earlier visit to their starting cell.

## Case I is impossible

In case I the target of the twelve-step return is the
first north arrival on eleven. Its source cannot be
`NL`, since there is no preceding north arrival to
supply it. Thus `P2=SR`, and its consecutive target
is the next west departure `P3=NL`.

It follows that

```text
10:F2=EL -> 11:P3=NL -> 8:I=WL -> 7:second SL -> 10:F4
```

is a square return. It skips `F3` in east-arrival order,
excluding case I.

## Case II is impossible

Here the same target is the second north arrival on eleven.
If `P2=NL`, it must be the first north arrival. The earlier
west departure is consequently `P1=SR`, immediately
followed by `P2=NL`; no other north arrival or west
departure is available between them.

The path `P1 -> 8:a=WR -> 9:M1=NR` then reaches the
first east arrival `G1` on twelve, because case II has
prefix B on nine. If `G1=ER`, its south step would
return from `P1=SR` to `SL`, contrary to its immediate
successor `P2=NL`. Hence `G1=EL`. But the south
predecessor of `P1` on twelve would then have a square
return to this first east arrival, requiring an earlier
east arrival `ER`. This is impossible.

Thus `P2=SR`, with consecutive target `P3=NL` supplied
by `F2=EL`. The same square from `F2` to `F4` that
excluded case I excludes case II.

## Case III forces one more square

In case III the eight-step return from `P2` ends at
the second north arrival on eleven, supplied by `F1=EL`.
Taking `P2=SR` would make its consecutive target
`P3=NL`, and the square from `F1` through `P3,I` and
the second `SL` on seven would end at `F4`, skipping
`F2,F3`. Therefore `P2=NL`, the first north arrival on
eleven. Again `P1=SR` immediately precedes it.

Prefix A on nine begins `D1=SR,SL,M1=NR`. Thus the
three-step path from `P1` through `8:a,9:M1` ends
at the second east arrival `G2` on twelve. It cannot
turn right: that would return from `P1=SR` to `SL`
instead of its immediate successor `P2=NL`. Hence
`G2=EL`.

The south predecessor of `P1` on twelve now has a square
return to `G2`. It must be the immediately preceding
east arrival `G1=ER`. In particular,

```text
12:G1=ER -> 11:P1=SR -> 8:a=WR -> 9:M1=NR -> 12:G2=EL,
tau(G2)=tau(G1)+4.                                  (3)
```

The first east arrival `G1` is supplied by the `SL`
after `D1` on nine. Its incoming predecessor is `F2=ER`.

## The upper clock contradiction

Use upper inward lifted times. A vertical step followed
by an east step has voltage minus one and time increment
`2+N`. Therefore

```text
tau(G1)=tau(F2)+2+N,
tau(G2)=tau(a)+2+N.
```

Equation (3) gives `tau(a)=tau(F2)+4`. Since `F2` is
supplied by `6:WR1` through the first `NR` on seven,

```text
tau(a)=tau(6:WR1)+N+6.                              (4)
```

But the first `SL` on seven precedes its first `NR`.
They are supplied by `8:E1` and `6:WR1` respectively,
by vertical steps with zero voltage. Hence

```text
tau(E1)<tau(6:WR1).
```

The initial event `a` on eight also precedes `E1` there.
Consequently

```text
tau(a)<tau(E1)<tau(6:WR1),
```

contradicting (4) for every positive period. This excludes
case III and finishes the exclusion of U.

Words T and V and the other U orders were excluded in
the preceding notes. Thus there is no single-`ER` upper
cap in family A. The final comparison uses the upper
voltage sign; it is not an orientation-free contradiction.
