# Two higher-row endings for Q, M_L0

Later result (21 September 2026): [the upper fat-cap exclusion](odd_skew_upper_fat122_exclusion_2026-09-21.md) closes family A, including the upper-cap branch studied here. The derivation and intermediate status below record the earlier reduction.

Subsequent status: both endings are excluded by the
common square obstruction in
`odd_skew_upper_a_q_ml0_exclusion_2026-09-15.md`.
The entire `M_L0` suffix is closed.

The suffix `M_L0` has only two possible endings on
eleven, according to the turn at its last west departure.
Each forces an explicit ending on twelve. The turn at
`F4` on ten remains open; this note does not exclude
either entire ending or the suffix itself.

## Notation and the fixed endings below

Use
`odd_skew_upper_a_q_middle_third_west_2026-09-15.md`.
The relevant suffix on eight is

```text
E3=ER,L7=WL,E4=ER,E5=EL,b=WR,L9=WL,c=WR,E6=EL.
```

On nine, `D3=NL` is supplied by `c`, and `D4=SR`.
The final portion, starting at the north arrival from
`E5`, is

```text
NR from E5,SL,NR from b,D3=NL,NR from E6,SL,D4=SR,SL.
```

Let the corresponding six east arrivals on twelve be
`A,B,C,D,E,F`, in that order. Thus `C` is supplied
by the north arrival from `b`, `D` by the north
arrival from `E6`, and `F` is the last east arrival
on twelve. These labels refer only to this local ending.

The word on ten ends

```text
...,U=WL,F5=ER,F6=EL,X=WR,F7=EL.                    (1)
```

Write `Pb,PL,Pc` for the west departures on eleven
feeding `b,L9,c` on eight, respectively. They are
the last three west departures, with `Pc` the last.

## All three occur after the north arrival from F6

The port `F6` is supplied by `L7` through the `SL`
after the middle north arrival on seven. Hence

```text
tau(F6) = tau(L7) + N + 2.
```

For each of the three west departures,

```text
tau(Pb) = tau(b)  + N - 1;
tau(PL) = tau(L9) + N - 1;
tau(Pc) = tau(c)  + N - 1.
```

There are at least three stable gaps between `L7`
and `b`, giving `tau(b)-tau(L7)>=12`; the other
two west targets occur still later. Therefore all
three departures occur strictly after `tau(F6)+1`,
the north arrival on eleven supplied by `F6`.

By (1), only two north arrivals remain available:
those supplied by `X` and `F7`.

The square

```text
PL -> 8:L9=WL -> 7:final SL -> 10:F7=EL -> north arrival on eleven
```

gives two possibilities. If `PL=SR`, its consecutive
target is `Pc=NL`, supplied by `F7`. If `PL=NL`,
its incoming predecessor on ten must be `X=WR`,
and the target is the final `NR`, supplied by `F7`.
In the latter case neither `Pb` nor `Pc` has an
available north predecessor, so both are `SR`.

## Case I: Pc=NL

Here `PL=SR` and `Pc=NL` is supplied by `F7`.
The seven-step path

```text
Pc -> 8:c=WR -> 9:D3=NL -> 6:WL2 -> 5:SL3 -> 8:E6=EL
   -> 9:north arrival from E6 -> 12:D
```

rules out `D=ER`: its south step would give another
west departure after the last one. Thus `D=EL`.

Starting at the south predecessor of `PL` on twelve,
follow its square to `Pc` and then this seven-step
path. The twelve-step first return to `D=EL` forces
that predecessor to be the immediately preceding east
arrival `C=ER`, supplying `PL`.

The square through `Pb,b`, the north arrival from
`b`, and `C=ER` then forces `Pb=NL`, immediately
before `PL=SR`. Its only available north predecessor
is `X`. Since `Pc` is also the last north arrival
on eleven, the ending is

```text
11: ...,Pb=NL,PL=SR,Pc=NL.
```

The last south arrival on eleven is `PL`, supplied
by `C=ER`. There is no south departure on twelve
after `C`. The remaining three east arrivals therefore
turn left, giving the full ending

```text
12: ...,C=ER,D=EL,WR,E=EL,WR,F=EL.
```

The three consecutive gaps `b -> L9 -> c -> E6`
on eight are all four, by the squares through
`C,PL`, through `F7,Pc`, and through `D3,6:WL2,5:SL3`.
The twelve-step return above also gives
`tau(D)-tau(C)=12`.

## Case II: Pc=SR

Here `PL=NL` is supplied by `X`; the north arrival
from `F7` is `NR`, and `Pb=SR`. There is no north
arrival between `Pb` and `PL`, so they are consecutive.
After `PL`, alternation gives

```text
11: ...,Pb=SR,PL=NL,NR,SL,Pc=SR,SL.
```

The three-step path from `Pb` through `b` and its
north arrival on nine ends at `C` on twelve. A right
turn there would return from `Pb=SR` to `SL`, rather
than its immediate successor `PL=NL`. Hence `C=EL`.
The south predecessor of `Pb` must consequently be
the immediately preceding east arrival `B=ER`.

If `D=EL`, the south predecessor of `Pc` would have
an eight-step first return to `D`, forcing `C=ER`
immediately before it. This contradicts `C=EL`.
Thus `D=ER`; its south step returns from `Pc=SR`
to the final `SL` on eleven. It is the last south
departure on twelve.

Between `B` and `D`, there are exactly two further
south departures, supplying the `SL` before `Pc`
and `Pc` itself. Both are `WL`, since `C=EL` is
the only intervening east arrival. Alternation fixes
the complete ending

```text
12: ...,B=ER,C=EL,WR,WL,WR,WL,D=ER,E=EL,WR,F=EL.
```

The `WL` immediately before `D` supplies `Pc` and
has an eight-step first return to `D`. Also, if `S`
is the south predecessor on ten of the `SL` supplying
`B`, the square through `B,Pb,b` gives
`tau(b)=tau(S)+4`.

## The unresolved turn at F4

Let `P5` denote the west departure on eleven feeding
the fifth south departure `L5=WL` on eight. If
`F4=ER`, the skipped-`E2` argument in the preceding
notes forces `P5=SR`.

If `F4=EL`, an `SR` source at `P5` would have a
twelve-step first return to the north arrival from
`F4`, forcing the next west departure, feeding `L7`,
to be `NL`. The resulting square from `F4` through
`L7` and the `SL` after the middle north arrival
would end at `F6=EL`, skipping `F5`. Hence `P5=NL`
in this case, with a `WR` immediately before `F4`
on ten.

Thus the remaining split at `F4` is equivalent to
the turn at this earlier west departure. Neither turn
has been excluded here. The two endings above and
the rest of Q remain open.
