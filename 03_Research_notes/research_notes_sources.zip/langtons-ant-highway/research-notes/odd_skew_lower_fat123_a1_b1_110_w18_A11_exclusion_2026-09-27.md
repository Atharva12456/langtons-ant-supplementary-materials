# One width-eighteen placement is impossible for the last lower fat band

27 September 2026. Work at growth eight and drift `(1,-3)`. The lower
fat `(1,2,3)` cap has `(omega_3,omega_4,j,k,l)=(1,1,1,1,0)`; its upper
cap must be fat `(1,2,3)` by the existing cap exclusions. The P22, rank,
and moment wake-family classification leaves exactly two width-eighteen
placements:

```text
A(1,1): O={0,2,3,4,6,8,16,18}
A(2,2): O={0,2,3,4,12,14,16,18}.
```

This note excludes **A(1,1)** at every period. The [separate A(2,2)
certificate](https://drive.google.com/file/d/1PA-n9i3XGMTFSzXAatJLko9vWX25WRcu/view?usp=drivesdk)
excludes the other placement; together they rule out width eighteen.

Start the lower cap with its fixed rows zero through four and extend
through physical center row nine. Start the upper fat cap in
half-turned inward coordinates with rows `0:WR`, `1:NR SL`, and
`2:WR WL WR`, then extend through inward row seven. Every generated row
obeys the directional flow and wake equations and alternates right and
left turns. A row is removed only for an explicitly witnessed finite
wrong same-cell first return or infeasibility of an unbounded integer
lifted-clock relaxation. The period variable satisfies
`N>=max(6, represented event count)` with no upper bound; consecutive
represented visits to one stable cell are at least four steps apart. The
period congruence is omitted, enlarging the surviving frontier and making
every clock rejection safe. Upper lifted voltage has the opposite sign
after the half-turn.

The lower survivor counts on rows five through nine are
`8,15,17,51,48`. The upper counts on inward rows three through seven
are `4,7,41,130,191`. The 48 lower center rows have the following port
count signatures, in the order `(NR,NL,SR,SL)`:

| Signature | Lower states |
|---|---:|
| `(9,3,2,8)` | 16 |
| `(6,2,3,7)` | 18 |
| `(8,0,1,9)` | 8 |
| `(7,1,0,6)` | 6 |

For each of the 191 upper prefixes, enumerate **all** wake-zero
directional count options for inward row eight. There are 965 such
options before constructing any row-eight word. Each option fixes the
outgoing direction counts on that row, so an arbitrary placeholder word
with those counts suffices to enumerate every directional count option
for inward row nine; this produces 6,296 count options. No alternation,
finite-return, or clock condition is imposed on these last two upper
rows. This is therefore a superset of all actual upper center words.

The half-turn exchanges `N` with `S` and keeps turn handedness. None of
the 6,296 upper row-nine count options, after this rotation, has one of
the four lower center signatures. The two caps cannot describe the
same physical center row. The count obstruction needs no center-word
ordering or cross-cut return check.

`code/python/verify_lower_fat123_a1_b1_110_w18_A11.py` regenerates
both frontiers from the fixed cap words, independently rechecks the two
width-eighteen static wake placements, enumerates the upper count
superset, and asserts that its center signature set is disjoint from
the lower set. Its output is
`results/lower_fat123_a1_b1_110_w18_A11_checks_2026-09-27.json`.
It uses no period or row-length cutoff and never treats a quotient
cycle as a physical return. This computation certifies the A(1,1)
placement; the A(2,2) exclusion completes the width-eighteen case.
