# Growth eight does not occur at period 52

The fixed-growth search used at period 50 has now been run at period 52.  This
note records the completed run and its audit.  It is a finite exclusion of one
period, not an argument about every period in any drift family.

## Result

There is no finite-support periodic highway with ant period `N=52` and growth
`g=8`.

The command-line settings were

```text
--period 52 --target-growth 8 --prefix-length 12 --deficit-depths 0
```

The first turn of a normalized positive-growth word is fixed, leaving 2,048
length-12 prefix ranks.  Eight half-open rank intervals of length 256 cover that
set exactly once.  No node cap was imposed, and the optional deficit rule was
disabled.  The combined counts are

```text
prefix ranks                  2,048
search nodes         38,465,607,042
endpoint prunes       6,051,510,823
growth prunes         7,227,635,776
residue checks        1,441,579,326
residue prunes        1,346,376,021
P3 checks                95,203,305
accepted words                    0
```

The residue test is used only as a proved pruning lemma.  Every leaf that passes
it is sent to the exact periodic-realisability test.

## Audit trail

The raw records are in `records/g8_p52_shards`.  The aggregate checker rebuilds
each prefix from its rank, checks the normalization directly, verifies exact rank
coverage and every per-rank counter sum, rejects capped or deficit-pruned runs,
compares both copies of the hit lists, and records a SHA-256 digest for every
shard.  Its output is

```text
results/growth8_period52_exclusion.json
bb8948dec0448e583d80785a800504747316ec1a65feb46c9696d7728888f54e
```

The relevant source digests are

```text
code/java/PositiveGrowthResidueSearch.java
315c18bd3f7749750fc8c618d5b3f464756d2ddd64bda5dd9be4cbb1f33e9c23

code/python/aggregate_target_growth_shards.py
c4db9da60a9b19e634a51d552420528e1cf43868d4754bf3d633cf951f920925
```

The aggregate can be rebuilt with

```text
python code/python/aggregate_target_growth_shards.py records/g8_p52_shards \
  --output results/growth8_period52_exclusion.json
```

The separate mode audit through period 18 remains the regression check for the
fixed-growth branch; it confirms that the target-growth runs partition the
original all-growth leaf, residue, P3, and hit records exactly.

Together with the general exclusion through period 48 and the targeted period-50
run, this made period 54 the first possibility left by those computations. Later
runs extend the exclusion through period 60; see
[growth8_period60_exclusion_2026-08-25.md](growth8_period60_exclusion_2026-08-25.md).
