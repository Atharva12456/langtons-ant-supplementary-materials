# The primitive-diagonal growth-eight boundary

## Statement

Normalize the drift to `d=(1,-1)`, put `t=x+y`, and take the two guard rails to
have levels `1` and `W+1`. Let `O` be the set of the eight excess-one translation
classes, identified with their transverse levels. Every finite-support
growth-eight highway in this orbit satisfies

```text
sum_(t in O) (-1)^t t = 3  (mod 4).                    (1)
```

Together with the signed count from P22, this exhausts the drift-periodic
mod-four additive weights with zero four-corner sum. The quotient parity flow has
the closed rank sign

```text
E+L=|O|/2  (mod 2).                                    (2)
```

At growth eight the right side of (2) is zero, exactly as P3 requires. Thus (1)
is a new all-period restriction, but neither (1) nor (2) excludes the orbit.

## The additive family

Write an arbitrary weight as

```text
w(x,y)=(-1)^(x+y) f(x,y).
```

The zero four-corner equation says that the mixed difference of `f` vanishes, so
`f=A(x)+B(y)`. Periodicity under `(x,y)->(x+1,y-1)` then gives a constant `c`
such that

```text
A(x+1)-A(x)=c,       B(y)-B(y-1)=c.
```

After moving a constant between `A` and `B`, every solution is

```text
f(x,y)=c(x+y)+beta.                                    (3)
```

The constant generator is the single P22 residue weight. Its north-heading
potential has monodromy `2 beta`. The remaining generator is

```text
w_1(x,y)=(-1)^(x+y)(x+y).
```

The start level is even after the rail normalization. Integrating the potential
along one southeast step gives monodromy one. Charge conservation is therefore

```text
sum_(t in O) (-1)^t t + 1 = 0  (mod 4),
```

which is (1). Equation (3) proves that there is no further condition in this
additive family.

## The one-lane rank sign

The quotient has one vertex at every transverse level. At even levels the
outgoing blocks are `W,E`, and at odd levels they are `S,N`; in either case their
targets are the adjacent levels. Modulo two, both the incoming and outgoing sums
at a vertex equal its odd-class indicator.

The finite flow is unique. A nonzero zero-boundary flow with a least source has a
block pointing below that source, and its target then requires a block from a
still lower source. Pair the boundary levels consecutively. The flow is the
symmetric difference of the finite segments between the four endpoint pairs.
A direct comparison of source and target port orders gives self-sign one for
each segment and cross-sign zero for every pair of segments. Hence

```text
E+L=number of segments=|O|/2  (mod 2),
```

proving (2). The checker count is odd, so the period congruence makes
`#L=(N-8)/2` odd. Exact alternation gives `K=#L=1`, while the one-tour
factorization gives `K=1+E+L`. Both sides therefore ask for `E+L=0`; the rank
sign is compatible rather than contradictory.

## Compatibility and audit

The horizontal/vertical wake split is one of `3+5`, `5+3`, or `7+1`, with the
two rail levels included among the horizontal classes. In the normalized window
between the rails, the audit enumerates every such placement at each even width
from ten through twenty. It finds 23,492 P22 placements and 11,746 satisfying
(1), exactly half at every width. All survivors have rank sign zero.

```text
python code/python/growth8_primitive_diagonal_boundary_audit.py \
  --output results/growth8_primitive_diagonal_boundary_audit.json
```

The program checks all sixteen weights in (3) over a representative lattice
window, including their potential monodromies. It also solves 238 bounded parity
systems directly, checks that each is unique, and compares every solution with
the segment construction and sign formula. These finite checks are regressions
for the displayed algebra; the all-period result is the classification and
finite-support segment proof above.

```text
growth8_primitive_diagonal_boundary_audit.py
302e1272de5cf556bab5738086e655171a1cdbaa5d84f80239da63d6453e5158

growth8_primitive_diagonal_boundary_audit.json
72c656636d0d6200a55613c5ffb84a6f8481c08ae0a9708def6675dcf8ffaf3a
```
