# A small upper-guard obstruction for literal positive skew

Date: 2026-10-01. Whole-orbit status: **OPEN**.

## Scope

The drift in the original physical coordinates is exactly `(1,3)`. The
clockwise Langton rule and a finite-support periodic highway premise give
R-first alternating stable words. There is no reflection or interchange of
R and L.

The local statement below excludes two upper-guard wake patterns:

1. offset three wakes, while offsets four, five and six are quiet;
2. offset five wakes, while offsets three, four and six are quiet.

Offset seven may be either wake or quiet. No later wake, width, lifetime or
upper bound on the period is assumed. The proof uses stable ordinal edge
matching, physical first returns, and once the correct upper clock sign.

Under the complete growth-eight arithmetic schedules supplied in
`work_positive_skew_global_20260930/upper_guard_wake_schedules_depth9.json`,
these two local statements imply quiet upper offsets three and five for the
**lower thin `(1,2,2)` / upper guard** cap pair. This arithmetic input has that
specific lower-cap scope. The conclusion is not asserted here for lower
fat bands A or B, nor does it exclude upper guard altogether.

## Conventions and two rules

Apply the orientation-preserving half-turn to the upper cap so that inward
offsets use the lower-looking ports. In these coordinates the drift is
`(-1,-3)`, the level coordinate is `s=3x-y`, and the representatives are
`(0,-s)`. A displayed event at copy k has position `(k,-s+3k)`. The original
positive period N remains positive, and the exact upper clock is

```
tau(target) = tau(source) + 1 + N*dx,
```

where dx is the horizontal step, `+1` for E and `-1` for W. This is the
**+N** sign. Vertical steps have dx zero. All rows have strictly increasing
integer lifted times; N is any integer at least one.

A fixed directed edge sends the first departure to the first arrival,
the second to the second, and so on. If a forced path returns to its
starting physical cell without an intermediate visit there, its endpoint
is the immediately next stable event. In particular its turn is opposite.
All first-return paths used below have zero displacement.

Write `N_i`, `S_i`, `E_i` for incoming-heading ordinals on a row; write
`D_i` for west-departure ordinals. Indices in the optional checker are
zero-based event indices instead.

Put `a=omega_3`, `b=omega_4`. The upper guard normal form already proved by
the zero-voltage cap square is

```
0: NR; 1: WR; 2: NR;
3: WR,WL,ER,[WL]^(1-a);
4: SR,SL,(NR,SL)^(1-a),[NR]^b.
```

Both cases below have b=0. Exact flow and alternation provide finite count
domains with no visit bound: on an odd new row, with A east departures
three rows earlier and D north arrivals one row earlier,

```
ER=A-e, EL=e, WR=D-e, WL=A+D-3e-omega;
```

on an even new row, with B south departures one row earlier and C west
arrivals three rows earlier,

```
SR=q, SL=B-q, NL=C-q, NR=omega+B+C-3q.
```

All counts must be nonnegative. These are consequences of flow and of the
R-minus-L count; they are not imposed cutoffs.

## Case I: wake three, quiet four through six

Here `a=1`, and the fixed rows are

```
3: WR,WL,ER; 4: SR,SL; 5: ER,WL.
```

On six the count equations give either `SR=0` or `SR=1`. Let D1 be the
first west departure on six. The forced physical return is

```
D1 -> 3:WR -> 2:NR -> 5:ER -> 6:S1,
       W       N       E       S.
```

Since 5:ER is the first south departure, the endpoint is the first south
arrival on six. D1 cannot be SR: it would itself be an earlier south
arrival. Therefore D1 is NL, and its immediate next event is SR. Before
D1 there can be neither a west departure nor a south arrival; only NR
is available. Alternation leaves exactly one preceding NR. The counts
therefore force

```
6: NR,NL,SR,SL.
```

Let U be the second north departure on seven. It feeds `6:N2=NL`. Its
forced successors are

```
U -> 6:NL -> 3:WR -> 2:NR -> 5:ER -> 6:SR
  -> 3:WL -> 4:SR -> 1:WR -> 0:NR -> 3:ER
  -> 4:SL -> 7:E1.
```

The direction word is `NWNESWSWNESE`. Its displacement is zero and all
intermediate levels are below seven. U and E1 must be consecutive. U
cannot be EL, because E1 is the first east arrival. Thus U is WR and E1
is EL. E1 is then the third north departure on seven. But six has only
two north arrivals, so seven has only two north departures. Contradiction.

## Case II: wake five, quiet three, four and six

Here `a=0`, and

```
3: WR,WL,ER,WL; 4: SR,SL,NR,SL;
5: ER,WL,WR  or  WR,WL,ER.
```

The count equations on six give either `(SR,NR,NL,SL)=(0,5,3,2)` or
`(1,2,2,1)`. The four-step D1 return through `3:WR,2:NR,5:ER` rules out
SR=0: D1 would be NL, requiring an immediately following SR. Hence six
has exactly one SR, two NR, two NL and one SL.

If five is `ER,WL,WR`, 5:ER is its first south departure. The same return
makes D1=NL followed immediately by the first south arrival SR. Before
D1 only NR is available, so six starts `NR,NL,SR`. There are only two
possible completions:

```
P: 6: NR,NL,SR,SL,NR,NL;
X: 6: NR,NL,SR,NL,NR,SL.
```

Form X violates the correct upper clock. Its directed equalities and
strict row orders give the closed chain

```
5:WL < 5:WR -> 4:NR < second 4:SL
       <- second 3:WL <- second 6:NL < 6:NR < 6:SL <- 5:WL.
```

Use a lower bound of one on each strict order step. Reading the arrows
forward or backward contributes respectively `+1+N*dx` or `-1-N*dx`.
The complete cycle has constant term 2 and N coefficient +1. Summing its
eight inequalities would give `tau(5:WL) >= tau(5:WL)+2+N`, impossible
for every N>=1. In particular this step uses the upper +N clock, not the
lower guard's chronology.

If five is `WR,WL,ER`, 5:ER is its second south departure. The D1 return
therefore ends at the second south arrival on six. If D1=NL, its next
event is SR, and the earlier south arrival must be SL. Alternation and
the absence of an earlier west departure force form Q. If D1=SR, it
is the first south arrival, its next event is SL, and it must start the
row; the remainder is forced form R. Thus only three forms survive:

```
P: 5: ER,WL,WR; 6: NR,NL,SR,SL,NR,NL;
Q: 5: WR,WL,ER; 6: NR,SL,NR,NL,SR,NL;
R: 5: WR,WL,ER; 6: SR,SL,NR,NL,NR,NL.
```

All have four north arrivals on six and three east departures on four.
Consequently seven has exactly four north departures and three east
arrivals E1,E2,E3, in that order.

For P, let U be the second north departure on seven. The twelve-step
return from Case I still applies, so U=WR and E1=EL. E1 is the third
north departure and therefore feeds `6:N3=NR`, the fifth event. But
the eight-step path

```
6:SR -> 3:first WL -> 4:SR -> 1:WR -> 0:NR
     -> 3:ER -> first 4:SL -> 7:E1=EL -> 6:N3=NR
```

has word `WSWNESEN` and first returns to six. The immediate next event
after 6:SR is SL, whereas its endpoint is the later NR. Contradiction.

For Q, take U to be the third north departure on seven. It feeds the
first NL on six, and the same twelve-step path returns to E1. Thus
E1=EL is the fourth north departure. It feeds the last event on six,
which is its second NL and third west departure. The four-step path

```
7:E1=EL -> 6:last NL -> second 3:WL -> second 4:SL -> 7:E3
            N             W               S             E
```

is a physical first return. It makes E1 and E3 consecutive, while
ordinal matching places E2 strictly between them. Contradiction.

For R, let U be the second north departure on seven. It feeds the first
NL on six, now the second west departure. The forced return is

```
U -> 6:first NL -> first 3:WL -> 4:SR -> 1:WR -> 0:NR
  -> 3:ER -> first 4:SL -> 7:E1,
```

with word `NWSWNESE`. Hence U=WR and E1=EL, the third north departure.
Let V be the fourth and last north departure on seven. It feeds the
last NL on six. The word `NWSE` returns V immediately to E3.

If V=WR, E3 must be EL and would be a fifth north departure. Therefore
V=EL. It cannot itself be E3, so V=E2 and E3=ER. But E1 and E2 are
both L events and require an R event between them. Such an R event
would be either ER, giving an east arrival strictly between the first
and second east arrivals, or WR, giving a fourth north departure before
V. Both are impossible. This excludes R and completes Case II.

## Arithmetic consequence and independent reproduction

The complete supplied upper-G arithmetic schedules through nine, beyond
mandatory offsets 0,1,2, are

```
{}, {3}, {3,7}, {4}, {4,6}, {4,8}, {5}, {5,7},
{6}, {6,7}, {6,7,9}, {7}, {7,8}, {8}, {9}.
```

The two schedules containing three satisfy Case I. The two containing
five satisfy Case II. Thus the lower-thin / upper-G pair necessarily has
quiet upper offsets three and five. Both exclusions finish at seven;
no depth-nine turn-word search is required.

`verify_upper_guard_small.py` imports no exploratory implementation and
requires only Python's standard library. It derives headings and target
levels geometrically; enumerates every raw R-first alternating word of
each exact count vector; rejects only replayed finite physical returns
or the explicitly verified `2+N` clock cycle; and checks both choices at
offset seven. It examines only 574 raw candidate extensions, retaining
every rejection certificate. A finite trace cutoff can only retain an
extra candidate, never reject one. Both domains close before any cutoff
could support an exclusion.

Run from the repository root:

```
python work_positive_skew_upperguard_20261001/verify_upper_guard_small.py
```

The result and compact certificates are saved beside the checker. The
arithmetic schedule file is read only to verify the stated implication;
the local proofs and their independent raw enumeration do not import it.
The checker does not construct a P3 trace, impose a global visit count,
claim a highway from a local survivor, or decide the whole drift orbit.
Whole-orbit status remains **OPEN**.


Reproduction code and audit data for this note are retained in
`work_positive_skew_upperguard_20261001`. The canonical copy was integrated on 1 October 2026.
