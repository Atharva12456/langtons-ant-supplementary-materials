# Smaller all-width wake restrictions for positive-skew band C

Update, later 1 October: the
[upper-F122 quiet-six lemma](positive_skew_upper_thin_quiet6_requires_quiet7_2026-10-01.md)
now excludes that cap's entire upper-wake-seven branch in band C.
Upper F122 therefore has quiet seven; if upper four is quiet, upper
eight must wake whether six is quiet or wake. Five exact endpoint
families remain under quiet four, classified in that note and the
[upper-six note](positive_skew_bandC_upper6_wake8_reduction_2026-10-01.md).
These later restrictions do not change section 3's four schedules for
the different upper F123 cap. The whole orbit remains open.

Work with literal drift `(1,3)`, growth eight, and `t=3x-y`, with the
minimum transverse level normalized to zero. The lower `(1,2,3)` band C
forces wakes `0,2,3,4`. Write `W` for the even width. The established
width exclusion gives `W>=18`. The whole drift orbit remains **open**.

This note gives arithmetic lemmas valid at every width and period. It
also saves a smaller necessary upper-word domain for subsequent work.
It neither constructs a highway nor proves that its surviving words can
be joined across the strip.

## 1. Only one disjoint opposite-checker pair is possible

Label a wake by its fibre `j=-t mod3` and sign `epsilon=(-1)^t`.
P22 requires the signed wake sum in each of the three fibres to equal
two modulo four. Each fibre therefore contains at least two wakes.
With eight total wakes, their unsigned sizes must be `4,2,2`.
A two-wake fibre has equal signs; a four-wake fibre has a `3+1` sign
split. These statements follow by listing the signed sums at sizes two
and four, not from a search over widths.

Consequently there cannot be two **disjoint** opposite-sign pairs,
whether they lie in the same fibre or different fibres. The two smaller
fibres contain no such pair, and the larger fibre has only one minority
sign wake, which every opposite-sign pair must share. This distinction
matters: several pairs sharing that one wake are allowed.

In band C, `0` and `3` are already an opposite-sign pair in fibre zero.
The wakes `2` and `4` supply a positive wake to each other fibre.
Thus the complete fibre sign counts have exactly the following two forms:

| Fibre | Positive-dominant zero fibre | Negative-dominant zero fibre |
|---|---|---|
| zero | 3 positive, 1 negative | 1 positive, 3 negative |
| one | 2 positive, 0 negative | 2 positive, 0 negative |
| two | 2 positive, 0 negative | 2 positive, 0 negative |

Every odd wake is therefore `3 mod6`. In the first case level three is
the only odd wake; in the second case level zero is the only positive
wake in fibre zero. This is a global restriction on all eight wakes.

## 2. Upper offset three is quiet for both remaining upper caps

The upper extremal wake `W` is positive. A hypothetical wake at `W-3`
would be negative and lie in the same fibre as `W`. Since `W>=18`,
that pair is disjoint from the lower pair `0,3`. Section 1 excludes it.

Hence **band C forces quiet upper inward offset three**, independently
of whether the upper cap is `(1,2,2)` or `(1,2,3)`. This extends the
previous quiet-three result to the upper `(1,2,2)` case. It does not
exclude either upper cap when that offset is quiet.

## 3. Four upper schedules for an upper `(1,2,3)` cap

Use the exact seven endpoint families in
[the earlier classification](positive_skew_fatC_fat123_wake_families_2026-09-30.md).
Its fixed upper wakes are `W-2,W`, with upper offset one quiet. Its
extra wakes through inward offset nine are **exactly**

```text
{}, {4}, {4,8}, {7}.
```

In particular offsets `3,5,6,9` are quiet. Wake eight forces wake
four, `W=2 mod6`, and the sole residual wake `W-8`. Wake seven forces
quiet four, `W=4 mod6`, and two odd residual wakes, the larger at `W-7`.
These implications involve only wake positions, not visit multiplicities.

Here is an all-width derivation directly from that table. If offset
four is quiet, its first two families have residual distances from W
at least twelve/ten and fourteen/ten, respectively. The third family's
even residual distances are at least ten. In the fourth family,
`W=6m+4` and residuals are `6r+3` with `r<=m-1`; their upper
distances are `6(m-r)+1>=7`. Only distance seven can occur through
nine, at the larger parameter `p=m-1`.

If offset four is wake, the three families have sole residual distances
`6(m-q)`, `6(m-q)+2`, and `6(m-q)+4`, with `1<=q<=m-1`.
In the first family the only possible distance through nine would be
six, at `q=m-1`, but the required even parity of `m+q` excludes it.
In the second family distance eight occurs exactly at `q=m-1`, and
the required odd parity is automatic. The third family's distance is
at least ten. This proves every exclusion just stated without a
bounded-width assumption.

All four arithmetic schedules occur. The following examples pass P22,
moment and rank; they are **endpoint wake sets**, not ant traces:

| Extra upper schedule | W | Complete wake set |
|---|---:|---|
| empty | 20 | `0,2,3,4,6,10,18,20` |
| four | 18 | `0,2,3,4,6,14,16,18` |
| four and eight | 20 | `0,2,3,4,12,16,18,20` |
| seven | 22 | `0,2,3,4,9,15,20,22` |

## 4. Band C with upper `(1,2,2)` also has quiet offset five

A small separate local lemma says that an upper `(1,2,2)` cap with
quiet offsets three and four and wake offset five must have wake
offset six. This lemma has no growth assumption. Its finite-domain
proof exhausts raw alternating words through offset seven, with
unbounded integer `N>=1` and strict stable order. The first-six-row
normal classification is computer-assisted; the terminal obstruction
can be described by short physical returns. See the
[small local proof](positive_skew_tight_thin_reductions_2026-10-01.md)
and its independent checker in `work_positive_skew_thin_20261001`.

Now suppose band C meets such an upper cap and offset five is wake.
Section 1 forces every odd wake into fibre zero, so `W-5=3 mod6`
and `W=2 mod6`. Fibre one already contains its two required positive
wakes `2,W`; therefore `W-6`, another positive fibre-one wake, is
impossible. Offset six is quiet.

Offset four must also be quiet. Otherwise the seven fixed wakes are
`0,2,3,4,W-5,W-4,W`, leaving one residual wake. Section 1 forces
that residual to be negative in fibre zero, hence `6q+3`, strictly
between level four and `W-5`: the next such level after `W-5` lies
above W. The fixed ordered fibre word is

```text
0,1,0,2,0,2,1.
```

It has eleven increasing-fibre pairs. The residual adds two pairs,
one with each later positive upper fibre-one/two wake, so the full
rank stays odd. This contradicts the required even rank.

Section 2 already gives quiet offset three. Quiet offsets three,
four and six with wake five contradict the small local lemma.
Therefore **lower band C forces quiet upper offset five for either
remaining upper cap**. For upper `(1,2,2)` this proof combines P22,
rank and the checked local lemma; for upper `(1,2,3)` it follows from
the seven-family arithmetic classification in section 3.

The local lemma was freshly rerun: survivor counts at offsets three
through seven are `2,3,3,3,0`, from `2,38,48,57,1242` raw words.
Root independently replayed every one of its 1,374 physical-return
certificates and rederived both rejected integer-clock systems with
the upper sign `+N`. The independent replay is
`work_positive_skew_root_20261001/replay_thin_upper_obstruction.py`.
This does not exclude the upper cap with quiet offset five.

## 5. Checked pruning data and limits

Run from the project root:

```text
python work_positive_skew_root_20261001/verify_bandC_schedule_lemmas.py
```

The independent checker imports no frontier engine. It enumerates all
growth-eight P22 sign-count distributions: there are 24 overall and
exactly the two displayed band-C distributions. It separately uses the
original longitudinal-coordinate rank definition, including tied
longitudinal coordinates, to regress all seven families at every even
width 18 through 120. All 2,279 accepted endpoint sets have one of the
four schedules. The hand proofs above establish the unbounded scope;
the coordinate checks are regressions.

The saved complete upper domain through offset seven contains 13,707
upper `(1,2,3)` word prefixes before this conditional pruning. Its
three compatible wake patterns have respectively 112, 96, and 1,684
prefixes, leaving 1,892. The checker writes the smaller domain to
`results/positive_skew_bandC_upperF123_depth7_pruned_2026-10-01.json`,
with the original domain settings and source hash. Its ports use the
upper half-turn gauge and the positive clock sign `+N`. Offsets eight
and nine have not been enumerated in that file; their schedule
restrictions must be applied when extending it.

The two fibre patterns and the four upper schedules were independently
audited. Necessary local prefixes remain in the reduced domain. There
is no upper width bound, all-period chronological exclusion of band C,
or whole-orbit closure in this note.
