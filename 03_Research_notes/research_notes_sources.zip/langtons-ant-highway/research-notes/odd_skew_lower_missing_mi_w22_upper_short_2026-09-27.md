# M-I at width 22: the upper short band is impossible

For growth eight and drift `(1,-3)`, the lower-missing M-I family has its
first static placement at width 22, with wake set

```text
O={0,1,4,6,10,14,20,22}.
```

This certificate excludes the **short** initial band of the upper fat
`(1,2,3)` cap at that placement. The other upper initial bands were already
excluded: `210` by the all-width near-wake lemma, and `111` and `120` by
separate width-22 two-cap joins. Hence M-I has no width-22 placement.
Its indexed wake family has no smaller width and next admits width 28, so
M-I requires `W>=28`. Wider M-I placements and the full drift orbit
remain open.

The upper short seed in inward coordinates is

```text
0: WR
1: NR SL
2: WR WL WR
3: NR NL
4: WR EL WR EL.
```

The lower missing-cap frontier has 302 exact-integer-clock prefixes through
physical center row eleven, each with a distinct center word. The upper
frontier enumerates every directional count and every alternating word
consistent with forced finite-return adjacency, removes
only explicit finite wrong returns or infeasible real upper clocks, and
applies a necessary full-width count-flow filter anchored to the lower
prefixes. The short frontier has 3,754 prefixes at inward row eight;
the count filter removes one. It leaves 11,971 at inward row nine and
24,240 at inward row ten. The row-ten extension tests 1,917,992
adjacency words: 1,615,618 have finite wrong returns, 278,134 fail
relaxed clocks, and 24,240 survive. No period or stable-row length is
bounded.

The two cap frontiers meet at row eleven. Across the 24,240 upper prefixes,
196,159 center count options across the prefixes are checked; 24,240 match one of
the rotated lower center count vectors. These give 1,868,917 exact center
word pairs. An upper-half finite wrong return excludes 1,865,618; an
exact real upper clock rejects another 3,141. Each of the remaining
158 pairs specifies all 23 physical rows. In every complete word system,
a finite ordinal walk returns to the same cell and horizontal copy at
the wrong next stable event. Thus no full word remains. The result JSON
stores all 158 word systems and their return paths; an independent
standard-library checker replays every path.

The real upper clock is a relaxation of the required integer clock, so a
rejection remains valid for every admissible period. A finite return is
traced only through already assigned events. No repeated quotient state
is used as a physical return, and no period or row-length upper bound is
imposed.

Run `python code/python/verify_lower_missing_mi_w22_upper_short.py` from
the repository root for a complete regeneration. The verifier also accepts
`--from-upper-checkpoint` to reuse the locally verified depth-ten upper
frontier and repeat the lower frontier and full join. It writes
`results/lower_missing_mi_w22_upper_short_checks_2026-09-27.json`.
Then run
`python code/python/check_lower_missing_mi_w22_upper_short_witnesses.py`
to replay all final paths without a solver.
