# Wake placements for a lower missing cap and an upper `(1,2,3)` cap

Later results: [the missing-cap offset-six theorem](odd_skew_missing_cap_offset6_2026-09-23.md) excludes M-II. The M-I width-22 bands are excluded separately for [long 111](odd_skew_lower_missing_mi_w22_upper111_2026-09-24.md), [long 120](odd_skew_lower_missing_mi_w22_upper120_2026-09-26.md), and [short](odd_skew_lower_missing_mi_w22_upper_short_2026-09-27.md). The classification below records the preceding arithmetic stage; M-I at larger widths remains open.

22 September 2026

## Result and scope

Take drift `(1,-3)` and growth eight.  Suppose the lower cap has profile
`(1,1,0)` (missing) and the upper cap has profile `(1,2,3)` (fat).  Normalize
the transverse levels to `0<=t<=W`, with the lower cap at level zero.  Then
every such trace has wake set `O` in one of the following two families.

| Family | Width | Wake set | Integer restrictions |
|---|---|---|---|
| M-I | `W=6m+4` | `{0,1,4,6,6i+4,6k+2,6m+2,6m+4}` | `1<=i<k<=m-1`, `i+k` odd |
| M-II | `W=6m+2` | `{0,1,4,7,6k+2,6j+1,6m,6m+2}` | `1<=k<j<=m-1`, `j-k` even |

No width divisible by six is possible.  Family M-I first appears at `W=22`,
with the single placement `{0,1,4,6,10,14,20,22}`.  Family M-II first appears at
`W=26`, with the single placement `{0,1,4,7,8,19,24,26}`.  In either family
exactly one of levels six and seven is a wake.  At width `6m+4` there are
`floor((m-1)^2/4)` placements, and at width `6m+2` there are
`floor((m-2)^2/4)`.

These are necessary conditions valid at every period.  They are not
constructions, and they exclude neither family at any width.  The proof is by
hand.  It uses only the cap wake levels, P22, the odd-skew rank parity, the
additive moment, and the lower-missing lemma `omega_6+omega_7>=1`.  An
exhaustive enumeration then confirms the final classification, and each
intermediate step, through `W=80`.

The derivation independently confirms the classification recorded in the
22 September working notes.  Its two convention checks also pass.  The moment
condition may be evaluated with the lower cap at level zero; in fact, given
P22, it does not depend on the level translation at all.  Its orientation is
fixed, however: the lower cap must be the minimum of `3x+y`.  The rank parity is
unchanged by every relabelling of the residues and by reversing the level
order.

## Premises

1. **Caps.**  The lower missing cap has fixed rows `0:WR`, `1:NR`, `2:` empty,
   `3:SR,SL`, `4:WR,WL,ER`.  Thus levels `0,1,4` are wakes and levels `2,3` are
   non-wake.  The upper `(1,2,3)` cap has one, two, and three visits on levels
   `W`, `W-1`, and `W-2`.  Since a stable word has odd length exactly at a wake,
   levels `W` and `W-2` are wakes and level `W-1` is not.  Both extreme
   arrivals are horizontal, so `W` is even.
2. **P22.**  There are exactly eight wake levels.  In each fibre `O_r` (wake
   levels with a fixed residue mod 3), the signed sum of the checker signs is
   `2 mod 4`.  With eight wakes this is equivalent to the following: the fibre
   sizes are `4,2,2`, each two-element fibre has two wakes of equal parity, and
   the four-element fibre splits 3+1 by parity.
3. **Rank** (`growth8_odd_skew_additive_2026-08-23.md`, equation (2)).  Put
   `I_ij=#{(u,v) in O_i x O_j : u<v}`.  Then `I_01+I_02+I_12` is even.
4. **Moment** (same note, equation (1), for `s=-1`).  In cap-normalized levels:

   ```text
   M = sum_(t in O) (-1)^(t+1) floor((t+1)/3) = 3  (mod 4).
   ```

5. **Lower-missing lemma** (`odd_skew_excursions_and_domino_transfer_2026-08-31.md`,
   section "Level six or level seven must be wake").  At a lower `(1,1,0)` cap
   and growth eight, `omega_6+omega_7>=1`.  Its proof uses exact P3 at the lower
   cap, the lower-cap clock sign, and P22.  It assumes nothing about the upper
   cap or the period.  It must not be transferred to an upper missing cap.

## Conventions

### Residues and checker signs

With `t_raw=3x+y`, a translation class with base `(x,y)` has
`y = t_raw (mod 3)`, and its checker sign is `(-1)^(x+y) = (-1)^(t_raw)`,
because `x+y = t_raw-2x`.  The normalized level is `t=t_raw-t_min`.  Hence the
normalized residues `t mod 3` are a cyclic relabelling of the `y mod 3`
fibres, and `(-1)^t` equals the checker sign up to one common factor.  Neither
change affects P22: the condition "signed sum `=2 mod 4` in every fibre" is
invariant under a global sign and under any relabelling of fibres.

### The rank parity is labelling-invariant

For `d=(1,-3)`, the additive note orders fibre `j` by `U_j={3n+j}` with
`n=x+floor(y/3)` and `j=y mod 3`.  Since `3n+j=3x+y=t_raw`, the rank ordering
is the ordering of raw levels.  Normalization preserves that order.

Changing the residue labels changes only which of each pair of fibres is
called the smaller one.  For two fibres `A,B` with distinct levels,

```text
#{(u,v) in B x A : u<v} = |A||B| - #{(u,v) in A x B : u<v}.
```

The fibre sizes are `4,2,2`, so every product `|A||B|` is even.  Hence the
parity of `I_01+I_02+I_12` is the same under all six labellings.  Reversing the
level order replaces each term by `|A||B|` minus that term, which again
preserves the parity.  The rank condition can therefore be evaluated with
`t mod 3` labels in normalized coordinates, measured from either cap.

### The moment is translation-invariant but orientation-sensitive

In the additive note's coordinates, `3n+j=t_raw`, so `n=floor(t_raw/3)`,
`j=t_raw mod 3`, and `(-1)^(n+j)=(-1)^(t_raw)`.  The moment is therefore

```text
sum_(t in O) (-1)^(t_raw) floor(t_raw/3) = 3  (mod 4).
```

For an integer `c`, put `M_c = sum_O (-1)^(t+c) floor((t+c)/3)`.  Write
`s=t+c`.  Since `floor((s+1)/3)=floor(s/3)+[s = 2 mod 3]`,

```text
M_(c+1) = -M_c - S,
```

where `S` is the signed sum over one residue fibre.  By P22, `S=2 mod 4`, so
`M_(c+1) = 2-M_c (mod 4)`.  Thus `M_c=3` if and only if `M_(c+1)=3`.
**Given P22, the moment condition does not depend on the level translation.**
The normalized formula with `t+1`, which corresponds to `c=1`, is therefore
correct with the lower cap at level zero.  So are `c=0` and every other shift.

The shift by one has an explanation.  The rank section of the additive note
gives even raw vertices horizontal *departures*, whereas even normalized levels
have horizontal *arrivals*.  So `t_raw = t+1 (mod 2)`.  By the shift
invariance, this bookkeeping does not affect the moment condition.

The orientation cannot be reversed.  Since
`floor(-s/3) = -floor(s/3) - [s != 0 mod 3]`, and two fibre sums of `2 mod 4`
cancel mod four, reflection `t -> -t` negates the moment modulo four.  In
upper inward coordinates `u=W-t`, the same condition therefore reads

```text
sum_(u) (-1)^(u+1) floor((u+1)/3) = 1  (mod 4).
```

The level shifts `E +3`, `N +1` coincide with the additive note's
`t=3x-sy=3x+y` (for `s=-1`, `N -> t+1`, `E -> t+3`).  The lower cap is the
minimum of this `t`.  So the families below use the correct orientation.

All three statements were checked on the 15,158 P22 placements with these caps
and `W<=80`.  The checks were all 36 rank labellings and orders, the moment
shifts `c=-6,...,6`, and reflection (see Verification).

## Derivation

### Fibre sizes

The wakes `1` (odd) and `4` (even) lie in `O_1` and have opposite checker signs.
Their contributions cancel, so `O_1` needs two more wakes of equal parity.
Hence `|O_1|=4` and `|O_0|=|O_2|=2`.  Since `0 in O_0`, the other member of
`O_0` is even and divisible by three, so it is `0 mod 6`.

The upper wakes `W` and `W-2` are both even, with residues `W` and `W+1 mod 3`.
They therefore lie in different fibres.

Small widths fail directly.  For `W=0,2,4` the caps overlap inconsistently:
level `2` or `1` would have to be both wake and non-wake, or would not exist.
For `W=6` or `W=8`, at most six levels can be wakes.  The general cases below
also cover these widths.

### Width `0 mod 6` is impossible

Put `W=6m`.  Then `W` lies in `O_0`, so `O_0={0,W}`.  The level `W-2` is
`1 mod 3`, so `O_1={1,4,W-2,a}`.  Three of the signs are fixed: level 1 is odd,
and levels 4 and `W-2` are even.  A 3+1 split forces `a` to be even.
Consequently:

* level 7 (odd, `1 mod 3`) cannot be a wake;
* level 6 is a wake only if `6=W`, and width six has at most four wake levels.

This contradicts `omega_6+omega_7>=1`.  Without the lemma, width `0 mod 6` is
**not** excluded: 1,430 placements with `W<=80` pass P22, rank, and moment.

### Width `6m+4`

`W` is `1 mod 3` and even, so `O_1={1,4,a,W}` with `a` even.  Thus `a=6i+4` with
`4<a<W`, so `1<=i<=m-1`.  The level `W-2=6m+2` lies in `O_2`, so
`O_2={c,W-2}` with `c=2 mod 6`.  Level two is empty, and the next level after
`W-2` in that class is `W+4`, so `c=6k+2` with `1<=k<=m-1`.  Finally,
`O_0={0,b}` with `b=0 mod 6`.  Level 7 would be an odd member of `O_1`, so the
lemma forces `b=6`.  Level `W-1=6m+3` is odd, so it is automatically excluded.
Result:

```text
O={0,1,4,6,6i+4,6k+2,6m+2,6m+4},    1<=i,k<=m-1.
```

### Width `6m+2`

`W` is `2 mod 3`, so `O_2={c,W}` with `c=6k+2` and `1<=k<=m-1`.  Level
`W-2=6m` gives `O_0={0,6m}`.  Level 6 is a wake only if `6m=6`.  Then `W=8`,
and no `c=2 mod 6` with `2<c<8` exists.  By the lemma, level 7 is therefore a
wake.  It is odd, so the fourth member of `O_1` is odd as well: `6j+1`, with
`6j+1` not equal to `1`, `7`, or the non-wake level `W-1=6m+1`.  Result:

```text
O={0,1,4,7,6j+1,6k+2,6m,6m+2},      2<=j<=m-1,  1<=k<=m-1.
```

### Rank

Width `6m+4`.  Here `O_0={0,6}`, `O_1={1,4,A,W}`, and `O_2={C,W-2}`, with
`A=6i+4>=10` and `C=6k+2>=8`.  Counting pairs gives

```text
I_01 = 4+2 = 6,
I_02 = 2+2 = 4,
I_12 = 2+2+(1+[C>A])+0 = 5+[C>A].
```

So `I=15+[C>A]`.  It is even exactly when `C>A`, which holds exactly when
`k>i`.

Width `6m+2`.  Here `O_0={0,6m}`, `O_1={1,4,7,J}`, and `O_2={K,W}`, with
`J=6j+1<=6m-5` and `K=6k+2>=8`.  Then

```text
I_01 = 4+0 = 4,
I_02 = 2+1 = 3,
I_12 = 2+2+2+(1+[K>J]) = 7+[K>J].
```

So `I=14+[K>J]`.  It is even exactly when `K<J`, which holds exactly when
`k<j`.

### Moment

The terms `(-1)^(t+1) floor((t+1)/3)` are as follows.

```text
M-I : t   = 0  1  4  6  6i+4     6k+2     6m+2     6m+4
      f   = 0  0 -1 -2 -(2i+1)  -(2k+1)  -(2m+1)  -(2m+1)
      M   = -7-2(i+k)-4m          = 3 (mod 4)  <=>  i+k odd

M-II: t   = 0  1  4  7  6j+1  6k+2     6m    6m+2
      f   = 0  0 -1  2  2j   -(2k+1)  -2m   -(2m+1)
      M   = -1+2(j-k)-4m          = 3 (mod 4)  <=>  j-k even
```

As a cross-check, the `c=0` form gives `5+2(i+k)+4m` and `-1-2(j-k)+4m`.  These
lead to the same parity conditions.

### Width bounds and counts

M-I needs `1<=i<k<=m-1` with `i+k` odd.  The first case is `m=3`, `i=1`,
`k=2`, so `W=22`.  M-II needs `1<=k<j<=m-1` with `j-k` even.  The first case is
`m=4`, `k=1`, `j=3`, so `W=26`.  The number of pairs is
`ceil(n/2)floor(n/2)=floor(n^2/4)` in M-I, with `n=m-1`, and
`C(ceil(n/2),2)+C(floor(n/2),2)=floor((n-1)^2/4)` in M-II.

## Consequences for the cap bands

In upper inward coordinates `u=W-t`, the two families are as follows.

```text
M-I : {0,2,6p+2,6q,6m-2,6m,6m+3,6m+4},   p=m-k, q=m-i, 1<=p<q<=m-1, p+q odd
M-II: {0,2,6a+1,6b,6m-5,6m-2,6m+1,6m+2}, a=m-j, b=m-k, 1<=a<b<=m-1, b-a even
```

* Upper offsets `1,3,4,5,6` are non-wake in both families.  Offset 7 is a wake
  only in M-II with `j=m-1`, and offset 8 only in M-I with `k=m-1`.  Since
  upper offsets 3 and 4 are non-wake, the four-band theorem
  (`odd_skew_upper_fat123_four_band_reduction_2026-09-21.md`) applies.  The
  upper initial band is therefore the short row, `(1,1,1)`, `(1,2,0)`, or
  `(2,1,0)`.
* On the lower side, M-I has levels `5,7,8,9` non-wake, with next wake
  `6i+4>=10`; level 10 is a wake exactly when `i=1`.  M-II has levels `5,6`
  non-wake; level 8 is a wake exactly when `k=1`, and otherwise the next wake is
  at least 14.

## Verification

The scripts are in `code/python/` (run from that directory).  Python
3.13.14, standard library only.

```text
python lower_missing_upper_fat123_families.py 80
```

This enumerates every 8-subset of `[0,W]` containing `0,1,4,W-2,W` and avoiding
`2,3,W-1`, for every even `W<=80`.  It filters by P22, rank, moment, and the
lemma, in that order.  The result is compared with the closed forms.  Output
(excerpt):

```text
even W<=80: total placements 250; all W agree with M-I u M-II: True
surviving counts after P22 / +rank / +moment / +lemma: {'p22': 15158, 'rank': 7007, 'moment': 3490, 'lemma': 250}
P22+rank+moment survivors WITHOUT the lemma, by W mod 6: {0: 1430, 2: 980, 4: 1080}
convention audit over 15158 P22 placements:
  rank parity changes under residue shift/permutation/order reversal: 0
  moment "=3 mod 4" changes under level shift c in [-6,6]: 0
  upper-inward (reflected) moment not equal to 1 exactly when lower moment is 3: 0
ALL_CHECKS_PASSED=True
```

Per-width counts, as brute force / M-I / M-II: 22:1/1/0, 26:1/0/1, 28:2/2/0,
32:2/0/2, 34:4/4/0, 38:4/0/4, 40:6, 44:6, 46:9, 50:9, 52:12, 56:12, 58:16,
62:16, 64:20, 68:20, 70:25, 74:25, 76:30, 80:30, with every width agreeing.

```text
python lower_missing_upper_fat123_derivation_steps.py 80
```

This checks each hand step against brute force: width `0 mod 6` is empty after
P22 and the lemma; the pre-rank parametrizations for widths `6m+4` and `6m+2`
are exact; the integer values of `I_01,I_02,I_12` match the displayed counts;
and the moments equal exactly `-7-2(i+k)-4m` and `-1+2(j-k)-4m`.  Output:
`STEPS_OK=True (W<=80)`.

```text
python lower_missing_upper_fat123_upper_offsets.py 140
```

This confirms the upper-inward forms and the offset table for `W<=140`; its
output ends with `UPPER_FORMS_OK=True`.

```text
lower_missing_upper_fat123_families.py  fb5d1b040f149c69d3078432d7566b2b27a5199a77345857d89b750745e4a3e0
lower_missing_upper_fat123_derivation_steps.py  9b170fa4e960bf82f21e36c1a58fe2c618eb5397f66374eec9173ba77b159667
lower_missing_upper_fat123_upper_offsets.py  22ae0bd43d7718a808e71121157586f23d7a2565c73398707124737cb2dadf97
```

## Status

**Proved at every period** (by hand, from premises 1-5): the lower-missing /
upper-`(1,2,3)` wake set lies in M-I or M-II, and width `0 mod 6` is
impossible.  The enumeration up to `W=80` is a check of the hand argument, not
part of it.

**Not proved:** that any placement in M-I or M-II is realized.  Also not proved
is any exclusion of the upper band choices listed above.  The lemma
`omega_6+omega_7>=1` is essential: without it, all three width classes survive
the static conditions.
