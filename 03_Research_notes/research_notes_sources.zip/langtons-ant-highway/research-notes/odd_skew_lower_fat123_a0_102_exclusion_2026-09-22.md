# The lower fat `(1,2,3)` bands with `omega_3=0` and `(j,k,l)=(1,0,2)` are impossible

22 September 2026

For drift `(1,-3)`, the two lower-cap bands

```text
0: WR
1: NR,SL
2: WR,WL,WR
3: SR,SL,NR,SL,NR,SL
4: WR,WL,ER,EL,WR,WL,WR,WL,[WR]^b          b = omega_4 in {0,1}
```

cannot occur at any period. These were two of the four `j=1,k=0` bands that
escape the long black-lifetime bounds of the September 12 normal form, and
two of the five lower `(1,2,3)` bands still open after the earlier exclusions
of 22 September. The remaining open lower `(1,2,3)` bands are now
`(1,1,1)` with `omega_3=0` and either `omega_4`, and `(1,1,0)` with
`omega_3=omega_4=1`.

## Method and scope

Starting from the displayed rows, each later row is enumerated exhaustively.
For both wake values at every level, the flow and excess equations give every
possible count row, and every right/left alternating stable word with those
counts is considered. A word is discarded only if one of the following
necessary conditions fails:

1. a zero-displacement walk from a new event through already built rows
   returns to the new level, and the event it reaches is not the next stable
   event (applied while the word is built);
2. a witnessed finite same-cell first return lands on an event other than the
   next stable visit (walks are followed only through built rows; no quotient
   cycle is extrapolated);
3. the exact lifted clock is infeasible over the integers:

   ```text
   tau(target) = tau(source) + 1 - N*lambda,   lambda(E)=1, lambda(W)=-1,
   N >= 6,     tau(t,i+1) - tau(t,i) >= 4.
   ```

No P22 wake restriction, rank or moment condition, period upper bound, width bound,
row-length bound or black-lifetime bound is used. Rows above the upper cap are
empty and occur in the enumeration as the empty word, so an empty frontier at
level nine excludes the band for every width, including widths below nine.

| `omega_4` | Level | Count rows | Words | Rejected by return | Rejected by clock | Survivors |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 5 | 6 | 13 | 9 | 0 | 4 |
| 0 | 6 | 34 | 120 | 78 | 0 | 42 |
| 0 | 7 | 405 | 450 | 378 | 12 | 60 |
| 0 | 8 | 627 | 2,999 | 2,431 | 116 | 452 |
| 0 | 9 | 5,208 | 1,088 | 1,088 | 0 | **0** |
| 1 | 5 | 6 | 17 | 13 | 0 | 4 |
| 1 | 6 | 38 | 209 | 143 | 9 | 57 |
| 1 | 7 | 615 | 2,983 | 2,557 | 132 | 294 |
| 1 | 8 | 3,831 | 34,861 | 29,421 | 2,328 | 3,112 |
| 1 | 9 | 46,424 | 26,435 | 26,435 | 0 | **0** |

"Words" counts the words that pass condition 1 during construction. At level
nine every such word has a witnessed wrong first return; the clock is needed
only at levels six through eight.

## Reproduction and independent checks

```bash
python code/python/verify_lower_fat123_a0_102_exclusion.py
```

The standalone checker uses Z3 for the clock and writes
`results/lower_fat123_a0_102_checks_2026-09-22.json` with
`all_checks_passed=true`. A separately written Java explorer, which decides
the clock with an exact parametric Bellman-Ford iteration instead of Z3,
reproduces every entry of the table, including the split between return and
clock rejections. With P22 wake pruning switched on, both bands still die at
level nine (4, 42, 60, 452, 0 and 4, 57, 240, 2936, 0 survivors). The same
enumeration gives exactly the published counts for the seven lower `(1,2,3)`
bands excluded earlier on 22 September, and matches the independent probe
counts through level eight recorded in the parallel working copy.

This is a computer-checked all-period exclusion under the stable-word
framework of `odd_skew_lower_fat_cap_normal_form_2026-09-12.md`. It is not a
Lean formalization, and it does not close the `(1,-3)` drift orbit.
