# The four-step phase condition is redundant for strong lifted clocks

Every Langton-ant step turns by ninety degrees, so movement axes
alternate horizontal and vertical. A closed physical walk has equally
many horizontal and vertical moves, with each number even because east
balances west and north balances south. Its length is therefore a
multiple of four. Successive visits to one physical cell share a time
residue modulo four.

In the canonical positive-skew coordinates `t=3x-y`, even-row arrivals
are vertical and odd-row arrivals are horizontal. Choose representatives
`c_t=(0,-t)`. With literal drift `(1,3)` and `N=2 mod4`, one global time
shift gives the lifted representative phases

```text
phi(t)=0 for even t, 3 for odd t.
```

This applies to either clock gauge `tau(target)-tau(source)=1+sigma*N*dx`,
where `sigma=+1` at the upper cap and `-1` at the lower. From an even row,
E/W steps reach an odd row and have increment three modulo four. From an
odd row, N/S steps reach an even row and have increment one modulo four.
Thus every equality edge has increment `phi(target)-phi(source)` modulo
four, regardless of gauge.

Adding these phases does **not** strengthen an integer clock system
whose stable gaps are already at least four. Given any satisfying integer
clock `tau`, define simultaneously at every event

```text
tau'(q)=4*floor((tau(q)-phi(row(q)))/4)+phi(row(q)).
```

On an equality edge the two expressions inside the floors differ by an
integer, because the adjusted clock increment is a multiple of four.
The exact edge equality is preserved. For adjacent events at one row,
their phases agree and their original clock gap is at least four.
Their floored difference is at least one, so the new gap is again at
least four. No assumption that the equality graph is connected is needed.
The period and all period-floor constraints are unchanged.

Consequently the globally phased strong system is feasible if and only
if the existing strong system is feasible. Under weak gaps of one the
rounding can collapse a strict gap, so this redundancy statement does
not apply to weak clocks.

The [independent witness checker](../work_positive_skew_root_20261004/verify_phase_rounding.py)
replays all 2,076 complete shared-upper-row-twelve SAT models: 220,520
event values, 193,532 stable gaps, and 171,364 original edge equalities.
Every saved witness already has the displayed phases; the transformation
changes zero values. The
[audit report](../work_positive_skew_root_20261004/phase_rounding_audit.json)
binds the exact source models and parent words. No new prefix or cap
family is excluded. The whole `(1,3)` growth-eight orbit remains **OPEN**.
