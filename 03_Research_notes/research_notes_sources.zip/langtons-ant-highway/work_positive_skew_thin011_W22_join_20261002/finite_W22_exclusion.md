# Finite width-22 exclusion for lower thin011 / upper F123 wake6

This note concerns literal displacement `(1,3)`, growth eight, width **22**,
and wake offsets

`{0,4,6,7,8,16,20,22}`.

The complete join has no survivors, and independent complete checks have
passed: all 1,518 parent domains, all 617,021 emitted row-nine words,
all 135,293 reached row-ten words, all 113,976 imported or new clock
rejections, and every one of the 234,821 cached word-existence domains.
Thus no cap in this exact width-22 family can realize the stated literal
displacement and growth. The final bound reports and source hashes are
saved in `final_certificate_audit.json`. This is a finite-width result.
The arbitrary-width family and the full literal positive-skew orbit remain
**OPEN**.

## Assumptions and exact interface domain

The cap reduction and lower thin rigidity supply the following lower words
at offsets zero through seven (bits `c,e,f = 0,1,1`):

```
0 NR
1 WR WL
2 NR SL
3 WR WL ER WL
4 SR SL SR
5 ER WL ER WL
6 NR NL SR NL NR SL NR SL NR SL NR
7 WR WL WR EL WR WL WR WL WR WL WR
```

These contain 38 events. The upper inward seed is
`0 NR`, `1 WR WL`, `2 NR SL NR`, followed by quiet rows three through
five, wake row six, and quiet rows seven through ten. The complete necessary
upper weak-clock domain contains 415 words, supplied by
`../work_positive_skew_upperfat_wake6_20261002/complete10_result.json` and
independently audited in that directory's `independent_audit_3_10.json`.
No positive period ceiling is imposed in that upper source.

Map its upper offset `u` to global offset `22-u`, exchange E/W and N/S,
and preserve R/L. Thus the two supplied domains cover global rows zero
through seven and twelve through twenty-two. The remaining rows are eight
(wake), nine, ten, and eleven (quiet). The join allows every exact count
profile and every necessary stable word on those four rows.

For a port `hR` or `hL`, rotate the incoming heading `h` right or left to
obtain its outgoing direction. With `t=3x-y`, the four direction shifts
are E `+3`, W `-3`, N `-1`, S `+1`. Exact interface balance is

`out_D(t) = in_D(t + shift(D))`.

The stable word starts with R and alternates. Its R count exceeds its L
count by one on row eight, and equals its L count on rows nine through
eleven. The row-count recurrence solves these integer constraints using
already assigned interfaces; its range is finite from the exact known
flows, with no count cutoff. Assigning an arbitrary word for a count vector
while computing later count vectors loses no count information: all
interfaces depend only on port multiplicities.

The freshly regenerated full count domain is:

| Stage | Count vectors | Interface rejects |
| --- | ---: | ---: |
| 8 | 1,245 | 0 |
| 9 | 5,395 | 4,469 |
| 10 | 8,468 | 7,542 |
| 11 | 5,843 | 4,922 |

There are 921 fully balanced matrices. Their total physical displacements
are `(-3,-9)` (415), `(-7,-21)` (258), `(1,3)` (221), and `(5,15)` (27).
Only the 221 matrices with literal displacement `(1,3)` remain. They have
eight distinct gap count profiles and exact full event totals
`N=210` (12 matrices), `226` (100), or `242` (109). Each meets `N>=62` and
`N=2 mod 4`. There is one retained matrix per retained upper source word.
Here `N` is determined by the complete event count, not selected from a
bounded search interval.

## Necessary chronology and physical return constraints

Use representatives `(0,-t)`, with copy `k` at `(k,3k-t)`, and lower
lifted clocks `tau=i-Nk`. Matching the ordinal departure and arrival of a
directed interface gives

`tau(target) = tau(source) + 1 - N*dx`.

Thus an east edge has shift `1-N`, a west edge `1+N`, and a vertical edge
shift one. Consecutive stable events on one physical cell satisfy a gap
of at least four. At fixed count-derived `N`, these form integer equality
constraints and integer difference inequalities. An equality path with
incompatible stable order, an inconsistent directed equality cycle, or
a positive cycle of compressed stable inequalities proves impossibility.

For each departure ordinal of a new row, follow the already assigned
ordinal edges in actual `(x,y)` coordinates until the first return to the
new quotient row or an unassigned interface. If this first quotient
return is the **same physical point**, its matching arrival ordinal must
be the immediately next stable event. If it is another translated copy,
this immediate-next constraint is not applied. The audit independently
checks the coordinates, not just the quotient row.

An alternating-word existence check then uses only the remaining port
counts and the next required heading/arrival ordinal. Both arrival and
departure ordinals are determined by the used port counts, so the finite
dynamic-programming state is complete. Every transition consumes one port;
an unfinished next-event requirement at the end is rejected. No runtime
or node limit is used inside this finite existence check.

The earlier signed translated-excursion row-nine generator is safe to
reuse here: all witnessed row-nine returns through the old domain are
zero-copy `NWSE` excursions. North arrivals with an NR turn leave into the
missing row eleven; an NL turn returns through row eight, row five WL,
and row six SL in four steps. South departures leave into missing row ten.
Consequently its signed-order filter adds no row-nine restrictions. This
was checked in fresh geometry for all 1,518 row-eight parents. The final
audit also regenerates each plain zero-copy row-nine domain directly,
which verifies the reused domains without relying on that observation.

## Exhaustive finite rejection chain

The complete row-eight word domain emits 3,450 necessary words. Exact
fixed-period gap-four clocks reject 1,932; 1,518 remain. The independent
count and row-eight audit passed in `independent_audit_through8.json`.

For all 1,518 remaining parents, row-nine count vectors represent
74,525,472 raw alternating words and emit 617,021 necessary words. Their
complete partition is:

| Row-nine disposition | Number |
| --- | ---: |
| Previously checked exact-clock rejection, independently replayed | 100,364 |
| Empty necessary row-ten word domain | 498,641 |
| New exact-clock rejection | 13,611 |
| Reaches row-ten word enumeration | 4,405 |
| Total | 617,021 |

The 4,405 row-nine continuations represent 3,583,487,277 raw row-ten words
and emit 135,293 necessary row-ten words. Of these, 135,292 have an empty
necessary row-eleven domain. The remaining one fails its exact-period
gap-four clocks. No row-eleven word reaches enumeration or a full-tour
test. The exclusion therefore does not require accepting a purported
full quotient tour or interpreting a return to another copy as a physical
first return.

The one terminal clock rejection has a short hand certificate. Use
zero-based event indices and put `F=(12,5)`, `G=(12,6)`, `D=(13,2)`,
`E=(13,3)`, `A=(14,4)`, and `C=(14,6)`. Actual ordinal paths give

| Path | Directions | Length | Final copy |
| --- | --- | ---: | ---: |
| F to C | `ESWS` | 4 | 0 |
| G to D | `WSE` | 3 | 0 |
| E to A | `SESWSESWSENWNENWN` | 17 | 0 |

Therefore `tau(C)=tau(F)+4`, `tau(D)=tau(G)+3`, and
`tau(A)=tau(E)+17` for every period. Stable order supplies
`F<G`, `D<E`, and `A<(14,5)<C`. Even with gaps only one, following this
chain gives `tau(C)>=tau(F)+24`, contradicting the four-step path F to C.
With gap four the contradiction has positive cycle sum 32. The checker
`unique_row10_hand_certificate.py` independently verifies all departure
and arrival ordinals and every intermediate physical coordinate, and
saves them in `unique_row10_hand_certificate.json`. These traces are
clock equalities between different cells; they make no first-return claim.
This pattern occurs at parent 856, upper source word 239, and its
count-derived period is 226, although its final contradiction needs no
period value.

Complete parents zero through 230 reuse saved complete row-nine outputs;
their 100,364 imported clock rejections are freshly proved again. All
other parents are regenerated. Each complete parent is checkpointed;
partial parent records from interrupted passes are deduplicated by the
complete-parent reconstruction. Earlier capped breadth outputs and the
first two capped lookahead passes are explicitly incomplete and are not
used as an exhaustion certificate.

The final constraint cache has 234,821 distinct `(counts, zero-copy pairs)`
domains: 121,576 empty and 2,579 nonempty first queried at row ten, and
110,665 empty and one nonempty first queried at row eleven. An independent
recursion with reversed port order verified every existence result,
including positive witnesses, in `constraint_domain_audit.json`.

## Certificate files and independent checks

`count_domain.json` and `count_balance_rejections.jsonl` contain the exact
count domain and interface/displacement rejection certificates.
`stage_8.json` and `stage_8_rejections.jsonl` contain the complete initial
word stage. `lookahead_parent_checkpoints.jsonl` contains all 1,518 complete
parent outputs. `lookahead_completed_rejections.jsonl` contains the unique
final lookahead rejections, while
`ordered_stage9_completed_rejections.jsonl` contains the imported clock
rejections. `lookahead_constraint_domains.json` contains the complete
finite existence signatures. `lookahead_result.json` is the complete
primary result; the older `result.json` is an interrupted baseline.

`lookahead_independent_audit.py` imports neither the frontier generator,
the primary fixed-extension clock solver, nor the lookahead engine. It
freshly regenerates each complete row-nine domain and each reached row-ten
domain; compares exact word sets with the saved disposition records;
reconstructs every used zero-copy pair in actual coordinates; and proves
every imported or new fixed-period clock rejection by an independent
equality-path and stable-cycle construction. It saves explicit clock
proofs to `lookahead_independent_clock_proofs.jsonl` and the complete
coverage report to `lookahead_geometry_clock_audit.json`. Distinct clock
proof signatures receive direct Z3 crosschecks as well: all 199 distinct
signatures passed. Every clock rejection was proved by a positive stable
component cycle. The independent audit checked all 232,241 negative
constraint signatures actually referenced by the complete rejection chain;
the separate cache audit also checked every positive signature and every
unused cached signature.

`complete_parent_row9_coverage.jsonl` records each complete parent's count
profile, period, reconstructed row-nine word-set count/hash, and rejection
partition. Its set coverage is certified by the fresh equality-of-word-sets
checks in the independent audit, rather than by a resource-limited search.
`final_certificate_audit.json` binds all final reports and certificate
sources by SHA-256. A closure claim is justified only when its complete
independent checks have passed. The theorem's scope remains exactly the
width-22 member stated above.
