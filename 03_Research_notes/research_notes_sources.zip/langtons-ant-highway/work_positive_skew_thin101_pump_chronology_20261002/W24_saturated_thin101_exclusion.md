# Width 24 saturated lowerthin101 exclusion

Whole literal `(1,3)`, growth 8 orbit status: **OPEN**. This note closes
only the saturated thin101 family at width 24. Larger widths are not
closed by this argument, and the quiet-12 search on unbounded local
prefixes in `pump_hand_obstruction.md` remains incomplete.

The family has width `W=6m` and wakes
`{0,4,5,7,W-8,W-7,W-2,W}`. At `W=24` these are
`{0,4,5,7,16,17,22,24}`. Its fixed lower rows 0..7 are:

```
0 NR
1 WR WL
2 NR SL
3 WR WL ER WL
4 SR SL SR
5 ER WL ER
6 NR NL SR NL NR SL NR SL
7 WR WL WR EL WR WL WR
```

Use `t=3x-y`, representatives `(0,-t)+k(1,3)`, and lower stable clocks
`tau=i-Nk`. Every directed edge has clock increment `1-N dx`. The upper
half-turn preserves R/L and stable order and reverses all headings; hence
the upper clock is `1+N dx` in its own gauge. The upper boundary occupies
global rows 14..24, disjoint from the bridge rows 8..13.

The quiet row-8 flow counts are exactly either `(SR,SL)=(1,1)` or
`(NR,NL,SL)=(3,1,2)`. The former has one word and is excluded by the
short count contradiction in `W24_SRSL_count_obstruction.md`. The latter
has exactly the following three raw words:

```
NR NL NR SL NR SL
NR SL NR NL NR SL
NR SL NR SL NR NL
```

The upper boundary is the complete necessary weak-clock domain of 32
upperF123 prefixes: quiet offsets 3..6, wakes 7,8, quiet offsets 9,10.
`audit_upper32_source.py` freshly regenerated every necessary word from
all nonnegative flow vectors, replayed 2,274 physical certificates, and
checked all 96 rejected unbounded `+N` clocks. It imports no frontier
implementation. The evidence is `upper32_independent_audit.json`.

The 32 upper words have four count profiles. Here `(Hu,Vu)` is upper-gauge
displacement, `(X,Y,Z,T)` denotes global-14 W departures, global-15 E
arrivals, global-16 W departures, global-14 S arrivals, respectively.

| upper profile | words | `(Hu,Vu)` | `(X,Y,Z,T)` |
|---|---:|---|---|
| 0 | 12 | `(19,-5)` | `(13,13,10,10)` |
| 1 | 8 | `(15,-5)` | `(9,13,10,6)` |
| 2 | 8 | `(15,-1)` | `(9,9,10,10)` |
| 3 | 4 | `(11,-1)` | `(5,9,10,6)` |

The other row-8 variant has a particularly small complete count domain.
Let `e` be the row-9 EL count. Row 9 has counts

`(ER,EL,WR,WL)=(5-e,e,4-e,9-3e)`, so `e=0,1,2,3`.

Let `s,h,k,z` be the SR10, EL11, SR12, EL13 counts. Primitive horizontal
displacement and the four cut counts force them uniquely:

| profile | `s` | `h` | `k` | `z` | exact full period |
|---|---:|---:|---:|---:|---:|
| 0 | `4-e` | 3 | `4-e` | `11-3e` | `254-16e` |
| 1 | `5-e` | 2 | `4-e` | `10-3e` | `238-16e` |
| 2 | `4-e` | 4 | `3-e` | `11-3e` | `238-16e` |
| 3 | `5-e` | 3 | `3-e` | `10-3e` | `222-16e` |

For completeness, row 10 has counts
`(NR,NL,SR,SL)=(20-4e-3s,6-s,s,14-4e-s)`.
Write `D=26-4e-4s`, the row-10 N-arrival count. Row 11 has
`(ER,EL,WR,WL)=(5-h,h,D-h,5+D-3h)`.
Write `B=10+D-4h` and `C=13-4e`. Row 12 has
`(NR,NL,SR,SL)=(B+C-3k,C-k,k,B-k)`.
Write `A=34-8e-4s` and `D13=B+2C-4k`. Row 13 has
`(ER,EL,WR,WL)=(A-z,z,D13-z,A+D13-3z)`.

To derive the table, the fixed lower cap has displacement `(4,-2)`, so
the bridge needs horizontal displacement `Hu-3`. Its horizontal
contributions are 4 at row 8, `28-8e-4s` at row 10, and `Y-C` at row 12.
Thus `4(e+s)=22+Y-Hu`, fixing `s`. The W cut at row 11 then gives
`4h=5+2D-X`; the E cut at row 12 gives `4k=2B+C-Y`; the W cut at row 13
gives `4z=A+2D13-Z`. The S cut at row 13 agrees automatically.
All sixteen resulting vectors are nonnegative and balanced, and each
has total displacement `(1,3)`. There are no further primitive count
profiles. `verify_W24_count_formulas.py` independently verifies this
table, every directed edge count, and its exact agreement with the
separate exhaustive count audit.

The period is the sum of visit counts over all 25 quotient rows. It is
fixed by a complete count profile, between 174 and 254 in the table.
This is a necessary equality for an actual period; it is not a guessed
clock bound. Fixed lower clocks require stable gaps at least 4.

`audit_alternative8_row9.py` independently checked all 1,422 raw row-9
words: 1,352 have wrong physical first returns and 16 have impossible
weak lower clocks. Fifty-four local prefixes remain. These are matched
to the sixteen complete count profiles and their compatible upper words,
giving exactly 1,728 initial boundary pairs. Fixed-period clocks reject
432, leaving 1,296 pairs.

The complete necessary join then gives:

| added row | parents | necessary words | physical rejects | fixed-clock rejects | survivors |
|---|---:|---:|---:|---:|---:|
| 10 | 1,296 | 4,608 | 2,624 | 880 | 1,104 |
| 11 | 1,104 | 15,700 | 11,120 | 3,956 | 624 |
| 12 | 624 | 1,918 | 1,902 | 16 | 0 |

`fixed_period_join.py` imposes all four upper cut counts before extending
row 10. Every finite count word domain is covered. Its 45-second and
two-million-node safeguards were not reached at any stage; the saved
result has `complete_through=12` and no stop reason. No row-13 word
extension is needed.

The independent audit, `audit_W24_join.py`, does not import the join or
its clock engine. It regenerates the row-10/11/12 domains with a prior
independent **zero-copy adjacency** generator, and obtains exactly the
same 4,608, 15,700 and 1,918 necessary words. No completed word is removed
by translated-return order in this audit, so signed order pruning is
not needed for the proof of completeness. It freshly replays every
physical certificate in the original compass coordinates, checking that
the displayed return is the first physical return and has the wrong
stable ordinal. Every fixed-clock rejection is certified by a positive
cycle of stable-order difference inequalities. The audit verifies its
integer event potentials against every directed edge at the exact period
and verifies the displayed cycle has positive total weight. No solver
claim is needed for those 5,284 fixed-period clock contradictions. The
audit also verifies that each potential component label fibre is exactly
one connected component of the undirected equality graph, including
isolated events; disconnected components may not share a free root.
The 16 weak row-9 clock rejections are freshly checked with Z3, with `N>=1`
unbounded. In total this independent audit verifies 16,998 physical
rejections and 5,300 clock rejections.

Run the complete proof chain from the repository root:

```
python -B work_positive_skew_thin101_pump_chronology_20261002/audit_upper32_source.py
python -B work_positive_skew_thin101_pump_chronology_20261002/audit_row10_row11_raw.py
python -B work_positive_skew_thin101_pump_chronology_20261002/count_W24_domains.py
python -B work_positive_skew_thin101_pump_chronology_20261002/verify_W24_count_formulas.py
python -B work_positive_skew_thin101_pump_chronology_20261002/audit_W24_join.py
```

These prove a completed finite necessary-domain exclusion at width 24.
They neither establish a highway nor close the all-width saturated
family. The upper domain is an audited necessary boundary, not a list
of actual orbit prefixes. Canonical notes and other agents' files were
not modified.
