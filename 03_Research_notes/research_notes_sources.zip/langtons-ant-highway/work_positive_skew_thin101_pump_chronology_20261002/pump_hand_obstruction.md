# The thin101 count pump fails; a stronger local count restriction

The specified six-row count pump cannot follow the fixed lower thin101
prefix. Two four-step physical returns already exclude its row-ten
count choice; rows eleven through thirteen are unnecessary. The complete
1,296-word regression rejects every proposed pump word by a finite
wrong physical first return. The all-width family is **OPEN**: other
quiet bridge counts and words remain possible necessary prefixes.

## Fixed domain and three physical squares

Use the literal lower gauge `t=3x-y`, drift `(1,3)`, and lower clock
`tau(target)=tau(source)+1-N*dx`, with integer `N>=1` unbounded.
The hand-forced lower thin101 rows are

```text
0 NR; 1 WR WL; 2 NR SL;
3 WR WL ER WL; 4 SR SL SR; 5 ER WL ER;
6 NR NL SR NL NR SL NR SL;
7 WR WL WR EL WR WL WR.
```

Condition on quiet row eight with the word `SR SL`. Quiet row nine is
then forced by flow to `(ER WL)^5`: it has five east arrivals and no
north departures. At quiet row ten all exact nonnegative count vectors
are

```text
SR=s, SL=10-s, NL=6-s, NR=16-3s,  0<=s<=5.
```

These six vectors represent 85,102 R-first alternating words. Write
`D_i` for row ten's i-th west departure and `S_j` for its j-th south
arrival. There are exactly six D events and ten S events.

Three ordinal paths through old rows are physical first returns:

| Adjacency | Old ports visited | Direction word |
|---|---|---|
| D1 -> S1 | row7 W-arrival1=WR; row6 N-arrival1=NR; row9 E-arrival1=ER | WNES |
| D4 -> S3 | row7 W-arrival4=WR; row6 N-arrival4=NR; row9 E-arrival2=ER | WNES |
| D6 -> S7 | row7 W-arrival6=WR; row6 N-arrival5=NR; row9 E-arrival4=ER | WNES |

Each path has physical positions `(0,-10),(-1,-10),(-1,-9),
(0,-9),(0,-10)`. The endpoint must immediately follow its start in
the stable word, with the opposite turn. No quotient return at another
copy is used as adjacency.

For an adjacency D_i -> S_j, if D_i=NL, its successor is S_j=SR,
also the next west departure D_(i+1). If D_i=SR, the successor is
S_j=SL. Before D1, neither a west departure nor a south arrival can
occur, so alternation makes row ten begin exactly `NR NL SR`:
D1=NL and S1=SR=D2. At the other end, D6 cannot be NL, since its
next event would be S7=SR=D7, exceeding the six west departures.
Hence D6=SR=S6 and its successor is S7=SL.

Two consecutive SR events cannot be consecutive in both the D and S
ordinal lists. An intervening L is either NL, which adds a D, or SL,
which adds an S. This simple observation controls the middle square.

If D4=NL, then S3=SR=D5. D3 cannot be SR=S2, because D2=SR=S1
and D3=SR=S2 would be consecutive in both lists. Thus D3=NL, and
the six D events have types `NL,SR,NL,NL,SR,SR`: **s=3**.

If D4=SR, its next event is S3=SL, so D4=S2. The L between
D2=S1 and D4=S2 is necessarily D3=NL. D5 may be NL or SR, giving
respectively **s=3 or s=4**. These exhaust the six D events.

Therefore

```text
SR10 is 3 or4,
H10 = Edepartures10-Wdepartures10 = 20-4*SR10 is 8 or4.
```

This restriction uses only physical returns, ordinal order, and
alternation. It is independent of N, growth, width, and every later row.
It is the useful additional restriction beyond aggregate count flow.

## Six exact row-ten words

The same three adjacencies give exactly the following six words:

```text
A0 NR NL SR NL NR SL NR NL SR SL NR SL SR SL NR SL NR SL NR SL
A1 NR NL SR NL SR SL NR NL NR SL NR SL SR SL NR SL NR SL NR SL
A2 NR NL SR NL SR SL NR SL NR NL NR SL SR SL NR SL NR SL NR SL
A3 NR NL SR NL SR SL NR SL NR SL NR NL SR SL NR SL NR SL NR SL
A4 NR NL SR SL NR NL NR NL SR SL NR SL SR SL NR SL NR SL NR SL
B  NR NL SR NL SR SL SR SL SR SL NR SL NR SL NR SL
```

The A words have `NR7,NL3,SR3,SL7`; B has `NR4,NL2,SR4,SL6`.
For D4=NL, S2=SL may occur just before or just after D3=NL,
giving A0 and A4. For D4=SR and D5=NL, that NL may occur in one
of the three positions before D6=S6=SR, giving A1,A2,A3.
For D5=SR, the consecutive-ordinal observation forces D5=S4;
the word is B. Remaining ports after S7 alternate NR,SL.

A separate raw enumeration of all 85,102 words tests only the three
displayed adjacencies and gives exactly this six-word set. It imports
no adjacency generator. Thus it independently regresses the hand
classification and the separate necessary-word generator.

## Why the proposed zero-displacement pump fails

The pump chooses s=5, i.e. `NR1,NL1,SR5,SL5`, contrary to the
proved restriction s in {3,4}. More explicitly, the first square and
its counts force `NR NL (SR SL)^5`. Its fourth west departure is
its fifth south arrival SR. The second WNES square returns it to its
third south arrival SR, an earlier row-ten event. This is a wrong
physical first return of length four.

The proposed row-ten and row-thirteen counts each admit 36 raw words,
so the exact pump has 1,296 block words. The fresh complete regression
checks all 1,296 and finds 1,296 finite physical rejections. No clock
test is needed to exclude the pump. Additional evidence includes a
12-step wrong physical return and a 44-step quotient cycle displaced
by `-2d`, giving the lower-clock contradiction `44+2N=0`. The latter
is a nonzero-copy quotient cycle, **not** a physical adjacency. The
initial tentative 18-step cycle was an ordinal error and is not used.

## Quiet eleven survives; no branch closure

For each of the six words, quiet row eleven has both complete count
choices `e=EL11=0` and `e=1`. All 112 raw words are independently
covered; 103 fail a physical first return, six have inconsistent
unbounded lower clocks, and three survive:

```text
A1 -> (WR WL)^4 WR EL (WR WL)^4
A2 -> (WR WL)^5 WR EL (WR WL)^3
B  -> (WR WL)^3 ER WL (WR WL)^3
```

These are necessary local prefixes, not trajectories. Their explicit
strong growth-eight local clock witnesses have periods 82,82,74,
respectively, and pass `N>=assigned lower events`, `N=2 mod4`, and
stable gap four. The assigned counts are 80,80,72, so their own lower
event counts already imply `N>=62`; no lower/upper nonoverlap argument
is needed to apply that floor at these depths. The weaker witnesses
22,22,14 are only weak local models, never periods of an actual
growth-eight orbit.

All three survivors give quiet-row-twelve flow parameters `B=8,C=5`:

```text
SR12=s, SL12=8-s, NL12=5-s, NR12=13-3s, 0<=s<=4.
H12=16-4s >=0.
```

Thus the first bridge part contributes H10>=4, and the next even row
has H12>=0. No proof shows that this positive transfer repeats at
arbitrary cuts, or that row eight must be SR,SL among all quiet
row-eight possibilities. The arithmetic all-width family remains open.

## Bounded continuation and reproduction

The strong extension through row twelve uses lower `1-Ndx`,
`N>=max(62,assigned lower events)`, `N=2 mod4`, stable gap four,
and no upper bound on N. A 45-second stage cap stopped it during
parent zero's SR12=0 vector: 916 emitted words, 817 clock rejections,
99 retained local prefixes. This row-twelve stage is explicitly
**INCOMPLETE**; row thirteen was not reached. Its 99 survivors are
not a complete domain or trajectories. A prior unbounded direct-Z3
weak row-twelve run was interrupted; its partial rejection file is
not a completeness certificate. The last completed domain is row eleven.

Reproduce from the project root:

```text
python -B work_positive_skew_thin101_pump_chronology_20261002/verify_pump.py
python -B work_positive_skew_thin101_pump_chronology_20261002/audit_row10_row11_raw.py
python -B work_positive_skew_thin101_pump_chronology_20261002/extend_strong_quiet12_13.py
```

The first two checks pass and have no resource cap. The last is an
explicitly bounded continuation; capped stages remain incomplete.
Only this particular count pump is excluded. The wider row-eight
branch, the saturated upper-F123 family, and the whole literal
positive-skew growth-eight orbit remain **OPEN**.
