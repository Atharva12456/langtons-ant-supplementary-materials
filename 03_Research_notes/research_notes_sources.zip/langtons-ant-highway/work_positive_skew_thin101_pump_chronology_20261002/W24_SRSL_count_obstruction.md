# Conditional width 24 obstruction for lower row 8 = SR SL

Whole literal `(1,3)`, growth 8 orbit status: **OPEN**.

The [complete width-24 join](W24_saturated_thin101_exclusion.md) also excludes the other three quiet row-8 words. The count argument in this note covers only the SR SL variant; larger widths remain open.

This note excludes one row-8 variant in the saturated lowerthin101 family
at width 24. It does not exclude the three other quiet row-8 words or any
larger width. Its upper boundary input is the complete necessary weak-clock
domain of 32 upperF123 prefixes with wakes 7,8 and quiet rows 3..6,9,10,
saved in `work_positive_skew_upperF123_wake7_20261001/wake8/stage_10.json`.
The count proof below is independent of the upper frontier implementation;
necessity of that boundary domain is independently checked by
`audit_upper32_source.py`, which freshly regenerated stages 3..10 and
replayed all 2,274 physical certificates and 96 rejected unbounded `+N`
clocks. Its complete report is `upper32_independent_audit.json`; all 32
saved prefixes were covered without importing a frontier implementation.

Use the original lower gauge `t=3x-y`, and turn ports R/L without changing
their order. The upper half-turn sends E to W and N to S, while preserving
R/L and stable order. Write `(Hu,Vu)` for an upper prefix displacement in
its own lower-looking gauge. Its physical contribution is `(-Hu,-Vu)`.

The fixed lower rows 0..7 contribute `(4,-2)`. The four upper count profiles
through upper offset 10 have the following properties. Global rows are
`24-u`, so they occupy rows 14..24.

| upper `(Hu,Vu)` | number of words | W departures at global 14 | E arrivals at global 15 |
|---|---:|---:|---:|
| `(19,-5)` | 12 | 13 | 13 |
| `(15,-5)` | 8 | 9 | 13 |
| `(15,-1)` | 8 | 9 | 9 |
| `(11,-1)` | 4 | 5 | 9 |

Assume row 8 is `SR SL`, and rows 9..13 are quiet, as forced by this
width-24 wake set. Row 9 is `(ER WL)^5`. The complete independent raw
classification of quiet rows 10,11 is saved in
`row10_row11_raw_audit.json`; it uses compass first returns and unbounded
lower clocks `1-N dx`, `N>=1`, with strict stable order. There are two
count cases among its three necessary surviving words:

| case | row 10 `(NR,NL,SR,SL)` | W arrivals at row 11 | H contribution of rows 8..11 |
|---|---|---:|---:|
| A (two words) | `(7,3,3,7)` | 17 | 8 |
| B (one word) | `(4,2,4,6)` | 13 | 4 |

The edge from global 14 to global 11 is a W edge. Thus row-11 W arrivals
must equal global-14 W departures. Case A is impossible, since every
upper profile has at most 13 such departures. Case B forces the first
upper profile, `(Hu,Vu)=(19,-5)`.

The required bridge displacement, on rows 8..13, is consequently

`(1,3) - (4,-2) - (-19,5) = (16,0)`.

For case B the quiet row-12 count vector, with parameter `s`, is

`(NR,NL,SR,SL) = (13-3s, 5-s, s, 8-s)`.

It has `21-4s` E departures. The E edge from row 12 to global row 15
requires this number to equal 13, so `s=2`. Its horizontal contribution
is E departures minus W departures, namely `16-4s=8`. Odd rows 11 and
13 have only vertical departures. Thus the bridge horizontal displacement
is `4+8=12`, contradicting the required 16.

This establishes the conditional obstruction without enumerating row-12
or row-13 words or imposing a period ceiling.

`python -B work_positive_skew_thin101_pump_chronology_20261002/count_W24_domains.py`
rechecks every nonnegative quiet flow vector, all four boundary cut counts,
every directed edge count of the full width-24 strip, and primitive
displacement. It leaves exactly one balanced SRSL count profile, with full
displacement `(-3,-9)`, and rejects it. Counter comparison deliberately
normalizes zero fields: ordinary dictionary equality would incorrectly
discard the case before the displacement check.

The independent all-width raw row-10/11 classification and the exact pump
obstruction remain in `pump_hand_obstruction.md`. The bounded quiet-12
exploration there is still explicitly incomplete. The 16 primitive count
profiles for the other quiet row-8 count vector are only counts, not orbit
witnesses.
