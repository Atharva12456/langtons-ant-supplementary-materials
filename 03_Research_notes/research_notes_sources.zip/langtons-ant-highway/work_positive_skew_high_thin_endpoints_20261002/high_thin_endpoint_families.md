# High lower-thin endpoint families, 2026-10-02

Scope: literal positive-skew drift `(1,3)`, growth eight, and the already
established width condition `W >= 18`. This note classifies endpoint sets
using P22, the positive-skew rank parity, and the signed moment congruence.
It does not assert that an arithmetically admissible endpoint set has a
trajectory. The width parameters below are unbounded.

Later finite results exclude the [width-22 lower011/F123 wake-six member](../work_positive_skew_thin011_W22_join_20261002/finite_W22_exclusion.md) and the [width-24 saturated lower101/F123 member](../work_positive_skew_thin101_pump_chronology_20261002/W24_saturated_thin101_exclusion.md). The table below records arithmetic endpoint conditions, so its minimum widths do not incorporate those later word and clock exclusions. Larger widths in those families remain open.

## 1. Definitions and exact endpoint result

Write `O` for the eight distinct wake levels, with lower extreme `0` and
upper extreme `W`. The three lower thin profiles have fixed wake sets

```
L011 = {0,4,6,7}, L101 = {0,4,5,7}, L110 = {0,4,5,6}.
```

Here `U` denotes the fixed upper inward offsets. For F123 the outer offset
1 is quiet; for F122 offsets 1 and 2 are quiet. In every case considered
below, the four lower and three upper wakes are distinct, so there is
exactly one further level `t`, with

```
O = Lbits union {W-u : u in U} union {t},  8 <= t < W.
```

The table is necessary and sufficient for this endpoint set to satisfy
P22, even positive-skew rank, and moment `1 mod 4`. The intervening upper
quiet offsets listed in section 4 are consequences of the table; they
are not needed as extra arithmetic assumptions.

| Lower | Upper cap and fixed offsets `U` | Width | Residual `t` | Exact parameter conditions | Exact rank | Exact moment | Minimum endpoint width |
|---|---|---|---|---|---:|---|---:|
| 011 | F123 `{0,2,7}` | impossible | — | P22 fails | — | — | — |
| 101 | F123 `{0,2,7}` | `6m` | `6r+4` | `1 <= r <= m-2`, `m+r` even | 10 | `2m+2r+1` | 18 |
| 110 | F123 `{0,2,7}` | `6m` | `6r+3` | `1 <= r <= m-3`, `m-r` odd | 10 | `2m-2r+3` | 24 |
| 011 | F122 `{0,4,6}` | `6m+2` | `6r+4` | `1 <= r <= m-3`, `m-r` odd | 12 | `6m+2r+3` | 26 |
| 101 | F122 `{0,4,6}` | `6m+4` | `6r+5` | `1 <= r <= m-2`, `m-r` even | 12 | `6m-2r-3` | 22 |
| 110 | F122 `{0,4,6}` | impossible | — | Every P22 set has odd rank 13 | — | — | — |
| 011 | F123 `{0,2,6}` | `6m+4` | `6r+2` | `1 <= r <= m-2`, `m+r` even | 14 | `6m+2r+5` | 22 |
| 110 | F122 `{0,4,7}` | `6m+4` | `6r+5` | `1 <= r <= m-3`, `m-r` odd | 10 | `2m-2r+3` | 28 |
| 110 | F122 `{0,3,4}` | `6m+2` | `6r+5` | `1 <= r <= m-2`, `m-r` even | 12 | `2m-2r+1` | 20 |

The minimum widths are arithmetic minima under `W >= 18`, not existence
claims for ant orbits. An endpoint witness at each minimum is recorded in
the JSON regression artifact.

## 2. P22 derivation without a width cutoff

For a wake at level `t`, its fibre is `j=(-t) mod 3`, its longitudinal
coordinate is `n=ceil(t/3)`, and its checker sign is `epsilon=(-1)^t`.
P22 requires the signed sum in each fibre to be `2 mod 4`. With eight
wakes in total, the fibre populations must be `4,2,2`: the four-wake
fibre has a `3+1` sign split, while each two-wake fibre has uniform sign.

For seven fixed wakes, adding the one residual can repair only one
fibre charge. Since `W` is even, its only possible residues modulo six
are `0,2,4`. Computing the seven fixed signs gives this complete finite
residue table. An entry is the only permitted residue of `t`; a dash
means that no residual sign can repair the three P22 charges.

| Lower / upper offsets | `W=0 mod 6` | `W=2 mod 6` | `W=4 mod 6` |
|---|---:|---:|---:|
| 011 / F123 `{0,2,7}` | — | — | — |
| 101 / F123 `{0,2,7}` | 4 | — | — |
| 110 / F123 `{0,2,7}` | 3 | — | — |
| 011 / F122 `{0,4,6}` | — | 4 | — |
| 101 / F122 `{0,4,6}` | — | — | 5 |
| 110 / F122 `{0,4,6}` | — | 2 | — |
| 011 / F123 `{0,2,6}` | — | — | 2 |
| 110 / F122 `{0,4,7}` | — | — | 5 |
| 110 / F122 `{0,3,4}` | — | 5 | — |

For example, lower011 has fixed unsigned fibre populations `(2,0,2)`.
The upper F123 offsets `{0,2,7}` add one wake in each fibre for every
residue of `W`, leaving `(3,1,3)`. Adding one residual leaves two odd
populations. Thus this case fails P22 at every width.

In the remaining P22 cases, the seven fixed sign counts, listed as
`(positive,negative)` in fibres `0,1,2`, are:

| Lower / upper offsets | Fixed sign counts | Residual sign/fibre |
|---|---|---|
| 101 / F123 `{0,2,7}` | `(2,0);(0,2);(2,1)` | positive, fibre 2 |
| 110 / F123 `{0,2,7}` | `(3,0);(0,2);(2,0)` | negative, fibre 0 |
| 011 / F122 `{0,4,6}` | `(2,0);(2,0);(2,1)` | positive, fibre 2 |
| 101 / F122 `{0,4,6}` | `(2,0);(0,1);(3,1)` | negative, fibre 1 |
| 110 / F122 `{0,4,6}` | `(2,0);(2,1);(2,0)` | positive, fibre 1 |
| 011 / F123 `{0,2,6}` | `(2,0);(1,0);(3,1)` | positive, fibre 1 |
| 110 / F122 `{0,4,7}` | `(3,1);(0,1);(2,0)` | negative, fibre 1 |
| 110 / F122 `{0,3,4}` | `(2,0);(1,2);(2,0)` | negative, fibre 1 |

Together with `8 <= t < W`, exclusion of fixed wakes, and the outer cap
quiet cells, this yields the preliminary P22 ranges in the next table.
These calculations depend only on residues, not on an enumeration up to
some maximum width.

## 3. Exact rank and moment

In the original coordinates, the rank is

```
R = sum(n < z for i < j, n in fibre i, z in fibre j).
```

Equivalently, sort the wake levels increasingly, replace each by its
fibre label, and count increasing-fibre pairs. To see why ties cause no
exception, write a level in fibre `i` as `3n-i`. If `i<j` and the
longitudinal coordinates are equal, the fibre-`i` level is the later
one, and the pair does not contribute in either description.

The following table gives the seven-wake fixed rank `R0`, its exact
signed moment `M0`, and the change caused by the residual. The variable
`m` is the one in the width formula above.

| Lower / upper offsets | Preliminary P22 range | `R0` | Residual rank contribution | `M0` | Residual moment |
|---|---|---:|---|---|---|
| 101 / F123 `{0,2,7}` | `1 <= r <= m-2` | 8 | 2 | `2m-1` | `2r+2` |
| 110 / F123 `{0,2,7}` | `1 <= r <= m-1` | 8 | 2 if `r <= m-2`; 1 if `r=m-1` | `2m+4` | `-(2r+1)` |
| 011 / F122 `{0,4,6}` | `1 <= r <= m-2` | 10 | 2 | `6m+1` | `2r+2` |
| 101 / F122 `{0,4,6}` | `1 <= r <= m-1` | 9 | 3 if `r <= m-2`; 2 if `r=m-1` | `6m-1` | `-(2r+2)` |
| 110 / F122 `{0,4,6}` | `1 <= r <= m-2` | 10 | 3 | `6m+2` | `2r+1` |
| 011 / F123 `{0,2,6}` | `1 <= r <= m-1` | 10 | 4 | `6m+4` | `2r+1` |
| 110 / F122 `{0,4,7}` | `1 <= r <= m-1` | 7 | 3 if `r <= m-2`; 4 if `r=m-1` | `2m+5` | `-(2r+2)` |
| 110 / F122 `{0,3,4}` | `1 <= r <= m-2` | 9 | 3 | `2m+3` | `-(2r+2)` |

The boundary placements `r=m-1` in the second, fourth, and seventh rows
have odd rank and are excluded. In the lower110/F122 `{0,4,6}` row,
the fixed fibre word is

```
0,2,1,0,1,2,1.
```

The positive fibre-1 residual lies in the body and contributes three
increasing pairs: two lower fibre-0 wakes before it and one upper
fibre-2 wake after it. Hence its exact total rank is always `10+3=13`.
This proves the second arithmetic exclusion independently of moment.

Adding the displayed moments and imposing `M=1 mod 4` gives exactly the
parities in the endpoint table. In lower011/F123 `{0,2,6}`, this parity
also excludes `r=m-1` even though its rank is even. In rows requiring
`m-r` odd, the allowed bound `r<=m-2` sharpens to `r<=m-3`.

These calculations prove sufficiency as well: every parameter choice in
the endpoint table supplies the required P22 signs, an even exact rank,
and the correct moment. Increasing `m` by two with `r` fixed shifts the
three upper wakes by 12, preserves all three conditions, and exhibits
an unbounded arithmetic ray in each nonempty family. It provides no
trajectory construction.

## 4. Forced upper wake distances

Let `delta=W-t` be the residual's upper inward distance. Its possibilities
are as follows, with `h` a nonnegative integer.

| Lower / upper offsets | Residual distance | Forced quiet offsets beyond the prescribed cap | First optional residual wake |
|---|---|---|---|
| 101 / F123 `{0,2,7}` | `8+12h` | 9,10 | 8 iff `r=m-2` |
| 110 / F123 `{0,2,7}` | `15+12h` | 8 through 14 | 15 iff `r=m-3` |
| 011 / F122 `{0,4,6}` | `16+12h` | 9 through 15 | 16 iff `r=m-3` |
| 101 / F122 `{0,4,6}` | `11+12h` | 9,10 | 11 iff `r=m-2` |
| 011 / F123 `{0,2,6}` | `14+12h` | 8 through 13 | 14 iff `r=m-2` |
| 110 / F122 `{0,4,7}` | `17+12h` | 8 through 16 | 17 iff `r=m-3` |
| 110 / F122 `{0,3,4}` | `9+12h` | 5 through 8 | 9 iff `r=m-2` |

The quiet ranges in the table refer to the whole endpoint set, not only
the residual. They are safe from overlap with the lower fixed wakes at
the stated minimum widths. For deeper offsets one must separately check
whether a lower fixed wake has entered the upper band; the congruence
`delta=base+12h` by itself does not rule that out.

Two splits matter for local continuation probes:

* Lower101/F123 `{0,2,7}` with upper8 quiet has `r<=m-4`, residual
  distance at least 20, and minimum endpoint width 30. Upper8 wake is
  the other exact slice, `r=m-2`.
* Lower110/F122 `{0,3,4}` with upper9 quiet has `r<=m-4`, residual
  distance at least 21, and minimum endpoint width 32. Upper9 wake is
  the other exact slice, `r=m-2`. A probe that assumes quiet offsets 9 through 12
  does not cover the wake9 slice.

The arithmetic also forces lower8 and lower9 quiet except for the two
families with residual `6r+2` or `6r+3`: lower011/F123 `{0,2,6}` has
lower8 wake iff `r=1`, and lower110/F123 `{0,2,7}` has lower9 wake iff
`r=1`.

## 5. Consequence of the independently derived local wake3/4 obstruction

Root's independent weak local derivation in
`../work_positive_skew_upperthin_high110_20261002/audit_wake34_raw.py`
excludes upper F122 with wakes at offsets 3 and 4, and quiet offsets 5 through 8 for both
possible bits at upper9. The reported raw audit has 2,234 candidate row
words, 2,216 physical-return rejections, one clock rejection, and no
surviving row 9 extension; its detailed artifact is
`../work_positive_skew_upperthin_high110_20261002/independent_wake34_raw/result.json`.

Combining that local result with the final endpoint row above excludes
the entire lower110/F122 `{0,3,4}` family. In particular, the fixed
moment is exactly `2m+3`; adding the negative residual gives
`1+2(m-r)`, and every admissible set has rank 12 and quiet upper offsets 5
through 8. The local result covers both upper9 slices, so this conclusion
does not depend on assuming quiet9 or on a width cutoff.

This is a conditional cap/profile exclusion. The literal growth-eight
orbit problem remains open after these endpoint deductions.

## 6. Independent original-coordinate regression

`audit_high_thin_endpoints.py` imports neither the frontier code nor an
older endpoint checker. For every even `W` from 18 through 180 and every
possible residual level for all nine requested profile/bit pairs, it:

1. Computes fibres, checker charges, exact rank, and unreduced moment
   directly from `j=(-t)%3` and `n=ceil(t/3)`.
2. Compares the complete P22 classification, including the forbidden
   boundary placements, with the exact formulas in this note.
3. Compares rank/moment acceptance with the seven unbounded families.
4. Checks the prescribed quiet offsets, the forced quiet ranges in
   section 4, the optional upper8/9 equivalences, arithmetic minimum
   widths, and the 12-level upper translation.

The fresh run checked **64,534 endpoint sets** and returned
`HIGH LOWER-THIN EXACT ENDPOINT AUDIT: PASS`. The full result is
`high_thin_original_coordinate_audit.json`. This finite run is a
regression of the residue/rank/moment derivation, not its justification
at unbounded width and not a trajectory search.
